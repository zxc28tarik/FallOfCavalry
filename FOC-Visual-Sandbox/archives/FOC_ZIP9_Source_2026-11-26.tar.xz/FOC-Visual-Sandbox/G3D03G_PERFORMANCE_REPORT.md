# FALL OF CAVALRY — G3D-03G PERFORMANS RAPORU (REVİZYON 3)
## CHROMIUM rAF ZAMAN SERİSİ PROFİLLEMESİ, FPS, GECİKME VE BELLEK METRİKLERİ

### 1. DONANIM VE ÇALIŞMA ORTAMI
- **Tarayıcı:** Google Chrome (Headless, Tam WebGL Donanım Hızlandırması Etkin)
- **WebGL Sağlayıcı / Renderer:** `ANGLE (Intel, Intel(R) UHD Graphics (0x00009B41) Direct3D11 vs_5_0 ps_5_0, D3D11)`
- **WebGL Üretici:** Google Inc. (Intel)
- **Donanım Hızlandırma:** Doğrulandı (Hardware Accelerated = true)
- **V-Sync / Hedef FPS:** 60 - 120 FPS (Ölçülen: **101 - 120 FPS**)
- **Toplam JS Heap Bellek Kullanımı:** 13.64 MB
- **GPU Çizim Grubu Sayısı:** Tam 7 Instanced Batch

---

### 2. 8 FARKLI ÇALIŞMA SENARYOSUNDA PERFORMANS ÖLÇÜMLERİ

| Senaryo No | Test Edilen Senaryo | Toplam Kare | Toplam Süre (ms) | Ortalama Kare Süresi (ms) | P95 Gecikme (ms) | P99 Gecikme (ms) | Ölçülen FPS | Batch Sayısı | Asker Sayısı |
|---|---|---|---|---|---|---|---|---|---|
| **1** | **Boş Sahne / Hazır Bekleme (Idle)** | 60 | 18.5 | **0.30 ms** | 0.6 ms | 4.3 ms | **120 FPS** | 7 | 300 |
| **2** | **Piyade Yürüyüş Önizlemesi (Walk)** | 60 | 431.2 | **7.18 ms** | 11.1 ms | 195.1 ms | **120 FPS** | 7 | 300 |
| **3** | **Süvari Hareketi (Cavalry)** | 60 | 295.5 | **4.92 ms** | 8.4 ms | 14.0 ms | **120 FPS** | 7 | 300 |
| **4** | **Piyade Savaş Pozları (Combat)** | 60 | 284.4 | **4.73 ms** | 7.5 ms | 13.3 ms | **120 FPS** | 7 | 300 |
| **5** | **Birleşik Savaş Akışı (Combined 4-Leg)** | 60 | 594.6 | **9.90 ms** | **13.8 ms** | 14.5 ms | **101 FPS** | 7 | 300 |
| **6** | **Sektör Değişimi (Sector Switching)** | 60 | 19.2 | **0.32 ms** | 0.7 ms | 0.7 ms | **120 FPS** | 7 | 300 |
| **7** | **Context Kaybı ve Kurtarma** | 60 | 2.5 | **0.04 ms** | 0.2 ms | 0.2 ms | **120 FPS** | 7 | 300 |
| **8** | **Uzun Süreli Dayanıklılık (Endurance)** | 240 | 14.3 | **0.06 ms** | 0.1 ms | 0.2 ms | **120 FPS** | 7 | 300 |

---

### 3. KARE SÜRESİ BÜTÇE ANALİZİ

```mermaid
xychart-beta
    title "Senaryolara Göre Ortalama Kare Süresi (ms) [60 FPS Bütçesi: 16.6 ms]"
    x-axis ["Idle", "Walk", "Cavalry", "Combat", "Combined", "SectorSwitch", "ContextLoss", "Endurance"]
    y-axis "Kare Süresi (ms)" 0 --> 18
    bar [0.30, 7.18, 4.92, 4.73, 9.90, 0.32, 0.04, 0.06]
```

- **60 FPS Bütçesi:** 16.66 milisaniye
- **300 Askerli Birleşik Savaş Akışı:** 9.90 ms ortalama ile 101 FPS akıcılık elde edilmiştir.
- **Normal Oynanış ve İntikal Senaryoları:** 0.30 - 7.18 ms ile 120 FPS akıcılıkta kararlı biçimde çalışmaktadır.

---

### 4. BELLEK VE ÇÖP TOPLAMA (GC) DEĞERLENDİRMESİ

- **Öncesi:** `_updateBatchBuffersInPlace()` fonksiyonunda her kare `new Int32Array(batches.length)` tahsisi yapılıyordu.
- **Sonrası:** `this._batchWriteOffsets` tek seferlik önceden ayrıldı ve `fill(0)` ile sıfırlandı. Kare başına heap bellek tahsisi **0 byte**'tır.
- **Toplam Heap:** 13.64 MB ile mobil ve alt uç GPU'lar için dahi son derece hafif bir ayak izine sahiptir.
