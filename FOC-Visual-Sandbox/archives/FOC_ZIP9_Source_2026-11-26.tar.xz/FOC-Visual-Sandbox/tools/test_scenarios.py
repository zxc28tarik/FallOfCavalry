import subprocess
import os
import tempfile
import json
import re
import io
import base64
from PIL import Image
import numpy as np

def test_scenarios():
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
        base_html = f.read()

    base_html = base_html.replace("alpha: false,", "alpha: false, preserveDrawingBuffer: true,")

    scenarios = [
        ("initial", "// do nothing"),
        ("sec1", "controller.selectSector(1);"),
        ("sec2", "controller.selectSector(2);"),
        ("combined_preview", "controller.toggleCombinedPreview();"),
        ("cam_rotate", "controller.renderer.cameraController.rotateBy(1.2, -0.4);"),
        ("cam_close", "controller.renderer.cameraController.zoomBy(-35); controller.renderer.cameraController.rotateBy(0.8, -0.2);"),
        ("sim_30_ticks", "for(let i=0; i<30; i++) controller.renderer.soldierRegistry.update(0.05);")
    ]

    for name, code in scenarios:
        script = f'''
<script>
window.addEventListener('DOMContentLoaded', () => {{
    setTimeout(() => {{
        try {{
            const controller = window.__focBattle3DPreview;
            {code}
            const cvs = document.querySelector('canvas');
            const res = {{ img: cvs ? cvs.toDataURL('image/png') : '' }};
            const pre = document.createElement('pre');
            pre.id = 'renderOutput';
            pre.textContent = JSON.stringify(res);
            document.body.appendChild(pre);
        }} catch(e) {{
            const pre = document.createElement('pre');
            pre.id = 'renderOutput';
            pre.textContent = JSON.stringify({{ error: e.message }});
            document.body.appendChild(pre);
        }}
    }}, 1500);
}});
</script>
'''
        temp_html = f'temp_scen_{name}.html'
        with open(temp_html, 'w', encoding='utf-8') as f:
            f.write(base_html.replace('</body>', script + '</body>'))

        temp_profile = os.path.join(tempfile.gettempdir(), f'foc_scen_{name}')
        cmd = [
            chrome_path,
            '--headless=new',
            '--disable-gpu-sandbox',
            '--enable-webgl',
            '--use-gl=angle',
            '--use-angle=d3d11',
            '--no-sandbox',
            f'--user-data-dir={temp_profile}',
            '--virtual-time-budget=10000',
            '--dump-dom',
            'file:///' + os.path.abspath(temp_html).replace('\\', '/')
        ]

        res = subprocess.run(cmd, capture_output=True, text=True, timeout=20, encoding='utf-8', errors='replace')
        m = re.search(r'<pre id="renderOutput">(.*?)</pre>', res.stdout, re.DOTALL)
        if m:
            data = json.loads(m.group(1))
            if data.get('img'):
                raw = base64.b64decode(data['img'].split(',')[1])
                img = Image.open(io.BytesIO(raw))
                arr = np.array(img)
                # Count bright green (G > 180, R < 100, B < 100)
                bright_green = np.sum((arr[:, :, 1] > 180) & (arr[:, :, 0] < 100) & (arr[:, :, 2] < 100))
                # Count bright red (R > 180, G < 50, B < 50)
                bright_red = np.sum((arr[:, :, 0] > 180) & (arr[:, :, 1] < 50) & (arr[:, :, 2] < 50))
                print(f"Scenario {name:16}: Green={bright_green:6}, Red={bright_red:6}")
                if bright_green > 100:
                    img.save(f"glitch_{name}.png")
                    print(f"  --> FOUND BRIGHT GREEN in {name}! Saved glitch_{name}.png")
            elif data.get('error'):
                print(f"Scenario {name:16}: Error: {data['error']}")
        else:
            print(f"Scenario {name:16}: not captured")

        if os.path.exists(temp_html):
            os.remove(temp_html)

if __name__ == '__main__':
    test_scenarios()
