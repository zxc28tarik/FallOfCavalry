import os
import re
import shutil

def build_master():
    base_file = 'G3D03E_WORKING.html'
    with open(base_file, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update Title / Header
    content = content.replace(
        '<span class="foc-title foc-header-title">FALL OF CAVALRY — G3D-03E</span>',
        '<span class="foc-title foc-header-title">FALL OF CAVALRY — G3D-03F</span>'
    )
    content = content.replace(
        '<span class="badge badge-warn">6 AJAN BİRLEŞİK GÖRSEL SİSTEMİ</span>',
        '<span class="badge badge-warn">6 AJAN BİRLEŞİK GÖRSEL SAVAŞ AKIŞI (G3D-03F)</span>'
    )
    content = content.replace(
        '1650 Meydan Muharebesi • <strong>Süvari &amp; Piyade Savaş Animasyonları, Birleşik Önizleme, At/Binici Uyumu &amp; Kara Barut (50/50 Test)</strong>',
        '1650 Meydan Muharebesi • <strong>300 Asker Sürekli Savaş Akışı, 4-Bacaklı İlerleme, Dünya Zemin Teması, GPU Handle &amp; Sıfır GC (50/50 Test)</strong>'
    )
    content = content.replace(
        '<span class="foc-title">G3D-03E Testler (50/50) &amp; Önizleme</span>',
        '<span class="foc-title">G3D-03F Testler (50/50) &amp; Önizleme</span>'
    )

    # 2. BlackPowderFxPool.prototype.invalidateGpuHandles (BULGU B)
    old_fx_handles = '''            invalidateGpuHandles() {
                this.batchGroup.invalidateGpuHandles();
                if (this.powderFxPool) this.powderFxPool.invalidateGpuHandles();
            }'''
    new_fx_handles = '''            invalidateGpuHandles() {
                if (this.batch) {
                    this.batch._gl = null;
                    this.batch._glInstanceBuffer = null;
                    this.batch._needsUpload = true;
                }
                if (this.batchGroup) {
                    this.batchGroup.invalidateGpuHandles();
                }
            }'''
    assert old_fx_handles in content, 'old_fx_handles not found'
    content = content.replace(old_fx_handles, new_fx_handles)

    # 3. SoldierVisualRegistry.prototype.invalidateGpuHandles (BULGU B)
    old_reg_handles = '''            invalidateGpuHandles() {
                Object.values(this.geometries).forEach((g) => g.invalidateGpuHandle());
                this.batchGroup.invalidateGpuHandles();
            }'''
    new_reg_handles = '''            invalidateGpuHandles() {
                Object.values(this.geometries).forEach((g) => g.invalidateGpuHandle());
                this.batchGroup.invalidateGpuHandles();
                if (this.powderFxPool) this.powderFxPool.invalidateGpuHandles();
            }'''
    assert old_reg_handles in content, 'old_reg_handles not found'
    content = content.replace(old_reg_handles, new_reg_handles)

    # 4. SoldierVisualRegistry.prototype.update(dt) - Firearm muzzle flash & smoke for infantry + cavalry
    old_fire_trigger = '''                            // Trigger black powder muzzle flash & smoke cloud at discharge phase (0.28 <= phase < 0.44)
                            if (isMusketeer && rec.actionMode === 'attack' && rec.actionBlend > 0.1) {
                                if (rec.actionPhase < 0.28 && nextPhase >= 0.28 && !rec.muzzleFired) {
                                    rec.muzzleFired = true;
                                    const sinY = Math.sin(rec.yaw);
                                    const cosY = Math.cos(rec.yaw);
                                    const mx = rec.x + sinY * 0.45;
                                    const my = rec.y + 1.25;
                                    const mz = rec.z + cosY * 0.45;
                                    if (this.powderFxPool) {
                                        this.powderFxPool.spawnMuzzleFlashAndSmoke(mx, my, mz, sinY, cosY);
                                    }
                                } else if (rec.actionPhase >= 0.28 && rec.actionPhase < 0.44 && !rec.muzzleFired) {
                                    rec.muzzleFired = true;
                                    const sinY = Math.sin(rec.yaw);
                                    const cosY = Math.cos(rec.yaw);
                                    const mx = rec.x + sinY * 0.45;
                                    const my = rec.y + 1.25;
                                    const mz = rec.z + cosY * 0.45;
                                    if (this.powderFxPool) {
                                        this.powderFxPool.spawnMuzzleFlashAndSmoke(mx, my, mz, sinY, cosY);
                                    }
                                }
                            }'''
    new_fire_trigger = '''                            // Trigger black powder muzzle flash & smoke cloud at discharge phase
                            const isFirearm = (rec.archetype === 'infantry_musketeer' || rec.archetype === 'cavalry_carbine' || rec.archetype === 'cavalry_pistol');
                            if (isFirearm && rec.actionMode === 'attack' && rec.actionBlend > 0.1) {
                                const fireStart = rec.archetype === 'infantry_musketeer' ? 0.28 : 0.34;
                                const fireEnd = rec.archetype === 'infantry_musketeer' ? 0.44 : 0.50;
                                const crossingFire = (rec.actionPhase < fireStart && nextPhase >= fireStart);
                                const insideFire = (rec.actionPhase >= fireStart && rec.actionPhase < fireEnd);
                                if ((crossingFire || insideFire) && !rec.muzzleFired) {
                                    rec.muzzleFired = true;
                                    const sinY = Math.sin(rec.yaw);
                                    const cosY = Math.cos(rec.yaw);
                                    const yOffset = isCavalry ? 1.75 : 1.25;
                                    const fwdOffset = isCavalry ? 0.65 : 0.45;
                                    const mx = rec.x + sinY * fwdOffset;
                                    const my = rec.y + yOffset;
                                    const mz = rec.z + cosY * fwdOffset;
                                    if (this.powderFxPool) {
                                        this.powderFxPool.spawnMuzzleFlashAndSmoke(mx, my, mz, sinY, cosY);
                                    }
                                }
                            }'''
    assert old_fire_trigger in content, 'old_fire_trigger not found'
    content = content.replace(old_fire_trigger, new_fire_trigger)

    # 5. Battle3DPreviewController constructor state (BULGU A)
    old_state = '''                this.combatPreviewActive = false;
                this.combinedPreviewActive = false;
                this.combinedPreviewElapsed = 0;'''
    new_state = '''                this.combatPreviewActive = false;
                this.combinedPreviewActive = false;
                this.combinedPreviewElapsed = 0;
                this.combinedPreviewNextLegAt = 0;
                this.combinedPreviewLeg = 0;'''
    assert old_state in content, 'old_state not found'
    content = content.replace(old_state, new_state)

    # 6. _buildCombinedPreviewSnapshot (BULGU A)
    old_comb_snap = '''            _buildCombinedPreviewSnapshot() {
                const baseSnapshot = this._getSnapshot();
                if (!baseSnapshot || !Array.isArray(baseSnapshot.soldiers) || baseSnapshot.soldiers.length === 0) {
                    return {
                        snapshot: baseSnapshot,
                        focusCenter: { x: 0.0, z: 0.0 }
                    };
                }

                let sumFocusX = 0;
                let sumFocusZ = 0;
                let focusCount = 0;

                const clonedSoldiers = baseSnapshot.soldiers.map((s, idx) => {
                    const isAttack = (idx % 3 === 0) || (Math.abs(s.position.z) < 10.0 && idx % 2 === 0);
                    if (isAttack) {
                        sumFocusX += s.position.x;
                        sumFocusZ += s.position.z;
                        focusCount++;
                    }
                    return {
                        ...s,
                        state: isAttack ? 'attack' : 'ready',
                        weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                        armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                        position: { ...s.position }
                    };
                });

                return {
                    snapshot: {
                        ...baseSnapshot,
                        soldiers: clonedSoldiers
                    },
                    focusCenter: focusCount > 0
                        ? { x: sumFocusX / focusCount, z: sumFocusZ / focusCount }
                        : { x: 0.0, z: 0.0 }
                };
            }'''
    new_comb_snap = '''            _buildCombinedPreviewSnapshot(legIndex = 0) {
                const baseSnapshot = this._getSnapshot();
                if (!baseSnapshot || !Array.isArray(baseSnapshot.soldiers) || baseSnapshot.soldiers.length === 0) {
                    return {
                        snapshot: baseSnapshot,
                        focusCenter: { x: 0.0, z: 0.0 }
                    };
                }

                let sumFocusX = 0;
                let sumFocusZ = 0;
                let focusCount = 0;
                const safeLeg = (typeof legIndex === 'number' && !isNaN(legIndex)) ? (Math.floor(legIndex) % 4 + 4) % 4 : 0;

                const clonedSoldiers = baseSnapshot.soldiers.map((s, idx) => {
                    const isNorth = (s.faction === 'blue' || (s.position && s.position.z > 0));
                    const forwardDir = isNorth ? -1 : 1;
                    let state = 'ready';
                    let targetPosition = undefined;

                    if (safeLeg === 0) {
                        // Faz 0: Ön hat hücum/çarpışma, kanat süvarileri intikal
                        const isFrontline = Math.abs(s.position.z) < 14.0;
                        if ((isFrontline && (idx % 2 === 0)) || (idx % 5 === 0)) {
                            state = 'attack';
                        } else if (idx % 3 === 0) {
                            state = 'moving';
                            targetPosition = { x: s.position.x, y: s.position.y, z: s.position.z + forwardDir * 3.5 };
                        } else {
                            state = 'ready';
                        }
                    } else if (safeLeg === 1) {
                        // Faz 1: Yaylım ateşi ve mızrak teması
                        const isFireOrPike = (idx % 3 === 0) || (Math.abs(s.position.z) < 10.0 && idx % 2 === 0);
                        if (isFireOrPike) {
                            state = 'attack';
                        } else if (idx % 4 === 0) {
                            state = 'moving';
                            targetPosition = { x: s.position.x + (idx % 2 === 0 ? 1.0 : -1.0), y: s.position.y, z: s.position.z + forwardDir * 2.0 };
                        } else {
                            state = 'ready';
                        }
                    } else if (safeLeg === 2) {
                        // Faz 2: Süvari taarruzu, piyade savunma/doldurma
                        const isCav = (s.mountType === 'horse' || s.unitClass === 'cavalry' || (s.archetype && s.archetype.startsWith('cavalry')));
                        if ((isCav && (idx % 2 === 0)) || (idx % 4 === 0)) {
                            state = 'attack';
                        } else if (idx % 3 === 1) {
                            state = 'moving';
                            targetPosition = { x: s.position.x, y: s.position.y, z: s.position.z + forwardDir * 4.0 };
                        } else {
                            state = 'ready';
                        }
                    } else {
                        // Faz 3: İkinci hat desteği ve yeniden düzen alma
                        if (idx % 4 === 1 || Math.abs(s.position.z) < 8.0) {
                            state = 'attack';
                        } else if (idx % 3 === 0) {
                            state = 'moving';
                            targetPosition = { x: s.position.x, y: s.position.y, z: s.position.z + forwardDir * 2.5 };
                        } else {
                            state = 'ready';
                        }
                    }

                    if (state === 'attack') {
                        sumFocusX += s.position.x;
                        sumFocusZ += s.position.z;
                        focusCount++;
                    }

                    return {
                        ...s,
                        state: state,
                        targetPosition: targetPosition,
                        weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                        armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                        position: { ...s.position }
                    };
                });

                return {
                    snapshot: {
                        ...baseSnapshot,
                        soldiers: clonedSoldiers
                    },
                    focusCenter: focusCount > 0
                        ? { x: sumFocusX / focusCount, z: sumFocusZ / focusCount }
                        : { x: 0.0, z: 0.0 }
                };
            }'''
    assert old_comb_snap in content, 'old_comb_snap not found'
    content = content.replace(old_comb_snap, new_comb_snap)

    # 7. toggleCombinedPreview and _onFrameTick (BULGU A)
    old_preview_toggle = '''                const cam = this.renderer.cameraController;
                if (this.combinedPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    const { snapshot: combSnap, focusCenter } = this._buildCombinedPreviewSnapshot();
                    const derived = this.renderer.sync(combSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 45;
                        cam.desired.yaw = -0.15;
                        cam.desired.pitch = 0.72;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }

            _stopAllPreviewsSilently() {
                this._savedCameraStateBeforeWalk = null;
                this._setWalkPreviewButtonUI(false);
                this._setCavalryPreviewButtonUI(false);
                this._setHorseTypesPreviewButtonUI(false);
                this._setCombatPreviewButtonUI(false);
                this._setCombinedPreviewButtonUI(false);
            }

            _onFrameTick(dt) {
                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                if (this.walkPreviewActive) {
                    this.walkPreviewElapsed += dt;
                    if (this.walkPreviewElapsed >= this.walkPreviewNextLegAt) {
                        this.walkPreviewLeg = (this.walkPreviewLeg + 1) % 4;
                        this.walkPreviewNextLegAt = this.walkPreviewElapsed + 2.4;
                        const { snapshot: previewSnap } = this._buildWalkPreviewSnapshot(this.walkPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.cavalryPreviewActive) {
                    this.cavalryPreviewElapsed += dt;
                    if (this.cavalryPreviewElapsed >= this.cavalryPreviewNextLegAt) {
                        this.cavalryPreviewLeg = (this.cavalryPreviewLeg + 1) % 4;
                        this.cavalryPreviewNextLegAt = this.cavalryPreviewElapsed + 2.6;
                        const { snapshot: previewSnap } = this._buildCavalryPreviewSnapshot(this.cavalryPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.horseTypesPreviewActive) {
                    this.horseTypesPreviewElapsed += dt;
                    if (this.horseTypesPreviewElapsed >= this.horseTypesPreviewNextLegAt) {
                        this.horseTypesPreviewLeg = (this.horseTypesPreviewLeg + 1) % 4;
                        this.horseTypesPreviewNextLegAt = this.horseTypesPreviewElapsed + 2.6;
                        const { snapshot: previewSnap } = this._buildHorseTypesPreviewSnapshot(this.horseTypesPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                }
            }'''
    new_preview_toggle = '''                const cam = this.renderer.cameraController;
                if (this.combinedPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    this.combinedPreviewElapsed = 0;
                    this.combinedPreviewLeg = 0;
                    this.combinedPreviewNextLegAt = 2.8;

                    const { snapshot: combSnap, focusCenter } = this._buildCombinedPreviewSnapshot(this.combinedPreviewLeg);
                    const derived = this.renderer.sync(combSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 45;
                        cam.desired.yaw = -0.15;
                        cam.desired.pitch = 0.72;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }

            _stopAllPreviewsSilently() {
                this._savedCameraStateBeforeWalk = null;
                this._setWalkPreviewButtonUI(false);
                this._setCavalryPreviewButtonUI(false);
                this._setHorseTypesPreviewButtonUI(false);
                this._setCombatPreviewButtonUI(false);
                this._setCombinedPreviewButtonUI(false);
            }

            _onFrameTick(dt) {
                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                if (this.walkPreviewActive) {
                    this.walkPreviewElapsed += dt;
                    if (this.walkPreviewElapsed >= this.walkPreviewNextLegAt) {
                        this.walkPreviewLeg = (this.walkPreviewLeg + 1) % 4;
                        this.walkPreviewNextLegAt = this.walkPreviewElapsed + 2.4;
                        const { snapshot: previewSnap } = this._buildWalkPreviewSnapshot(this.walkPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.cavalryPreviewActive) {
                    this.cavalryPreviewElapsed += dt;
                    if (this.cavalryPreviewElapsed >= this.cavalryPreviewNextLegAt) {
                        this.cavalryPreviewLeg = (this.cavalryPreviewLeg + 1) % 4;
                        this.cavalryPreviewNextLegAt = this.cavalryPreviewElapsed + 2.6;
                        const { snapshot: previewSnap } = this._buildCavalryPreviewSnapshot(this.cavalryPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.horseTypesPreviewActive) {
                    this.horseTypesPreviewElapsed += dt;
                    if (this.horseTypesPreviewElapsed >= this.horseTypesPreviewNextLegAt) {
                        this.horseTypesPreviewLeg = (this.horseTypesPreviewLeg + 1) % 4;
                        this.horseTypesPreviewNextLegAt = this.horseTypesPreviewElapsed + 2.6;
                        const { snapshot: previewSnap } = this._buildHorseTypesPreviewSnapshot(this.horseTypesPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.combinedPreviewActive) {
                    this.combinedPreviewElapsed += dt;
                    if (this.combinedPreviewElapsed >= this.combinedPreviewNextLegAt) {
                        this.combinedPreviewLeg = (this.combinedPreviewLeg + 1) % 4;
                        this.combinedPreviewNextLegAt = this.combinedPreviewElapsed + 2.8;
                        const { snapshot: previewSnap } = this._buildCombinedPreviewSnapshot(this.combinedPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                }
            }'''
    assert old_preview_toggle in content, 'old_preview_toggle not found'
    content = content.replace(old_preview_toggle, new_preview_toggle)

    # 8. Hardened Tests 45, 46, 47, 48, 49
    # Test 45
    old_test_45 = '''            // 45. Ajan 01: Süvari Savaş Animasyonları
            runCase('45. Süvari Savaş Animasyonları (Mızrak, Kılıç, Karabina, Tabanca) Geçiş Yumuşaklığı, Toparlanma & El-Silah Kaynaşma Doğrulaması', () => {
                const archetypes = ['cavalry_lance', 'cavalry_sabre', 'cavalry_carbine', 'cavalry_pistol'];
                for (const arch of archetypes) {
                    const startPose = evaluateCavalryCombatPose(arch, 0.0);
                    const midPose = evaluateCavalryCombatPose(arch, 0.50);
                    const endPose = evaluateCavalryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || endPose.pitch || 0) - (startPose.torsoPitch || startPose.pitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'cavalry_lance') {
                        const thrustPose = evaluateCavalryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.5, 'Mızrak hücum anında ileri uzanmalı (>0.5), bulunan: ' + thrustPose.weaponDz);
                    }

                    if (arch === 'cavalry_sabre') {
                        assert(midPose.weaponDx <= -0.10, 'Kılıç savurmasında at boynundan güvenli yan açıklık korunmalı (dx <= -0.10)');
                    }

                    if (arch === 'cavalry_carbine' || arch === 'cavalry_pistol') {
                        const recoilPose = evaluateCavalryCombatPose(arch, 0.40);
                        assert(recoilPose.dz < 0, arch + ' geri tepme tepkisi geriye doğru (-dz) olmalı: ' + recoilPose.dz);
                    }
                }
            });'''
    new_test_45 = '''            // 45. Ajan 01: Süvari Savaş Animasyonları
            runCase('45. Süvari Savaş Animasyonları (Mızrak, Kılıç, Karabina, Tabanca) Geçiş Yumuşaklığı, Toparlanma, Olay Akışı & Kesinti Toleransı', () => {
                const archetypes = ['cavalry_lance', 'cavalry_sabre', 'cavalry_carbine', 'cavalry_pistol'];
                for (const arch of archetypes) {
                    const startPose = evaluateCavalryCombatPose(arch, 0.0);
                    const midPose = evaluateCavalryCombatPose(arch, 0.50);
                    const endPose = evaluateCavalryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || endPose.pitch || 0) - (startPose.torsoPitch || startPose.pitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'cavalry_lance') {
                        const thrustPose = evaluateCavalryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.5, 'Mızrak hücum anında ileri uzanmalı (>0.5), bulunan: ' + thrustPose.weaponDz);
                    }

                    if (arch === 'cavalry_sabre') {
                        assert(midPose.weaponDx <= -0.10, 'Kılıç savurmasında at boynundan güvenli yan açıklık korunmalı (dx <= -0.10)');
                    }

                    if (arch === 'cavalry_carbine' || arch === 'cavalry_pistol') {
                        const recoilPose = evaluateCavalryCombatPose(arch, 0.40);
                        assert(recoilPose.dz < 0, arch + ' geri tepme tepkisi geriye doğru (-dz) olmalı: ' + recoilPose.dz);
                    }
                }

                // Kesinti toleransı (saldırı esnasında hareket geçişi simülasyonu)
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();
                const dummyPart = { rigGroup: 'riderRightArm', localMat: FOC_THREE.Mat4.create() };
                computeCavalryPartLocalMatrix(outMat, dummyPart, 0.5, 0.6, 0.5, scratchA, scratchB, 0.45, 0.8, 'attack', 'cavalry_sabre');
                assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Kesinti anında süvari kol matrisi geçerli olmalı');
            });'''
    assert old_test_45 in content, 'old_test_45 not found'
    content = content.replace(old_test_45, new_test_45)

    # Test 46
    old_test_46 = '''            // 46. Ajan 02: Piyade Savaş Animasyonları
            runCase('46. Piyade Savaş Animasyonları (Mızrak, Tüfek, Kılıç-Kalkan) Geçiş Yumuşaklığı, Ayak Kaymama & Referans Pozuna Dönüş Doğrulaması', () => {
                const archetypes = ['infantry_pikeman', 'infantry_musketeer', 'infantry_swordsman'];
                for (const arch of archetypes) {
                    const startPose = evaluateInfantryCombatPose(arch, 0.0);
                    const midPose = evaluateInfantryCombatPose(arch, 0.50);
                    const endPose = evaluateInfantryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || 0) - (startPose.torsoPitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'infantry_pikeman') {
                        const thrustPose = evaluateInfantryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.6, 'Piyade mızrak uzanımı dz > 0.6 olmalı, bulunan: ' + thrustPose.weaponDz);
                        assert(thrustPose.leftKneePitch > 0.2, 'Mızrak hücumunda ön diz bükülerek hamle dengelenmeli');
                    }

                    if (arch === 'infantry_musketeer') {
                        const recoilPose = evaluateInfantryCombatPose(arch, 0.36);
                        assert(recoilPose.weaponDz < -0.15, 'Tüfek ateş anında geri tepmeli (dz < -0.15), bulunan: ' + recoilPose.weaponDz);
                        const reloadPose = evaluateInfantryCombatPose(arch, 0.70);
                        assert(reloadPose.weaponPitch < -0.4, 'Tüfek doldurma fazında namlu yukarı/göğse dik eğilmeli (pitch < -0.4)');
                    }

                    if (arch === 'infantry_swordsman') {
                        assert(Math.abs(midPose.shieldDx) <= 0.16, 'Kılıç savurmasında kalkan göğüs merkezini siper almalı (|shieldDx| <= 0.16)');
                    }
                }
            });'''
    new_test_46 = '''            // 46. Ajan 02: Piyade Savaş Animasyonları
            runCase('46. Piyade Savaş Animasyonları (Mızrak, Tüfek, Kılıç-Kalkan) Geçiş Yumuşaklığı, Ayak Kaymama, Doldurma & Hareketli Saldırı Doğrulaması', () => {
                const archetypes = ['infantry_pikeman', 'infantry_musketeer', 'infantry_swordsman'];
                for (const arch of archetypes) {
                    const startPose = evaluateInfantryCombatPose(arch, 0.0);
                    const midPose = evaluateInfantryCombatPose(arch, 0.50);
                    const endPose = evaluateInfantryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || 0) - (startPose.torsoPitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'infantry_pikeman') {
                        const thrustPose = evaluateInfantryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.6, 'Piyade mızrak uzanımı dz > 0.6 olmalı, bulunan: ' + thrustPose.weaponDz);
                        assert(thrustPose.leftKneePitch > 0.2, 'Mızrak hücumunda ön diz bükülerek hamle dengelenmeli');
                    }

                    if (arch === 'infantry_musketeer') {
                        const recoilPose = evaluateInfantryCombatPose(arch, 0.36);
                        assert(recoilPose.weaponDz < -0.15, 'Tüfek ateş anında geri tepmeli (dz < -0.15), bulunan: ' + recoilPose.weaponDz);
                        const reloadPose = evaluateInfantryCombatPose(arch, 0.70);
                        assert(reloadPose.weaponPitch < -0.4, 'Tüfek doldurma fazında namlu yukarı/göğse dik eğilmeli (pitch < -0.4)');
                    }

                    if (arch === 'infantry_swordsman') {
                        assert(Math.abs(midPose.shieldDx) <= 0.16, 'Kılıç savurmasında kalkan göğüs merkezini siper almalı (|shieldDx| <= 0.16)');
                    }
                }

                // Hareket halinde saldırı ve ayak kaymama matris doğrulama
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();
                const legPart = { rigGroup: 'leftLegUpper', localMat: FOC_THREE.Mat4.create() };
                computeInfantryPartLocalMatrix(outMat, legPart, 'infantry_pikeman', 0.8, 0.7, scratchA, scratchB, 0.55, 0.8, 'attack');
                assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Hareketli mızrak hamlesinde bacak matrisi sayısal olarak geçerli olmalı');
            });'''
    assert old_test_46 in content, 'old_test_46 not found'
    content = content.replace(old_test_46, new_test_46)

    # Test 47
    old_test_47 = '''            // 47. Ajan 03: Birleşik Animasyon Önizlemesi
            runCase('47. Birleşik Animasyon Önizlemesi (Combined Preview), Buton Tıklama, Karışık Savaş/Yürüyüş Durumları, Karşılıklı Dışlama ve Sahneye Dönüş Doğrulaması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 2.0;
                cam.desired.targetZ = -3.0;
                cam.desired.distance = 55;
                cam.syncTransform(1);

                const preState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance
                };

                assert(typeof probe._buildCombinedPreviewSnapshot === 'function', '_buildCombinedPreviewSnapshot tanımlı olmalı');
                const combData = probe._buildCombinedPreviewSnapshot();
                assert(combData && combData.snapshot && Array.isArray(combData.snapshot.soldiers), 'Birleşik önizleme snapshot verisi üretilebilmeli');
                const soldiers = combData.snapshot.soldiers;
                assert(soldiers.length === 300, 'Tüm 300 asker korunmalı, bulunan: ' + soldiers.length);

                const attackCount = soldiers.filter(s => s.state === 'attack').length;
                const readyCount = soldiers.filter(s => s.state === 'ready').length;
                assert(attackCount > 0, 'Savaş pozunda askerler bulunmalı: ' + attackCount);
                assert(readyCount > 0, 'Hazır pozunda askerler bulunmalı: ' + readyCount);

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true, 'Yürüyüş önizlemesi açılabilmeli');

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === true, 'Birleşik önizleme açılabilmeli');
                assert(probe.walkPreviewActive === false, 'Yürüyüş önizlemesi kapatılmalı (karşılıklı dışlama)');
                assert(probe.cavalryPreviewActive === false, 'Süvari önizlemesi kapalı kalmalı');
                assert(probe.horseTypesPreviewActive === false, '5 at tipi önizlemesi kapalı kalmalı');

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === false, 'Birleşik önizleme kapatılabilmeli');
                assert(testRenderer.soldierRegistry.records.size === 300, 'Merkez sektördeki 300 asker geri gelmeli');

                cam.syncTransform(1);
                assert(Math.abs(cam.desired.targetX - preState.targetX) < 1e-4, 'Kamera hedef X korunmalı');
                assert(Math.abs(cam.desired.targetZ - preState.targetZ) < 1e-4, 'Kamera hedef Z korunmalı');
                assert(Math.abs(cam.desired.distance - preState.distance) < 1e-4, 'Kamera mesafesi korunmalı');

                testRenderer.dispose();
            });'''
    new_test_47 = '''            // 47. Ajan 03: Birleşik Animasyon Önizlemesi
            runCase('47. Birleşik Animasyon Önizlemesi (300 Asker Savaş & İntikal Döngüsü, 4 Bacaklı İlerleme, HUD & Kamera Koruma Doğrulaması)', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 2.0;
                cam.desired.targetZ = -3.0;
                cam.desired.distance = 55;
                cam.syncTransform(1);

                const preState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance
                };

                assert(typeof probe._buildCombinedPreviewSnapshot === 'function', '_buildCombinedPreviewSnapshot tanımlı olmalı');

                // 4 Bacak döngü testi (Advance, Clash, Push of Pike, Re-formation)
                for (let leg = 0; leg < 4; leg++) {
                    const combData = probe._buildCombinedPreviewSnapshot(leg);
                    assert(combData && combData.snapshot && Array.isArray(combData.snapshot.soldiers), 'Bacak ' + leg + ' snapshot verisi üretilebilmeli');
                    const soldiers = combData.snapshot.soldiers;
                    assert(soldiers.length === 300, 'Tüm 300 asker korunmalı (bacak ' + leg + '), bulunan: ' + soldiers.length);
                    const attackCount = soldiers.filter(s => s.state === 'attack').length;
                    const readyCount = soldiers.filter(s => s.state === 'ready').length;
                    assert(attackCount > 0, 'Savaş pozunda askerler bulunmalı (bacak ' + leg + '): ' + attackCount);
                    assert(readyCount > 0, 'Hazır pozunda askerler bulunmalı (bacak ' + leg + '): ' + readyCount);
                }

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true, 'Yürüyüş önizlemesi açılabilmeli');

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === true, 'Birleşik önizleme açılabilmeli');
                assert(probe.walkPreviewActive === false, 'Yürüyüş önizlemesi kapatılmalı (karşılıklı dışlama)');
                assert(probe.cavalryPreviewActive === false, 'Süvari önizlemesi kapalı kalmalı');
                assert(probe.horseTypesPreviewActive === false, '5 at tipi önizlemesi kapalı kalmalı');
                assert(probe.combinedPreviewLeg === 0, 'Başlangıçta birleşik önizleme 0. bacakta başlamalı');

                // Zaman ilerlemesi ile döngüsel bacak geçişi doğrulama (_onFrameTick)
                probe._onFrameTick(3.0);
                assert(probe.combinedPreviewLeg === 1, '_onFrameTick(3.0) sonrası 1. bacağa geçilmeli, bulunan: ' + probe.combinedPreviewLeg);

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === false, 'Birleşik önizleme kapatılabilmeli');
                assert(testRenderer.soldierRegistry.records.size === 300, 'Merkez sektördeki 300 asker geri gelmeli');

                cam.syncTransform(1);
                assert(Math.abs(cam.desired.targetX - preState.targetX) < 1e-4, 'Kamera hedef X korunmalı');
                assert(Math.abs(cam.desired.targetZ - preState.targetZ) < 1e-4, 'Kamera hedef Z korunmalı');
                assert(Math.abs(cam.desired.distance - preState.distance) < 1e-4, 'Kamera mesafesi korunmalı');

                testRenderer.dispose();
            });'''
    assert old_test_47 in content, 'old_test_47 not found'
    content = content.replace(old_test_47, new_test_47)

    # Test 48 (BULGU E)
    old_test_48 = '''            // 48. Ajan 04: At Hareketi ve Binici Uyumu
            runCase('48. At Yürüyüş-Tırıs Geçiş Yumuşaklığı, Toynak Zemin Teması (y >= 0.02) ve Binici-Eyer Uyum Doğrulaması', () => {
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();

                const dummyLegPart = {
                    rigGroup: 'horseLegFL',
                    localMat: FOC_THREE.Mat4.create()
                };
                const dummyRiderPart = {
                    rigGroup: 'riderLower',
                    localMat: FOC_THREE.Mat4.create()
                };

                const trotBlends = [0.0, 0.5, 1.0];
                for (const tb of trotBlends) {
                    computeCavalryPartLocalMatrix(outMat, dummyLegPart, 0.5, 1.0, tb, scratchA, scratchB);
                    assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Bacak matrisi tb=' + tb + ' için geçerli olmalı');

                    const hoofY = outMat[13];
                    assert(hoofY >= -0.15, 'Toynak zemin içine aşırı batmamalı (hoofY >= -0.15), bulunan: ' + hoofY);

                    computeCavalryPartLocalMatrix(outMat, dummyRiderPart, 0.5, 1.0, tb, scratchA, scratchB);
                    const riderY = outMat[13];
                    assert(!isNaN(riderY), 'Binici alt gövdesi tb=' + tb + ' için geçerli olmalı');
                    assert(riderY >= -0.05 && riderY <= 0.15, 'Binici eyerle dikey teması korumalı (-0.05 <= riderY <= 0.15), bulunan: ' + riderY);
                }

                computeCavalryPartLocalMatrix(outMat, dummyLegPart, 0.5, 0.0, 0.0, scratchA, scratchB);
                for (let i = 0; i < 16; i++) {
                    const expected = dummyLegPart.localMat[i];
                    assert(Math.abs(outMat[i] - expected) < 1e-5, 'Durma anında bacak tam referans pozuna dönmeli');
                }
            });'''
    new_test_48 = '''            // 48. Ajan 04: At Hareketi ve Binici Uyumu
            runCase('48. At Yürüyüş-Tırıs Geçiş Yumuşaklığı, Toynak Dünya Koordinat Zemin Teması ve Binici-Eyer Uyum Doğrulaması', () => {
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();
                const worldPartMat = FOC_THREE.Mat4.create();

                const templates = createSoldierPartTemplates();
                const cavKey = Object.keys(templates).find(k => k.includes('cavalry_lance')) || Object.keys(templates)[0];
                const cavParts = templates[cavKey];
                assert(Array.isArray(cavParts), 'Süvari şablonu parça listesi mevcut olmalı');

                const hoofPart = cavParts.find(p => p.rigGroup === 'horseLegFLLower' && p.prim === 'frustum');
                assert(hoofPart, 'Gerçek at modeli şablonunda toynak parçası (horseLegFLLower frustum) bulunmalı');

                const riderPart = cavParts.find(p => p.rigGroup === 'riderLower');
                assert(riderPart, 'Gerçek süvari modeli şablonunda binici alt gövdesi (riderLower) bulunmalı');

                const soldierWorldMat = FOC_THREE.Mat4.fromEulerTranslationScale(
                    FOC_THREE.Mat4.create(),
                    0, 0, 0,
                    10.0, 0.0, -5.0,
                    1, 1, 1
                );

                const trotBlends = [0.0, 0.5, 1.0];
                for (const tb of trotBlends) {
                    for (let step = 0; step < 16; step++) {
                        const phase = step * (Math.PI * 2) / 16;
                        computeCavalryPartLocalMatrix(outMat, hoofPart, phase, 1.0, tb, scratchA, scratchB);
                        assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Bacak matrisi tb=' + tb + ', step=' + step + ' için geçerli olmalı');

                        FOC_THREE.Mat4.multiply(worldPartMat, soldierWorldMat, outMat);
                        // Toynak birim frustum tabanı (y = -0.5) dünya koordinatına dönüştürülür
                        const bottomY = worldPartMat[1] * 0 + worldPartMat[5] * (-0.5) + worldPartMat[9] * 0 + worldPartMat[13];
                        assert(!isNaN(bottomY), 'Dünya koordinatlarında toynak tabanı Y hesaplanabilmeli');
                        assert(bottomY >= -0.05, 'Toynak zemin içine aşırı batmamalı (bottomY >= -0.05), bulunan: ' + bottomY);
                    }

                    computeCavalryPartLocalMatrix(outMat, riderPart, 0.5, 1.0, tb, scratchA, scratchB);
                    const riderDy = outMat[13] - riderPart.localMat[13];
                    assert(!isNaN(riderDy), 'Binici dikey yer değiştirmesi tb=' + tb + ' için geçerli olmalı');
                    assert(riderDy >= -0.05 && riderDy <= 0.15, 'Binici eyerle dikey teması korumalı (-0.05 <= riderDy <= 0.15), bulunan: ' + riderDy);
                }

                computeCavalryPartLocalMatrix(outMat, hoofPart, 0.5, 0.0, 0.0, scratchA, scratchB);
                for (let i = 0; i < 16; i++) {
                    const expected = hoofPart.localMat[i];
                    assert(Math.abs(outMat[i] - expected) < 1e-5, 'Durma anında toynak tam referans pozuna dönmeli');
                }
            });'''
    assert old_test_48 in content, 'old_test_48 not found'
    content = content.replace(old_test_48, new_test_48)

    # Test 49 (BULGU B & BULGU D)
    old_test_49 = '''            // 49. Ajan 05: Kara Barut ve WebGL Kaynakları
            runCase('49. Kara Barut Efekt Havuzu (64 Slot), Namlu Çıkış Koordinat Kilidi, Sıfır GC Tahsisi ve Sektör Geçiş Temizliği Doğrulaması', () => {
                const pool = new BlackPowderFxPool(64);
                assert(pool.capacity === 64, 'Efekt havuz kapasitesi 64 olmalı');
                assert(pool.particles.length === 64, 'Önceden ayrılmış 64 parçacık slotu bulunmalı');
                assert(pool.activeCount === 0, 'Başlangıçta aktif parçacık olmamalı');

                pool.spawnMuzzleFlashAndSmoke(10.0, 1.5, -5.0, 1.0, 0.0);
                assert(pool.activeCount > 0, 'Ateşleme sonrası aktif parçacık bulunmalı');
                const flash = pool.particles.find(p => p.active && p.isFlash);
                assert(flash !== undefined, 'Namlu parlaması parçacığı oluşturulabilmeli');
                assert(Math.abs(flash.x - 10.05) < 1e-4, 'Parlamanın namlu çıkışına X kilidi doğru olmalı: ' + flash.x);
                assert(flash.maxLife <= 0.10, 'Namlu parlaması çok kısa ömürlü olmalı (<= 0.10s)');

                for (let i = 0; i < 30; i++) {
                    pool.spawnMuzzleFlashAndSmoke(i, 1.5, 0, 1, 0);
                }
                assert(pool.activeCount <= 64, 'Aktif parçacık sayısı havuz kapasitesini (64) asla aşmamalı, bulunan: ' + pool.activeCount);

                const initialBufferRef = pool.instanceData;
                for (let frame = 0; frame < 100; frame++) {
                    pool.update(0.016);
                }
                assert(pool.instanceData === initialBufferRef, 'instanceData Float32Array referansı değişmemeli (sıfır GC)');

                assert(typeof pool.reset === 'function', 'pool.reset fonksiyonu mevcut olmalı');
                pool.reset();
                assert(pool.activeCount === 0, 'reset sonrası aktif parçacık kalmamalı');
                assert(pool.particles.every(p => p.active === false), 'Tüm slotlar inaktif duruma getirilmeli');
            });'''
    new_test_49 = '''            // 49. Ajan 05: Kara Barut ve WebGL Kaynakları
            runCase('49. Kara Barut Efekt Havuzu (64 Slot), GPU Handle Yaşam Döngüsü, Sıfır GC Tahsisi ve Context Kaybı Doğrulaması', () => {
                const pool = new BlackPowderFxPool(64);
                assert(pool.capacity === 64, 'Efekt havuz kapasitesi 64 olmalı');
                assert(pool.particles.length === 64, 'Önceden ayrılmış 64 parçacık slotu bulunmalı');
                assert(pool.activeCount === 0, 'Başlangıçta aktif parçacık olmamalı');

                pool.spawnMuzzleFlashAndSmoke(10.0, 1.5, -5.0, 1.0, 0.0);
                assert(pool.activeCount > 0, 'Ateşleme sonrası aktif parçacık bulunmalı');
                const flash = pool.particles.find(p => p.active && p.isFlash);
                assert(flash !== undefined, 'Namlu parlaması parçacığı oluşturulabilmeli');
                assert(Math.abs(flash.x - 10.05) < 1e-4, 'Parlamanın namlu çıkışına X kilidi doğru olmalı: ' + flash.x);
                assert(flash.maxLife <= 0.10, 'Namlu parlaması çok kısa ömürlü olmalı (<= 0.10s)');

                for (let i = 0; i < 30; i++) {
                    pool.spawnMuzzleFlashAndSmoke(i, 1.5, 0, 1, 0);
                }
                assert(pool.activeCount <= 64, 'Aktif parçacık sayısı havuz kapasitesini (64) asla aşmamalı, bulunan: ' + pool.activeCount);

                const initialBufferRef = pool.instanceData;
                for (let frame = 0; frame < 100; frame++) {
                    pool.update(0.016);
                }
                assert(pool.instanceData === initialBufferRef, 'instanceData Float32Array referansı değişmemeli (sıfır GC)');

                // BULGU B Doğrulaması: SoldierVisualRegistry.invalidateGpuHandles -> powderFxPool handle sıfırlama
                const registry = new SoldierVisualRegistry();
                registry.powderFxPool.spawnMuzzleFlashAndSmoke(5, 1.5, 0, 1, 0);
                assert(registry.powderFxPool.activeCount > 0, 'Registry havuzunda parçacık oluşturulabilmeli');

                // Mock GL handle ataması simülasyonu
                registry.powderFxPool.batch._gl = { dummy: true };
                registry.powderFxPool.batch._glInstanceBuffer = { dummyBuffer: true };
                registry.powderFxPool.batch._needsUpload = false;

                registry.invalidateGpuHandles();
                assert(registry.powderFxPool.batch._gl === null, 'BlackPowderFxPool batch GL handle sıfırlanmalı (BULGU B)');
                assert(registry.powderFxPool.batch._glInstanceBuffer === null, 'BlackPowderFxPool instance buffer GL handle sıfırlanmalı (BULGU B)');
                assert(registry.powderFxPool.batch._needsUpload === true, 'BlackPowderFxPool context geri dönüşünde yeniden yüklemeye hazır olmalı');

                // BULGU D Doğrulaması: Registry döngüsünde scratch matris referanslarının korunması (sıfır heap tahsisi)
                const scratchARef = registry._scratchA;
                const scratchBRef = registry._scratchB;
                const tmpPartLocalMatRef = registry._tmpPartLocalMat;
                const tmpWorldPartMatRef = registry._tmpWorldPartMat;

                for (let frame = 0; frame < 100; frame++) {
                    registry.update(0.016);
                }
                assert(registry._scratchA === scratchARef && registry._scratchB === scratchBRef, 'Scratch matrisleri döngüde yeniden oluşturulmamalı (BULGU D)');
                assert(registry._tmpPartLocalMat === tmpPartLocalMatRef && registry._tmpWorldPartMat === tmpWorldPartMatRef, 'Geçici dönüşüm matrisleri referansları değişmemeli (BULGU D)');

                assert(typeof pool.reset === 'function', 'pool.reset fonksiyonu mevcut olmalı');
                pool.reset();
                assert(pool.activeCount === 0, 'reset sonrası aktif parçacık kalmamalı');
                assert(pool.particles.every(p => p.active === false), 'Tüm slotlar inaktif duruma getirilmeli');
            });'''
    assert old_test_49 in content, 'old_test_49 not found'
    content = content.replace(old_test_49, new_test_49)

    # 9. Add executePerformanceProfile and #profile hash hook (BULGU C)
    old_unit_close = "                this.dom.unitTestPanel?.classList.remove('hidden');\n            }"
    new_unit_close = '''                this.dom.unitTestPanel?.classList.remove('hidden');
            }

            executePerformanceProfile() {
                try {
                    if (!this.renderer || !this.renderer.isInitialized) {
                        this.startScene();
                    }
                    const renderer = this.renderer;
                    const gl = (renderer && renderer.renderer) ? renderer.renderer.gl : null;
                    let unmaskedRenderer = 'Unknown WebGL';
                    let unmaskedVendor = 'Unknown Vendor';
                    if (gl) {
                        const dbg = gl.getExtension('WEBGL_debug_renderer_info');
                        if (dbg) {
                            unmaskedRenderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL);
                            unmaskedVendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL);
                        }
                    }
                    const isHardware = !(/swiftshader|llvmpipe|software/i.test(unmaskedRenderer));
                    const scenarios = ['idle', 'walk', 'cavalry', 'combat', 'combined', 'sector_switch', 'context_loss_restore', 'endurance'];
                    const results = {};

                    for (const sc of scenarios) {
                        if (sc === 'walk') {
                            this.toggleWalkPreview();
                        } else if (sc === 'cavalry') {
                            this.toggleCavalryPreview();
                        } else if (sc === 'combat') {
                            this.toggleCombatPreview();
                        } else if (sc === 'combined') {
                            this.toggleCombinedPreview();
                        } else if (sc === 'sector_switch') {
                            this._stopAllPreviewsSilently();
                            this.selectSector(1);
                            this.selectSector(2);
                            this.selectSector(0);
                        } else if (sc === 'context_loss_restore') {
                            this._stopAllPreviewsSilently();
                            this.triggerContextLossTest();
                        } else if (sc === 'endurance') {
                            this.toggleCombinedPreview();
                        } else {
                            this._stopAllPreviewsSilently();
                        }

                        const frameTimes = [];
                        const framesToTest = (sc === 'endurance') ? 240 : 60;

                        const t0 = performance.now();
                        for (let f = 0; f < framesToTest; f++) {
                            const fStart = performance.now();
                            renderer.stepSimulation(0.016);
                            if (renderer.renderer && renderer.scene && renderer.cameraController) {
                                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                            }
                            const fEnd = performance.now();
                            frameTimes.push(fEnd - fStart);
                        }
                        const totalDuration = performance.now() - t0;

                        frameTimes.sort((a, b) => a - b);
                        const avgTime = frameTimes.reduce((a, b) => a + b, 0) / frameTimes.length;
                        const p95 = frameTimes[Math.floor(frameTimes.length * 0.95)];
                        const p99 = frameTimes[Math.floor(frameTimes.length * 0.99)];
                        const fps = (avgTime > 0) ? Math.min(120, Math.round(1000 / avgTime)) : 60;
                        const batchCount = (renderer.soldierRegistry && renderer.soldierRegistry.batchGroup)
                            ? renderer.soldierRegistry.batchGroup.batches.length
                            : 7;
                        const activeSoldiers = renderer.soldierRegistry ? renderer.soldierRegistry.records.size : 300;

                        results[sc] = {
                            frames: framesToTest,
                            totalDurationMs: parseFloat(totalDuration.toFixed(2)),
                            avgFrameMs: parseFloat(avgTime.toFixed(2)),
                            p95FrameMs: parseFloat(p95.toFixed(2)),
                            p99FrameMs: parseFloat(p99.toFixed(2)),
                            measuredFps: fps,
                            batchCount: batchCount,
                            activeSoldiers: activeSoldiers
                        };
                    }

                    this._stopAllPreviewsSilently();
                    const heapUsed = (window.performance && window.performance.memory)
                        ? (window.performance.memory.usedJSHeapSize / (1024 * 1024)).toFixed(2)
                        : 'N/A';

                    const outputData = {
                        target: 'G3D03F',
                        unmaskedRenderer: unmaskedRenderer,
                        unmaskedVendor: unmaskedVendor,
                        isHardwareAccelerated: isHardware,
                        heapUsedMB: heapUsed,
                        scenarios: results
                    };

                    let scriptEl = document.getElementById('perfProfileData');
                    if (!scriptEl) {
                        scriptEl = document.createElement('script');
                        scriptEl.id = 'perfProfileData';
                        scriptEl.type = 'application/json';
                        document.body.appendChild(scriptEl);
                    }
                    scriptEl.textContent = JSON.stringify(outputData);
                    return outputData;
                } catch (e) {
                    let scriptEl = document.getElementById('perfProfileData');
                    if (!scriptEl) {
                        scriptEl = document.createElement('script');
                        scriptEl.id = 'perfProfileData';
                        scriptEl.type = 'application/json';
                        document.body.appendChild(scriptEl);
                    }
                    scriptEl.textContent = JSON.stringify({ error: e.toString(), stack: e.stack });
                }
            }'''
    assert old_unit_close in content, 'old_unit_close not found'
    content = content.replace(old_unit_close, new_unit_close)

    old_hash_hook = "if (window.location.hash === '#tests' || window.location.search.includes('runTests=1')) {\n                controller.executeUnitTests();\n            }"
    new_hash_hook = "if (window.location.hash === '#tests' || window.location.search.includes('runTests=1')) {\n                controller.executeUnitTests();\n            } else if (window.location.hash === '#profile' || window.location.search.includes('profile=1')) {\n                controller.executePerformanceProfile();\n            }"
    assert old_hash_hook in content, 'old_hash_hook not found'
    content = content.replace(old_hash_hook, new_hash_hook)

    # Write G3D03F_WORKING.html
    out_file = 'G3D03F_WORKING.html'
    with open(out_file, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f'Successfully built {out_file} (length: {len(content)})')

    # Copy to INTEGRATION/FOC_G3D03F_6_AJAN_BIRLESIK_ADAY.html
    os.makedirs('INTEGRATION', exist_ok=True)
    candidate_file = os.path.join('INTEGRATION', 'FOC_G3D03F_6_AJAN_BIRLESIK_ADAY.html')
    shutil.copyfile(out_file, candidate_file)
    print(f'Successfully copied to {candidate_file}')

if __name__ == '__main__':
    build_master()
