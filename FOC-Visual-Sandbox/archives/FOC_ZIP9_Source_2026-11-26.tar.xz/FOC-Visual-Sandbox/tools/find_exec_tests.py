# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('executeUnitTests() {')
print("Found executeUnitTests at:", idx)
if idx != -1:
    print(text[idx:idx+600])
