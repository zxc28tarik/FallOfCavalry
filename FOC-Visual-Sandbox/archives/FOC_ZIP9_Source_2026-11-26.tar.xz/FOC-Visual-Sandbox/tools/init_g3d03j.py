import os
import shutil

base_file = 'G3D03H_WORKING.html'
target_working = 'G3D03J_WORKING.html'

shutil.copyfile(base_file, target_working)
print(f'Created {target_working} ({os.path.getsize(target_working)} bytes)')

for i in range(1, 7):
    agent_dir = os.path.join('G3D03J', 'AJANLAR', f'{i:02d}')
    os.makedirs(agent_dir, exist_ok=True)
    dst_work = os.path.join(agent_dir, 'WORKING.html')
    dst_deliv = os.path.join(agent_dir, 'DELIVERABLE.html')
    shutil.copyfile(target_working, dst_work)
    shutil.copyfile(target_working, dst_deliv)
    print(f'Initialized Agent {i:02d} in {agent_dir}')

print('G3D-03J workspace initialization complete.')
