with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('function createSoldierPartTemplates()')
idx_ret = text.find('return templates;', idx)
print(text[idx_ret-800:idx_ret+50])
