import subprocess, os, tempfile

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), 'foc_test_profile_loc')

test_script = """
<script>
window.addEventListener('load', () => {
    const d = document.createElement('div');
    d.id = 'locationDebugInfo';
    d.textContent = JSON.stringify({
        href: window.location.href,
        search: window.location.search,
        hash: window.location.hash,
        isTest: window.location.hash === '#tests' || window.location.search.includes('runTests=1')
    });
    document.body.appendChild(d);
});
</script>
"""

with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    orig = f.read()

with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(orig.replace('</body>', test_script + '</body>'))

file_url = 'file:///' + os.path.abspath('G3D03K_WORKING.html').replace('\\', '/') + '?runTests=1#tests'
cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--virtual-time-budget=2000',
    '--dump-dom',
    file_url
]

proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15, encoding='utf-8', errors='replace')

with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(orig)

pos = proc.stdout.find('id="locationDebugInfo"')
if pos != -1:
    end = proc.stdout.find('</div>', pos)
    print("LOCATION INFO:", proc.stdout[pos+23:end])
else:
    print("Not found")
