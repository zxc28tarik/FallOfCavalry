# -*- coding: utf-8 -*-
"""
tools/capture_soldier_closeup.py
Captures a close-up screenshot of the live battlefield soldiers rendered in WebGL
to verify G3D-03L 2.0 anatomical hand grip, musket rest, cavalier hat and historical uniform details.
"""

import subprocess, os, tempfile, time

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), f'foc_closeup_{int(time.time())}')
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')
screenshot_path = r'C:\Users\zxc28\.gemini\antigravity\brain\991bada2-65ad-4998-90fb-0999f47003c5\g3d03l_soldier_closeup.png'

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Inject script to position camera close to soldiers right after entering battle
inject_script = """
<script>
window.addEventListener('load', () => {
    setTimeout(() => {
        // Start battle
        const btn = document.getElementById('btnStartBattleMain');
        if (btn) btn.click();

        setTimeout(() => {
            const ctrl = window.focPreviewController || (window.focBattleEngine ? window.focBattleEngine.controller : null);
            if (ctrl && ctrl.cameraController) {
                // Position camera for a clear close-up view of infantry soldiers
                ctrl.cameraController.setTarget(0, 1.3, 0);
                ctrl.cameraController.current.yaw = 0.2;
                ctrl.cameraController.current.pitch = 0.35;
                ctrl.cameraController.current.dist = 4.5;
                ctrl.cameraController.update(0.016);
            }
            window.__SCREENSHOT_READY = true;
        }, 1200);
    }, 800);
});
</script>
"""

patched_html = content.replace('</body>', inject_script + '\n</body>')
temp_html = os.path.join(tempfile.gettempdir(), 'foc_closeup_test.html')
with open(temp_html, 'w', encoding='utf-8') as f:
    f.write(patched_html)

cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--window-size=1280,720',
    f'--screenshot={screenshot_path}',
    f'file:///{temp_html.replace(os.sep, "/")}'
]

print("Capturing close-up screenshot...")
subprocess.run(cmd, capture_output=True, timeout=20)
if os.path.exists(screenshot_path):
    print(f"Screenshot successfully saved: {screenshot_path} ({os.path.getsize(screenshot_path)} bytes)")
else:
    print("Screenshot failed.")
