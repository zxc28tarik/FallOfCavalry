# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('window.__focBattle3DPreview')
print('Found at:', idx)
if idx != -1:
    print(text[idx-100:idx+300])
