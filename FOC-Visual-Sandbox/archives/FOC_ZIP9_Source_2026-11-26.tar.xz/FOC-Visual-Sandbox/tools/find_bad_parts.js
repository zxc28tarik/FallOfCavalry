// tools/find_bad_parts.js
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('FallOfCavalry_PLAYABLE_RTS.html', 'utf8');

const codeStart = html.indexOf('function makePart(');
const ce1 = html.indexOf('function createSoldierPartTemplates', codeStart);
const ret = html.indexOf('return templates;', ce1);
const codeEnd = html.indexOf('}', ret) + 1;
const code = html.substring(codeStart, codeEnd);

const sandbox = {
    console,
    Math,
    Float32Array,
    Uint16Array,
    Object,
    Array,
    FOC_THREE: {
        Mat4: {
            create: () => new Float32Array(16),
            fromEulerTranslationScale: () => new Float32Array(16),
            multiply: () => new Float32Array(16)
        },
        Material: function(opts) { Object.assign(this, opts); },
        Color: function(hex) { this.hex = hex; }
    }
};

const ctx = vm.createContext(sandbox);
try {
    vm.runInContext(code, ctx);
    const templates = vm.runInContext('createSoldierPartTemplates()', ctx);
    console.log('Total enumerable templates:', Object.keys(templates).length);

    const allKeys = Object.getOwnPropertyNames(templates);
    console.log('Total property names in templates:', allKeys.length);

    const validPrims = new Set(['box', 'cylinder', 'sphere', 'cone', 'dome', 'frustum',
        'orgTorsoCoat', 'orgTorsoArmored', 'orgHeadNatural', 'orgLimb', 'orgBoot', 'orgHand',
        'orgHelmetBork', 'orgHelmetTurban', 'orgHelmetPointed', 'orgHelmetMorion', 'orgHelmetCavalier',
        'orgHorseBody', 'orgHorseNeckHead', 'orgHorseSaddle', 'orgHorseLegUpper', 'orgHorseLegLower',
        'orgArmMusketL', 'orgArmMusketR', 'orgArmPikeL', 'orgArmPikeR', 'orgArmSwordR', 'orgArmShieldL',
        'orgArmRiderReinsL', 'orgArmRiderWeaponR', 'orgFallingCollar', 'orgHairCurtain', 'orgRiderLegL',
        'orgRiderLegR', 'orgHorseTail'
    ]);

    let badCount = 0;
    for (const key of allKeys) {
        const parts = templates[key];
        if (!Array.isArray(parts)) continue;
        for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            if (!part || !part.prim || !validPrims.has(part.prim)) {
                console.error(`BAD PART in template [${key}] part ${i}: prim="${part ? part.prim : 'null'}", mat="${part ? part.mat : 'null'}"`);
                badCount++;
            }
        }
    }
    console.log('Finished scan. Bad parts count:', badCount);
} catch (e) {
    console.error('VM error:', e);
}
