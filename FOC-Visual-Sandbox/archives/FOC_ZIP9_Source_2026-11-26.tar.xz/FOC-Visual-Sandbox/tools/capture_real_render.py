import subprocess
import os
import tempfile
import json
import re
import base64

def run(html_name='G3D03G_WORKING.html', out_png='actual_rendered_canvas.png'):
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    temp_profile = os.path.join(tempfile.gettempdir(), f'foc_debug_profile_{os.path.splitext(html_name)[0]}')

    with open(html_name, 'r', encoding='utf-8') as f:
        content = f.read()

    # Enable preserveDrawingBuffer
    content = content.replace("alpha: false,", "alpha: false, preserveDrawingBuffer: true,")

    diag_code = '''
<script>
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        try {
            const cvs = document.querySelector('canvas');
            const c = window.__focBattle3DPreview;
            const res = {
                hasCanvas: !!cvs,
                w: cvs ? cvs.width : 0,
                h: cvs ? cvs.height : 0,
                batches: c ? c.renderer.soldierRegistry.batchGroup.batches.length : 0,
                records: c ? c.renderer.soldierRegistry.records.size : 0,
                img: cvs ? cvs.toDataURL('image/png') : ''
            };
            const pre = document.createElement('pre');
            pre.id = 'renderOutput';
            pre.textContent = JSON.stringify(res);
            document.body.appendChild(pre);
        } catch (e) {
            const pre = document.createElement('pre');
            pre.id = 'renderOutput';
            pre.textContent = JSON.stringify({ error: e.message, stack: e.stack });
            document.body.appendChild(pre);
        }
    }, 1200);
});
</script>
'''
    temp_html = 'G3D03G_TEST_RENDER.html'
    with open(temp_html, 'w', encoding='utf-8') as f:
        f.write(content.replace('</body>', diag_code + '</body>'))

    cmd = [
        chrome_path,
        '--headless=new',
        '--disable-gpu-sandbox',
        '--enable-webgl',
        '--use-gl=angle',
        '--use-angle=d3d11',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--virtual-time-budget=10000',
        '--dump-dom',
        'file:///' + os.path.abspath(temp_html).replace('\\', '/')
    ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=25, encoding='utf-8', errors='replace')
        m = re.search(r'<pre id="renderOutput">(.*?)</pre>', res.stdout, re.DOTALL)
        if m:
            data = json.loads(m.group(1))
            if data.get('img'):
                raw = base64.b64decode(data['img'].split(',')[1])
                with open(out_png, 'wb') as img_f:
                    img_f.write(raw)
                del data['img']
                print(f'Successfully saved {out_png}!')
            print(json.dumps(data, indent=2))
        else:
            print('Could not find renderOutput. Stdout len:', len(res.stdout), 'End of stdout:', res.stdout[-800:])
    finally:
        if os.path.exists(temp_html):
            os.remove(temp_html)

if __name__ == '__main__':
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else 'G3D03G_WORKING.html'
    out = sys.argv[2] if len(sys.argv) > 2 else 'actual_rendered_canvas.png'
    run(target, out)
