with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('class SoldierVisualRegistry')
end = text.find('class PowderFxPool', pos)
reg_text = text[pos:end]
for line in reg_text.splitlines():
    if '(' in line and ')' in line and '{' in line and not line.strip().startswith('//'):
        print(line.strip())
