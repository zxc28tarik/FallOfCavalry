# -*- coding: utf-8 -*-
"""
tools/build_g3d03k_models.py
Generates the G3D-03K High-Fidelity Anatomical Model Builders:
- Agent 01: buildAnatomicalHumanBase with 3 Body Profiles ('slim', 'average', 'heavy'), articulated hands, calf/knee contours.
- Agent 02: Ottoman Layered Clothing & Armor (flared pleated kaftan, wrapped kuşak, yemeni, cevşen, çar-ayna, tolga, bork).
- Agent 03: European / HRE Uniforms & Armor (peascod doublet/buff coat, bucket boots, Morion comb, tapul ridge, 3/4 plate).
- Agent 04: Head & Face Anatomy (brow, nose, jawline, ears, facial hair: mustache, van dyke, beard, clean).
- Agent 05: Enhanced 1650 PBR Materials (blackenedSteel, burnishedBronze, buffLeather, fineSilk, roughWool).
- Agent 06: RTSModularUnitBuilder & Showcase Quality Comparison.
"""

def get_g3d03k_models_code():
    return '''
        /* ============================================================================
         * G3D-03K İLERİ DÜZEY ANATOMİK VE TARİHSEL MODEL ŞABLONLARI
         * ============================================================================ */

        // ----------------------------------------------------------------------------
        // AGENT 01: İNSAN ANATOMİSİ VE 3 TEMEL VÜCUT PROFİLİ (Slim, Average, Heavy)
        // ----------------------------------------------------------------------------
        const BODY_PROFILES = {
            slim: {
                shoulderWidth: 0.46,
                chestWidth: 0.44,
                chestDepth: 0.28,
                waistWidth: 0.36,
                waistDepth: 0.24,
                limbRadiusScale: 0.88,
                headScale: 0.96
            },
            average: {
                shoulderWidth: 0.52,
                chestWidth: 0.50,
                chestDepth: 0.32,
                waistWidth: 0.40,
                waistDepth: 0.27,
                limbRadiusScale: 1.0,
                headScale: 1.0
            },
            heavy: {
                shoulderWidth: 0.58,
                chestWidth: 0.56,
                chestDepth: 0.38,
                waistWidth: 0.46,
                waistDepth: 0.32,
                limbRadiusScale: 1.15,
                headScale: 1.05
            }
        };

        // Articulated hand builder with defined palm and angled thumb grip
        function buildArticulatedHand(mat, x, y, z, rigGroup, isLeft = false) {
            const sideSign = isLeft ? 1 : -1;
            return [
                // Palm
                makePart('box', mat, x, y, z, 0.08, 0.09, 0.05, 0, 0, 0, rigGroup),
                // Thumb joint
                makePart('box', mat, x + sideSign * 0.045, y - 0.015, z + 0.02, 0.035, 0.045, 0.035, 0.3, sideSign * 0.4, 0, rigGroup),
                // Finger cluster
                makePart('box', mat, x, y + 0.045, z + 0.005, 0.075, 0.05, 0.04, 0, 0, 0, rigGroup)
            ];
        }

        // Detailed anatomical head with brow, nose bridge, jawline and ears
        function buildAnatomicalHead(skinMat, hairMat, beardType = 'mustache', options = {}) {
            const hScale = options.headScale || 1.0;
            const parts = [
                // Neck with cervical taper
                makePart('frustum', skinMat, 0, 1.45, 0.015, 0.15 * hScale, 0.13, 0.13 * hScale, 0.1, 0, 0, 'torso'),
                // Cranium / Skull vault
                makePart('sphere', skinMat, 0, 1.58, 0.01, 0.23 * hScale, 0.25 * hScale, 0.24 * hScale, 0, 0, 0, 'torso'),
                // Forehead & Brow ridge
                makePart('box', skinMat, 0, 1.62, 0.12 * hScale, 0.20 * hScale, 0.06 * hScale, 0.08 * hScale, 0.15, 0, 0, 'torso'),
                // Nose bridge
                makePart('cone', skinMat, 0, 1.55, 0.16 * hScale, 0.05 * hScale, 0.09 * hScale, 0.05 * hScale, Math.PI * 0.5 + 0.35, 0, 0, 'torso'),
                // Jawline and Chin
                makePart('frustum', skinMat, 0, 1.49, 0.07 * hScale, 0.18 * hScale, 0.10 * hScale, 0.14 * hScale, -0.2, 0, 0, 'torso'),
                // Left Ear
                makePart('dome', skinMat, -0.13 * hScale, 1.57, -0.01, 0.05 * hScale, 0.08 * hScale, 0.03 * hScale, 0, -Math.PI * 0.5, 0, 'torso'),
                // Right Ear
                makePart('dome', skinMat,  0.13 * hScale, 1.57, -0.01, 0.05 * hScale, 0.08 * hScale, 0.03 * hScale, 0,  Math.PI * 0.5, 0, 'torso')
            ];

            // Facial hair variations
            if (beardType === 'mustache' || beardType === 'ottoman_pala') {
                // Broad drooping Ottoman mustache
                parts.push(
                    makePart('cone', hairMat, -0.06 * hScale, 1.505, 0.135 * hScale, 0.045 * hScale, 0.12 * hScale, 0.035 * hScale, Math.PI * 0.6, 0.5, -0.3, 'torso'),
                    makePart('cone', hairMat,  0.06 * hScale, 1.505, 0.135 * hScale, 0.045 * hScale, 0.12 * hScale, 0.035 * hScale, Math.PI * 0.6, -0.5, 0.3, 'torso')
                );
            } else if (beardType === 'vandyke') {
                // European pointed goatee and upturned mustache
                parts.push(
                    makePart('box', hairMat, 0, 1.52, 0.14 * hScale, 0.11 * hScale, 0.03 * hScale, 0.02 * hScale, 0, 0, 0, 'torso'),
                    makePart('cone', hairMat, 0, 1.45, 0.12 * hScale, 0.05 * hScale, 0.09 * hScale, 0.04 * hScale, -Math.PI * 0.4, 0, 0, 'torso')
                );
            } else if (beardType === 'full_beard') {
                // Full trimmed veteran beard
                parts.push(
                    makePart('frustum', hairMat, 0, 1.47, 0.08 * hScale, 0.20 * hScale, 0.12 * hScale, 0.15 * hScale, -0.25, 0, 0, 'torso')
                );
            }

            return parts;
        }

        // Master Anatomical Human Base
        const buildAnatomicalHumanBase = (side, profileKey = 'average', options = {}) => {
            const isEnemy = side === 'enemy';
            const prof = BODY_PROFILES[profileKey] || BODY_PROFILES.average;
            const skinMat = options.skinMat || 'skin';
            const hairMat = options.hairMat || 'wood';
            const clothMat = options.clothMat || (isEnemy ? 'enemyCloth' : 'playerCloth');
            const breechesMat = options.breechesMat || (isEnemy ? 'enemyBreeches' : 'playerBreeches');
            const leatherMat = options.leatherMat || 'leather';
            const beardType = options.beardType || (isEnemy ? 'vandyke' : 'ottoman_pala');

            const legX = prof.shoulderWidth * 0.34;
            const rScale = prof.limbRadiusScale;

            const baseParts = [
                // Ground Contact Shadow
                makePart('cylinder', 'shadow', 0, 0.02, 0, 1.08, 0.02, 1.08, 0, 0, 0, 'shadow'),

                // Footwear: Leather shoes / boots with distinct sole & heel
                makePart('box', leatherMat, -legX, 0.025, 0.04, 0.11 * rScale, 0.05, 0.24, 0, 0, 0, 'leftLegLower'),
                makePart('box', leatherMat,  legX, 0.025, 0.04, 0.11 * rScale, 0.05, 0.24, 0, 0, 0, 'rightLegLower'),
                makePart('box', 'darkCloth', -legX, 0.045, -0.05, 0.10 * rScale, 0.04, 0.08, 0, 0, 0, 'leftLegLower'),
                makePart('box', 'darkCloth',  legX, 0.045, -0.05, 0.10 * rScale, 0.04, 0.08, 0, 0, 0, 'rightLegLower'),

                // Lower Leg & Gastrocnemius Calf Contour
                makePart('frustum', breechesMat, -legX, 0.24, 0.0, 0.17 * rScale, 0.42, 0.19 * rScale, 0, 0, 0, 'leftLegLower'),
                makePart('frustum', breechesMat,  legX, 0.24, 0.0, 0.17 * rScale, 0.42, 0.19 * rScale, 0, 0, 0, 'rightLegLower'),
                // Knee Cap Articulation
                makePart('dome', breechesMat, -legX, 0.48, 0.04, 0.12 * rScale, 0.08, 0.12 * rScale, 0.3, 0, 0, 'leftLegLower'),
                makePart('dome', breechesMat,  legX, 0.48, 0.04, 0.12 * rScale, 0.08, 0.12 * rScale, 0.3, 0, 0, 'rightLegLower'),

                // Thigh / Quadriceps Muscle Mass
                makePart('frustum', breechesMat, -legX, 0.68, 0.0, 0.22 * rScale, 0.38, 0.23 * rScale, Math.PI, 0, 0, 'leftLegUpper'),
                makePart('frustum', breechesMat,  legX, 0.68, 0.0, 0.22 * rScale, 0.38, 0.23 * rScale, Math.PI, 0, 0, 'rightLegUpper'),

                // Pelvis & Lower Torso
                makePart('frustum', clothMat, 0, 0.88, 0.0, prof.waistWidth, 0.26, prof.waistDepth, 0, 0, 0, 'torso'),

                // Waist Belt / Sash Layer
                makePart('cylinder', leatherMat, 0, 0.98, 0.0, prof.waistWidth * 0.92, 0.09, prof.waistDepth * 0.92, 0, 0, 0, 'torso'),
                makePart('box', 'gold', 0, 0.98, prof.waistDepth * 0.48, 0.09, 0.08, 0.035, 0, 0, 0, 'torso'),

                // Upper Chest with Natural Taper (Broad shoulders tapering down to waist)
                makePart('frustum', clothMat, 0, 1.20, 0.0, prof.shoulderWidth, 0.44, prof.chestDepth, Math.PI, 0, 0, 'torso'),

                // Deltoid Shoulder Muscle Caps
                makePart('sphere', clothMat, -prof.shoulderWidth * 0.52, 1.34, 0.0, 0.12 * rScale, 0.13 * rScale, 0.12 * rScale, 0, 0, 0, 'torso'),
                makePart('sphere', clothMat,  prof.shoulderWidth * 0.52, 1.34, 0.0, 0.12 * rScale, 0.13 * rScale, 0.12 * rScale, 0, 0, 0, 'torso'),

                // Detailed Anatomical Head & Neck
                ...buildAnatomicalHead(skinMat, hairMat, beardType, { headScale: prof.headScale })
            ];

            return baseParts;
        };

        // ----------------------------------------------------------------------------
        // AGENT 02: OSMANLI ÇOK KATMANLI KIYAFET VE ZIRH KALİTESİ
        // ----------------------------------------------------------------------------
        const buildOttomanHighDefHumanBase = (side, profileKey = 'average', options = {}) => {
            const isEnemy = side === 'enemy';
            const kaftanColor = options.kaftanMat || (isEnemy ? 'enemyCloth' : 'ottomanCrimson');
            const salvarColor = options.salvarMat || 'ottomanNavy';
            const kusakColor = options.kusakMat || 'ottomanSaffron';

            const base = buildAnatomicalHumanBase(side, profileKey, {
                clothMat: kaftanColor,
                breechesMat: salvarColor,
                leatherMat: 'leather',
                beardType: 'ottoman_pala',
                ...options
            });

            const prof = BODY_PROFILES[profileKey] || BODY_PROFILES.average;

            // Add Flared Pleated Kaftan Skirt with Split Front
            const kaftanSkirt = [
                // Lower Flared Skirt
                makePart('frustum', kaftanColor, 0, 0.84, -0.01, prof.waistWidth * 1.26, 0.34, prof.waistDepth * 1.30, 0, 0, 0, 'torso'),
                // Gold Embroidered Border Hem
                makePart('frustum', 'gold', 0, 0.68, -0.01, prof.waistWidth * 1.28, 0.03, prof.waistDepth * 1.32, 0, 0, 0, 'torso'),
                // Split Lapel Front Opening
                makePart('box', 'ottomanWhite', 0, 1.18, prof.chestDepth * 0.51, 0.06, 0.40, 0.02, 0, 0, 0, 'torso'),
                // Three-Dimensional Wrapped Silk Kuşak
                makePart('cylinder', kusakColor, 0, 0.98, 0.0, prof.waistWidth * 1.05, 0.12, prof.waistDepth * 1.06, 0, 0, 0, 'torso'),
                makePart('box', 'gold', 0, 0.98, prof.waistDepth * 0.54, 0.10, 0.09, 0.04, 0, 0, 0, 'torso')
            ];

            return [...base, ...kaftanSkirt];
        };

        // ----------------------------------------------------------------------------
        // AGENT 03: AVRUPA / HRE ASKER KIYAFETLERİ VE ZIRHLARI
        // ----------------------------------------------------------------------------
        const buildEuropeanHighDefHumanBase = (side, profileKey = 'average', options = {}) => {
            const isEnemy = side === 'enemy';
            const coatColor = options.coatMat || (isEnemy ? 'enemyCloth' : 'playerCloth');
            const breechesColor = options.breechesMat || (isEnemy ? 'enemyBreeches' : 'playerBreeches');

            const base = buildAnatomicalHumanBase(side, profileKey, {
                clothMat: coatColor,
                breechesMat: breechesColor,
                leatherMat: 'buffLeather',
                beardType: 'vandyke',
                ...options
            });

            const prof = BODY_PROFILES[profileKey] || BODY_PROFILES.average;

            // European Peascod Doublet Flared Tabs & Falling Linen Collar
            const europeanDetails = [
                // Starched Falling White Collar
                makePart('frustum', 'linen', 0, 1.40, 0.02, prof.shoulderWidth * 0.52, 0.05, prof.chestDepth * 0.72, 0, 0, 0, 'torso'),
                // Peascod Doublet Waist Skirt Tabs (Peplos)
                makePart('frustum', coatColor, 0, 0.88, 0.0, prof.waistWidth * 1.15, 0.22, prof.waistDepth * 1.18, 0, 0, 0, 'torso'),
                // Leather Cross-Belt Baldric for Sword Hanger
                makePart('box', 'buffLeather', -0.06, 1.16, 0.0, 0.07, 0.44, prof.chestDepth * 1.05, 0, 0, -0.42, 'torso'),
                makePart('box', 'steel', -0.06, 0.98, prof.chestDepth * 0.52, 0.08, 0.06, 0.03, 0, 0, -0.42, 'torso')
            ];

            return [...base, ...europeanDetails];
        };

        // ----------------------------------------------------------------------------
        // AGENT 04 & 05: TARİHSEL MİĞFERLER, BAŞLIKLAR VE ZIRH SETLERİ
        // ----------------------------------------------------------------------------

        // 1. White Felt Börk (Janissary) with Hollow Fit
        function buildHighDefBork() {
            return [
                // Brass Spoon Holder (Zarf)
                makePart('box', 'burnishedBronze', 0, 1.68, 0.16, 0.065, 0.18, 0.045, 0.1, 0, 0, 'torso'),
                makePart('sphere', 'gold', 0, 1.76, 0.17, 0.05, 0.05, 0.035, 0, 0, 0, 'torso'),
                // White Felt Tapered Crown
                makePart('frustum', 'ottomanWhite', 0, 1.82, 0.02, 0.29, 0.32, 0.30, 0, 0, 0, 'torso'),
                // Draping Rear Fabric Flap (Over Neck & Shoulders)
                makePart('frustum', 'ottomanWhite', 0, 1.56, -0.16, 0.25, 0.48, 0.085, -0.34, 0, 0, 'torso'),
                makePart('box', 'ottomanCrimson', 0, 1.34, -0.22, 0.22, 0.04, 0.03, -0.34, 0, 0, 'torso')
            ];
        }

        // 2. High-Comb Morion Helmet (HRE Pikeniere)
        function buildHighDefMorion() {
            return [
                // Helmet Skull Bowl
                makePart('dome', 'steel', 0, 1.70, 0.02, 0.30, 0.22, 0.32, 0, 0, 0, 'torso'),
                // Curved Swept-Wing Brim (Fore & Aft Peaks)
                makePart('frustum', 'steel', 0, 1.63, 0.02, 0.40, 0.05, 0.44, 0, 0, 0, 'torso'),
                // Prominent High Crescent Comb
                makePart('box', 'steel', 0, 1.82, 0.02, 0.035, 0.18, 0.34, 0, 0, 0, 'torso'),
                makePart('frustum', 'steel', 0, 1.88, 0.02, 0.03, 0.08, 0.28, 0, 0, 0, 'torso'),
                // Rivet Band along Rim
                makePart('cylinder', 'burnishedBronze', 0, 1.64, 0.02, 0.31, 0.025, 0.33, 0, 0, 0, 'torso')
            ];
        }

        // 3. Peaked Burgonet Helmet (HRE Hellebardier)
        function buildHighDefBurgonet() {
            return [
                // Skull Bowl
                makePart('dome', 'steel', 0, 1.70, 0.02, 0.30, 0.22, 0.31, 0, 0, 0, 'torso'),
                // Fixed Brow Peak Visor
                makePart('box', 'steel', 0, 1.64, 0.16, 0.28, 0.04, 0.12, 0.35, 0, 0, 'torso'),
                // Neck Lames (Lobster Tail)
                makePart('frustum', 'steel', 0, 1.54, -0.13, 0.26, 0.14, 0.10, -0.4, 0, 0, 'torso'),
                // Hinged Cheek Guards
                makePart('box', 'steel', -0.14, 1.54, 0.05, 0.03, 0.14, 0.10, 0, 0, 0, 'torso'),
                makePart('box', 'steel',  0.14, 1.54, 0.05, 0.03, 0.14, 0.10, 0, 0, 0, 'torso')
            ];
        }

        // 4. Şişak / Tolga Helmet with Nasal Bar (Sipahi)
        function buildHighDefSisak() {
            return [
                // Pointed Fluted Bowl
                makePart('cone', 'damascusSteel', 0, 2.32, -0.03, 0.28, 0.32, 0.28, 0, 0, 0, 'riderUpper'),
                makePart('cone', 'burnishedBronze', 0, 2.44, -0.03, 0.08, 0.16, 0.08, 0, 0, 0, 'riderUpper'),
                // Brow Visor & Sliding Nasal Bar
                makePart('box', 'damascusSteel', 0, 2.18, 0.12, 0.26, 0.04, 0.08, 0.25, 0, 0, 'riderUpper'),
                makePart('box', 'burnishedBronze', 0, 2.10, 0.16, 0.025, 0.18, 0.025, 0, 0, 0, 'riderUpper'),
                // Mail Camail Neck Drape
                makePart('cylinder', 'darkSteel', 0, 2.05, -0.04, 0.31, 0.22, 0.31, 0, 0, 0, 'riderUpper')
            ];
        }

        // 5. Broad Cavalier Hat with Ostrich Plume (Musketier)
        function buildHighDefCavalierHat() {
            return [
                // Wide Upturned Felt Brim
                makePart('cylinder', 'darkCloth', 0, 1.66, 0.02, 0.46, 0.03, 0.46, 0.1, 0, 0.15, 'torso'),
                // Crown
                makePart('cylinder', 'darkCloth', 0, 1.74, 0.02, 0.28, 0.16, 0.28, 0.1, 0, 0.15, 'torso'),
                // Flowing Ostrich Feather Plume
                makePart('frustum', 'linen', 0.14, 1.82, -0.06, 0.06, 0.28, 0.10, -0.4, 0, 0.6, 'torso'),
                makePart('frustum', 'ottomanCrimson', 0.18, 1.88, -0.12, 0.05, 0.24, 0.08, -0.6, 0, 0.7, 'torso')
            ];
        }

        // 6. Çevşen Breastplate Armor (Janissary / Bostancı)
        function buildHighDefCevsen() {
            return [
                // Interlocking Mail Vest
                makePart('cylinder', 'damascusSteel', 0, 1.20, 0.005, 0.52, 0.38, 0.34, 0, 0, 0, 'torso'),
                // Central Steel Disc Plate
                makePart('cylinder', 'damascusSteel', 0, 1.22, 0.175, 0.26, 0.025, 0.26, Math.PI * 0.5, 0, 0, 'torso'),
                makePart('sphere', 'burnishedBronze', 0, 1.22, 0.19, 0.07, 0.07, 0.07, 0, 0, 0, 'torso'),
                // Arm bazuband bracers
                makePart('cylinder', 'damascusSteel', -0.32, 1.12, 0.10, 0.07, 0.18, 0.07, 0, 0, 0, 'torso'),
                makePart('cylinder', 'damascusSteel',  0.32, 1.12, 0.10, 0.07, 0.18, 0.07, 0, 0, 0, 'torso')
            ];
        }

        // 7. Tapul Ridged Breastplate with Tassets (HRE Pikeniere)
        function buildHighDefTapulArmor() {
            return [
                // Peascod Ridged Front Breastplate
                makePart('frustum', 'steel', 0, 1.22, 0.02, 0.52, 0.42, 0.36, Math.PI, 0, 0, 'torso'),
                // Deflection Central Spine Ridge
                makePart('box', 'steel', 0, 1.22, 0.20, 0.035, 0.40, 0.05, 0.12, 0, 0, 'torso'),
                // Articulated Thigh Tassets (Laminated Plates)
                makePart('frustum', 'steel', -0.14, 0.82, 0.08, 0.20, 0.24, 0.14, -0.2, 0, 0, 'leftLegUpper'),
                makePart('frustum', 'steel',  0.14, 0.82, 0.08, 0.20, 0.24, 0.14, -0.2, 0, 0, 'rightLegUpper')
            ];
        }

        // ----------------------------------------------------------------------------
        // AGENT 06: MODÜLER ASKER BİRLEŞTİRME MOTORU (RTSModularUnitBuilder)
        // ----------------------------------------------------------------------------
        class RTSModularUnitBuilder {
            static assembleSoldier(archetype, side, seed = 0) {
                const isOttoman = archetype.includes('ottoman') || archetype.includes('janissary') || archetype.includes('azap') || archetype.includes('sipahi') || archetype.includes('deli') || archetype.includes('bostanci') || archetype.includes('humbaraci') || archetype.includes('levend') || archetype.includes('ciritci') || archetype.includes('akinci');

                // Determine profile deterministically from seed
                const profiles = ['slim', 'average', 'heavy'];
                const profile = profiles[Math.abs(seed) % profiles.length];

                if (isOttoman) {
                    if (archetype.includes('janissary')) {
                        const base = buildOttomanHighDefHumanBase(side, profile, { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                        return [...base, ...buildHighDefBork(), ...buildHighDefCevsen()];
                    } else if (archetype.includes('bostanci')) {
                        const base = buildOttomanHighDefHumanBase(side, 'heavy', { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                        return [...base, ...buildHighDefCevsen()];
                    } else {
                        return buildOttomanHighDefHumanBase(side, profile);
                    }
                } else {
                    if (archetype.includes('pikeniere')) {
                        const base = buildEuropeanHighDefHumanBase(side, profile, { coatMat: 'playerCloth', breechesMat: 'playerBreeches' });
                        return [...base, ...buildHighDefMorion(), ...buildHighDefTapulArmor()];
                    } else if (archetype.includes('hellebardier')) {
                        const base = buildEuropeanHighDefHumanBase(side, profile, { coatMat: 'darkCloth', breechesMat: 'buffLeather' });
                        return [...base, ...buildHighDefBurgonet()];
                    } else if (archetype.includes('musketier')) {
                        const base = buildEuropeanHighDefHumanBase(side, profile, { coatMat: 'playerCloth', breechesMat: 'playerBreeches' });
                        return [...base, ...buildHighDefCavalierHat()];
                    } else {
                        return buildEuropeanHighDefHumanBase(side, profile);
                    }
                }
            }
        }
    '''

