with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('templateKey = resolveCavalryVisualVariant(s);')
print(text[idx-400:idx+600])
