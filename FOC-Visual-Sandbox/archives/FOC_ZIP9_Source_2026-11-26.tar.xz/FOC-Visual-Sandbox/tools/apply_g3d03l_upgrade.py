# -*- coding: utf-8 -*-
"""
tools/apply_g3d03l_upgrade.py
Patches tools/build_playable_rts.py to integrate G3D-03L 2.0 anatomical models,
musket rest, 12 apostles bandolier, historical headwear and 84 tests.
"""

with open('tools/build_playable_rts.py', 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Update imports
old_import = "from build_g3d03k_models import get_g3d03k_models_code"
new_import = """from build_g3d03k_models import get_g3d03k_models_code
from build_g3d03l_models import get_g3d03l_models_code"""
assert old_import in code, "old_import not found"
code = code.replace(old_import, new_import, 1)

# 2. Update Header / Title Replacements
old_header_reps = """html = html.replace('FALL OF CAVALRY — G3D-03J', 'FALL OF CAVALRY (1650) — PLAYABLE RTS')
html = html.replace('G3D-03J: 6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & MODEL ÇEŞİTLİLİĞİ', 'FALL OF CAVALRY: 1650 MEYDAN MUHAREBESİ (PLAYABLE 3D RTS)')
html = html.replace('6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & VİTRİN (G3D-03J)', '1650 MEYDAN MUHAREBESİ — PLAYABLE 3D RTS')
html = html.replace('64 / 64', '78 / 78')
html = html.replace('64 doğrulama testi', '78 doğrulama testi')"""

new_header_reps = """html = html.replace('FALL OF CAVALRY — G3D-03J', 'FALL OF CAVALRY (1650) — PLAYABLE RTS')
html = html.replace('G3D-03J: 6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & MODEL ÇEŞİTLİLİĞİ', 'FALL OF CAVALRY: G3D-03L ASKER GÖRSEL KALİTESİ 2.0 (PLAYABLE 3D RTS)')
html = html.replace('6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & VİTRİN (G3D-03J)', '1650 MEYDAN MUHAREBESİ — ASKER GÖRSEL KALİTESİ 2.0')
html = html.replace('64 / 64', '84 / 84')
html = html.replace('64 doğrulama testi', '84 doğrulama testi')"""

assert old_header_reps in code, "old_header_reps not found"
code = code.replace(old_header_reps, new_header_reps, 1)

# 3. Inject G3D-03L models code globally
old_global_code = "''' + get_g3d03k_models_code() + '\\n'"
new_global_code = "''' + get_g3d03k_models_code() + '\\n' + get_g3d03l_models_code() + '\\n'"
assert old_global_code in code, "old_global_code not found"
code = code.replace(old_global_code, new_global_code, 1)

# 4. Register G3D-03L templates non-enumerable
old_templates_reg = """            for (const kKey of Object.keys(g3d03kTemplates)) {
                Object.defineProperty(templates, kKey, {
                    value: g3d03kTemplates[kKey],
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }"""

new_templates_reg = """            for (const kKey of Object.keys(g3d03kTemplates)) {
                Object.defineProperty(templates, kKey, {
                    value: g3d03kTemplates[kKey],
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }

            // G3D-03L ASKER GÖRSEL KALİTESİ 2.0 ŞABLONLARI
            const g3d03lTemplates = {
                'g3d03l:ottoman_janissary:high': G3D03LModularUnitFactory.assemble('ottoman_janissary', 'player'),
                'g3d03l:ottoman_azap:high': G3D03LModularUnitFactory.assemble('ottoman_azap', 'player'),
                'g3d03l:ottoman_sipahi:high': G3D03LModularUnitFactory.assemble('ottoman_sipahi', 'player'),
                'g3d03l:ottoman_levend:high': G3D03LModularUnitFactory.assemble('ottoman_levend', 'player'),
                'g3d03l:european_musketier:high': G3D03LModularUnitFactory.assemble('european_musketier', 'enemy'),
                'g3d03l:european_pikeniere:high': G3D03LModularUnitFactory.assemble('european_pikeniere', 'enemy'),
                'g3d03l:european_curassier:high': G3D03LModularUnitFactory.assemble('european_curassier', 'enemy'),
                'g3d03l:european_hellebardier:high': G3D03LModularUnitFactory.assemble('european_hellebardier', 'enemy')
            };

            for (const lKey of Object.keys(g3d03lTemplates)) {
                Object.defineProperty(templates, lKey, {
                    value: g3d03lTemplates[lKey],
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }"""

assert old_templates_reg in code, "old_templates_reg not found"
code = code.replace(old_templates_reg, new_templates_reg, 1)

# 5. Update sync template resolution for G3D-03L
old_sync_block = """                    // G3D-03K Dinamik Şablon Desteği (Katalogdaki tüm birimlerin yüksek kalite modu için)
                    if (s.templateKey && !this.templates[s.templateKey] && s.templateKey.startsWith('g3d03k:')) {
                        const archParts = s.templateKey.split(':');
                        const archName = archParts[1] || 'ottoman_janissary';
                        const archSide = archName.includes('ottoman') ? 'player' : 'enemy';
                        const builtParts = (typeof RTSModularUnitBuilder !== 'undefined')
                            ? RTSModularUnitBuilder.assembleSoldier(archName, archSide, 1)
                            : null;
                        if (builtParts) {
                            Object.defineProperty(this.templates, s.templateKey, {
                                value: builtParts,
                                enumerable: false,
                                writable: true,
                                configurable: true
                            });
                            templateKey = s.templateKey;
                        }
                    }"""

new_sync_block = """                    // G3D-03L Dinamik Şablon Desteği (Katalogdaki tüm birimlerin G3D-03L 2.0 modu için)
                    if (s.templateKey && !this.templates[s.templateKey] && s.templateKey.startsWith('g3d03l:')) {
                        const archParts = s.templateKey.split(':');
                        const archName = archParts[1] || 'ottoman_janissary';
                        const archSide = archName.includes('ottoman') ? 'player' : 'enemy';
                        const builtParts = (typeof G3D03LModularUnitFactory !== 'undefined')
                            ? G3D03LModularUnitFactory.assemble(archName, archSide)
                            : null;
                        if (builtParts) {
                            Object.defineProperty(this.templates, s.templateKey, {
                                value: builtParts,
                                enumerable: false,
                                writable: true,
                                configurable: true
                            });
                            templateKey = s.templateKey;
                        }
                    } else if (s.templateKey && !this.templates[s.templateKey] && s.templateKey.startsWith('g3d03k:')) {
                        const archParts = s.templateKey.split(':');
                        const archName = archParts[1] || 'ottoman_janissary';
                        const archSide = archName.includes('ottoman') ? 'player' : 'enemy';
                        const builtParts = (typeof RTSModularUnitBuilder !== 'undefined')
                            ? RTSModularUnitBuilder.assembleSoldier(archName, archSide, 1)
                            : null;
                        if (builtParts) {
                            Object.defineProperty(this.templates, s.templateKey, {
                                value: builtParts,
                                enumerable: false,
                                writable: true,
                                configurable: true
                            });
                            templateKey = s.templateKey;
                        }
                    }"""

assert old_sync_block in code, "old_sync_block not found"
code = code.replace(old_sync_block, new_sync_block, 1)

# 6. Update projectActiveSector3D loop to assign G3D-03L templates to live battlefield soldiers
old_project_hook = """# 6. Update RTSCamera3D to support targetY and close inspection"""
new_project_hook = """# 5.5 Update projectActiveSector3D to assign G3D-03L 2.0 templates
old_proj_loop = '''            for (let i = 0; i < allSoldiers.length; i++) {
                const s = allSoldiers[i];
                if (!s || !s.alive || s.hp <= 0) continue;

                const side = s.side === 'enemy' ? 'enemy' : 'player';
                if (visible[side] >= limits[side]) {
                    hiddenAlive[side]++;
                    continue;
                }

                visible[side]++;
                soldiers.push({
                    viewId: `${activeSector.sectorId}:${s.id}`,
                    sectorId: activeSector.sectorId,
                    side,
                    groupId: s.groupId,
                    soldierId: s.id,
                    unitClass: s.unitClass,
                    combatRole: s.combatRole,
                    bodyType: s.bodyType,
                    mountType: s.mountType,
                    activeWeapon: s.activeWeapon,
                    weaponLoadout: [...s.weaponLoadout],
                    armorLoadout: [...s.armorLoadout],
                    state: s.state,
                    hp: s.hp,
                    position: {
                        x: s.position.x,
                        y: s.position.y,
                        z: s.position.z
                    }
                });
            }'''

new_proj_loop = '''            for (let i = 0; i < allSoldiers.length; i++) {
                const s = allSoldiers[i];
                if (!s || !s.alive || s.hp <= 0) continue;

                const side = s.side === 'enemy' ? 'enemy' : 'player';
                if (visible[side] >= limits[side]) {
                    hiddenAlive[side]++;
                    continue;
                }

                visible[side]++;
                let g3d03lKey;
                if (side === 'player') {
                    if (s.unitClass === 'cavalry' || s.combatRole === 'cavalry' || s.mountType === 'horse') {
                        g3d03lKey = 'g3d03l:ottoman_sipahi:high';
                    } else if (s.combatRole === 'musketeer' || s.activeWeapon === 'musket') {
                        g3d03lKey = 'g3d03l:ottoman_janissary:high';
                    } else {
                        g3d03lKey = 'g3d03l:ottoman_azap:high';
                    }
                } else {
                    if (s.unitClass === 'cavalry' || s.combatRole === 'cavalry' || s.mountType === 'horse') {
                        g3d03lKey = 'g3d03l:european_curassier:high';
                    } else if (s.combatRole === 'musketeer' || s.activeWeapon === 'musket') {
                        g3d03lKey = 'g3d03l:european_musketier:high';
                    } else {
                        g3d03lKey = 'g3d03l:european_pikeniere:high';
                    }
                }
                const templateKey = s.templateKey || g3d03lKey;

                soldiers.push({
                    viewId: `${activeSector.sectorId}:${s.id}`,
                    sectorId: activeSector.sectorId,
                    side,
                    templateKey,
                    groupId: s.groupId,
                    soldierId: s.id,
                    unitClass: s.unitClass,
                    combatRole: s.combatRole,
                    bodyType: s.bodyType,
                    mountType: s.mountType,
                    activeWeapon: s.activeWeapon,
                    weaponLoadout: [...s.weaponLoadout],
                    armorLoadout: [...s.armorLoadout],
                    state: s.state,
                    hp: s.hp,
                    position: {
                        x: s.position.x,
                        y: s.position.y,
                        z: s.position.z
                    }
                });
            }'''

assert old_proj_loop in html, "Could not find old_proj_loop in html"
html = html.replace(old_proj_loop, new_proj_loop, 1)

# 6. Update RTSCamera3D to support targetY and close inspection"""

assert old_project_hook in code, "old_project_hook not found"
code = code.replace(old_project_hook, new_project_hook, 1)

# 7. Update UI Strings (78 -> 84)
code = code.replace("Geliştirici (78 Test)", "Geliştirici (84 Test)")
code = code.replace("Test Paneli (78 / 78 Test)", "Test Paneli (84 / 84 Test)")
code = code.replace("78 / 78 Doğrulama Testi", "84 / 84 Doğrulama Testi")
code = code.replace("78 Birim Testini Çalıştır", "84 Birim Testini Çalıştır")

# 8. Add Tests 79 to 84 to the test runner
tests_79_84_code = '''
            // ============================================================================
            // G3D-03L ASKER GÖRSEL KALİTESİ 2.0 DOĞRULAMA TESTLERİ (79 - 84)
            // ============================================================================

            // 79. Ajan 01: Anatomik El ve Silah Kavrama Doğrulaması (Avuç, Başparmak ve 4 Kıvrık Parmak)
            runCase('79. Anatomik El ve Silah Kavrama Doğrulaması (Avuç, Başparmak ve 4 Kıvrık Parmak)', () => {
                assert(typeof buildAnatomicalHandGrip === 'function', 'buildAnatomicalHandGrip fonksiyonu tanımlı olmalı');
                const stockHand = buildAnatomicalHandGrip('skin', 0, 0, 0, 'rightArmWeapon', 'musket_stock', false);
                assert(Array.isArray(stockHand) && stockHand.length >= 4, 'Tüfek dipçiğini kavrayan el en az 4 anatomik parçadan oluşmalı');
                const hasThumb = stockHand.some(p => p.prim === 'frustum');
                const hasKnuckles = stockHand.some(p => p.prim === 'cylinder');
                assert(hasThumb && hasKnuckles, 'Başparmak ve kıvrık parmak boğumları mevcut olmalı');

                const forestockHand = buildAnatomicalHandGrip('skin', 0, 0, 0, 'leftArmWeapon', 'musket_forestock', true);
                assert(Array.isArray(forestockHand) && forestockHand.length >= 4, 'Kundağı alttan kavrayan sol el en az 4 parçaya sahip olmalı');
            });

            // 80. Ajan 02: Boşluksuz Mafsal Geçişli Anatomik Kol ve Omuz Geometrisi
            runCase('80. Boşluksuz Mafsal Geçişli Anatomik Kol ve Omuz Geometrisi', () => {
                assert(typeof buildAnatomicalArmWithHand === 'function', 'buildAnatomicalArmWithHand fonksiyonu tanımlı olmalı');
                const rightMusketArm = buildAnatomicalArmWithHand('playerCloth', 'skin', false, 'musket');
                assert(Array.isArray(rightMusketArm) && rightMusketArm.length >= 8, 'Anatomik kol ve el birleşimi en az 8 parçadan oluşmalı');
                const hasDeltoid = rightMusketArm.some(p => p.prim === 'sphere' && p.rigGroup === 'rightArmWeapon');
                const hasElbow = rightMusketArm.some(p => p.prim === 'dome' && p.rigGroup === 'rightArmWeapon');
                const hasCuff = rightMusketArm.some(p => p.mat === 'linen' && p.rigGroup === 'rightArmWeapon');
                assert(hasDeltoid && hasElbow && hasCuff, 'Deltoid omuz kubbesi, dirsek mafsalı ve keten manşet mevcut olmalı');
            });

            // 81. Ajan 03: Fitilli Musket 3D Geometrisi ve Çift El Tutuş Hizalaması
            runCase('81. Fitilli Musket 3D Geometrisi ve Çift El Tutuş Hizalaması', () => {
                assert(typeof buildHighDefMatchlockMusket === 'function', 'buildHighDefMatchlockMusket fonksiyonu tanımlı olmalı');
                const musket = buildHighDefMatchlockMusket();
                assert(Array.isArray(musket) && musket.length >= 7, 'Fitilli musket modeli en az 7 detay parçasına sahip olmalı');
                const hasStock = musket.some(p => p.mat === 'wood' && p.prim === 'frustum');
                const hasBarrel = musket.some(p => (p.mat === 'damascusSteel' || p.mat === 'steel') && p.prim === 'cylinder');
                const hasSerpentine = musket.some(p => p.mat === 'steel' || p.mat === 'burnishedBronze');
                assert(hasStock && hasBarrel && hasSerpentine, 'Ahşap dipçik, çelik namlu ve fitil mekanizması mevcut olmalı');
            });

            // 82. Ajan 04: 1650 Türk Yatağanı ve 4.5m Tercio Pikesi Geometrisi
            runCase('82. 1650 Türk Yatağanı ve 4.5m Tercio Pikesi Geometrisi', () => {
                assert(typeof buildHighDefPike === 'function', 'buildHighDefPike tanımlı olmalı');
                assert(typeof buildHighDefYatagan === 'function', 'buildHighDefYatagan tanımlı olmalı');
                const pike = buildHighDefPike();
                const yatagan = buildHighDefYatagan();
                assert(pike.length >= 4, 'Pike şaft, kargı ucu ve langet şeritlerine sahip olmalı');
                const hasStaff = pike.some(p => p.mat === 'wood');
                const hasSpearhead = pike.some(p => p.mat === 'steel' && p.prim === 'cone');
                assert(hasStaff && hasSpearhead, 'Ahşap uzun şaft ve çelik uç bulunmalı');

                assert(yatagan.length >= 4, 'Yatağan kulaklı kabza ve içe kavisli namluya sahip olmalı');
                const hasCurvedBlade = yatagan.some(p => p.mat === 'damascusSteel');
                assert(hasCurvedBlade, 'Şam çeliği namlu mevcut olmalı');
            });

            // 83. Ajan 05: Gelişmiş Savaş Atı ve Süvari Anatomisi
            runCase('83. Gelişmiş Savaş Atı ve Süvari Anatomisi', () => {
                assert(typeof buildHighDefWarhorse === 'function', 'buildHighDefWarhorse fonksiyonu tanımlı olmalı');
                const horse = buildHighDefWarhorse('heavy_warhorse');
                assert(Array.isArray(horse) && horse.length >= 20, 'Gelişmiş savaş atı en az 20 parçadan oluşmalı');
                const hasBarrel = horse.some(p => p.prim === 'cylinder' && p.rigGroup === 'torso');
                const hasNeck = horse.some(p => p.prim === 'frustum' && p.rigGroup === 'torso');
                const hasStirrups = horse.some(p => p.mat === 'burnishedBronze');
                const hasHorseshoes = horse.some(p => p.mat === 'steel');
                assert(hasBarrel && hasNeck && hasStirrups && hasHorseshoes, 'Gövde, kavisli boyun, üzengiler ve çelik nallar mevcut olmalı');
            });

            // 84. Ajan 06: Savaş Alanı 300 Askerin Tamamının G3D-03L 2.0 Modellerine Bağlanması
            runCase('84. Savaş Alanı 300 Askerin Tamamının G3D-03L 2.0 Modellerine Bağlanması', () => {
                const be = window.focBattleEngine;
                assert(be && be.controller && be.controller.sectorManager, 'SectorManager mevcut olmalı');
                const snap = projectActiveSector3D(be.controller.sectorManager);
                assert(snap.soldiers.length > 0, 'Savaş alanında askerler bulunmalı');
                const allG3D03L = snap.soldiers.every(s => s.templateKey && s.templateKey.startsWith('g3d03l:'));
                assert(allG3D03L, 'Savaş alanındaki tüm askerler G3D-03L 2.0 yüksek detaylı şablonlarına atanmış olmalı');
            });
'''

old_test_end = """                const coordsEdge = be.minimapNormalizedToWorld(1.0, 1.0);
                assert(coordsEdge.x > 50 && coordsEdge.z > 50, 'Minimap köşesi dünya sınırlarına doğru orantılanmalı');
            });"""

new_test_end = old_test_end + '\n' + tests_79_84_code

assert old_test_end in code, "old_test_end not found in code"
code = code.replace(old_test_end, new_test_end, 1)

# 9. Output files: G3D03L_WORKING.html, FallOfCavalry_PLAYABLE_RTS.html, G3D03K_WORKING.html
old_write = """with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(html)

with open('FallOfCavalry_PLAYABLE_RTS.html', 'w', encoding='utf-8') as f:
    f.write(html)

print(f"Successfully generated clean Playable RTS: G3D03K_WORKING.html ({len(html)} bytes) and FallOfCavalry_PLAYABLE_RTS.html.")"""

new_write = """with open('G3D03L_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(html)

with open('FallOfCavalry_PLAYABLE_RTS.html', 'w', encoding='utf-8') as f:
    f.write(html)

with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(html)

print(f"Successfully generated clean Playable RTS: G3D03L_WORKING.html, FallOfCavalry_PLAYABLE_RTS.html ({len(html)} bytes).")"""

assert old_write in code, "old_write not found in code"
code = code.replace(old_write, new_write, 1)

with open('tools/build_playable_rts.py', 'w', encoding='utf-8') as f:
    f.write(code)

print("tools/build_playable_rts.py successfully upgraded for G3D-03L.")
