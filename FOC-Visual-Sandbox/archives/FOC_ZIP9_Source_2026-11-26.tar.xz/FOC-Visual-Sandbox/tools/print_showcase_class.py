# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

start = text.find('class RTSUnitShowcaseController')
end = text.find('class Battle3DPreviewController', start)
print(text[start:end])
