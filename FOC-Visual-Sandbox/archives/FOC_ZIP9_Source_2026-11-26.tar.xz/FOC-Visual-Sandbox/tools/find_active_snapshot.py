# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('getActiveSnapshot')
if idx != -1:
    print(text[idx-50:idx+350])
else:
    idx2 = text.find('sectorManager.get')
    print("get in sectorManager:", text[idx2-50:idx2+350] if idx2 != -1 else "NOT FOUND")
