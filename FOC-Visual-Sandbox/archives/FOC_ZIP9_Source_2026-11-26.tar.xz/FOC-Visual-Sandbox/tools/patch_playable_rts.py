with open('tools/build_playable_rts.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Camera in open()
old_cam = """                    cam.desired.targetX = 0;
                    cam.desired.targetY = 0.95;
                    cam.desired.targetZ = 0;
                    cam.desired.distance = 3.2;
                    cam.desired.pitch = 0.20;
                    cam.desired.yaw = 0.35;
                    cam.current.targetX = 0;
                    cam.current.targetY = 0.95;
                    cam.current.targetZ = 0;
                    cam.current.distance = 3.2;
                    cam.current.pitch = 0.20;
                    cam.current.yaw = 0.35;"""

new_cam = """                    cam.desired.targetX = 0;
                    cam.desired.targetY = 1.10;
                    cam.desired.targetZ = 0;
                    cam.desired.distance = 3.6;
                    cam.desired.pitch = 0.16;
                    cam.desired.yaw = Math.PI - 0.25;
                    cam.current.targetX = 0;
                    cam.current.targetY = 1.10;
                    cam.current.targetZ = 0;
                    cam.current.distance = 3.6;
                    cam.current.pitch = 0.16;
                    cam.current.yaw = Math.PI - 0.25;"""

assert old_cam in text, "old_cam not found"
text = text.replace(old_cam, new_cam, 1)

# 2. Camera & side in syncShowcaseSoldiers()
old_sync_soldier = """                if (!this.compareMode) {
                    const tplKey = getTpl(this.currentCulture, currentUnit.key, this.selectedVariant);
                    soldiers.push({
                        viewId: 'SHOWCASE:U1',
                        soldierId: 'sc1',
                        side: isOttoman ? 'player' : 'enemy',"""

new_sync_soldier = """                const isCav = isCavalry(currentUnit.key);
                const cam = rndr.cameraController;
                if (cam && this.isOpen) {
                    cam.desired.targetX = 0;
                    cam.desired.targetY = isCav ? 1.30 : 1.10;
                    cam.desired.targetZ = 0;
                    cam.desired.distance = isCav ? 5.8 : 3.6;
                    cam.desired.yaw = Math.PI - 0.25;
                    cam.desired.pitch = isCav ? 0.20 : 0.16;
                    cam.current.targetX = 0;
                    cam.current.targetY = cam.desired.targetY;
                    cam.current.targetZ = 0;
                    cam.current.distance = cam.desired.distance;
                    cam.current.yaw = cam.desired.yaw;
                    cam.current.pitch = cam.desired.pitch;
                }

                if (!this.compareMode) {
                    const tplKey = getTpl(this.currentCulture, currentUnit.key, this.selectedVariant);
                    soldiers.push({
                        viewId: 'SHOWCASE:U1',
                        soldierId: 'sc1',
                        side: (this.currentCulture === 'european' && currentUnit.key === 'musketier') ? 'player' : (isOttoman ? 'player' : 'enemy'),"""

assert old_sync_soldier in text, "old_sync_soldier not found"
text = text.replace(old_sync_soldier, new_sync_soldier, 1)

# 3. Info card template key
old_card_tpl = "<div>Şablon Anahtarı: <strong>${currentUnit.template}:v${this.selectedVariant}</strong></div>"
new_card_tpl = "<div>Şablon Anahtarı: <strong>${this.qualityMode === 'high' ? ('g3d03l:' + this.currentCulture + '_' + currentUnit.key + ':high') : (currentUnit.template + ':v' + this.selectedVariant)}</strong></div>"

assert old_card_tpl in text, "old_card_tpl not found"
text = text.replace(old_card_tpl, new_card_tpl, 1)

with open('tools/build_playable_rts.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("Updated tools/build_playable_rts.py successfully!")
