with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = [m.start() for m in re.finditer(r'\b(damage|hp|alive|takeDamage|attackTarget)\b', text, re.I)]
print("Total occurrences of combat keywords:", len(matches))
for m in matches[:15]:
    print('--- at', m)
    print(text[m-40:m+80])
