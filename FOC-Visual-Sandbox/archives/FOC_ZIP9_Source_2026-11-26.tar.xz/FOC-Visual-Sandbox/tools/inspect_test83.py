with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find("83. Gelişmiş Savaş Atı")
if idx != -1:
    print(text[idx-50:idx+1200])
else:
    print("Test 83 not found")
