# -*- coding: utf-8 -*-
import subprocess
import tempfile
import os

profile_dir = tempfile.mkdtemp(prefix='foc_test_debug_')
html_path = os.path.abspath('G3D03K_WORKING.html')
cmd = [
    r'C:\Program Files\Google\Chrome\Application\chrome.exe',
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={profile_dir}',
    '--enable-logging=stderr',
    '--v=1',
    '--dump-dom',
    f'file:///{html_path.replace(os.sep, "/")}#tests'
]

print("Running command...")
try:
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
    print("Return code:", res.returncode)
    print("Stdout length:", len(res.stdout))
    idx = res.stdout.find('id="test-results"')
    if idx != -1:
        print("test-results:", res.stdout[idx:idx+300])
    else:
        print("test-results NOT FOUND")
        print("Stdout snippet:", res.stdout[:500])
    print("Stderr:", res.stderr[:500])
except subprocess.TimeoutExpired as e:
    print("TIMEOUT after 15s!")
    if e.stdout:
        print("Stdout:", e.stdout[:500])
    if e.stderr:
        print("Stderr:", e.stderr[:500])
