with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('this.renderer = new Battle3DRenderer({')
print(text[pos+400:pos+1500])
