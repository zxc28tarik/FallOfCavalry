with open('tools/run_headless_test.py', 'r', encoding='utf-8') as f:
    print(f.read())
