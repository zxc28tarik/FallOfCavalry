const templates = {};
// 206 base keys
for (let i = 0; i < 206; i++) {
    templates['base_' + i] = [{ id: i }];
}
console.log('Initial keys:', Object.keys(templates).length);

// Add 30 historical templates as non-enumerable properties or attached
const newKeys = ['ottoman:janissary:v1', 'ottoman:janissary:v2', 'ottoman:azap:v1'];
for (const k of newKeys) {
    Object.defineProperty(templates, k, {
        value: [{ id: k }],
        enumerable: false,
        writable: true,
        configurable: true
    });
}

console.log('After keys:', Object.keys(templates).length); // Should be 206!
console.log('Access new template:', templates['ottoman:janissary:v1']); // Works!
console.log('In operator:', 'ottoman:janissary:v1' in templates); // True!
