with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find("european: [")
if idx != -1:
    print(text[idx:idx+1500])
