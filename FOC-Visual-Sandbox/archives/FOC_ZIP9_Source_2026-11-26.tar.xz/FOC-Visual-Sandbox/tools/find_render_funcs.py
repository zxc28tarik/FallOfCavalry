with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
for m in re.finditer(r'function (\w*Render\w*|\w*Queue\w*|\w*Soldier\w*)', text):
    print(m.group(0))
