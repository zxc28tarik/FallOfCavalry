with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = re.findall(r"['\"](\d+)\.\s+([^'\"]+)['\"]", text)
print('Total tests found:', len(matches))
for num, name in matches:
    if any(k in name.lower() for k in ['şablon', 'template', '206', 'g3d03', 'görsel', 'model', 'asker']):
        print(f'{num}. {name}')
