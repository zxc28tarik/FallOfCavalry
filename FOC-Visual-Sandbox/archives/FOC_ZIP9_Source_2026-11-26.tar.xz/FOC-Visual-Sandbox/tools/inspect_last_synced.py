with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('sync(snapshot) {')
print(text[pos:pos+300])
