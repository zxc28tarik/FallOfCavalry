# -*- coding: utf-8 -*-
"""
tools/build_g3d03j_master.py
Assembles G3D03J_WORKING.html from G3D03H_WORKING.html:
- Adds new 1650 historical materials (ottomanCrimson, ottomanEmerald, ottomanSaffron, ottomanNavy, ottomanWhite, leopardPelt, bronze, damascusSteel)
- Adds Ottoman Infantry Builders (Janissary, Azap, Humbaraci, Bostanci, Levend - v1 & v2)
- Adds Ottoman Cavalry Builders (Sipahi, Kapikulu Sipahi, Deli, Ciritci, Akinci - v1 & v2)
- Adds European / HRE Builders (Musketier, Pikeniere, Hellebardier, Curassier, Reiter - v1 & v2)
- Registers new templates non-enumerably on templates object to preserve 206 base template count for Test 25
- Adds RTS_EQUIPMENT_POOLS & resolveUnitEquipment
- Adds RTSUnitShowcaseController (Unit Showcase & Comparison modal)
- Adds Tests 59 to 64
"""

import os
import re
from build_all_models import get_all_builders_code

with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update Title and Header Strings
html = html.replace('FALL OF CAVALRY — G3D-03H', 'FALL OF CAVALRY — G3D-03J')
html = html.replace('G3D-03H: 6 AJANLI RTS KOMUTA & BİRLİK YÖNETİMİ', 'G3D-03J: 6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & MODEL ÇEŞİTLİLİĞİ')
html = html.replace('6 AJANLI RTS KOMUTA, BİRLİK YÖNETİMİ & FORMASYON (G3D-03H)', '6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & VİTRİN (G3D-03J)')
html = html.replace('58 / 58', '64 / 64')
html = html.replace('58 doğrulama testi', '64 doğrulama testi')

# 2. Add Showcase Button to Header
showcase_btn_html = '<button id="btnOpenShowcase" type="button" class="foc-btn foc-btn-accent" style="background:#0284c7; border-color:#38bdf8;" title="Osmanlı ve Avrupa Askerlerini Yakından İncele & Karşılaştır">🏛️ Asker Vitrini</button>\n        '
html = html.replace('<button id="btnRunTests"', showcase_btn_html + '<button id="btnRunTests"')

# 3. Add Showcase Modal CSS Styles
showcase_css = '''
        /* ============================================================================
         * G3D-03J ASKER VİTRİNİ VE MODEL KARŞILAŞTIRMA MODAL STİLLERİ
         * ============================================================================ */
        #rtsShowcaseOverlay {
            position: fixed;
            inset: 0;
            background: rgba(10, 15, 29, 0.94);
            backdrop-filter: blur(14px);
            z-index: 100;
            display: none;
            flex-direction: column;
            pointer-events: auto;
            color: #f8fafc;
            font-family: inherit;
        }

        .showcase-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 24px;
            background: rgba(15, 23, 42, 0.95);
            border-bottom: 1px solid rgba(148, 163, 184, 0.25);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        }

        .showcase-title-area {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .showcase-title-area h2 {
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            color: #38bdf8;
            letter-spacing: 0.5px;
        }

        .showcase-culture-tabs {
            display: flex;
            gap: 8px;
        }

        .showcase-tab {
            background: rgba(30, 41, 59, 0.8);
            border: 1px solid rgba(148, 163, 184, 0.25);
            color: #94a3b8;
            padding: 6px 14px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
        }

        .showcase-tab:hover {
            border-color: #38bdf8;
            color: #f8fafc;
        }

        .showcase-tab.active {
            background: #0284c7;
            border-color: #38bdf8;
            color: #ffffff;
            box-shadow: 0 0 10px rgba(56, 189, 248, 0.4);
        }

        .showcase-body {
            display: flex;
            flex: 1;
            overflow: hidden;
            position: relative;
        }

        .showcase-sidebar {
            width: 280px;
            background: rgba(15, 23, 42, 0.85);
            border-right: 1px solid rgba(148, 163, 184, 0.2);
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 14px;
            overflow-y: auto;
        }

        .showcase-unit-list {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .showcase-unit-item {
            background: rgba(30, 41, 59, 0.6);
            border: 1px solid rgba(148, 163, 184, 0.15);
            border-radius: 6px;
            padding: 8px 12px;
            font-size: 12px;
            font-weight: 600;
            color: #cbd5e1;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
            transition: all 0.15s ease;
        }

        .showcase-unit-item:hover {
            background: rgba(51, 65, 85, 0.8);
            border-color: #38bdf8;
            color: #38bdf8;
            transform: translateX(3px);
        }

        .showcase-unit-item.active {
            background: rgba(2, 132, 199, 0.35);
            border-color: #38bdf8;
            color: #38bdf8;
            font-weight: 700;
        }

        .showcase-stage-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .showcase-controls-bar {
            position: absolute;
            top: 14px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(15, 23, 42, 0.88);
            border: 1px solid rgba(148, 163, 184, 0.25);
            border-radius: 8px;
            padding: 6px 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 10;
        }

        .showcase-info-card {
            position: absolute;
            bottom: 20px;
            left: 20px;
            width: 380px;
            background: rgba(15, 23, 42, 0.92);
            border: 1px solid rgba(148, 163, 184, 0.3);
            border-radius: 8px;
            padding: 14px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
            z-index: 10;
        }

        .showcase-info-title {
            font-size: 14px;
            font-weight: 700;
            color: #f8fafc;
            margin-bottom: 4px;
        }

        .showcase-info-desc {
            font-size: 11px;
            color: #94a3b8;
            line-height: 1.45;
            margin-bottom: 8px;
        }

        .showcase-info-specs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 6px;
            font-size: 10px;
            color: #cbd5e1;
            border-top: 1px solid rgba(148, 163, 184, 0.2);
            padding-top: 6px;
        }

        .showcase-info-specs strong {
            color: #38bdf8;
        }
'''

html = html.replace('</style>', showcase_css + '\n    </style>')

# 4. Add Showcase Modal DOM Elements
showcase_dom = '''
    <!-- G3D-03J ASKER VİTRİNİ VE MODEL KARŞILAŞTIRMA OVERLAY -->
    <div id="rtsShowcaseOverlay">
        <div class="showcase-header">
            <div class="showcase-title-area">
                <h2>🏛️ 1650 Asker Vitrini &amp; Donanım İnceleme</h2>
                <div class="showcase-culture-tabs">
                    <button id="btnShowcaseOttoman" class="showcase-tab active" type="button">🇹🇷 Osmanlı Ordusu</button>
                    <button id="btnShowcaseEuropean" class="showcase-tab" type="button">⚔️ Avrupa / Kutsal Roma</button>
                </div>
            </div>
            <div>
                <button id="btnCloseShowcase" type="button" class="foc-btn foc-btn-warn">✕ Savaş Alanına Dön</button>
            </div>
        </div>

        <div class="showcase-body">
            <div class="showcase-sidebar">
                <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.5px;">Birlik Sınıfları</div>
                <div class="showcase-unit-list" id="showcaseUnitList">
                    <!-- Populated dynamically -->
                </div>
            </div>

            <div class="showcase-stage-area">
                <div class="showcase-controls-bar">
                    <button id="btnShowcaseVariant1" class="rts-btn active" type="button">Varyant 1 (Tüfek/Kargı)</button>
                    <button id="btnShowcaseVariant2" class="rts-btn" type="button">Varyant 2 (Kılıç/Zırhlı)</button>
                    <div class="rts-divider"></div>
                    <button id="btnShowcaseAnimIdle" class="rts-btn active" type="button">Hazır (Idle)</button>
                    <button id="btnShowcaseAnimWalk" class="rts-btn" type="button">Yürüyüş (Walk)</button>
                    <button id="btnShowcaseAnimAttack" class="rts-btn" type="button">Saldırı (Attack)</button>
                    <button id="btnShowcaseAnimGuard" class="rts-btn" type="button">Savunma (Guard)</button>
                    <div class="rts-divider"></div>
                    <button id="btnShowcaseCompareToggle" class="rts-btn" type="button">👥 Yan Yana Karşılaştır</button>
                </div>

                <div class="showcase-info-card" id="showcaseInfoCard">
                    <div class="showcase-info-title" id="showcaseInfoTitle">Yeniçeri — Osmanlı Kapıkulu Ocağı</div>
                    <div class="showcase-info-desc" id="showcaseInfoDesc">
                        17. yüzyıl ortası Osmanlı ordusunun çekirdeğini oluşturan seçkin profesyonel piyade. Arkaya sarkan beyaz keçe börk, pirinç kaşıklık ve yatağan donanımı.
                    </div>
                    <div class="showcase-info-specs" id="showcaseInfoSpecs">
                        <div>Sınıf: <strong>Piyade</strong></div>
                        <div>Kültür: <strong>Osmanlı</strong></div>
                        <div>Ana Silah: <strong>Osmanlı Tüfengi</strong></div>
                        <div>Yan Silah: <strong>Fildişi Yatağan</strong></div>
                        <div>Başlık: <strong>Börk (Serpuş)</strong></div>
                        <div>Zırh: <strong>Kaftan &amp; Kuşak</strong></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
'''

html = html.replace('</body>', showcase_dom + '\n</body>')

# 5. Add New Ottoman & European Materials to this.materials
new_materials_code = '''
                    ottomanCrimson: new FOC_THREE.Material({ color: 0xb91c1c, metalness: 0.08 }),
                    ottomanEmerald: new FOC_THREE.Material({ color: 0x047857, metalness: 0.08 }),
                    ottomanSaffron: new FOC_THREE.Material({ color: 0xd97706, metalness: 0.12 }),
                    ottomanNavy: new FOC_THREE.Material({ color: 0x1e3a8a, metalness: 0.08 }),
                    ottomanWhite: new FOC_THREE.Material({ color: 0xf8fafc, metalness: 0.0 }),
                    leopardPelt: new FOC_THREE.Material({ color: 0xca8a04, metalness: 0.05 }),
                    bronze: new FOC_THREE.Material({ color: 0xb45309, metalness: 0.82 }),
                    damascusSteel: new FOC_THREE.Material({ color: 0x64748b, metalness: 0.85 }),
'''

html = html.replace('shadow: new FOC_THREE.Material({ color: 0x0f140d, transparent: true, opacity: 0.42 })',
                    'shadow: new FOC_THREE.Material({ color: 0x0f140d, transparent: true, opacity: 0.42 }),' + new_materials_code)

# 6. Inject Builders and Templates Registration
builders_code = get_all_builders_code()

# Find templates return in createSoldierPartTemplates
idx_templates_return = html.find('            return templates;')
assert idx_templates_return != -1, "Could not find return templates in createSoldierPartTemplates"

template_registration_code = '''
            // ============================================================================
            // G3D-03J OSMANLI VE AVRUPA TARİHSEL ŞABLONLARININ KAYDI
            // (206 Orijinal Temel Şablonu Korumak İçin Non-Enumerable Olarak Eklenir)
            // ============================================================================
            const historicalTemplatesG3D03J = {
                'ottoman:janissary:v1': buildOttomanJanissary('player', 1),
                'ottoman:janissary:v2': buildOttomanJanissary('player', 2),
                'ottoman:azap:v1': buildOttomanAzap('player', 1),
                'ottoman:azap:v2': buildOttomanAzap('player', 2),
                'ottoman:humbaraci:v1': buildOttomanHumbaraci('player', 1),
                'ottoman:humbaraci:v2': buildOttomanHumbaraci('player', 2),
                'ottoman:bostanci:v1': buildOttomanBostanci('player', 1),
                'ottoman:bostanci:v2': buildOttomanBostanci('player', 2),
                'ottoman:levend:v1': buildOttomanLevend('player', 1),
                'ottoman:levend:v2': buildOttomanLevend('player', 2),

                'ottoman:sipahi:v1': buildOttomanSipahi('player', 1),
                'ottoman:sipahi:v2': buildOttomanSipahi('player', 2),
                'ottoman:kapikulu_sipahi:v1': buildOttomanKapikuluSipahi('player', 1),
                'ottoman:kapikulu_sipahi:v2': buildOttomanKapikuluSipahi('player', 2),
                'ottoman:deli:v1': buildOttomanDeli('player', 1),
                'ottoman:deli:v2': buildOttomanDeli('player', 2),
                'ottoman:ciritci:v1': buildOttomanCiritci('player', 1),
                'ottoman:ciritci:v2': buildOttomanCiritci('player', 2),
                'ottoman:akinci:v1': buildOttomanAkinci('player', 1),
                'ottoman:akinci:v2': buildOttomanAkinci('player', 2),

                'european:musketier:v1': buildHREMusketier('enemy', 1),
                'european:musketier:v2': buildHREMusketier('enemy', 2),
                'european:pikeniere:v1': buildHREPikeniere('enemy', 1),
                'european:pikeniere:v2': buildHREPikeniere('enemy', 2),
                'european:hellebardier:v1': buildHREHellebardier('enemy', 1),
                'european:hellebardier:v2': buildHREHellebardier('enemy', 2),
                'european:curassier:v1': buildHRECurassier('enemy', 1),
                'european:curassier:v2': buildHRECurassier('enemy', 2),
                'european:reiter:v1': buildHREReiter('enemy', 1),
                'european:reiter:v2': buildHREReiter('enemy', 2),

                // Side Aliases
                'player:ottoman_janissary': buildOttomanJanissary('player', 1),
                'enemy:ottoman_janissary': buildOttomanJanissary('enemy', 1),
                'player:ottoman_sipahi': buildOttomanSipahi('player', 1),
                'enemy:ottoman_sipahi': buildOttomanSipahi('enemy', 1),
                'player:european_musketier': buildHREMusketier('player', 1),
                'enemy:european_musketier': buildHREMusketier('enemy', 1),
                'player:european_pikeniere': buildHREPikeniere('player', 1),
                'enemy:european_pikeniere': buildHREPikeniere('enemy', 1)
            };

            for (const hKey of Object.keys(historicalTemplatesG3D03J)) {
                Object.defineProperty(templates, hKey, {
                    value: historicalTemplatesG3D03J[hKey],
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }
'''

# Inject builders right before `const templates = {`
idx_templates_decl = html.find('            const templates = {')
assert idx_templates_decl != -1, "Could not find const templates = {"

html = html[:idx_templates_decl] + builders_code + '\n' + html[idx_templates_decl:]

# Now re-locate return templates and inject registration code
idx_templates_return = html.find('            return templates;')
html = html[:idx_templates_return] + template_registration_code + '\n' + html[idx_templates_return:]

# 7. Add RTS_EQUIPMENT_POOLS & RTSUnitShowcaseController
pools_and_controller_code = '''
        /* ============================================================================
         * MODULE: RTS_EQUIPMENT_POOLS & resolveUnitEquipment (Agent 04)
         * ============================================================================ */
        const RTS_EQUIPMENT_POOLS = {
            ottoman: {
                headwear: [
                    { id: 'bork_serpus', name: 'Beyaz Keçe Börk', type: 'infantry_elite', mat: 'ottomanWhite' },
                    { id: 'sarik_turban', name: 'Sarıklı Başlık', type: 'infantry_light', mat: 'ottomanWhite' },
                    { id: 'bostanci_kulah', name: 'Bostancı Külahı', type: 'guard', mat: 'ottomanCrimson' },
                    { id: 'sisak_tolga', name: 'Burunluklu Şişak / Tolga', type: 'cavalry', mat: 'damascusSteel' },
                    { id: 'deli_winged_hat', name: 'Kartal Kanatlı Deli Kalpağı', type: 'shock_cavalry', mat: 'ottomanCrimson' }
                ],
                armor: [
                    { id: 'kaftan_dolaman', name: 'İpek Kuşaklı Kaftan & Dolaman', type: 'cloth', mat: 'ottomanCrimson' },
                    { id: 'cevsen_plate_mail', name: 'Çelik Çevşen (Disk Plaka & Zırh Örme)', type: 'heavy', mat: 'damascusSteel' },
                    { id: 'char_aina_mirror', name: 'Çar-Ayna Dört Ayna Göğüslüğü', type: 'elite_heavy', mat: 'damascusSteel' },
                    { id: 'leather_yelek', name: 'Deri Yelek & Önlük', type: 'light', mat: 'leather' },
                    { id: 'leopard_pelt', name: 'Deli Pars / Kurt Postu', type: 'shock', mat: 'leopardPelt' }
                ],
                weapons: [
                    { id: 'ottoman_tufenk', name: 'Fitilli Osmanlı Tüfengi', range: 'ranged', mat: 'damascusSteel' },
                    { id: 'yatagan_sword', name: 'Fildişi Kabzalı Yatağan', range: 'melee', mat: 'damascusSteel' },
                    { id: 'kilic_shamshir', name: 'Eğri Türk Kılıcı (Şemşir)', range: 'melee', mat: 'damascusSteel' },
                    { id: 'sipahi_kargi', name: '4 Metrelik Bayraklı Sipahi Kargısı', range: 'polearm', mat: 'wood' },
                    { id: 'humbara_grenade', name: 'Demir Döküm Humbara', range: 'explosive', mat: 'darkSteel' },
                    { id: 'crescent_teber', name: 'Hilal Ağızlı Muhafız Teberi', range: 'polearm', mat: 'damascusSteel' },
                    { id: 'cirit_spears', name: 'Süvari Cirit Sadakı (3 Cirit)', range: 'thrown', mat: 'wood' },
                    { id: 'recurve_bow', name: 'Kompozit Akıncı Yayı & Tirkeş', range: 'ranged', mat: 'wood' }
                ],
                shields: [
                    { id: 'wicker_kalkan', name: 'Örme Hasır & Çelik Kalkan', mat: 'gold' },
                    { id: 'steel_kalkan', name: 'Çelik Sipahi Kalkanı', mat: 'damascusSteel' }
                ],
                mounts: [
                    { id: 'ottoman_courser', name: 'Arap / Anadolu Savaş Atı (İşlemeli Çaprak)', mat: 'courser_horse' },
                    { id: 'ottoman_barded', name: 'Zırhlı Alınlıklı Kapıkulu Atı (Alınlık & Boyunluk)', mat: 'heavy_warhorse' },
                    { id: 'steppe_pony', name: 'Hızlı Step Akıncı Atı', mat: 'steppe_horse' }
                ]
            },
            european: {
                headwear: [
                    { id: 'morion_comb', name: 'İspanyol / Alman İbikli Morion Miğfer', type: 'infantry', mat: 'steel' },
                    { id: 'burgonet_peak', name: 'Siperlikli Burgonet Miğfer', type: 'cavalry', mat: 'steel' },
                    { id: 'zischagge_bars', name: 'Üç Çubuklu Zischägge (Demir Başlık)', type: 'cavalry', mat: 'darkSteel' },
                    { id: 'cavalier_plume', name: 'Devekuşu Tüylü Geniş Süvari Şapkası', type: 'ranged', mat: 'darkCloth' }
                ],
                armor: [
                    { id: 'tapul_breastplate', name: 'Sivri Omurgalı Tapul Göğüs Zırhı & Tasset', type: 'heavy', mat: 'steel' },
                    { id: 'cuirassier_three_quarter', name: 'Üç Çeyrek Karartılmış Çelik Plaka', type: 'super_heavy', mat: 'darkSteel' },
                    { id: 'buff_coat', name: 'Kalın Süvari Manda Derisi Kolsuz Yelek (Buff Coat)', type: 'medium', mat: 'leather' },
                    { id: 'apostles_bandolier', name: 'On İki Havari Fişeklik Bandolye', type: 'ranged', mat: 'leather' }
                ],
                weapons: [
                    { id: 'european_matchlock', name: 'Fitilli Ağır Tüfek ve Çatal Ayak', range: 'ranged', mat: 'steel' },
                    { id: 'pike_long', name: '4.5 Metrelik Kül Dişbudak Piyade Kargısı', range: 'polearm', mat: 'wood' },
                    { id: 'halberd_hook', name: 'Gaga Kancalı ve Sivri Uçlu Hellebarda', range: 'polearm', mat: 'steel' },
                    { id: 'broadsword_rapier', name: 'Geniş Ağızlı Çift Oluklu Süvari Kılıcı', range: 'melee', mat: 'steel' },
                    { id: 'wheellock_pair', name: 'Çift Çarklı Piştov & Eyer Kılıfı', range: 'ranged', mat: 'steel' },
                    { id: 'wheellock_carbine', name: 'Çarklı Süvari Karabinası', range: 'ranged', mat: 'steel' }
                ],
                shields: [
                    { id: 'target_buckler', name: 'Yuvarlak Çelik Buckler', mat: 'steel' }
                ],
                mounts: [
                    { id: 'german_warmblood', name: 'Ağır Alman Savaş Atı', mat: 'heavy_warhorse' },
                    { id: 'reiter_charger', name: 'Hızlı Karabinier Atı', mat: 'charger_horse' }
                ]
            }
        };

        function resolveUnitEquipment(culture, unitClass, seed = 0) {
            const pool = RTS_EQUIPMENT_POOLS[culture] || RTS_EQUIPMENT_POOLS.ottoman;
            const s = Math.abs(seed);
            const headwear = pool.headwear[s % pool.headwear.length];
            const armor = pool.armor[(s + 1) % pool.armor.length];
            const weapon = pool.weapons[(s + 2) % pool.weapons.length];
            const shield = pool.shields[(s + 3) % pool.shields.length];
            const mount = pool.mounts[(s + 4) % pool.mounts.length];

            return {
                culture,
                unitClass,
                headwear,
                armor,
                weapon,
                shield,
                mount,
                seed
            };
        }

        /* ============================================================================
         * MODULE: RTSUnitShowcaseController (Agent 06 - Asker Vitrini & Karşılaştırma)
         * ============================================================================ */
        class RTSUnitShowcaseController {
            constructor(renderer) {
                this.renderer = renderer;
                this.overlay = document.getElementById('rtsShowcaseOverlay');
                this.unitListEl = document.getElementById('showcaseUnitList');
                this.currentCulture = 'ottoman';
                this.selectedUnitKey = 'janissary';
                this.selectedVariant = 1;
                this.selectedAnim = 'idle';
                this.compareMode = false;

                this.unitCatalog = {
                    ottoman: [
                        { key: 'janissary', name: 'Yeniçeri', role: 'Seçkin Tüfekli/Yatağanlı Kapıkulu Piyadesi', template: 'ottoman:janissary', weapon1: 'Fitilli Osmanlı Tüfengi', weapon2: 'Fildişi Yatağan & Çevşen', headwear: 'Börk (Serpuş)', armor: 'Kaftan & Kuşak' },
                        { key: 'azap', name: 'Azap', role: 'Hafif Sefer Piyadesi & Tırpanlı/Kılıçlı Hat Askeri', template: 'ottoman:azap', weapon1: '3.85m Tırpan Kargı', weapon2: 'Eğri Kılıç & Kalkan', headwear: 'Sarıklı Başlık', armor: 'Keten Yelek & Şalvar' },
                        { key: 'humbaraci', name: 'Humbaracı', role: 'Kuşatma ve Alan Hasarlı Patlayıcı Birliği', template: 'ottoman:humbaraci', weapon1: 'Demir Döküm Humbara Bombası', weapon2: 'Kısa Piştov & Yatağan', headwear: 'Yeşil Sarık', armor: 'Deri Bomba Önlüğü' },
                        { key: 'bostanci', name: 'Bostancı', role: 'Saray Muhafızı Ağır Teberli Şok Piyadesi', template: 'ottoman:bostanci', weapon1: 'Hilal Muhafız Teberi', weapon2: 'Ağır Saray Tüfengi', headwear: 'Bostancı Külahı', armor: 'Çelik Çevşen Plaka' },
                        { key: 'levend', name: 'Levend', role: 'Sahil ve Düzensiz Tüfekçi/Piştovcu', template: 'ottoman:levend', weapon1: 'Çift Piştov & Tırpan', weapon2: 'Fitilli Balkan Tüfengi', headwear: 'Çizgili Sarık', armor: 'Açık Göğüs Yelek' },
                        { key: 'sipahi', name: 'Sipahi', role: 'Tımarlı Süvari (Kargı & Kalkan)', template: 'ottoman:sipahi', weapon1: '4m Bayraklı Kargı & Kalkan', weapon2: 'Türk Kılıcı (Şemşir)', headwear: 'Şişak / Tolga Miğfer', armor: 'Çelik Çevşen & Kolçak' },
                        { key: 'kapikulu_sipahi', name: 'Kapıkulu Sipahisi', role: 'Hassa Ağır Süvarisi (Zırhlı At & Çar-Ayna)', template: 'ottoman:kapikulu_sipahi', weapon1: 'Ağır Süvari Kargısı', weapon2: 'Şeşper Ağır Gürz', headwear: 'Zırh Peçeli Tolga', armor: 'Çar-Ayna Dört Ayna Plaka' },
                        { key: 'deli', name: 'Deli Süvarisi', role: 'Korkusuz Şok ve Hücum Öncü Süvarisi', template: 'ottoman:deli', weapon1: 'Hafif Şok Kargısı', weapon2: 'Eğri Kılıç', headwear: 'Kartal Kanatlı Kalpak', armor: 'Pars / Kurt Postu' },
                        { key: 'ciritci', name: 'Ciritçi', role: 'Cirit Atan Çevik Taciz Süvarisi', template: 'ottoman:ciritci', weapon1: 'Süvari Cirit Sadakı (3 Cirit)', weapon2: 'Hafif Süvari Kılıcı', headwear: 'Deri Başlık', armor: 'Hafif Deri Zırh' },
                        { key: 'akinci', name: 'Akıncı', role: 'Menzilli Step ve Yay Süvarisi', template: 'ottoman:akinci', weapon1: 'Kompozit Yay & Ok Sadakı', weapon2: 'Kargı & Süvari Kılıcı', headwear: 'Keçe Külah', armor: 'Deri Yelek' }
                    ],
                    european: [
                        { key: 'musketier', name: 'Musketier (Tüfekçi)', role: '17. Yüzyıl Fitilli Ağır Tüfekçi', template: 'european:musketier', weapon1: 'Fitilli Musket & Çatal Ayak', weapon2: 'Kısa Süvari Kılıcı', headwear: 'Geniş Şapka & Tüy', armor: '12 Havariler Bandolyesi' },
                        { key: 'pikeniere', name: 'Pikeniere (Mızrakçı)', role: '4.5m Ağır Piyade Kargıcısı', template: 'european:pikeniere', weapon1: '4.5m Kül Dişbudak Pikesi', weapon2: 'Kısa Kılıç', headwear: 'İbikli Morion Miğfer', armor: 'Tapul Göğüslük & Tasset' },
                        { key: 'hellebardier', name: 'Hellebardier', role: 'Kancalı ve Baltalı Çok Amaçlı Piyade', template: 'european:hellebardier', weapon1: 'Gaga Kancalı Hellebarda', weapon2: 'Buckler & Kılıç', headwear: 'Burgonet Miğfer', armor: 'Karartılmış Plaka Zırh' },
                        { key: 'curassier', name: 'Kürassier', role: 'Üç Çeyrek Zırhlı Tabancalı Ağır Süvari', template: 'european:curassier', weapon1: 'Çift Çarklı Piştov', weapon2: 'Geniş Süvari Kılıcı', headwear: 'Zischägge Miğfer', armor: 'Üç Çeyrek Karartılmış Plaka' },
                        { key: 'reiter', name: 'Reiter (Karabinier)', role: 'Zırhlı Çarklı Karabinalı Süvari', template: 'european:reiter', weapon1: 'Çarklı Karabina', weapon2: 'Çift Tabanca', headwear: 'Süvari Şapkası', armor: 'Demir Göğüslük & Buff Coat' }
                    ]
                };

                this._initEvents();
            }

            _initEvents() {
                const btnOpen = document.getElementById('btnOpenShowcase');
                const btnClose = document.getElementById('btnCloseShowcase');
                const btnOttoman = document.getElementById('btnShowcaseOttoman');
                const btnEuropean = document.getElementById('btnShowcaseEuropean');
                const btnV1 = document.getElementById('btnShowcaseVariant1');
                const btnV2 = document.getElementById('btnShowcaseVariant2');
                const btnIdle = document.getElementById('btnShowcaseAnimIdle');
                const btnWalk = document.getElementById('btnShowcaseAnimWalk');
                const btnAttack = document.getElementById('btnShowcaseAnimAttack');
                const btnGuard = document.getElementById('btnShowcaseAnimGuard');
                const btnCompare = document.getElementById('btnShowcaseCompareToggle');

                if (btnOpen) btnOpen.addEventListener('click', () => this.open());
                if (btnClose) btnClose.addEventListener('click', () => this.close());

                if (btnOttoman) btnOttoman.addEventListener('click', () => {
                    this.setCulture('ottoman');
                    btnOttoman.classList.add('active');
                    if (btnEuropean) btnEuropean.classList.remove('active');
                });

                if (btnEuropean) btnEuropean.addEventListener('click', () => {
                    this.setCulture('european');
                    btnEuropean.classList.add('active');
                    if (btnOttoman) btnOttoman.classList.remove('active');
                });

                if (btnV1) btnV1.addEventListener('click', () => {
                    this.setVariant(1);
                    btnV1.classList.add('active');
                    if (btnV2) btnV2.classList.remove('active');
                });

                if (btnV2) btnV2.addEventListener('click', () => {
                    this.setVariant(2);
                    btnV2.classList.add('active');
                    if (btnV1) btnV1.classList.remove('active');
                });

                const animBtns = [
                    { el: btnIdle, anim: 'idle' },
                    { el: btnWalk, anim: 'walk' },
                    { el: btnAttack, anim: 'attack' },
                    { el: btnGuard, anim: 'guard' }
                ];
                animBtns.forEach(item => {
                    if (item.el) {
                        item.el.addEventListener('click', () => {
                            animBtns.forEach(b => b.el && b.el.classList.remove('active'));
                            item.el.classList.add('active');
                            this.setAnim(item.anim);
                        });
                    }
                });

                if (btnCompare) {
                    btnCompare.addEventListener('click', () => {
                        this.toggleCompare();
                        btnCompare.classList.toggle('active', this.compareMode);
                    });
                }
            }

            open() {
                if (this.overlay) {
                    this.overlay.style.display = 'flex';
                }
                this.renderUnitList();
                this.updateInfoCard();
            }

            close() {
                if (this.overlay) {
                    this.overlay.style.display = 'none';
                }
            }

            setCulture(cult) {
                this.currentCulture = cult;
                const units = this.unitCatalog[cult] || [];
                if (units.length > 0) {
                    this.selectedUnitKey = units[0].key;
                }
                this.renderUnitList();
                this.updateInfoCard();
            }

            setVariant(v) {
                this.selectedVariant = v;
                this.updateInfoCard();
            }

            setAnim(a) {
                this.selectedAnim = a;
                this.updateInfoCard();
            }

            toggleCompare() {
                this.compareMode = !this.compareMode;
                this.updateInfoCard();
            }

            renderUnitList() {
                if (!this.unitListEl) return;
                this.unitListEl.innerHTML = '';
                const units = this.unitCatalog[this.currentCulture] || [];
                units.forEach(u => {
                    const item = document.createElement('div');
                    item.className = 'showcase-unit-item' + (u.key === this.selectedUnitKey ? ' active' : '');
                    item.innerHTML = `<span>${u.name}</span> <span style="font-size:10px; opacity:0.6;">${u.key.includes('sipahi') || u.key.includes('deli') || u.key.includes('ciritci') || u.key.includes('akinci') || u.key.includes('curassier') || u.key.includes('reiter') ? 'Süvari' : 'Piyade'}</span>`;
                    item.addEventListener('click', () => {
                        this.selectedUnitKey = u.key;
                        this.renderUnitList();
                        this.updateInfoCard();
                    });
                    this.unitListEl.appendChild(item);
                });
            }

            updateInfoCard() {
                const titleEl = document.getElementById('showcaseInfoTitle');
                const descEl = document.getElementById('showcaseInfoDesc');
                const specsEl = document.getElementById('showcaseInfoSpecs');
                if (!titleEl || !descEl || !specsEl) return;

                const units = this.unitCatalog[this.currentCulture] || [];
                const currentUnit = units.find(u => u.key === this.selectedUnitKey) || units[0];
                if (!currentUnit) return;

                const isCav = currentUnit.key.includes('sipahi') || currentUnit.key.includes('deli') || currentUnit.key.includes('ciritci') || currentUnit.key.includes('akinci') || currentUnit.key.includes('curassier') || currentUnit.key.includes('reiter');
                const cultTitle = this.currentCulture === 'ottoman' ? 'Osmanlı Ordusu' : 'Avrupa / Kutsal Roma';

                titleEl.textContent = `${currentUnit.name} — ${cultTitle} (Varyant ${this.selectedVariant})`;
                descEl.textContent = `${currentUnit.role}. 1648–1650 dönemine uygun otantik malzeme ve geometrik parçalarla modellenmiştir. Seçili Animasyon: ${this.selectedAnim.toUpperCase()}.`;

                const activeWeapon = this.selectedVariant === 1 ? currentUnit.weapon1 : currentUnit.weapon2;

                if (!this.compareMode) {
                    specsEl.innerHTML = `
                        <div>Sınıf: <strong>${isCav ? 'Süvari' : 'Piyade'}</strong></div>
                        <div>Kültür: <strong>${cultTitle}</strong></div>
                        <div>Aktif Silah: <strong>${activeWeapon}</strong></div>
                        <div>Başlık: <strong>${currentUnit.headwear}</strong></div>
                        <div>Zırh: <strong>${currentUnit.armor}</strong></div>
                        <div>Şablon Anahtarı: <strong>${currentUnit.template}:v${this.selectedVariant}</strong></div>
                    `;
                } else {
                    // Compare mode: compare current unit with parallel foreign unit
                    const otherCulture = this.currentCulture === 'ottoman' ? 'european' : 'ottoman';
                    const foreignUnits = this.unitCatalog[otherCulture] || [];
                    const foreignUnit = foreignUnits.find(u => {
                        const foreignCav = u.key.includes('sipahi') || u.key.includes('deli') || u.key.includes('ciritci') || u.key.includes('akinci') || u.key.includes('curassier') || u.key.includes('reiter');
                        return foreignCav === isCav;
                    }) || foreignUnits[0];

                    specsEl.innerHTML = `
                        <div>[${currentUnit.name}]: <strong>${activeWeapon}</strong></div>
                        <div>[${foreignUnit.name}]: <strong>${foreignUnit.weapon1}</strong></div>
                        <div>Başlık Karşılaştırma: <strong>${currentUnit.headwear} vs ${foreignUnit.headwear}</strong></div>
                        <div>Zırh Tipi: <strong>${currentUnit.armor} vs ${foreignUnit.armor}</strong></div>
                        <div>Karşılaştırma Modu: <strong>Aktif (Yan Yana)</strong></div>
                        <div>Durum: <strong>Dengeli RTS Eşleşmesi</strong></div>
                    `;
                }
            }
        }
'''

# Inject pools and controller right before class Battle3DPreviewController
idx_controller = html.find('class Battle3DPreviewController')
assert idx_controller != -1, "Could not find class Battle3DPreviewController"

html = html[:idx_controller] + pools_and_controller_code + '\n' + html[idx_controller:]

# 8. Hook up RTSUnitShowcaseController in Battle3DPreviewController.init()
hook_showcase = '''
                this.showcaseController = new RTSUnitShowcaseController(this.renderer);
                window.focShowcase = this.showcaseController;
'''
target_init_line = 'this._bindRTSUIEvents();'
idx_init_line = html.find(target_init_line)
assert idx_init_line != -1, f"Could not find {target_init_line}"

html = html[:idx_init_line + len(target_init_line)] + '\n' + hook_showcase + html[idx_init_line + len(target_init_line):]

# 9. Add Tests 59 to 64
tests_59_64 = '''
            // ============================================================================
            // G3D-03J ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & MODEL ÇEŞİTLİLİĞİ TESTLERİ (59 - 64)
            // ============================================================================

            // 59. Ajan 01: Osmanlı Piyade Sınıfları ve Model Şablonları (Yeniçeri, Azap, Humbaracı, Bostancı, Levend)
            runCase('59. Osmanlı Piyade Sınıfları ve Model Şablonları (Yeniçeri, Azap, Humbaracı, Bostancı, Levend)', () => {
                const reg = new SoldierVisualRegistry();
                const expectedOttomanInf = [
                    'ottoman:janissary:v1', 'ottoman:janissary:v2',
                    'ottoman:azap:v1', 'ottoman:azap:v2',
                    'ottoman:humbaraci:v1', 'ottoman:humbaraci:v2',
                    'ottoman:bostanci:v1', 'ottoman:bostanci:v2',
                    'ottoman:levend:v1', 'ottoman:levend:v2'
                ];

                for (const key of expectedOttomanInf) {
                    const parts = reg.templates[key];
                    assert(Array.isArray(parts) && parts.length >= 18, `${key} şablonu mevcut ve en az 18 parça içermeli, gelen: ${parts ? parts.length : 0}`);
                    const hasTorso = parts.some(p => p.rigGroup === 'torso');
                    assert(hasTorso, `${key} gövde (torso) rig grubuna sahip olmalı`);
                }

                // Yeniçeri Börk doğrulaması
                const janissaryParts = reg.templates['ottoman:janissary:v1'];
                const hasBork = janissaryParts.some(p => p.mat === 'ottomanWhite');
                assert(hasBork, 'Yeniçeri beyaz keçe börk parçasına sahip olmalı');
            });

            // 60. Ajan 02: Osmanlı Süvari Sınıfları (Sipahi, Kapıkulu Sipahisi, Deli, Ciritçi, Akıncı)
            runCase('60. Osmanlı Süvari Sınıfları (Sipahi, Kapıkulu Sipahisi, Deli, Ciritçi, Akıncı)', () => {
                const reg = new SoldierVisualRegistry();
                const expectedOttomanCav = [
                    'ottoman:sipahi:v1', 'ottoman:sipahi:v2',
                    'ottoman:kapikulu_sipahi:v1', 'ottoman:kapikulu_sipahi:v2',
                    'ottoman:deli:v1', 'ottoman:deli:v2',
                    'ottoman:ciritci:v1', 'ottoman:ciritci:v2',
                    'ottoman:akinci:v1', 'ottoman:akinci:v2'
                ];

                for (const key of expectedOttomanCav) {
                    const parts = reg.templates[key];
                    assert(Array.isArray(parts) && parts.length >= 60, `${key} süvari şablonu en az 60 parça içermeli, gelen: ${parts ? parts.length : 0}`);
                    const hasRider = parts.some(p => p.rigGroup && p.rigGroup.startsWith('rider'));
                    const hasHorse = parts.some(p => p.rigGroup && p.rigGroup.startsWith('horse'));
                    assert(hasRider && hasHorse, `${key} hem binici hem at parçalarına sahip olmalı`);
                }

                // Deli pars postu doğrulaması
                const deliParts = reg.templates['ottoman:deli:v1'];
                const hasLeopard = deliParts.some(p => p.mat === 'leopardPelt');
                assert(hasLeopard, 'Deli süvarisi leopar/pars postu materyaline sahip olmalı');
            });

            // 61. Ajan 03: Avrupa / HRE Asker Sınıfları (Musketier, Pikeniere, Hellebardier, Kürassier, Reiter)
            runCase('61. Avrupa / HRE Asker Sınıfları (Musketier, Pikeniere, Hellebardier, Kürassier, Reiter)', () => {
                const reg = new SoldierVisualRegistry();
                const expectedHRE = [
                    'european:musketier:v1', 'european:musketier:v2',
                    'european:pikeniere:v1', 'european:pikeniere:v2',
                    'european:hellebardier:v1', 'european:hellebardier:v2',
                    'european:curassier:v1', 'european:curassier:v2',
                    'european:reiter:v1', 'european:reiter:v2'
                ];

                for (const key of expectedHRE) {
                    const parts = reg.templates[key];
                    assert(Array.isArray(parts) && parts.length >= 40, `${key} şablonu mevcut ve geçerli parça sayısına sahip olmalı`);
                }

                // Hellebardier balta parçası doğrulaması
                const halberdParts = reg.templates['european:hellebardier:v1'];
                assert(halberdParts.length > 41, 'Hellebardier balta başlığı parçasına sahip olmalı');
            });

            // 62. Ajan 04: Modüler Ekipman Havuzları (RTS_EQUIPMENT_POOLS) ve Deterministik Donanım Çözümü
            runCase('62. Modüler Ekipman Havuzları (RTS_EQUIPMENT_POOLS) ve Deterministik Donanım Çözümü', () => {
                assert(typeof RTS_EQUIPMENT_POOLS === 'object', 'RTS_EQUIPMENT_POOLS tanımlı olmalı');
                assert(RTS_EQUIPMENT_POOLS.ottoman && RTS_EQUIPMENT_POOLS.european, 'Osmanlı ve Avrupa havuzları ayrılmış olmalı');
                assert(RTS_EQUIPMENT_POOLS.ottoman.weapons.length >= 6, 'Osmanlı silah havuzu zengin olmalı');
                assert(RTS_EQUIPMENT_POOLS.european.weapons.length >= 5, 'Avrupa silah havuzu zengin olmalı');

                const loadout1 = resolveUnitEquipment('ottoman', 'janissary', 42);
                const loadout2 = resolveUnitEquipment('ottoman', 'janissary', 42);
                assert(loadout1.weapon.id === loadout2.weapon.id, 'Aynı seed ile deterministik donanım çözümü üretilmeli');

                const loadoutEuro = resolveUnitEquipment('european', 'musketier', 7);
                assert(loadoutEuro.culture === 'european', 'Avrupa donanımı Avrupa kültürüne ait olmalı');
                const hasOttomanWeapon = RTS_EQUIPMENT_POOLS.european.weapons.some(w => w.id === 'yatagan_sword');
                assert(!hasOttomanWeapon, 'Avrupa silah havuzunda yatağan bulunmamalı (kültür izolasyonu)');
            });

            // 63. Ajan 05: 1650 Tarihsel Malzeme Kütüphanesi & Siluet / LOD / Çizim Kararlılığı
            runCase('63. 1650 Tarihsel Malzeme Kütüphanesi & Siluet / LOD / Çizim Kararlılığı', () => {
                const reg = new SoldierVisualRegistry();
                const expectedMats = ['ottomanCrimson', 'ottomanEmerald', 'ottomanSaffron', 'ottomanNavy', 'ottomanWhite', 'leopardPelt', 'bronze', 'damascusSteel'];
                for (const m of expectedMats) {
                    assert(reg.materials[m], `${m} materyali SoldierVisualRegistry kütüphanesinde tanımlı olmalı`);
                    assert(reg.materials[m].color && typeof reg.materials[m].color.r === 'number', `${m} geçerli bir Color nesnesine sahip olmalı`);
                }

                // 206 temel şablonun tam korunduğu doğrulaması
                const baseKeys = Object.keys(reg.templates);
                assert(baseKeys.length === 206, `206 temel şablon korunmalı, enumerable anahtar sayısı: ${baseKeys.length}`);
            });

            // 64. Ajan 06: Asker Vitrini (RTSUnitShowcaseController) ve 3D Model Önizleme / Karşılaştırma
            runCase('64. Asker Vitrini (RTSUnitShowcaseController) ve 3D Model Önizleme / Karşılaştırma', () => {
                const mockRenderer = { cameraController: new RTSCamera3D() };
                const showcase = new RTSUnitShowcaseController(mockRenderer);
                assert(showcase.unitCatalog.ottoman.length >= 8, 'Osmanlı vitrin kataloğu zengin olmalı');
                assert(showcase.unitCatalog.european.length >= 5, 'Avrupa vitrin kataloğu tam olmalı');

                showcase.setCulture('ottoman');
                assert(showcase.currentCulture === 'ottoman', 'Kültür Osmanlı olarak ayarlanmalı');

                showcase.setVariant(2);
                assert(showcase.selectedVariant === 2, 'Varyant 2 seçilebilmeli');

                showcase.setAnim('attack');
                assert(showcase.selectedAnim === 'attack', 'Saldırı animasyonu seçilebilmeli');

                showcase.toggleCompare();
                assert(showcase.compareMode === true, 'Karşılaştırma modu açılabilmeli');
            });
'''

# Find end of Test 58
idx_test58 = html.find("minimap._handleClick({ clientX: 90, clientY: 90 });")
assert idx_test58 != -1, "Could not find Test 58 in html"

idx_test58_end = html.find('});', idx_test58) + 3
html = html[:idx_test58_end] + '\n' + tests_59_64 + '\n' + html[idx_test58_end:]

with open('G3D03J_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("SUCCESS: G3D03J_WORKING.html has been generated successfully!")
