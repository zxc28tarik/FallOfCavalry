# -*- coding: utf-8 -*-
with open('tools/build_g3d03k_models.py', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace("m('", "makePart('")

with open('tools/build_g3d03k_models.py', 'w', encoding='utf-8') as f:
    f.write(text)

print("Updated m(' to makePart(' in tools/build_g3d03k_models.py")
