// Verification script for FOC-RC01 RTS bug fixes
const fs = require('fs');

const html = fs.readFileSync('FallOfCavalry_PLAYABLE_RTS.html', 'utf8');

console.log('--- Checking RTS Battle Engine Fixes in HTML ---');

// Check 1: Empty selection guard
const hasEmptyMoveGuard = html.includes('// Seçili asker yoksa tüm orduya hareket emri verme!') &&
                          html.includes('if (!ids || ids.length === 0) return;');
console.log('Check 1 (Empty Move Order Guard):', hasEmptyMoveGuard ? 'PASS' : 'FAIL');

// Check 2: Enemy unit filter
const hasEnemyFilter = html.includes("s.side !== 'enemy'");
console.log('Check 2 (Enemy Unit Filter):', hasEnemyFilter ? 'PASS' : 'FAIL');

// Check 3: ViewId cleaner
const hasViewIdCleaner = html.includes("id.split(':')[1]");
console.log('Check 3 (ViewId normalization):', hasViewIdCleaner ? 'PASS' : 'FAIL');

// Check 4: Reserve management
const hasReserveLogic = html.includes('s.isReserve = pTotal >= 150') &&
                        html.includes('s.isReserve = eTotal >= 150');
console.log('Check 4 (Reserve assignment):', hasReserveLogic ? 'PASS' : 'FAIL');

// Check 5: Casualty tracking fix (no hardcoded 150 subtraction)
const hasCasualtyFix = html.includes('Math.max(0, this.stats.initialPlayer - totalPlayerLiving)') &&
                       html.includes('Math.max(0, this.stats.initialEnemy - totalEnemyLiving)');
console.log('Check 5 (Dynamic casualty tracking):', hasCasualtyFix ? 'PASS' : 'FAIL');

// Check 6: Weapon properties & Arquebus classification
const hasArquebusRanged = html.includes("w.includes('arquebus')") &&
                          html.includes('range = 20.0;');
console.log('Check 6 (Arquebus ranged classification):', hasArquebusRanged ? 'PASS' : 'FAIL');

// Check 7: Order behaviors (hold_fire, move)
const hasHoldFireOrder = html.includes("att.currentOrder === 'hold_fire' && isRanged");
const hasMoveOrder = html.includes("att.currentOrder === 'move' && att.targetPos");
console.log('Check 7 (Order combat handling):', (hasHoldFireOrder && hasMoveOrder) ? 'PASS' : 'FAIL');

// Check 8: Cavalry charge moving requirement
const hasChargeVelocityCheck = html.includes('const isFastMoving = attacker.isMoving && (attacker.walkBlend === undefined || attacker.walkBlend > 0.35);');
console.log('Check 8 (Cavalry charge velocity check):', hasChargeVelocityCheck ? 'PASS' : 'FAIL');

// Check 9: Enemy melee approach (not halting at 22m)
const hasMeleeApproachFix = html.includes('const haltDist = isRanged ? 20.0 : (isCavalry ? 3.5 : 2.8);') &&
                            html.includes('if (dist > haltDist)');
console.log('Check 9 (Enemy melee approach fix):', hasMeleeApproachFix ? 'PASS' : 'FAIL');

// Check 10: Selection clear on startBattle
const hasStartBattleClear = html.includes('this.selectedSoldierIds = [];') &&
                            html.includes('this.controlGroups.clear();') &&
                            html.includes('this.controller.renderer.selectionManager.clearSelection();');
console.log('Check 10 (Start battle state reset):', hasStartBattleClear ? 'PASS' : 'FAIL');

// Check 11: Duplicate UI listener guard
const hasUIGuard = html.includes('if (this._uiInitialized) return;') &&
                   html.includes('this._uiInitialized = true;');
console.log('Check 11 (Duplicate UI listener guard):', hasUIGuard ? 'PASS' : 'FAIL');

// Check 12: Visual combat action trigger
const hasVisualCombatAction = html.includes('triggerSoldierVisualAction') &&
                              html.includes('reg.setSoldierVisualCombatAction(viewId, true, actionType);');
console.log('Check 12 (Visual combat action trigger):', hasVisualCombatAction ? 'PASS' : 'FAIL');

const allPassed = hasEmptyMoveGuard && hasEnemyFilter && hasViewIdCleaner && hasReserveLogic &&
                  hasCasualtyFix && hasArquebusRanged && hasHoldFireOrder && hasMoveOrder &&
                  hasChargeVelocityCheck && hasMeleeApproachFix && hasStartBattleClear &&
                  hasUIGuard && hasVisualCombatAction;

console.log('=== ALL RTS FIXES VERIFIED:', allPassed ? 'SUCCESS (12/12)' : 'INCOMPLETE');
process.exit(allPassed ? 0 : 1);
