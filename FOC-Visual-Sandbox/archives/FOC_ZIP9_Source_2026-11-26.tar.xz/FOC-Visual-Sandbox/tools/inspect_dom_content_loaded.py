with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('if (window.location.hash === \'#tests\' || window.location.search.includes(\'runTests=1\')) {')
print(text[pos-100:pos+400])
