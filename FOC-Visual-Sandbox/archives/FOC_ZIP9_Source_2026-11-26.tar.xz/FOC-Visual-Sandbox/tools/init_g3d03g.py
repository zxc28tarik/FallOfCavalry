import os
import shutil

base_file = 'G3D03G_WORKING.html'
for i in range(1, 7):
    agent_dir = os.path.join('G3D03G', 'AJANLAR', f'{i:02d}')
    os.makedirs(agent_dir, exist_ok=True)
    dst = os.path.join(agent_dir, 'WORKING.html')
    shutil.copyfile(base_file, dst)
    print(f'Initialized {dst} ({os.path.getsize(dst)} bytes)')
