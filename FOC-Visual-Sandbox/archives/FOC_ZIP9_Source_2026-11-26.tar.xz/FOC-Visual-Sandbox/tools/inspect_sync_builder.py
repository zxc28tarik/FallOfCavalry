with open('tools/build_playable_rts.py', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('classifySoldierArchetype(s);')
if idx != -1:
    print(text[idx-50:idx+800])
