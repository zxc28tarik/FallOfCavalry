import subprocess
import os
import tempfile
import json
import re

def inspect_batch1_instances():
    with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
        html = f.read()

    script = '''
<script>
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const c = window.__focBattle3DPreview;
        const reg = c.renderer.soldierRegistry;
        const b = reg.batchGroup.batches[1]; // Frustum batch
        const stride = 21;
        const numInstances = b.count;
        
        let crazyInstances = [];
        let minX = Infinity, maxX = -Infinity;
        let minY = Infinity, maxY = -Infinity;
        let minZ = Infinity, maxZ = -Infinity;
        let maxScale = 0;
        
        for (let i = 0; i < numInstances; i++) {
            const base = i * stride;
            const m = b.instanceData.slice(base, base + 16);
            const r = b.instanceData[base + 16];
            const g = b.instanceData[base + 17];
            const b_col = b.instanceData[base + 18];
            const a = b.instanceData[base + 19];
            
            const tx = m[12];
            const ty = m[13];
            const tz = m[14];
            
            const sx = Math.hypot(m[0], m[1], m[2]);
            const sy = Math.hypot(m[4], m[5], m[6]);
            const sz = Math.hypot(m[8], m[9], m[10]);
            
            if (tx < minX) minX = tx; if (tx > maxX) maxX = tx;
            if (ty < minY) minY = ty; if (ty > maxY) maxY = ty;
            if (tz < minZ) minZ = tz; if (tz > maxZ) maxZ = tz;
            if (sx > maxScale) maxScale = sx;
            if (sy > maxScale) maxScale = sy;
            if (sz > maxScale) maxScale = sz;
            
            // Check if scale is huge or position is weird or color is bright red
            if (sx > 10 || sy > 10 || sz > 10 || Math.abs(tx) > 100 || Math.abs(tz) > 100) {
                crazyInstances.push({ idx: i, tx, ty, tz, sx, sy, sz, r, g, b: b_col });
            }
        }
        
        const res = {
            numInstances,
            crazyCount: crazyInstances.length,
            crazySample: crazyInstances.slice(0, 10),
            bounds: { minX, maxX, minY, maxY, minZ, maxZ, maxScale }
        };
        
        const pre = document.createElement('pre');
        pre.id = 'instanceBounds';
        pre.textContent = JSON.stringify(res, null, 2);
        document.body.appendChild(pre);
    }, 1000);
});
</script>
'''

    temp_html = 'test_inst_bounds.html'
    with open(temp_html, 'w', encoding='utf-8') as f:
        f.write(html.replace('</body>', script + '</body>'))

    temp_profile = os.path.join(tempfile.gettempdir(), 'foc_inst_prof')
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    cmd = [
        chrome_path,
        '--headless=new',
        '--disable-gpu-sandbox',
        '--enable-webgl',
        '--use-gl=angle',
        '--use-angle=d3d11',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--virtual-time-budget=5000',
        '--dump-dom',
        'file:///' + os.path.abspath(temp_html).replace('\\', '/')
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=15, encoding='utf-8', errors='replace')
    m = re.search(r'<pre id="instanceBounds">(.*?)</pre>', res.stdout, re.DOTALL)
    if m:
        print(m.group(1))
    else:
        print('Not found')
    if os.path.exists(temp_html):
        os.remove(temp_html)

if __name__ == '__main__':
    inspect_batch1_instances()
