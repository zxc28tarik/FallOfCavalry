# -*- coding: utf-8 -*-
"""
tools/fixed_euro_cavalry.py
1650 European / HRE Cavalry — 4 Fixed, Non-Modular Mounted Archetypes.

Uses unified organic meshes:
  'orgHorseBody', 'orgHorseNeckHead', 'orgHorseSaddle', 'orgHorseTail',
  'orgHorseLegUpper', 'orgHorseLegLower',
  'orgTorsoCoat', 'orgTorsoArmored', 'orgHeadNatural',
  'orgHairCurtain', 'orgFallingCollar',
  'orgRiderLegL', 'orgRiderLegR',
  'orgArmRiderReinsL', 'orgArmRiderWeaponR',
  'orgLimb', 'orgHand',
  'orgHelmetCavalier', 'orgHelmetMorion'
Plus primitives ONLY for thin bridle/reins/breaststrap, stirrups,
pistols, carbines, lances, swords, facial accents, and historical armor trim.
"""


def get_fixed_euro_cavalry_code():
    """Return JavaScript defining the 4 fixed 1650 European/HRE cavalry archetypes."""
    return r"""
        /* ============================================================================
         * 1650 EUROPEAN / HRE CAVALRY — 4 FIXED, NON-MODULAR MOUNTED ARCHETYPES
         * ============================================================================ */

        function euroCavLimb(prim, mat, ax, ay, az, bx, by, bz, rStart, rEnd, rigGroup) {
            const dx = bx - ax;
            const dy = by - ay;
            const dz = bz - az;
            const len = Math.hypot(dx, dy, dz) || 0.001;
            const mx = (ax + bx) * 0.5;
            const my = (ay + by) * 0.5;
            const mz = (az + bz) * 0.5;
            const dir = rStart >= rEnd ? -1 : 1;
            const ux = (dx * dir) / len;
            const uy = (dy * dir) / len;
            const uz = (dz * dir) / len;
            const rx = Math.asin(Math.max(-1, Math.min(1, uz)));
            const rz = Math.atan2(-ux, uy);
            const avgScale = Math.max(rStart, rEnd) * 2.0;
            return makePart(prim, mat, mx, my, mz, avgScale, len, avgScale, rx, 0, rz, rigGroup);
        }

        function buildEuroHorseLeg(coatMat, side, isFront, isHeavy) {
            const x = side * (isFront ? 0.19 : 0.20);
            const sideTag = side < 0 ? 'L' : 'R';
            const upperRig = (isFront ? 'horseLegF' : 'horseLegH') + sideTag;
            const lowerRig = upperRig + 'Lower';

            if (isFront) {
                const rxU = Math.atan2(0.45 - 0.54, 1.09 - 0.54);
                const sx = isHeavy ? 0.35 : 0.32;
                const szU = isHeavy ? 0.38 : 0.35;
                const szL = isHeavy ? 0.37 : 0.34;
                return [
                    makePart('orgHorseLegUpper', coatMat, x, 0.815, 0.495, sx, 0.58, szU, rxU, 0, 0, upperRig),
                    makePart('orgHorseLegLower', coatMat, x, 0.28,  0.54,  sx, 0.56, szL, 0,   0, 0, lowerRig)
                ];
            }

            const rxU = Math.atan2(-0.45 - (-0.63), 1.12 - 0.55);
            const rxL = Math.atan2(-0.63 - (-0.58), 0.57 - 0.0);
            const sxU = isHeavy ? 0.38 : 0.35;
            const szU = isHeavy ? 0.44 : 0.40;
            const sxL = isHeavy ? 0.35 : 0.32;
            const szL = isHeavy ? 0.37 : 0.34;
            return [
                makePart('orgHorseLegUpper', coatMat, x, 0.835, -0.54,  sxU, 0.62,  szU, rxU, 0, 0, upperRig),
                makePart('orgHorseLegLower', coatMat, x, 0.293, -0.605, sxL, 0.575, szL, rxL, 0, 0, lowerRig)
            ];
        }

        function buildFixedEuroWarhorse(coatMat, maneMat, clothMat, options = {}) {
            const isHeavy = Boolean(options.heavy);
            const trimMat = options.trimMat || 'gold';
            const bodyW = isHeavy ? 0.70 : 0.66;
            const bodyH = isHeavy ? 0.74 : 0.70;
            const bodyL = isHeavy ? 1.40 : 1.34;
            const chestZ = isHeavy ? 0.695 : 0.665;
            const shX = isHeavy ? 0.185 : 0.175;
            const midX = isHeavy ? 0.125 : 0.118;
            const midZ = isHeavy ? 0.59 : 0.56;

            const parts = [
                makePart('cylinder', 'shadow', 0, 0.02, 0.0, 2.28, 0.02, 1.34, 0, 0, 0, 'shadow'),

                // Unified organic horse barrel (y=1.20) & arched neck+head (y=1.60, z=0.80)
                makePart('orgHorseBody', coatMat, 0, 1.20, 0.0, bodyW, bodyH, bodyL, 0, 0, 0, 'horseBody'),
                makePart('orgHorseNeckHead', coatMat, 0, 1.60, 0.80, 0.35, 0.76, 0.72, 0, 0, 0, 'horseNeckHead'),

                // Sleek thin leather curb bridle & bit rings hugging orgHorseNeckHead
                makePart('cylinder', 'leather', 0, 1.818, 0.860, 0.098, 0.015, 0.115, 0.72, 0, 0, 'horseNeckHead'),
                makePart('cylinder', 'leather', 0, 1.656, 1.013, 0.056, 0.014, 0.072, 0.78, 0, 0, 'horseNeckHead'),
                euroCavLimb('cylinder', 'leather', -0.045, 1.818, 0.860, -0.028, 1.621, 1.046, 0.007, 0.007, 'horseNeckHead'),
                euroCavLimb('cylinder', 'leather',  0.045, 1.818, 0.860,  0.028, 1.621, 1.046, 0.007, 0.007, 'horseNeckHead'),
                makePart('sphere', trimMat, -0.029, 1.621, 1.046, 0.020, 0.020, 0.020, 0, 0, 0, 'horseNeckHead'),
                makePart('sphere', trimMat,  0.029, 1.621, 1.046, 0.020, 0.020, 0.020, 0, 0, 0, 'horseNeckHead'),

                // Lifelike dark shiny equine eyes nestled in sculpted orbits
                makePart('sphere', 'eyeDark', -0.040, 1.818, 0.865, 0.016, 0.016, 0.016, 0, 0, 0, 'horseNeckHead'),
                makePart('sphere', 'eyeDark',  0.040, 1.818, 0.865, 0.016, 0.016, 0.016, 0, 0, 0, 'horseNeckHead'),

                // Flowing sculpted organic horse tail (horseTail)
                makePart('orgHorseTail', maneMat, 0, 1.06, -0.82, 0.22, 0.78, 0.34, 0, 0, 0, 'horseTail'),

                // 4 Anatomical Organic Horse Legs (tucked at x=±0.19 front, x=±0.20 hind)
                ...buildEuroHorseLeg(coatMat, -1, true,  isHeavy),
                ...buildEuroHorseLeg(coatMat,  1, true,  isHeavy),
                ...buildEuroHorseLeg(coatMat, -1, false, isHeavy),
                ...buildEuroHorseLeg(coatMat,  1, false, isHeavy),

                // Contoured saddle cloth hugging barrel + sleek thin leather breaststrap (horseBody)
                makePart('orgHorseSaddle', clothMat, 0, 1.415, -0.07, 0.59, 0.30, 0.74, 0, 0, 0, 'horseBody'),
                euroCavLimb('cylinder', 'leather', -shX,  1.32, 0.28, -midX, 1.21, midZ, 0.009, 0.009, 'horseBody'),
                euroCavLimb('cylinder', 'leather',  shX,  1.32, 0.28,  midX, 1.21, midZ, 0.009, 0.009, 'horseBody'),
                euroCavLimb('cylinder', 'leather', -midX, 1.21, midZ,  0,    1.18, chestZ, 0.009, 0.009, 'horseBody'),
                euroCavLimb('cylinder', 'leather',  midX, 1.21, midZ,  0,    1.18, chestZ, 0.009, 0.009, 'horseBody'),

                // Reins leading from bit rings back to rider's left hand at (-0.14, 1.65, 0.31)
                euroCavLimb('cylinder', 'leather', -0.029, 1.621, 1.046, -0.145, 1.65, 0.31, 0.008, 0.008, 'horseBody'),
                euroCavLimb('cylinder', 'leather',  0.029, 1.621, 1.046, -0.135, 1.65, 0.31, 0.008, 0.008, 'horseBody'),

                // Contoured 1650 European war saddle (riderSaddle) & stirrup straps aligned to (±0.35, 0.77, 0.06)
                makePart('orgHorseSaddle', 'leather', 0, 1.44, -0.05, 0.58, 0.30, 0.66, 0, 0, 0, 'riderSaddle'),
                // Front pistol holsters flanking pommel
                makePart('frustum', 'leather', -0.21, 1.41, 0.23, 0.09, 0.22, 0.10, 0.38, 0,  0.14, 'riderSaddle'),
                makePart('frustum', 'leather',  0.21, 1.41, 0.23, 0.09, 0.22, 0.10, 0.38, 0, -0.14, 'riderSaddle'),
                // Stirrup straps & steel stirrups seated around boot foot at (±0.35, 0.77, 0.06)
                euroCavLimb('box', 'leather', -0.19, 1.38, 0.03, -0.35, 0.81, 0.06, 0.013, 0.013, 'riderSaddle'),
                euroCavLimb('box', 'leather',  0.19, 1.38, 0.03,  0.35, 0.81, 0.06, 0.013, 0.013, 'riderSaddle'),
                makePart('box', 'steel', -0.35, 0.77, 0.06, 0.115, 0.095, 0.040, 0, 0, 0, 'riderSaddle'),
                makePart('box', 'steel',  0.35, 0.77, 0.06, 0.115, 0.095, 0.040, 0, 0, 0, 'riderSaddle')
            ];

            if (isHeavy) {
                parts.push(
                    // Heavy cavalry saddle-roll behind cantle
                    makePart('cylinder', clothMat, 0, 1.46, -0.45, 0.14, 0.38, 0.14, 0, 0, Math.PI * 0.5, 'horseBody'),
                    makePart('cylinder', 'leather', -0.10, 1.46, -0.45, 0.15, 0.025, 0.15, 0, 0, Math.PI * 0.5, 'horseBody'),
                    makePart('cylinder', 'leather',  0.10, 1.46, -0.45, 0.15, 0.025, 0.15, 0, 0, Math.PI * 0.5, 'horseBody')
                );
            }

            return parts;
        }

        function buildSeatedEuroRiderBase(breechesMat, bootMat, coatMat, torsoPrim, options = {}) {
            const sashMat = options.sashMat || 'enemyCloth';
            const sleeveMat = options.sleeveMat || coatMat;
            const isCuirassier = Boolean(options.cuirassier);
            const collarMat = options.collarMat || 'linen';
            const useFallingCollar = Boolean(options.fallingCollar);

            const parts = [
                // Pelvis seated cleanly on saddle at y=1.50 (riderLower)
                makePart('frustum', breechesMat, 0, 1.50, -0.05, 0.44, 0.16, 0.36, Math.PI, 0, 0, 'riderLower'),

                // Upper-thigh breeches blend at hip (x=±0.20, y=1.46) into contoured rider leg+boot
                makePart('sphere', breechesMat, -0.20, 1.46, -0.01, 0.18, 0.17, 0.20, 0, 0, 0, 'riderLower'),
                makePart('sphere', breechesMat,  0.20, 1.46, -0.01, 0.18, 0.17, 0.20, 0, 0, 0, 'riderLower'),
                euroCavLimb('orgLimb', breechesMat, -0.19, 1.47, -0.02, -0.27, 1.37, 0.08, 0.090, 0.082, 'riderLower'),
                euroCavLimb('orgLimb', breechesMat,  0.19, 1.47, -0.02,  0.27, 1.37, 0.08, 0.090, 0.082, 'riderLower'),

                // Single-piece contoured rider leg + turned-down cavalier boot resting at (±0.35, 0.77, 0.06)
                makePart('orgRiderLegL', bootMat || 'leather', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderLower'),
                makePart('orgRiderLegR', bootMat || 'leather', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderLower'),

                // Brass rowel spurs aligned to heel at (±0.35, 0.77, -0.035)
                makePart('cone', 'gold', -0.35, 0.77, -0.035, 0.02, 0.05, 0.02, -Math.PI * 0.5, 0, 0, 'riderLower'),
                makePart('cone', 'gold',  0.35, 0.77, -0.035, 0.02, 0.05, 0.02, -Math.PI * 0.5, 0, 0, 'riderLower'),

                // Upper torso at y=1.62..1.90 (riderUpper)
                makePart(torsoPrim, coatMat, 0, 1.76, -0.04, 0.49, 0.38, 0.33, 0, 0, 0, 'riderUpper'),
                // Waist sash & leather sword belt
                makePart('cylinder', sashMat, 0, 1.63, -0.04, 0.46, 0.08, 0.32, 0, 0, 0, 'riderUpper'),
                makePart('cylinder', 'leather', 0, 1.60, -0.04, 0.45, 0.05, 0.31, 0, 0, 0, 'riderUpper'),
                makePart('box', 'gold', 0, 1.60, 0.12, 0.08, 0.065, 0.025, 0, 0, 0, 'riderUpper'),

                // Falling white linen collar (organic falling collar for light cav/harquebusier, clean collar at y=1.96 for cuirassier)
                useFallingCollar
                    ? makePart('orgFallingCollar', collarMat, 0, 0.55, -0.025, 1, 1, 1, 0, 0, 0, 'riderUpper')
                    : makePart('frustum', collarMat, 0, 1.96, -0.02, 0.31, 0.05, 0.28, 0.08, 0, 0, 'riderUpper'),

                // Neck, Natural Head at y=2.10, & wavy shoulder-length hair curtain (riderUpper)
                makePart('frustum', 'skin', 0, 1.99, -0.02, 0.16, 0.12, 0.15, 0.08, 0, 0, 'riderUpper'),
                makePart('orgHeadNatural', 'skin', 0, 2.10, -0.01, 0.22, 0.24, 0.22, 0, 0, 0, 'riderUpper'),
                makePart('orgHairCurtain', 'hairDark', 0, 0.56, -0.025, 0.96, 1.0, 0.92, 0, 0, 0, 'riderUpper'),

                // Sculpted eyes, eyebrows, handlebar mustache & goatee flush with orgHeadNatural
                makePart('sphere', 'eyeDark',  -0.030, 2.118, 0.076, 0.015, 0.012, 0.013, 0, 0, 0, 'riderUpper'),
                makePart('sphere', 'eyeDark',   0.030, 2.118, 0.076, 0.015, 0.012, 0.013, 0, 0, 0, 'riderUpper'),
                makePart('box',    'hairDark', -0.030, 2.131, 0.080, 0.026, 0.007, 0.011, 0, 0,  0.08, 'riderUpper'),
                makePart('box',    'hairDark',  0.030, 2.131, 0.080, 0.026, 0.007, 0.011, 0, 0, -0.08, 'riderUpper'),
                makePart('cone',   'hairDark', -0.028, 2.064, 0.068, 0.020, 0.054, 0.018, 0.15,  0.22,  1.38, 'riderUpper'),
                makePart('cone',   'hairDark',  0.028, 2.064, 0.068, 0.020, 0.054, 0.018, 0.15, -0.22, -1.38, 'riderUpper'),
                makePart('cone',   'hairDark',  0.0,   2.025, 0.068, 0.024, 0.042, 0.020, Math.PI + 0.15, 0, 0, 'riderUpper'),

                // Unified Single-Piece Left Arm holding reins (riderUpper), hand at (-0.14, 1.65, 0.31)
                makePart('orgArmRiderReinsL', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderUpper'),
                makePart('orgHand', 'skin', -0.14, 1.65, 0.31, 0.075, 0.075, 0.075, -0.15, 0, 0, 'riderUpper')
            ];

            if (isCuirassier) {
                parts.push(
                    // Articulated blackenedSteel tassets protecting upper thighs (riderLower)
                    makePart('box', 'blackenedSteel', -0.28, 1.44, 0.11, 0.15, 0.17, 0.13, 0.35, 0,  0.22, 'riderLower'),
                    makePart('box', 'blackenedSteel',  0.28, 1.44, 0.11, 0.15, 0.17, 0.13, 0.35, 0, -0.22, 'riderLower'),
                    // Segmented blackenedSteel pauldrons & central chest ridge (riderUpper)
                    makePart('dome', 'blackenedSteel', -0.24, 1.86, -0.02, 0.18, 0.13, 0.18, 0, 0,  0.35, 'riderUpper'),
                    makePart('dome', 'blackenedSteel',  0.24, 1.86, -0.02, 0.18, 0.13, 0.18, 0, 0, -0.35, 'riderUpper'),
                    makePart('box', 'gold', 0, 1.82, 0.072, 0.03, 0.24, 0.015, 0, 0, 0, 'riderUpper')
                );
            }

            return parts;
        }

        function buildEuroRiderRightArm(sleeveMat) {
            return [
                makePart('orgArmRiderWeaponR', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderRightArmWeapon'),
                makePart('orgHand', 'skin', 0.22, 1.67, 0.32, 0.075, 0.075, 0.075, 0.2, 0, 0, 'riderRightArmWeapon')
            ];
        }

        function buildZischaggeHelmetParts(metalMat, trimMat, lobsterTail = true) {
            const parts = [
                // Helmet bowl using unified organic morion mesh (y=2.17)
                makePart('orgHelmetMorion', metalMat, 0, 2.17, -0.01, 0.28, 0.21, 0.29, 0, 0, 0, 'riderUpper'),
                // Front visor peak & nasal bar
                makePart('frustum', metalMat, 0, 2.12, 0.12, 0.23, 0.03, 0.13, 0.22, 0, 0, 'riderUpper'),
                makePart('box', trimMat, 0, 2.08, 0.14, 0.022, 0.14, 0.016, 0, 0, 0, 'riderUpper'),
                // Hinged cheekpieces
                makePart('box', metalMat, -0.12, 2.06, 0.0, 0.024, 0.13, 0.09, 0, 0, 0.12, 'riderUpper'),
                makePart('box', metalMat,  0.12, 2.06, 0.0, 0.024, 0.13, 0.09, 0, 0, -0.12, 'riderUpper')
            ];
            if (lobsterTail) {
                // Articulated lobster-tail neck guard sweeping down the back
                parts.push(
                    makePart('frustum', metalMat, 0, 2.05, -0.13, 0.24, 0.15, 0.06, -0.35, 0, 0, 'riderUpper'),
                    makePart('box', trimMat, 0, 2.07, -0.14, 0.22, 0.016, 0.05, -0.35, 0, 0, 'riderUpper'),
                    makePart('box', trimMat, 0, 2.02, -0.15, 0.23, 0.016, 0.05, -0.35, 0, 0, 'riderUpper')
                );
            }
            return parts;
        }

        function buildBurgonetHelmetParts(metalMat, trimMat) {
            return [
                makePart('orgHelmetMorion', metalMat, 0, 2.17, -0.01, 0.27, 0.21, 0.28, 0, 0, 0, 'riderUpper'),
                makePart('frustum', metalMat, 0, 2.12, 0.11, 0.22, 0.03, 0.11, 0.20, 0, 0, 'riderUpper'),
                makePart('box', metalMat, -0.115, 2.06, 0.0, 0.022, 0.12, 0.08, 0, 0, 0.10, 'riderUpper'),
                makePart('box', metalMat,  0.115, 2.06, 0.0, 0.022, 0.12, 0.08, 0, 0, -0.10, 'riderUpper'),
                makePart('box', trimMat, 0, 2.25, -0.02, 0.025, 0.08, 0.22, 0, 0, 0, 'riderUpper')
            ];
        }

        function buildWheellockPistolParts(handX, handY, handZ) {
            return [
                // Angled walnut pistol butt & brass pommel ball
                makePart('frustum', 'wood', handX, handY - 0.04, handZ - 0.04, 0.042, 0.15, 0.052, -0.55, 0, 0, 'riderRightArmWeapon'),
                makePart('sphere', 'gold', handX, handY - 0.10, handZ - 0.09, 0.056, 0.056, 0.056, 0, 0, 0, 'riderRightArmWeapon'),
                // Forestock & wheellock lockplate
                makePart('box', 'wood', handX, handY + 0.03, handZ + 0.16, 0.042, 0.048, 0.34, 0.05, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'burnishedBronze', handX + 0.025, handY + 0.04, handZ + 0.08, 0.045, 0.018, 0.045, 0, 0, Math.PI * 0.5, 'riderRightArmWeapon'),
                // Steel pistol barrel aimed forward
                makePart('cylinder', 'steel', handX, handY + 0.055, handZ + 0.24, 0.032, 0.44, 0.032, Math.PI * 0.5 + 0.05, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'gold', handX, handY + 0.048, handZ + 0.42, 0.038, 0.025, 0.038, Math.PI * 0.5 + 0.05, 0, 0, 'riderRightArmWeapon')
            ];
        }

        function buildPallaschBroadswordParts(handX, handY, handZ, bladeLen, guardMat) {
            return [
                // Leather grip & brass pommel
                makePart('cylinder', 'leather', handX, handY, handZ + 0.02, 0.036, 0.15, 0.036, 0.40, 0, 0, 'riderRightArmWeapon'),
                makePart('sphere', guardMat, handX, handY - 0.06, handZ - 0.01, 0.056, 0.056, 0.056, 0, 0, 0, 'riderRightArmWeapon'),
                // Basket hilt (crossguard, knuckle bow, side bars)
                makePart('box', guardMat, handX, handY + 0.06, handZ + 0.06, 0.15, 0.022, 0.05, 0.40, 0, 0, 'riderRightArmWeapon'),
                makePart('box', guardMat, handX + 0.04, handY + 0.01, handZ + 0.08, 0.02, 0.14, 0.02, 0.40, 0, 0, 'riderRightArmWeapon'),
                makePart('box', guardMat, handX - 0.04, handY + 0.01, handZ + 0.08, 0.02, 0.14, 0.02, 0.40, 0, 0, 'riderRightArmWeapon'),
                // Straight double-edged Pallasch broadsword blade
                makePart('box', 'steel', handX, handY + bladeLen * 0.52, handZ + 0.26, 0.018, bladeLen, 0.052, 0.40, 0, 0, 'riderRightArmWeapon'),
                makePart('cone', 'steel', handX, handY + bladeLen * 1.04, handZ + 0.46, 0.020, 0.10, 0.048, 0.40, 0, 0, 'riderRightArmWeapon')
            ];
        }

        function buildEuroLanceParts(handX, handY, handZ, shaftLength, pennantMat) {
            const pitch = 1.02;
            const sinP = Math.sin(pitch);
            const cosP = Math.cos(pitch);
            const midOffset = shaftLength * 0.28;
            const tipOffset = shaftLength * 0.78;
            return [
                makePart('cylinder', 'wood', handX, handY + midOffset * cosP, handZ + midOffset * sinP, 0.042, shaftLength, 0.042, pitch, 0, 0, 'riderRightArmWeapon'),
                makePart('cone', 'steel', handX, handY + tipOffset * cosP, handZ + tipOffset * sinP, 0.064, 0.26, 0.032, pitch, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'gold', handX, handY + (tipOffset - 0.14) * cosP, handZ + (tipOffset - 0.14) * sinP, 0.052, 0.05, 0.052, pitch, 0, 0, 'riderRightArmWeapon'),
                makePart('box', pennantMat, handX, handY + (tipOffset - 0.40) * cosP - 0.11, handZ + (tipOffset - 0.40) * sinP, 0.015, 0.20, 0.54, pitch - 0.24, 0, 0, 'riderRightArmWeapon')
            ];
        }

        // 1. Kürassier Tabancalı (Heavy dark warhorse, blackenedSteel 3/4 cuirass, Zischägge, wheellock pistol)
        function buildFixedEuroCurassierPistol() {
            return [
                ...buildFixedEuroWarhorse('horseDark', 'horseDark', 'enemyCloth', { heavy: true }),
                ...buildSeatedEuroRiderBase('buffLeather', 'darkSteel', 'blackenedSteel', 'orgTorsoArmored', {
                    cuirassier: true,
                    sashMat: 'enemyCloth',
                    sleeveMat: 'blackenedSteel'
                }),
                ...buildZischaggeHelmetParts('blackenedSteel', 'gold', true),
                ...buildEuroRiderRightArm('blackenedSteel'),
                ...buildWheellockPistolParts(0.22, 1.67, 0.32)
            ];
        }

        // 2. Kürassier Kılıçlı (Heavy bay warhorse, blackenedSteel 3/4 cuirass, lobster-tail Zischägge, Pallasch broadsword)
        function buildFixedEuroCurassierSword() {
            return [
                ...buildFixedEuroWarhorse('horseBay', 'horseDark', 'playerCloth', { heavy: true }),
                ...buildSeatedEuroRiderBase('buffLeather', 'darkSteel', 'blackenedSteel', 'orgTorsoArmored', {
                    cuirassier: true,
                    sashMat: 'enemyCloth',
                    sleeveMat: 'blackenedSteel'
                }),
                ...buildZischaggeHelmetParts('blackenedSteel', 'gold', true),
                ...buildEuroRiderRightArm('blackenedSteel'),
                ...buildPallaschBroadswordParts(0.22, 1.67, 0.32, 0.92, 'gold')
            ];
        }

        // 3. Hafif Süvari / Demi-Lancer (Chestnut courser, crimson coat + steel breastplate, open burgonet, light lance)
        function buildFixedEuroLightCavalry() {
            return [
                ...buildFixedEuroWarhorse('horseChestnut', 'horseDark', 'enemyCloth', { heavy: false }),
                ...buildSeatedEuroRiderBase('buffLeather', 'leather', 'enemyCloth', 'orgTorsoCoat', {
                    sashMat: 'gold',
                    sleeveMat: 'enemyCloth'
                }),
                // Polished steel breastplate over crimson coat
                makePart('orgTorsoArmored', 'steel', 0, 1.78, 0.01, 0.45, 0.33, 0.31, 0, 0, 0, 'riderUpper'),
                ...buildBurgonetHelmetParts('steel', 'gold'),
                ...buildEuroRiderRightArm('enemyCloth'),
                ...buildEuroLanceParts(0.22, 1.67, 0.32, 3.6, 'enemyCloth')
            ];
        }

        // 4. Ateşli Hafif Süvari / Reiter (Bay/dun horse, buffLeather coat + steel breastplate, Cavalier hat, carbine)
        function buildFixedEuroHarquebusierMounted() {
            return [
                ...buildFixedEuroWarhorse('horseDun', 'wood', 'playerCloth', { heavy: false }),
                ...buildSeatedEuroRiderBase('playerBreeches', 'leather', 'buffLeather', 'orgTorsoCoat', {
                    sashMat: 'enemyCloth',
                    sleeveMat: 'buffLeather'
                }),
                // Steel breastplate over buff leather coat + carbine sling
                makePart('orgTorsoArmored', 'steel', 0, 1.78, 0.01, 0.45, 0.33, 0.31, 0, 0, 0, 'riderUpper'),
                makePart('box', 'leather', 0.0, 1.78, 0.115, 0.46, 0.055, 0.03, 0, 0, -0.65, 'riderUpper'),
                // Cavalier slouch hat with gold band & crimson plume
                makePart('orgHelmetCavalier', 'feltBlack', 0, 2.18, -0.01, 0.56, 0.24, 0.56, -0.06, 0.08, -0.05, 'riderUpper'),
                makePart('cylinder', 'gold', 0, 2.19, -0.01, 0.28, 0.028, 0.29, -0.06, 0.08, -0.05, 'riderUpper'),
                makePart('frustum', 'enemyCloth', 0.14, 2.28, -0.08, 0.08, 0.26, 0.05, -0.85, 0.25, -0.25, 'riderUpper'),
                // Mounted carbine on riderRightArmWeapon (hand at 0.22, 1.67, 0.32)
                ...buildEuroRiderRightArm('buffLeather'),
                makePart('frustum', 'wood', 0.22, 1.67, 0.22, 0.055, 0.24, 0.085, 1.35, 0, 0, 'riderRightArmWeapon'),
                makePart('box', 'wood', 0.22, 1.70, 0.46, 0.045, 0.055, 0.36, -0.12, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'steel', 0.22, 1.73, 0.66, 0.034, 0.68, 0.034, 1.45, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'burnishedBronze', 0.22, 1.72, 0.60, 0.042, 0.04, 0.042, 1.45, 0, 0, 'riderRightArmWeapon')
            ];
        }

        const FIXED_EURO_CAVALRY = {
            'fixed:euro_curassier_pistol': buildFixedEuroCurassierPistol(),
            'fixed:euro_curassier_sword': buildFixedEuroCurassierSword(),
            'fixed:euro_light_cavalry': buildFixedEuroLightCavalry(),
            'fixed:euro_harquebusier_mounted': buildFixedEuroHarquebusierMounted()
        };
    """
