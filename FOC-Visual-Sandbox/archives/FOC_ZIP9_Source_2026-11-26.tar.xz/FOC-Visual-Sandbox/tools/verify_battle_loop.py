import subprocess, os, tempfile, json

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), 'foc_battle_live_test')
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

test_script = """
<script>
window.addEventListener('load', () => {
    setTimeout(() => {
        const out = {};
        try {
            const preOverlay = document.getElementById('rtsPreBattleOverlay');
            const hud = document.getElementById('rtsBattleHUD');
            out.initial = {
                preOverlayDisplay: window.getComputedStyle(preOverlay).display,
                hudDisplay: window.getComputedStyle(hud).display,
                hasBattleEngine: !!window.rtsBattleEngine,
                gameState: window.rtsBattleEngine ? window.rtsBattleEngine.gameState : null
            };

            // Start battle
            const btn = document.getElementById('btnStartBattleMain');
            if (btn) btn.click();

            out.afterStart = {
                gameState: window.rtsBattleEngine ? window.rtsBattleEngine.gameState : null,
                preOverlayDisplay: window.getComputedStyle(preOverlay).display,
                hudDisplay: window.getComputedStyle(hud).display
            };

            const be = window.rtsBattleEngine;
            // Select friendly units and issue move order
            const friendlies = be.friendlyUnits.slice(0, 10);
            be.selectedSoldierIds = friendlies.map(u => u.id);
            be.issueMoveOrder(0, 15);

            out.moveOrder = {
                selectedCount: be.selectedSoldierIds.length,
                firstUnitWaypoints: friendlies[0].targetWaypoints
            };

            // Let simulated battle tick for 2 seconds (simulate 20 frames of 100ms)
            for (let i = 0; i < 20; i++) {
                be.update(0.1);
            }

            out.battleTick = {
                elapsed: be.battleElapsedSec,
                friendlyLive: be.friendlyUnits.filter(u => u.alive).length,
                enemyLive: be.enemyUnits.filter(u => u.alive).length,
                timerText: document.getElementById('hudTimer').textContent,
                friendlyText: document.getElementById('hudPlayerCount').textContent,
                enemyText: document.getElementById('hudEnemyCount').textContent,
                gameState: be.gameState
            };

        } catch (e) {
            out.error = e.toString() + "\\n" + e.stack;
        }

        const dump = document.createElement('div');
        dump.id = 'battleLiveOutput';
        dump.textContent = JSON.stringify(out);
        document.body.appendChild(dump);
    }, 400);
});
</script>
"""

temp_html = os.path.join(tempfile.gettempdir(), 'foc_battle_test_temp.html')
with open(temp_html, 'w', encoding='utf-8') as f:
    f.write(content.replace('</body>', test_script + '</body>'))

cmd = [
    chrome_path,
    '--headless=new',
    '--user-data-dir=' + temp_profile,
    '--virtual-time-budget=5000',
    '--dump-dom',
    '--screenshot=' + os.path.abspath('playable_rts_in_battle.png'),
    '--window-size=1280,720',
    'file:///' + temp_html.replace('\\', '/')
]

res = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
output = res.stdout

start_idx = output.find('<div id="battleLiveOutput">')
if start_idx != -1:
    end_idx = output.find('</div>', start_idx)
    raw = output[start_idx + len('<div id="battleLiveOutput">'):end_idx]
    print("BATTLE TEST OUTPUT:")
    print(raw)
else:
    print("Could not find battleLiveOutput. Output length:", len(output))
