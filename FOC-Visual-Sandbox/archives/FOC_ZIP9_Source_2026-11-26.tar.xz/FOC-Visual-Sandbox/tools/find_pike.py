import re

with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find("pikeman = (side)")
if idx == -1:
    idx = text.find("pikeman")
    # find where template is constructed
    matches = [m.start() for m in re.finditer(r"infantry_pikeman", text)]
    for m in matches:
        snippet = text[max(0, m-50):min(len(text), m+400)]
        if 'parts' in snippet or 'return' in snippet or 'humanBase' in snippet:
            print(snippet)
            print('='*40)
else:
    print(text[idx-50:idx+800])
