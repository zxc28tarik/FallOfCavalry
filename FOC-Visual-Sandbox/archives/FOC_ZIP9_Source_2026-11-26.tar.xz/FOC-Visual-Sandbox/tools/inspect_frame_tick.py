with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('_onFrameTick(dt) {')
if pos == -1:
    pos = text.find('_onFrameTick(deltaTime')
print("pos:", pos)
print(text[pos:pos+1500])
