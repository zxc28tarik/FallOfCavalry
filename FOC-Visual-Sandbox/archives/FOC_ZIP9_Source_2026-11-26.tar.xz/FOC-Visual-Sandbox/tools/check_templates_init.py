with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('this.templates = createSoldierPartTemplates();')
if idx == -1:
    idx = text.find('createSoldierPartTemplates')
print(text[idx-100:idx+800])
