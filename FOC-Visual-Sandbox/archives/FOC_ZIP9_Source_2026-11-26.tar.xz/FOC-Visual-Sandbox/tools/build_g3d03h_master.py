# -*- coding: utf-8 -*-
"""
Full build script for G3D03H_WORKING.html
"""

import os
import re

with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update Title and Header Strings
html = html.replace('FALL OF CAVALRY — G3D-03G', 'FALL OF CAVALRY — G3D-03H')
html = html.replace('G3D-03G: 6 AJANLI RTS MODEL KALİTESİ', 'G3D-03H: 6 AJANLI RTS KOMUTA & BİRLİK YÖNETİMİ')
html = html.replace('6 AJAN BİRLEŞİK GÖRSEL SAVAŞ AKIŞI (G3D 03F)', '6 AJANLI RTS KOMUTA, BİRLİK YÖNETİMİ & FORMASYON (G3D-03H)')
html = html.replace('50 / 50', '58 / 58')
html = html.replace('50 doğrulama testi', '58 doğrulama testi')

# 2. Add RTS CSS Styles
rts_css = '''
        /* ============================================================================
         * G3D-03H RTS KOMUTA, SEÇİM, FORMASYON VE MİNİMAP STİLLERİ
         * ============================================================================ */
        #selectionMarquee {
            position: absolute;
            border: 1.5px solid rgba(56, 189, 248, 0.9);
            background: rgba(56, 189, 248, 0.15);
            pointer-events: none;
            display: none;
            z-index: 35;
            box-shadow: 0 0 10px rgba(56, 189, 248, 0.3) inset;
        }

        #rtsBottomConsole {
            position: absolute;
            bottom: 54px;
            left: 50%;
            transform: translateX(-50%);
            width: calc(100% - 28px);
            max-width: 1280px;
            background: rgba(15, 23, 42, 0.92);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(148, 163, 184, 0.28);
            border-radius: 10px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.65);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 8px 16px;
            gap: 14px;
            z-index: 25;
            pointer-events: auto;
            transition: opacity 0.2s ease;
        }

        .rts-unit-card {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 260px;
        }
        .rts-unit-badge {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: #1e293b;
            border: 2px solid #38bdf8;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #38bdf8;
            flex-shrink: 0;
        }
        .rts-unit-badge.enemy {
            border-color: #ef4444;
            color: #ef4444;
        }
        .rts-unit-details {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .rts-unit-title {
            font-size: 13px;
            font-weight: 700;
            color: #f8fafc;
            letter-spacing: 0.3px;
        }
        .rts-unit-sub {
            font-size: 11px;
            color: #94a3b8;
            display: flex;
            gap: 8px;
        }
        .rts-unit-sub span.status-highlight {
            color: #38bdf8;
            font-weight: 600;
        }

        .rts-button-group {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }
        .rts-btn {
            background: rgba(30, 41, 59, 0.85);
            color: #e2e8f0;
            border: 1px solid rgba(148, 163, 184, 0.25);
            border-radius: 6px;
            padding: 6px 10px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
            display: flex;
            align-items: center;
            gap: 5px;
            user-select: none;
        }
        .rts-btn:hover {
            background: rgba(51, 65, 85, 0.95);
            border-color: #38bdf8;
            color: #38bdf8;
            transform: translateY(-1px);
        }
        .rts-btn.active {
            background: #0284c7;
            border-color: #38bdf8;
            color: #ffffff;
            box-shadow: 0 0 8px rgba(56, 189, 248, 0.5);
        }
        .rts-btn kbd {
            background: rgba(0, 0, 0, 0.35);
            border-radius: 3px;
            padding: 1px 4px;
            font-size: 9px;
            color: #94a3b8;
        }

        .rts-divider {
            width: 1px;
            height: 32px;
            background: rgba(148, 163, 184, 0.2);
        }

        #rtsMinimapWrapper {
            position: absolute;
            top: 56px;
            right: 14px;
            background: rgba(15, 23, 42, 0.92);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(148, 163, 184, 0.3);
            border-radius: 8px;
            padding: 6px;
            box-shadow: 0 6px 24px rgba(0, 0, 0, 0.6);
            z-index: 25;
            display: flex;
            flex-direction: column;
            gap: 4px;
            user-select: none;
        }
        .rts-minimap-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 10px;
            font-weight: 700;
            color: #94a3b8;
            padding: 0 2px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        #rtsMinimapCanvas {
            background: #0b1329;
            border-radius: 4px;
            border: 1px solid rgba(56, 189, 248, 0.2);
            cursor: crosshair;
        }
'''

html = html.replace('</style>', rts_css + '\n    </style>')

# 3. Add Marquee and HUD DOM Elements
rts_dom_elements = '''
    <!-- G3D-03H RTS MARQUEE SELECTION BOX -->
    <div id="selectionMarquee"></div>

    <!-- G3D-03H RTS MINIMAP -->
    <div id="rtsMinimapWrapper">
        <div class="rts-minimap-header">
            <span>Taktik Radar</span>
            <span id="minimapCoords" style="color: #38bdf8;">0, 0</span>
        </div>
        <canvas id="rtsMinimapCanvas" width="180" height="180"></canvas>
    </div>

    <!-- G3D-03H RTS MINIMALIST BOTTOM COMMAND CONSOLE -->
    <div id="rtsBottomConsole">
        <div class="rts-unit-card" id="rtsUnitCard">
            <div class="rts-unit-badge" id="rtsUnitBadge">⚔️</div>
            <div class="rts-unit-details">
                <div class="rts-unit-title" id="rtsUnitTitle">Tüm Ordu (150 Dost / 150 Düşman)</div>
                <div class="rts-unit-sub">
                    <span id="rtsUnitCount">300 Asker Hazır</span>
                    <span>•</span>
                    <span id="rtsUnitOrder" class="status-highlight">Emir: Serbest</span>
                    <span>•</span>
                    <span id="rtsUnitFormation">Formasyon: Hat</span>
                </div>
            </div>
        </div>

        <div class="rts-divider"></div>

        <!-- 8 Taktik Emir Butonları (Ajan 05) -->
        <div class="rts-button-group" id="rtsCommandBar">
            <button id="btnCmdMove" type="button" class="rts-btn active" title="Hedefe İlerle (M)"><kbd>M</kbd> Hareket</button>
            <button id="btnCmdHold" type="button" class="rts-btn" title="Mevcut Konumu Koru ve Savun (H)"><kbd>H</kbd> Konum Tut</button>
            <button id="btnCmdAttack" type="button" class="rts-btn" title="Hedefe Hücum Et (A)"><kbd>A</kbd> Saldır</button>
            <button id="btnCmdAttackMove" type="button" class="rts-btn" title="Saldırarak İlerle (T)"><kbd>T</kbd> Saldır-İlerle</button>
            <button id="btnCmdRetreat" type="button" class="rts-btn" title="Geri Çekil ve Toparlan (R)"><kbd>R</kbd> Geri Çekil</button>
            <button id="btnCmdFireAtWill" type="button" class="rts-btn" title="Menzile Girene Serbest Ateş (F)"><kbd>F</kbd> Serbest Ateş</button>
            <button id="btnCmdHoldFire" type="button" class="rts-btn" title="Ateşi Kes ve Barut Koru (X)"><kbd>X</kbd> Ateşi Kes</button>
            <button id="btnCmdRegroup" type="button" class="rts-btn" title="Birlikleri Merkeze Topla (G)"><kbd>G</kbd> Topla</button>
        </div>

        <div class="rts-divider"></div>

        <!-- 6 Taktik Formasyon Butonları (Ajan 03) -->
        <div class="rts-button-group" id="rtsFormationBar">
            <button id="btnFormLine" type="button" class="rts-btn active" title="Geniş Ateş Hattı (F1)">Hat</button>
            <button id="btnFormColumn" type="button" class="rts-btn" title="İntikal Kolu (F2)">Kol</button>
            <button id="btnFormWedge" type="button" class="rts-btn" title="Yarma Kaması (F3)">Kama</button>
            <button id="btnFormLoose" type="button" class="rts-btn" title="Gevşek Düzen (Top Atışına Karşı) (F4)">Gevşek</button>
            <button id="btnFormSkirmish" type="button" class="rts-btn" title="Dağınık Avcı Düzeni (F5)">Dağınık</button>
            <button id="btnFormCircle" type="button" class="rts-btn" title="Dairesel Savunma / Kirpi (F6)">Çember</button>
        </div>
    </div>
'''

html = html.replace('<footer id="focFooter"', rts_dom_elements + '\n    <footer id="focFooter"')

# 4. Insert RTS Mathematical & Core Classes
rts_js_classes = '''
        /* ============================================================================
         * G3D-03H RTS MATEMATİKSEL PROJEKSİYON VE RAYCAST FONKSİYONLARI
         * ============================================================================ */
        function screenToGroundPlane(screenX, screenY, width, height, cameraController) {
            if (!cameraController) return null;
            const safeW = Math.max(1, width);
            const safeH = Math.max(1, height);
            const ndcX = (screenX / safeW) * 2 - 1;
            const ndcY = 1 - (screenY / safeH) * 2;

            const cam = cameraController.current;
            const yaw = cam.yaw;
            const pitch = cam.pitch;
            const dist = cam.distance;

            const eyeX = cam.targetX + Math.sin(yaw) * Math.cos(pitch) * dist;
            const eyeY = Math.sin(pitch) * dist;
            const eyeZ = cam.targetZ + Math.cos(yaw) * Math.cos(pitch) * dist;

            const fwdX = -Math.sin(yaw) * Math.cos(pitch);
            const fwdY = -Math.sin(pitch);
            const fwdZ = -Math.cos(yaw) * Math.cos(pitch);

            const rightX = Math.cos(yaw);
            const rightY = 0;
            const rightZ = -Math.sin(yaw);

            const upX = rightY * fwdZ - rightZ * fwdY;
            const upY = rightZ * fwdX - rightX * fwdZ;
            const upZ = rightX * fwdY - rightY * fwdX;

            const aspect = safeW / safeH;
            const fovHalfTan = Math.tan(42 * 0.5 * Math.PI / 180);

            const rayDirX = fwdX + rightX * (ndcX * aspect * fovHalfTan) + upX * (ndcY * fovHalfTan);
            const rayDirY = fwdY + rightY * (ndcX * aspect * fovHalfTan) + upY * (ndcY * fovHalfTan);
            const rayDirZ = fwdZ + rightZ * (ndcX * aspect * fovHalfTan) + upZ * (ndcY * fovHalfTan);

            if (Math.abs(rayDirY) < 1e-5) return null;
            const t = -eyeY / rayDirY;
            if (t < 0) return null;

            return {
                x: eyeX + t * rayDirX,
                y: 0,
                z: eyeZ + t * rayDirZ
            };
        }

        function projectWorldToScreen(wx, wy, wz, cam, aspect, width, height) {
            const yaw = cam.yaw;
            const pitch = cam.pitch;
            const dist = cam.distance;

            const eyeX = cam.targetX + Math.sin(yaw) * Math.cos(pitch) * dist;
            const eyeY = Math.sin(pitch) * dist;
            const eyeZ = cam.targetZ + Math.cos(yaw) * Math.cos(pitch) * dist;

            const fwdX = -Math.sin(yaw) * Math.cos(pitch);
            const fwdY = -Math.sin(pitch);
            const fwdZ = -Math.cos(yaw) * Math.cos(pitch);

            const rightX = Math.cos(yaw);
            const rightY = 0;
            const rightZ = -Math.sin(yaw);

            const upX = rightY * fwdZ - rightZ * fwdY;
            const upY = rightZ * fwdX - rightX * fwdZ;
            const upZ = rightX * fwdY - rightY * fwdX;

            const dx = wx - eyeX;
            const dy = wy - eyeY;
            const dz = wz - eyeZ;

            const camZ = dx * fwdX + dy * fwdY + dz * fwdZ;
            if (camZ <= 0.1) return null;

            const camX = dx * rightX + dy * rightY + dz * rightZ;
            const camY = dx * upX + dy * upY + dz * upZ;

            const fovHalfTan = Math.tan(42 * 0.5 * Math.PI / 180);
            const ndcX = camX / (camZ * aspect * fovHalfTan);
            const ndcY = camY / (camZ * fovHalfTan);

            return {
                x: (ndcX + 1) * 0.5 * width,
                y: (1 - ndcY) * 0.5 * height,
                depth: camZ
            };
        }

        /* ============================================================================
         * MODULE: RTSSelectionManager (Agent 01 - Birlik Seçimi & Kontrol Grupları)
         * ============================================================================ */
        class RTSSelectionManager {
            constructor(renderer) {
                this.renderer = renderer;
                this.selectedSoldierIds = new Set();
                this.selectedGroupIds = new Set();
                this.controlGroups = new Map();
                this.lastSelectedArchetype = null;
                this.lastClickTime = 0;
                this.lastClickId = null;
            }

            clear() {
                this.selectedSoldierIds.clear();
                this.selectedGroupIds.clear();
                this.lastSelectedArchetype = null;
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            select(soldierId, isShift = false, selectEntireGroup = false) {
                if (!isShift) {
                    this.clear();
                }
                if (!soldierId) return;

                const rec = this.renderer.soldierRegistry?.records?.get(soldierId);
                if (!rec) return;

                if (selectEntireGroup && rec.groupId) {
                    this.selectGroup(rec.groupId, isShift);
                    return;
                }

                if (this.selectedSoldierIds.has(soldierId) && isShift) {
                    this.selectedSoldierIds.delete(soldierId);
                } else {
                    this.selectedSoldierIds.add(soldierId);
                    this.lastSelectedArchetype = rec.archetype;
                    if (rec.groupId) this.selectedGroupIds.add(rec.groupId);
                }
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            selectGroup(groupId, isShift = false) {
                if (!isShift) {
                    this.clear();
                }
                if (!groupId) return;
                this.selectedGroupIds.add(groupId);

                const records = this.renderer.soldierRegistry?.records;
                if (!records) return;

                for (const [id, rec] of records.entries()) {
                    if (rec.groupId === groupId) {
                        this.selectedSoldierIds.add(id);
                        this.lastSelectedArchetype = rec.archetype;
                    }
                }
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            selectInScreenRect(minX, minY, maxX, maxY, isShift = false, cameraController, width, height) {
                if (!isShift) {
                    this.clear();
                }
                const records = this.renderer.soldierRegistry?.records;
                if (!records || records.size === 0) return 0;

                let selectedCount = 0;
                const aspect = width / height;
                const cam = cameraController.current;

                for (const [id, rec] of records.entries()) {
                    const screen = projectWorldToScreen(rec.x, rec.y, rec.z, cam, aspect, width, height);
                    if (screen && screen.x >= minX && screen.x <= maxX && screen.y >= minY && screen.y <= maxY) {
                        this.selectedSoldierIds.add(id);
                        if (rec.groupId) this.selectedGroupIds.add(rec.groupId);
                        this.lastSelectedArchetype = rec.archetype;
                        selectedCount++;
                    }
                }
                if (this.renderer) this.renderer.selectionDirty = true;
                return selectedCount;
            }

            selectSameClass(archetype, isShift = false) {
                if (!isShift) {
                    this.clear();
                }
                const records = this.renderer.soldierRegistry?.records;
                if (!records) return;

                for (const [id, rec] of records.entries()) {
                    if (rec.archetype === archetype) {
                        this.selectedSoldierIds.add(id);
                        if (rec.groupId) this.selectedGroupIds.add(rec.groupId);
                    }
                }
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            assignControlGroup(num) {
                if (num < 1 || num > 9) return;
                this.controlGroups.set(num, new Set(this.selectedSoldierIds));
            }

            recallControlGroup(num, isShift = false) {
                if (num < 1 || num > 9) return false;
                const group = this.controlGroups.get(num);
                if (!group || group.size === 0) return false;

                if (!isShift) {
                    this.clear();
                }
                for (const id of group) {
                    this.selectedSoldierIds.add(id);
                    const rec = this.renderer.soldierRegistry?.records?.get(id);
                    if (rec && rec.groupId) this.selectedGroupIds.add(rec.groupId);
                }
                if (this.renderer) this.renderer.selectionDirty = true;
                return true;
            }

            isSelected(soldierId) {
                return this.selectedSoldierIds.has(soldierId);
            }

            getSelectedList() {
                const records = this.renderer.soldierRegistry?.records;
                if (!records) return [];
                const list = [];
                for (const id of this.selectedSoldierIds) {
                    const r = records.get(id);
                    if (r) list.push(r);
                }
                return list;
            }
        }

        /* ============================================================================
         * MODULE: RTSFormationManager (Agent 03 - 6 Taktik Formasyon Sistemi)
         * ============================================================================ */
        class RTSFormationManager {
            constructor() {
                this.currentFormation = 'line';
            }

            setFormation(type) {
                const valid = ['line', 'column', 'wedge', 'loose', 'skirmish', 'circle'];
                if (valid.includes(type)) {
                    this.currentFormation = type;
                    return true;
                }
                return false;
            }

            computeSlots(count, isCavalry = false, facingYaw = 0.0, formationOverride = null) {
                const form = formationOverride || this.currentFormation;
                const spX = isCavalry ? 2.2 : 1.1;
                const spZ = isCavalry ? 2.5 : 1.3;
                const localSlots = [];

                if (form === 'line') {
                    const files = Math.ceil(count / 2);
                    for (let i = 0; i < count; i++) {
                        const rank = i % 2;
                        const col = Math.floor(i / 2);
                        const lx = (col - (files - 1) * 0.5) * spX;
                        const lz = -rank * spZ;
                        localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                    }
                } else if (form === 'column') {
                    const numCols = count <= 4 ? 2 : 3;
                    for (let i = 0; i < count; i++) {
                        const col = i % numCols;
                        const row = Math.floor(i / numCols);
                        const lx = (col - (numCols - 1) * 0.5) * spX;
                        const lz = -row * spZ;
                        localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                    }
                } else if (form === 'wedge') {
                    for (let i = 0; i < count; i++) {
                        if (i === 0) {
                            localSlots.push({ x: 0, z: 0, extraYaw: 0 });
                        } else {
                            const tier = Math.floor((i + 1) / 2);
                            const side = (i % 2 === 1) ? -1 : 1;
                            const lx = side * tier * spX * 0.9;
                            const lz = -tier * spZ * 1.1;
                            localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                        }
                    }
                } else if (form === 'loose') {
                    const cols = Math.ceil(Math.sqrt(count * 1.5));
                    for (let i = 0; i < count; i++) {
                        const row = Math.floor(i / cols);
                        const col = i % cols;
                        const stagger = (row % 2) * 0.5 * spX;
                        const lx = (col - (cols - 1) * 0.5) * (spX * 2.0) + stagger;
                        const lz = -row * (spZ * 1.8);
                        localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                    }
                } else if (form === 'skirmish') {
                    const maxR = Math.sqrt(count) * spX * 1.2;
                    for (let i = 0; i < count; i++) {
                        const r = Math.sqrt((i + 0.5) / count) * maxR;
                        const ang = i * 2.3999632;
                        localSlots.push({
                            x: r * Math.cos(ang),
                            z: r * Math.sin(ang),
                            extraYaw: 0
                        });
                    }
                } else if (form === 'circle') {
                    const r = Math.max(3.0, (count * spX) / (2.0 * Math.PI));
                    for (let i = 0; i < count; i++) {
                        const ang = (i / count) * 2.0 * Math.PI;
                        localSlots.push({
                            x: r * Math.sin(ang),
                            z: r * Math.cos(ang),
                            extraYaw: ang
                        });
                    }
                }

                const cosY = Math.cos(facingYaw);
                const sinY = Math.sin(facingYaw);
                return localSlots.map(s => ({
                    dx: s.x * cosY - s.z * sinY,
                    dz: s.x * sinY + s.z * cosY,
                    yaw: facingYaw + s.extraYaw
                }));
            }
        }

        /* ============================================================================
         * MODULE: RTSMovementManager (Agent 02 - Birlik Hareketi & Rota Yönlendirme)
         * ============================================================================ */
        class RTSMovementManager {
            constructor(renderer) {
                this.renderer = renderer;
                this.waypointQueues = new Map();
                this.activeMovePings = [];
            }

            issueMoveOrder(targetX, targetZ, isShift = false, formationManager = null) {
                const selection = this.renderer.selectionManager?.getSelectedList() || [];
                if (selection.length === 0) return;

                this.triggerMovePing(targetX, targetZ);

                const groups = new Map();
                for (const sol of selection) {
                    const gKey = sol.groupId || 'independent';
                    if (!groups.has(gKey)) groups.set(gKey, []);
                    groups.get(gKey).push(sol);
                }

                for (const [gKey, soldiers] of groups.entries()) {
                    let cx = 0, cz = 0;
                    soldiers.forEach(s => { cx += s.x; cz += s.z; });
                    cx /= soldiers.length;
                    cz /= soldiers.length;

                    const facingYaw = Math.atan2(targetX - cx, targetZ - cz);
                    const isCavalry = soldiers[0]?.archetype?.startsWith('cavalry');
                    const slots = formationManager
                        ? formationManager.computeSlots(soldiers.length, isCavalry, facingYaw)
                        : soldiers.map(() => ({ dx: 0, dz: 0, yaw: facingYaw }));

                    for (let i = 0; i < soldiers.length; i++) {
                        const sol = soldiers[i];
                        const slot = slots[i];
                        const destX = targetX + slot.dx;
                        const destZ = targetZ + slot.dz;

                        if (!isShift) {
                            this.waypointQueues.delete(sol.viewId);
                            sol.targetX = destX;
                            sol.targetY = 0;
                            sol.targetZ = destZ;
                            sol.desiredYaw = slot.yaw;
                            sol.isMoving = true;
                            sol.currentOrder = 'move';
                            sol.isCombatActing = false;
                        } else {
                            if (!this.waypointQueues.has(sol.viewId)) {
                                this.waypointQueues.set(sol.viewId, []);
                            }
                            this.waypointQueues.get(sol.viewId).push({ x: destX, z: destZ, yaw: slot.yaw });
                        }
                    }
                }
            }

            updateWaypoints() {
                const records = this.renderer.soldierRegistry?.records;
                if (!records) return;

                for (const [id, queue] of this.waypointQueues.entries()) {
                    if (queue.length === 0) continue;
                    const sol = records.get(id);
                    if (!sol) continue;

                    const dist = Math.hypot(sol.targetX - sol.x, sol.targetZ - sol.z);
                    if (dist < 0.45 && !sol.isMoving) {
                        const nextWp = queue.shift();
                        sol.targetX = nextWp.x;
                        sol.targetY = 0;
                        sol.targetZ = nextWp.z;
                        sol.desiredYaw = nextWp.yaw;
                        sol.isMoving = true;
                    }
                }
            }

            triggerMovePing(x, z) {
                this.activeMovePings.push({ x, z, progress: 0 });
            }

            updatePings(dt) {
                for (let i = this.activeMovePings.length - 1; i >= 0; i--) {
                    this.activeMovePings[i].progress += dt * 1.5;
                    if (this.activeMovePings[i].progress >= 1.0) {
                        this.activeMovePings.splice(i, 1);
                    }
                }
            }
        }

        /* ============================================================================
         * MODULE: RTSCommandManager (Agent 05 - 8 Taktik RTS Emir Sistemi)
         * ============================================================================ */
        class RTSCommandManager {
            constructor(renderer) {
                this.renderer = renderer;
                this.currentOrder = 'move';
            }

            executeCommand(orderType) {
                const selection = this.renderer.selectionManager?.getSelectedList() || [];
                if (selection.length === 0) return false;

                this.currentOrder = orderType;

                for (const sol of selection) {
                    sol.currentOrder = orderType;

                    if (orderType === 'hold') {
                        sol.targetX = sol.x;
                        sol.targetY = sol.y;
                        sol.targetZ = sol.z;
                        sol.isMoving = false;
                        sol.isCombatActing = true;
                        sol.actionMode = 'guard';
                    } else if (orderType === 'attack') {
                        sol.isCombatActing = true;
                        sol.actionMode = 'attack';
                    } else if (orderType === 'attack_move') {
                        sol.actionMode = 'attack';
                    } else if (orderType === 'retreat') {
                        const retreatDir = sol.side === 'player' ? -1 : 1;
                        sol.targetX = sol.x;
                        sol.targetZ = sol.z + retreatDir * 20.0;
                        sol.desiredYaw = retreatDir < 0 ? Math.PI : 0;
                        sol.isMoving = true;
                        sol.isCombatActing = false;
                    } else if (orderType === 'fire_at_will') {
                        const isRanged = sol.archetype === 'infantry_musketeer' || sol.archetype.includes('carbine') || sol.archetype.includes('pistol');
                        if (isRanged) {
                            sol.isCombatActing = true;
                            sol.actionMode = 'attack';
                        }
                    } else if (orderType === 'hold_fire') {
                        sol.isCombatActing = false;
                        sol.muzzleFired = false;
                    } else if (orderType === 'regroup') {
                        const formManager = this.renderer.formationManager;
                        if (formManager) {
                            const selList = this.renderer.selectionManager.getSelectedList();
                            let cx = 0, cz = 0;
                            selList.forEach(s => { cx += s.x; cz += s.z; });
                            cx /= selList.length;
                            cz /= selList.length;
                            this.renderer.movementManager.issueMoveOrder(cx, cz, false, formManager);
                        }
                    }
                }
                return true;
            }
        }

        /* ============================================================================
         * MODULE: RTSMinimapController (Agent 06 - Sade Taktik Minimap & Radar)
         * ============================================================================ */
        class RTSMinimapController {
            constructor(canvas, renderer) {
                this.canvas = canvas;
                this.ctx = canvas ? canvas.getContext('2d') : null;
                this.renderer = renderer;
                this.isDragging = false;
                this.bounds = { minX: -60, maxX: 60, minZ: -60, maxZ: 60 };
                this._bindEvents();
            }

            _bindEvents() {
                if (!this.canvas) return;
                this.canvas.addEventListener('mousedown', (e) => {
                    if (e.button === 0) {
                        this.isDragging = true;
                        this._handleClick(e);
                    } else if (e.button === 2) {
                        e.preventDefault();
                        this._handleRightClick(e);
                    }
                });
                window.addEventListener('mousemove', (e) => {
                    if (this.isDragging) this._handleClick(e);
                });
                window.addEventListener('mouseup', () => {
                    this.isDragging = false;
                });
                this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
            }

            _handleClick(e) {
                const rect = this.canvas.getBoundingClientRect();
                const mx = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                const my = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));

                const wx = this.bounds.minX + mx * (this.bounds.maxX - this.bounds.minX);
                const wz = this.bounds.minZ + my * (this.bounds.maxZ - this.bounds.minZ);

                if (this.renderer.cameraController) {
                    this.renderer.cameraController.desired.targetX = wx;
                    this.renderer.cameraController.desired.targetZ = wz;
                }
            }

            _handleRightClick(e) {
                const rect = this.canvas.getBoundingClientRect();
                const mx = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                const my = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));

                const wx = this.bounds.minX + mx * (this.bounds.maxX - this.bounds.minX);
                const wz = this.bounds.minZ + my * (this.bounds.maxZ - this.bounds.minZ);

                if (this.renderer.movementManager) {
                    this.renderer.movementManager.issueMoveOrder(wx, wz, e.shiftKey, this.renderer.formationManager);
                }
            }

            render() {
                if (!this.ctx || !this.renderer) return;
                const ctx = this.ctx;
                const w = this.canvas.width;
                const h = this.canvas.height;

                ctx.clearRect(0, 0, w, h);

                // Grid lines
                ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(w * 0.5, 0); ctx.lineTo(w * 0.5, h);
                ctx.moveTo(0, h * 0.5); ctx.lineTo(w, h * 0.5);
                ctx.stroke();

                // Render soldiers
                const records = this.renderer.soldierRegistry?.records;
                const selManager = this.renderer.selectionManager;

                if (records) {
                    for (const [id, sol] of records.entries()) {
                        const sx = ((sol.x - this.bounds.minX) / (this.bounds.maxX - this.bounds.minX)) * w;
                        const sy = ((sol.z - this.bounds.minZ) / (this.bounds.maxZ - this.bounds.minZ)) * h;

                        const isSelected = selManager && selManager.isSelected(id);

                        if (isSelected) {
                            ctx.fillStyle = '#facc15';
                            ctx.beginPath();
                            ctx.arc(sx, sy, 3.5, 0, Math.PI * 2);
                            ctx.fill();
                        }

                        ctx.fillStyle = sol.side === 'enemy' ? '#ef4444' : '#38bdf8';
                        ctx.beginPath();
                        ctx.arc(sx, sy, isSelected ? 2.2 : 1.6, 0, Math.PI * 2);
                        ctx.fill();
                    }
                }

                // Render camera viewport frustum rectangle
                const cam = this.renderer.cameraController?.current;
                if (cam) {
                    const cx = ((cam.targetX - this.bounds.minX) / (this.bounds.maxX - this.bounds.minX)) * w;
                    const cy = ((cam.targetZ - this.bounds.minZ) / (this.bounds.maxZ - this.bounds.minZ)) * h;
                    const viewRadius = (cam.distance / 95.0) * (w * 0.22);

                    ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
                    ctx.lineWidth = 1.5;
                    ctx.strokeRect(cx - viewRadius, cy - viewRadius * 0.7, viewRadius * 2, viewRadius * 1.4);

                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(cx - 1.5, cy - 1.5, 3, 3);
                }
            }
        }
'''

html = html.replace('class RTSCamera3D {', rts_js_classes + '\n        class RTSCamera3D {')

# 5. Add focusOnSelection() to RTSCamera3D
focus_selection_method = '''
            focusOnSelection(selectionList) {
                if (!selectionList || selectionList.length === 0) {
                    this.focusOnDefaultTarget();
                    return;
                }
                let sumX = 0, sumZ = 0;
                selectionList.forEach(s => { sumX += s.x; sumZ += s.z; });
                this.desired.targetX = this._clamp(sumX / selectionList.length, this.bounds.minX, this.bounds.maxX);
                this.desired.targetZ = this._clamp(sumZ / selectionList.length, this.bounds.minZ, this.bounds.maxZ);
            }
'''
html = html.replace('focusOnDefaultTarget() {', focus_selection_method + '\n            focusOnDefaultTarget() {')

# 6. Enhance Battle3DRenderer with RTS Managers and Visuals
renderer_ctor_additions = '''
                this.selectionManager = new RTSSelectionManager(this);
                this.formationManager = new RTSFormationManager();
                this.movementManager = new RTSMovementManager(this);
                this.commandManager = new RTSCommandManager(this);
                this.minimapController = null;
                this.selectionDirty = true;
                this.selectionRingsNode = null;
                this.movePingNode = null;
                this.dragSelect = {
                    active: false,
                    startX: 0,
                    startY: 0,
                    currentX: 0,
                    currentY: 0
                };
'''
html = html.replace('this.input = {', renderer_ctor_additions + '\n                this.input = {')

# In Battle3DRenderer.init():
init_rts_visuals = '''
                this._buildSelectionAndPingVisuals();
                const minimapCanvas = document.getElementById('rtsMinimapCanvas');
                if (minimapCanvas) {
                    this.minimapController = new RTSMinimapController(minimapCanvas, this);
                }
'''
html = html.replace('this._startAnimationLoop();', init_rts_visuals + '\n                this._startAnimationLoop();')

# Add _buildSelectionAndPingVisuals and update methods to Battle3DRenderer:
rts_renderer_methods = '''
            _buildSelectionAndPingVisuals() {
                // Ground selection rings line node
                const ringGeo = new FOC_THREE.BufferGeometry().setFromPoints([]);
                ringGeo.drawMode = 'LINES';
                const ringMat = new FOC_THREE.Material({
                    color: 0x38bdf8,
                    transparent: true,
                    opacity: 0.9,
                    isLine: true
                });
                this.selectionRingsNode = new FOC_THREE.Line(ringGeo, ringMat);
                this.scene.add(this.selectionRingsNode);
                this.disposables.geometries.push(ringGeo);
                this.disposables.materials.push(ringMat);

                // Ground move ping line node
                const pingGeo = new FOC_THREE.BufferGeometry().setFromPoints([]);
                pingGeo.drawMode = 'LINES';
                const pingMat = new FOC_THREE.Material({
                    color: 0xfacc15,
                    transparent: true,
                    opacity: 0.9,
                    isLine: true
                });
                this.movePingNode = new FOC_THREE.Line(pingGeo, pingMat);
                this.scene.add(this.movePingNode);
                this.disposables.geometries.push(pingGeo);
                this.disposables.materials.push(pingMat);
            }

            _updateRTSVisuals(dt) {
                if (this.movementManager) {
                    this.movementManager.updateWaypoints();
                    this.movementManager.updatePings(dt);
                }

                // Update Selection Rings
                if (this.selectionRingsNode) {
                    const selList = this.selectionManager?.getSelectedList() || [];
                    if (selList.length > 0) {
                        const pts = [];
                        const segs = 16;
                        for (let i = 0; i < selList.length; i++) {
                            const s = selList[i];
                            const r = s.archetype?.startsWith('cavalry') ? 1.55 : 0.88;
                            for (let j = 0; j < segs; j++) {
                                const a1 = (j / segs) * Math.PI * 2;
                                const a2 = ((j + 1) / segs) * Math.PI * 2;
                                pts.push(
                                    { x: s.x + Math.cos(a1) * r, y: 0.06, z: s.z + Math.sin(a1) * r },
                                    { x: s.x + Math.cos(a2) * r, y: 0.06, z: s.z + Math.sin(a2) * r }
                                );
                            }
                        }
                        this.selectionRingsNode.geometry.setFromPoints(pts);
                        this.selectionRingsNode.geometry.invalidateGpuHandle();
                        this.selectionRingsNode.visible = true;
                    } else {
                        this.selectionRingsNode.visible = false;
                    }
                }

                // Update Move Pings
                if (this.movePingNode && this.movementManager) {
                    const pings = this.movementManager.activeMovePings;
                    if (pings.length > 0) {
                        const pts = [];
                        const segs = 16;
                        for (let i = 0; i < pings.length; i++) {
                            const p = pings[i];
                            const r = 0.5 + p.progress * 2.2;
                            for (let j = 0; j < segs; j++) {
                                const a1 = (j / segs) * Math.PI * 2;
                                const a2 = ((j + 1) / segs) * Math.PI * 2;
                                pts.push(
                                    { x: p.x + Math.cos(a1) * r, y: 0.08, z: p.z + Math.sin(a1) * r },
                                    { x: p.x + Math.cos(a2) * r, y: 0.08, z: p.z + Math.sin(a2) * r }
                                );
                            }
                        }
                        this.movePingNode.geometry.setFromPoints(pts);
                        this.movePingNode.geometry.invalidateGpuHandle();
                        this.movePingNode.visible = true;
                    } else {
                        this.movePingNode.visible = false;
                    }
                }

                if (this.minimapController) {
                    this.minimapController.render();
                }
            }
'''

html = html.replace('this._updateKeyboardNavigation(dt);', 'this._updateRTSVisuals(dt);\n                this._updateKeyboardNavigation(dt);')
html = html.replace('_animate(now) {', rts_renderer_methods + '\n            _animate(now) {')

# 7. Update Mouse & Keyboard Handlers in Battle3DRenderer
mouse_handlers_replacement = '''
            _onMouseDown(e) {
                if (document.activeElement && typeof document.activeElement.blur === 'function') {
                    document.activeElement.blur();
                }

                const rect = this.mount ? this.mount.getBoundingClientRect() : { left: 0, top: 0, width: 800, height: 600 };
                const clientX = e.clientX - rect.left;
                const clientY = e.clientY - rect.top;

                if (e.button === 0) {
                    // Left click: Selection start
                    if (e.altKey) {
                        this.input.isOrbiting = true;
                        this.input.lastX = e.clientX;
                        this.input.lastY = e.clientY;
                    } else {
                        this.dragSelect.active = true;
                        this.dragSelect.startX = clientX;
                        this.dragSelect.startY = clientY;
                        this.dragSelect.currentX = clientX;
                        this.dragSelect.currentY = clientY;
                        this.dragSelect.isShift = e.shiftKey;
                    }
                } else if (e.button === 1) {
                    // Middle click: Camera Orbit
                    this.input.isOrbiting = true;
                    this.input.lastX = e.clientX;
                    this.input.lastY = e.clientY;
                } else if (e.button === 2) {
                    // Right click: Issue Move / Attack command
                    e.preventDefault();
                    const w = this.mount ? this.mount.clientWidth : 800;
                    const h = this.mount ? this.mount.clientHeight : 600;
                    const hit = screenToGroundPlane(clientX, clientY, w, h, this.cameraController);
                    if (hit && this.movementManager) {
                        this.movementManager.issueMoveOrder(hit.x, hit.z, e.shiftKey, this.formationManager);
                    }
                }
            }

            _onMouseMove(e) {
                const rect = this.mount ? this.mount.getBoundingClientRect() : { left: 0, top: 0 };
                const clientX = e.clientX - rect.left;
                const clientY = e.clientY - rect.top;

                if (this.dragSelect.active) {
                    this.dragSelect.currentX = clientX;
                    this.dragSelect.currentY = clientY;

                    const dx = this.dragSelect.currentX - this.dragSelect.startX;
                    const dy = this.dragSelect.currentY - this.dragSelect.startY;
                    const marquee = document.getElementById('selectionMarquee');

                    if (Math.hypot(dx, dy) > 5 && marquee) {
                        const left = Math.min(this.dragSelect.startX, this.dragSelect.currentX);
                        const top = Math.min(this.dragSelect.startY, this.dragSelect.currentY);
                        const w = Math.abs(dx);
                        const h = Math.abs(dy);
                        marquee.style.left = `${left + rect.left}px`;
                        marquee.style.top = `${top + rect.top}px`;
                        marquee.style.width = `${w}px`;
                        marquee.style.height = `${h}px`;
                        marquee.style.display = 'block';
                    }
                }

                if (this.input.isOrbiting && this.cameraController) {
                    const dx = e.clientX - this.input.lastX;
                    const dy = e.clientY - this.input.lastY;
                    this.input.lastX = e.clientX;
                    this.input.lastY = e.clientY;
                    this.cameraController.rotateBy(dx * 0.005, -dy * 0.004);
                } else if (this.input.isPanning && this.cameraController) {
                    const dx = e.clientX - this.input.lastX;
                    const dy = e.clientY - this.input.lastY;
                    this.input.lastX = e.clientX;
                    this.input.lastY = e.clientY;
                    this.cameraController.panByScreenDelta(dx, dy);
                }
            }

            _onMouseUp(e) {
                if (this.dragSelect.active) {
                    const rect = this.mount ? this.mount.getBoundingClientRect() : { left: 0, top: 0, width: 800, height: 600 };
                    const marquee = document.getElementById('selectionMarquee');
                    if (marquee) marquee.style.display = 'none';

                    const dx = this.dragSelect.currentX - this.dragSelect.startX;
                    const dy = this.dragSelect.currentY - this.dragSelect.startY;
                    const w = this.mount ? this.mount.clientWidth : 800;
                    const h = this.mount ? this.mount.clientHeight : 600;

                    if (Math.hypot(dx, dy) > 6 && this.selectionManager) {
                        // Box Marquee Selection
                        const minX = Math.min(this.dragSelect.startX, this.dragSelect.currentX);
                        const maxX = Math.max(this.dragSelect.startX, this.dragSelect.currentX);
                        const minY = Math.min(this.dragSelect.startY, this.dragSelect.currentY);
                        const maxY = Math.max(this.dragSelect.startY, this.dragSelect.currentY);
                        this.selectionManager.selectInScreenRect(minX, minY, maxX, maxY, this.dragSelect.isShift, this.cameraController, w, h);
                    } else if (this.selectionManager) {
                        // Single Click Pick
                        const hit = screenToGroundPlane(this.dragSelect.startX, this.dragSelect.startY, w, h, this.cameraController);
                        if (hit) {
                            let closestId = null;
                            let minDist = 2.4;
                            const records = this.soldierRegistry?.records;
                            if (records) {
                                for (const [id, sol] of records.entries()) {
                                    const d = Math.hypot(sol.x - hit.x, sol.z - hit.z);
                                    if (d < minDist) {
                                        minDist = d;
                                        closestId = id;
                                    }
                                }
                            }
                            const now = performance.now();
                            if (closestId && (now - this.selectionManager.lastClickTime < 350) && this.selectionManager.lastClickId === closestId) {
                                // Double click: select same class
                                const rec = records?.get(closestId);
                                if (rec) this.selectionManager.selectSameClass(rec.archetype, this.dragSelect.isShift);
                            } else if (closestId) {
                                this.selectionManager.select(closestId, this.dragSelect.isShift, false);
                                this.selectionManager.lastClickTime = now;
                                this.selectionManager.lastClickId = closestId;
                            } else if (!this.dragSelect.isShift) {
                                this.selectionManager.clear();
                            }
                        }
                    }
                    this.dragSelect.active = false;
                }

                this.input.isPanning = false;
                this.input.isOrbiting = false;
            }
'''

# Find _onMouseDown and replace until _onWheel
start_idx = html.find('            _onMouseDown(e) {')
end_idx = html.find('            _onWheel(e) {')
if start_idx != -1 and end_idx != -1:
    html = html[:start_idx] + mouse_handlers_replacement + '\n' + html[end_idx:]
    print("Mouse handlers successfully replaced!")
else:
    print("ERROR: Could not find mouse handlers!")

# Update KeyDown to support Control Groups (1-9) and RTS Command Hotkeys:
keydown_additions = '''
                // G3D-03H RTS Hotkeys & Control Groups
                if (e.code.startsWith('Digit') && !e.ctrlKey) {
                    const num = parseInt(e.code.replace('Digit', ''), 10);
                    if (num >= 1 && num <= 9 && this.selectionManager) {
                        this.selectionManager.recallControlGroup(num, e.shiftKey);
                    }
                } else if (e.code.startsWith('Digit') && e.ctrlKey) {
                    const num = parseInt(e.code.replace('Digit', ''), 10);
                    if (num >= 1 && num <= 9 && this.selectionManager) {
                        this.selectionManager.assignControlGroup(num);
                    }
                }

                // Command hotkeys
                if (this.commandManager) {
                    if (e.code === 'KeyM') this.commandManager.executeCommand('move');
                    else if (e.code === 'KeyH') this.commandManager.executeCommand('hold');
                    else if (e.code === 'KeyA') this.commandManager.executeCommand('attack');
                    else if (e.code === 'KeyT') this.commandManager.executeCommand('attack_move');
                    else if (e.code === 'KeyR') this.commandManager.executeCommand('retreat');
                    else if (e.code === 'KeyF') this.commandManager.executeCommand('fire_at_will');
                    else if (e.code === 'KeyX') this.commandManager.executeCommand('hold_fire');
                    else if (e.code === 'KeyG') this.commandManager.executeCommand('regroup');
                }

                // Formation hotkeys F1-F6
                if (this.formationManager) {
                    if (e.code === 'F1') { e.preventDefault(); this.formationManager.setFormation('line'); }
                    else if (e.code === 'F2') { e.preventDefault(); this.formationManager.setFormation('column'); }
                    else if (e.code === 'F3') { e.preventDefault(); this.formationManager.setFormation('wedge'); }
                    else if (e.code === 'F4') { e.preventDefault(); this.formationManager.setFormation('loose'); }
                    else if (e.code === 'F5') { e.preventDefault(); this.formationManager.setFormation('skirmish'); }
                    else if (e.code === 'F6') { e.preventDefault(); this.formationManager.setFormation('circle'); }
                }
'''
html = html.replace("if (e.code === 'Space') {", keydown_additions + "\n                if (e.code === 'Space') {")

# 8. Update Battle3DPreviewController to wire up RTS HUD
controller_ui_wireup = '''
            _bindRTSUIEvents() {
                const renderer = this.renderer;
                if (!renderer) return;

                // Wire up 8 Command Buttons
                const cmdMap = {
                    btnCmdMove: 'move',
                    btnCmdHold: 'hold',
                    btnCmdAttack: 'attack',
                    btnCmdAttackMove: 'attack_move',
                    btnCmdRetreat: 'retreat',
                    btnCmdFireAtWill: 'fire_at_will',
                    btnCmdHoldFire: 'hold_fire',
                    btnCmdRegroup: 'regroup'
                };
                for (const [btnId, cmd] of Object.entries(cmdMap)) {
                    const btn = document.getElementById(btnId);
                    if (btn) {
                        btn.addEventListener('click', () => {
                            if (renderer.commandManager) {
                                renderer.commandManager.executeCommand(cmd);
                                document.querySelectorAll('#rtsCommandBar .rts-btn').forEach(b => b.classList.remove('active'));
                                btn.classList.add('active');
                            }
                        });
                    }
                }

                // Wire up 6 Formation Buttons
                const formMap = {
                    btnFormLine: 'line',
                    btnFormColumn: 'column',
                    btnFormWedge: 'wedge',
                    btnFormLoose: 'loose',
                    btnFormSkirmish: 'skirmish',
                    btnFormCircle: 'circle'
                };
                for (const [btnId, form] of Object.entries(formMap)) {
                    const btn = document.getElementById(btnId);
                    if (btn) {
                        btn.addEventListener('click', () => {
                            if (renderer.formationManager) {
                                renderer.formationManager.setFormation(form);
                                document.querySelectorAll('#rtsFormationBar .rts-btn').forEach(b => b.classList.remove('active'));
                                btn.classList.add('active');
                            }
                        });
                    }
                }
            }

            _updateRTSHUD() {
                const renderer = this.renderer;
                if (!renderer || !renderer.selectionManager) return;

                const selList = renderer.selectionManager.getSelectedList();
                const cardTitle = document.getElementById('rtsUnitTitle');
                const cardCount = document.getElementById('rtsUnitCount');
                const cardOrder = document.getElementById('rtsUnitOrder');
                const cardForm = document.getElementById('rtsUnitFormation');
                const cardBadge = document.getElementById('rtsUnitBadge');

                if (selList.length === 0) {
                    if (cardTitle) cardTitle.textContent = 'Tüm Ordu (150 Dost / 150 Düşman)';
                    if (cardCount) cardCount.textContent = '300 Asker Hazır';
                    if (cardOrder) cardOrder.textContent = 'Emir: Serbest';
                    if (cardForm && renderer.formationManager) {
                        const fNames = { line: 'Hat', column: 'Kol', wedge: 'Kama', loose: 'Gevşek', skirmish: 'Dağınık', circle: 'Çember' };
                        cardForm.textContent = `Formasyon: ${fNames[renderer.formationManager.currentFormation] || 'Hat'}`;
                    }
                    if (cardBadge) {
                        cardBadge.textContent = '⚔️';
                        cardBadge.className = 'rts-unit-badge';
                    }
                } else {
                    const first = selList[0];
                    const isEnemy = first.side === 'enemy';
                    const archetypeNames = {
                        infantry_pikeman: 'Mızraklı Piyade',
                        infantry_musketeer: 'Tüfekçi / Arkebüzcü',
                        infantry_swordsman: 'Kılıç-Kalkanlı Piyade',
                        cavalry_lance: 'Mızraklı Süvari (Kargıcı)',
                        cavalry_sabre: 'Kılıçlı Süvari (Reiter)',
                        cavalry_carbine: 'Karabinalı Süvari',
                        cavalry_pistol: 'Piştovlu Süvari'
                    };
                    const name = archetypeNames[first.archetype] || '1650 Birliği';
                    if (cardTitle) cardTitle.textContent = `${name} (${isEnemy ? 'Düşman' : 'Dost'})`;
                    if (cardCount) cardCount.textContent = `${selList.length} Asker Seçili`;
                    if (cardOrder && renderer.commandManager) {
                        const oNames = {
                            move: 'Hareket', hold: 'Konum Tut', attack: 'Saldır', attack_move: 'Saldır-İlerle',
                            retreat: 'Geri Çekil', fire_at_will: 'Serbest Ateş', hold_fire: 'Ateşi Kes', regroup: 'Toplandı'
                        };
                        cardOrder.textContent = `Emir: ${oNames[renderer.commandManager.currentOrder] || 'Hareket'}`;
                    }
                    if (cardForm && renderer.formationManager) {
                        const fNames = { line: 'Hat', column: 'Kol', wedge: 'Kama', loose: 'Gevşek', skirmish: 'Dağınık', circle: 'Çember' };
                        cardForm.textContent = `Formasyon: ${fNames[renderer.formationManager.currentFormation] || 'Hat'}`;
                    }
                    if (cardBadge) {
                        cardBadge.textContent = first.archetype?.startsWith('cavalry') ? '🐎' : '🛡️';
                        cardBadge.className = `rts-unit-badge ${isEnemy ? 'enemy' : ''}`;
                    }
                }
            }
'''

html = html.replace('this._bindUIEvents();', 'this._bindUIEvents();\n                this._bindRTSUIEvents();')
html = html.replace('_updateHUD(derived) {', controller_ui_wireup + '\n            _updateHUD(derived) {\n                this._updateRTSHUD();')

# 9. Add Tests 51 to 58 into the unit test registration section
rts_unit_tests = '''
            // ============================================================================
            // G3D-03H RTS KOMUTA, SEÇİM, FORMASYON VE MİNİMAP DOĞRULAMA TESTLERİ (51 - 58)
            // ============================================================================

            // 51. Ajan 01: RTS Birlik Seçimi ve Kontrol Grupları
            runCase('51. RTS Birlik Seçimi (Tekil & Grup Seçimi, Shift Ekleme/Çıkarma, Kontrol Grupları 1-9)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_SEL',
                    soldiers: [
                        { viewId: 's1', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 0, y: 0, z: 0 } },
                        { viewId: 's2', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 2, y: 0, z: 0 } },
                        { viewId: 's3', side: 'enemy', groupId: 'g2', archetype: 'infantry_musketeer', position: { x: 10, y: 0, z: 10 } }
                    ]
                });

                const mockRenderer = { soldierRegistry: reg, selectionDirty: false };
                const sel = new RTSSelectionManager(mockRenderer);

                // Tekil seçim
                sel.select('s1', false);
                assert(sel.selectedSoldierIds.size === 1 && sel.isSelected('s1'), 's1 tekil seçilmeli');

                // Shift ile ekleme
                sel.select('s3', true);
                assert(sel.selectedSoldierIds.size === 2 && sel.isSelected('s3'), 'Shift ile s3 seçime eklenmeli');

                // Grup seçimi
                sel.selectGroup('g1', false);
                assert(sel.selectedSoldierIds.size === 2 && sel.isSelected('s1') && sel.isSelected('s2'), 'g1 grubunun tüm askerleri seçilmeli');

                // Kontrol Grubu 1 atama ve geri çağırma
                sel.assignControlGroup(1);
                sel.clear();
                assert(sel.selectedSoldierIds.size === 0, 'Seçim temizlenmeli');

                const recalled = sel.recallControlGroup(1);
                assert(recalled && sel.selectedSoldierIds.size === 2 && sel.isSelected('s1'), 'Kontrol grubu 1 geri çağrılabilmeli');
                reg.dispose();
            });

            // 52. Ajan 01: Dikdörtgen Marquee Alan Seçimi
            runCase('52. Dikdörtgen Marquee Alan Seçimi (2D Ekran -> 3D Dünya Birim Kapsama Doğrulaması)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_BOX',
                    soldiers: [
                        { viewId: 'b1', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 0, y: 0, z: 0 } },
                        { viewId: 'b2', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 50, y: 0, z: 50 } }
                    ]
                });

                const mockCam = {
                    current: { targetX: 0, targetZ: 0, distance: 46, yaw: 0, pitch: 0.88 }
                };
                const mockRenderer = { soldierRegistry: reg, selectionDirty: false };
                const sel = new RTSSelectionManager(mockRenderer);

                // Ekran merkezini kapsayan bir dikdörtgen alan seçimi (400x300 piksel)
                const count = sel.selectInScreenRect(300, 200, 500, 400, false, mockCam, 800, 600);
                assert(count >= 1 && sel.isSelected('b1'), 'Merkezdeki b1 askeri dikdörtgen seçim kutusuna girmeli');
                assert(!sel.isSelected('b2'), 'Uzak köşedeki b2 askeri seçim kutusu dışında kalmalı');
                reg.dispose();
            });

            // 53. Ajan 02: Sağ Tık Hareket Emri & Shift Sıralı Emir Kuyruğu
            runCase('53. Sağ Tık Hareket Emri, Hedef Konum İnterpolasyonu & Shift Sıralı Emir Kuyruğu', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_MOVE',
                    soldiers: [
                        { viewId: 'm1', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 0, y: 0, z: 0 } }
                    ]
                });

                const mockRenderer = { soldierRegistry: reg };
                const sel = new RTSSelectionManager(mockRenderer);
                const mov = new RTSMovementManager(mockRenderer);
                mockRenderer.selectionManager = sel;

                sel.select('m1', false);

                // 1. Hareket emri
                mov.issueMoveOrder(10, 20, false);
                const sol = reg.records.get('m1');
                assert(sol.isMoving && sol.targetX === 10 && sol.targetZ === 20, 'Asker hedef konuma yönlendirilmeli');

                // 2. Shift ile sıralı hareket kuyruğu ekleme
                mov.issueMoveOrder(30, 40, true);
                assert(mov.waypointQueues.has('m1') && mov.waypointQueues.get('m1').length === 1, 'Shift ile ikinci hedef kuyruğa eklenmeli');
                reg.dispose();
            });

            // 54. Ajan 03: 6 Taktik Formasyon Matrisi
            runCase('54. 6 Taktik Formasyon Matrisi (Hat, Kol, Kama, Gevşek, Dağınık, Çember) & Slot Dağılımı', () => {
                const formManager = new RTSFormationManager();
                const formations = ['line', 'column', 'wedge', 'loose', 'skirmish', 'circle'];

                for (const f of formations) {
                    const slots = formManager.computeSlots(20, false, 0.0, f);
                    assert(slots.length === 20, `Formasyon ${f} 20 askere tam 20 slot üretmeli`);

                    // Slotlar arasında çakışma olmamalı
                    for (let i = 0; i < slots.length; i++) {
                        for (let j = i + 1; j < slots.length; j++) {
                            const d = Math.hypot(slots[i].dx - slots[j].dx, slots[i].dz - slots[j].dz);
                            assert(d > 0.35, `Formasyon ${f} slotları aşırı çakışmamalı (d > 0.35m)`);
                        }
                    }
                }
            });

            // 55. Ajan 03: Formasyon Dönüşü & Süvari/Piyade Aralık Uyumu
            runCase('55. Formasyon Dönüşü (Pivot/Wheel) & Süvari/Piyade Aralık Uyumu (Işınlanma Yok)', () => {
                const formManager = new RTSFormationManager();

                const infSlots = formManager.computeSlots(10, false, 0.0, 'line');
                const cavSlots = formManager.computeSlots(10, true, 0.0, 'line');

                const infWidth = Math.abs(infSlots[infSlots.length - 1].dx - infSlots[0].dx);
                const cavWidth = Math.abs(cavSlots[cavSlots.length - 1].dx - cavSlots[0].dx);

                assert(cavWidth > infWidth * 1.5, 'Süvari formasyonu piyadeden en az 1.5 kat daha geniş aralıklı olmalı');

                // 90 derece dönüş testi
                const rotSlots = formManager.computeSlots(10, false, Math.PI * 0.5, 'line');
                assert(Math.abs(rotSlots[0].dz) > 0.1, 'Açı değiştiğinde formasyon yönü dünya koordinatlarında dönmeli');
            });

            // 56. Ajan 04: RTS Kamera Panning, Zoom & Seçili Birliğe Odaklanma
            runCase('56. RTS Kamera Panning (WASD/Sınırlar), Zoom, Eğim & Seçili Birliğe Odaklanma (Space)', () => {
                const cam = new RTSCamera3D();
                cam.setBoundsAndTarget({ minX: -60, maxX: 60, minZ: -60, maxZ: 60 }, { x: 0, z: 0 }, true);

                cam.panRelative(20, 10);
                assert(cam.desired.targetX !== 0 || cam.desired.targetZ !== 0, 'Kamera pan hareketi uygulanmalı');

                cam.zoomBy(-15);
                assert(cam.desired.distance === 31, 'Kamera yakınlaşabilmeli');

                // Seçime odaklanma
                cam.focusOnSelection([{ x: 25, z: -30 }]);
                assert(Math.abs(cam.desired.targetX - 25) < 1e-4 && Math.abs(cam.desired.targetZ - (-30)) < 1e-4, 'Kamera seçili birliğe odaklanabilmeli');
            });

            // 57. Ajan 05: 8 Taktik RTS Emri
            runCase('57. 8 Taktik RTS Emri (Move, Hold, Attack, Attack-Move, Retreat, Fire-at-Will, Hold-Fire, Regroup)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_CMD',
                    soldiers: [
                        { viewId: 'c1', side: 'player', groupId: 'g1', archetype: 'infantry_musketeer', position: { x: 0, y: 0, z: 0 } }
                    ]
                });

                const mockRenderer = { soldierRegistry: reg };
                const sel = new RTSSelectionManager(mockRenderer);
                const cmd = new RTSCommandManager(mockRenderer);
                mockRenderer.selectionManager = sel;

                sel.select('c1', false);
                const sol = reg.records.get('c1');

                // Hold Ground
                cmd.executeCommand('hold');
                assert(sol.currentOrder === 'hold' && sol.isCombatActing && sol.actionMode === 'guard', 'Hold emri askeri guard pozuna almalı');

                // Attack Move
                cmd.executeCommand('attack_move');
                assert(sol.currentOrder === 'attack_move' && sol.actionMode === 'attack', 'Attack move hücum hazırlığı yapmalı');

                // Retreat
                cmd.executeCommand('retreat');
                assert(sol.currentOrder === 'retreat' && sol.isMoving, 'Geri çekilme intikali tetiklemeli');
                reg.dispose();
            });

            // 58. Ajan 06: İnteraktif Minimap
            runCase('58. İnteraktif Minimap (3D->2D Koordinat Dönüşümü, Kamera Frustum Göstergesi & Tıklama ile Yönlendirme)', () => {
                const mockCanvas = {
                    width: 180,
                    height: 180,
                    getContext: () => ({
                        clearRect: () => {},
                        beginPath: () => {},
                        moveTo: () => {},
                        lineTo: () => {},
                        stroke: () => {},
                        arc: () => {},
                        fill: () => {},
                        strokeRect: () => {},
                        fillRect: () => {}
                    }),
                    addEventListener: () => {},
                    getBoundingClientRect: () => ({ left: 0, top: 0, width: 180, height: 180 })
                };

                const mockCam = new RTSCamera3D();
                const mockRenderer = { cameraController: mockCam };
                const minimap = new RTSMinimapController(mockCanvas, mockRenderer);

                // Minimap tıklama simülasyonu: tam merkeze tıklama (90, 90) -> (0, 0) koordinatına taşımalı
                minimap._handleClick({ clientX: 90, clientY: 90 });
                assert(Math.abs(mockCam.desired.targetX) < 1e-4 && Math.abs(mockCam.desired.targetZ) < 1e-4, 'Minimap tıklaması dünya hedef koordinatını güncellemeli');
            });
'''

# Find end of Test 50 and append Tests 51-58
idx_test50 = html.find("runCase('50. Saha Görselliği")
if idx_test50 != -1:
    idx_test50_end = html.find('});', idx_test50) + 3
    html = html[:idx_test50_end] + '\n' + rts_unit_tests + '\n' + html[idx_test50_end:]
    print("Tests 51 to 58 successfully added!")
else:
    print("ERROR: Could not find Test 50!")

# Write out G3D03H_WORKING.html
with open('G3D03H_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(html)

print(f"G3D03H_WORKING.html successfully generated ({len(html)} bytes)!")
