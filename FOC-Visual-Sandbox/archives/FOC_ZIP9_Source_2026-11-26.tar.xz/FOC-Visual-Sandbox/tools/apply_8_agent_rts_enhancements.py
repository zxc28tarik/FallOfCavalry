import os
import re

with open('tools/build_playable_rts.py', 'r', encoding='utf-8') as f:
    script = f.read()

# 1. Update test counts in script strings
script = script.replace('70 / 70', '78 / 78')
script = script.replace('70 doğrulama testi', '78 doğrulama testi')
script = script.replace('⚙️ Geliştirici (70 Test)', '⚙️ Geliştirici (78 Test)')
script = script.replace('⚙️ Geliştirici &amp; Test Paneli (70 / 70 Test)', '⚙️ Geliştirici &amp; Test Paneli (78 / 78 Test)')
script = script.replace('🧪 70 Birim Testini Çalıştır', '🧪 78 Birim Testini Çalıştır')

# 2. Extract rts_engines_code block and replace with the enhanced 8-agent engine code
idx_rts_eng_start = script.find('rts_engines_code = \'\'\'') + len('rts_engines_code = \'\'\'')
idx_rts_eng_end = script.find('\'\'\'\n\npos_preview_ctrl = html.find(\'class Battle3DPreviewController {\')')

# We'll read the enhanced 8-agent engine code from tools/build_playable_rts_v2.py
with open('tools/build_playable_rts_v2.py', 'r', encoding='utf-8') as f:
    v2_code = f.read()

idx_v2_eng_start = v2_code.find('rts_engines_code = \'\'\'') + len('rts_engines_code = \'\'\'')
idx_v2_eng_end = v2_code.find('\'\'\'\n\npos_preview_ctrl = html.find(\'class Battle3DPreviewController {\')')
enhanced_rts_engines = v2_code[idx_v2_eng_start:idx_v2_eng_end]

script = script[:idx_rts_eng_start] + enhanced_rts_engines + script[idx_rts_eng_end:]

# 3. Extract tests block and replace with tests_65_78
idx_tests_start = script.find('tests_65_70 = \'\'\'')
idx_tests_end = script.find('\'\'\'\n\nidx_test64 = html.find("showcase.toggleCompare();")')

idx_v2_tests_start = v2_code.find('tests_65_78 = \'\'\'') + len('tests_65_78 = \'\'\'')
idx_v2_tests_end = v2_code.find('\'\'\'\n\nidx_test64 = html.find("showcase.toggleCompare();")')
enhanced_tests = v2_code[idx_v2_tests_start:idx_v2_tests_end]

script = script[:idx_tests_start] + 'tests_65_70 = \'\'\'' + enhanced_tests + script[idx_tests_end:]

# Write back to tools/build_playable_rts.py
with open('tools/build_playable_rts.py', 'w', encoding='utf-8') as f:
    f.write(script)

print("Successfully updated tools/build_playable_rts.py with 8-Agent enhancements!")
