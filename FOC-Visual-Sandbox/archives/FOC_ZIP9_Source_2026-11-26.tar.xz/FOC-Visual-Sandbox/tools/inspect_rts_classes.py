with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

for cls_name in ['SoldierInstance', 'UnitGroup', 'RTSCommandManager', 'RTSMovementManager']:
    pos = text.find('class ' + cls_name)
    if pos != -1:
        print(f"=== {cls_name} ===")
        print(text[pos:pos+1200])
