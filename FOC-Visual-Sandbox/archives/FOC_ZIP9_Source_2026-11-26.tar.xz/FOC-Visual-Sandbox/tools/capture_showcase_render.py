# -*- coding: utf-8 -*-
"""
tools/capture_showcase_render.py
Captures the Ottoman Janissary with Bork, Cevsen, and high-def matchlock musket.
"""

import subprocess, os, tempfile, time

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), f'foc_showcase_janissary_{int(time.time())}')
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')
screenshot_path = r'C:\Users\zxc28\.gemini\antigravity\brain\991bada2-65ad-4998-90fb-0999f47003c5\g3d03l_janissary_showcase.png'

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

hook_script = """
<script>
window.__autoOpenShowcase = function() {
    const pre = document.getElementById('rtsPreBattleOverlay');
    if (pre) pre.style.display = 'none';

    const sc = window.focShowcase || (window.focBattleEngine && window.focBattleEngine.controller ? window.focBattleEngine.controller.showcaseController : null);
    if (sc) {
        sc.open();
        sc.setCulture('ottoman');
        sc.selectedUnitKey = 'janissary';
        sc.syncShowcaseSoldiers();
        sc.updateInfoCard();
    }
};

window.addEventListener('DOMContentLoaded', () => {
    setTimeout(window.__autoOpenShowcase, 400);
    setTimeout(window.__autoOpenShowcase, 1000);
});
</script>
"""

patched = content.replace('</head>', hook_script + '\n</head>')
temp_file = os.path.join(tempfile.gettempdir(), 'foc_sc_janissary.html')
with open(temp_file, 'w', encoding='utf-8') as f:
    f.write(patched)

cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--window-size=1280,720',
    f'--screenshot={screenshot_path}',
    f'file:///{temp_file.replace(os.sep, "/")}'
]

print("Capturing showcase Ottoman Janissary...")
subprocess.run(cmd, capture_output=True, timeout=20)
if os.path.exists(screenshot_path):
    print(f"Captured: {screenshot_path} ({os.path.getsize(screenshot_path)} bytes)")
else:
    print("Failed to capture.")
