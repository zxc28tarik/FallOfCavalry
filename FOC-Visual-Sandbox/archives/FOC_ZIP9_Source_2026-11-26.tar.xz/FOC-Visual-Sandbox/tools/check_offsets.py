import re

with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Let's run a check in Node or in browser or inspect the counts in the script
script = '''
<script>
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const c = window.__focBattle3DPreview;
        const reg = c.renderer.soldierRegistry;
        
        // Count how many parts in each batch during rebuild
        const rebuildCounts = reg.batchGroup.batches.map(b => b.count);
        
        // Now simulate _updateBatchBuffersInPlace counting
        const batches = reg.batchGroup.batches;
        const writeOffsets = new Int32Array(batches.length);
        
        for (const rec of reg.records.values()) {
            const parts = reg.templates[rec.templateKey] || reg.templates['player:infantry_pikeman'];
            for (let p = 0; p < parts.length; p++) {
                const part = parts[p];
                const bIdx = part._batchIndex;
                if (bIdx !== undefined && bIdx >= 0 && bIdx < batches.length) {
                    writeOffsets[bIdx]++;
                }
            }
        }
        
        const comparison = batches.map((b, idx) => ({
            batchIdx: idx,
            rebuildCount: b.count,
            updateOffsetCount: writeOffsets[idx],
            matches: b.count === writeOffsets[idx]
        }));
        
        const pre = document.createElement('pre');
        pre.id = 'offsetCheck';
        pre.textContent = JSON.stringify(comparison, null, 2);
        document.body.appendChild(pre);
    }, 1000);
});
</script>
'''

import subprocess, os, tempfile, json

temp_html = 'test_offsets.html'
with open(temp_html, 'w', encoding='utf-8') as f:
    f.write(html.replace('</body>', script + '</body>'))

temp_profile = os.path.join(tempfile.gettempdir(), 'foc_off_prof')
chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu-sandbox',
    '--enable-webgl',
    '--use-gl=angle',
    '--use-angle=d3d11',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--virtual-time-budget=5000',
    '--dump-dom',
    'file:///' + os.path.abspath(temp_html).replace('\\', '/')
]
res = subprocess.run(cmd, capture_output=True, text=True, timeout=15, encoding='utf-8', errors='replace')
m = re.search(r'<pre id="offsetCheck">(.*?)</pre>', res.stdout, re.DOTALL)
if m:
    print(m.group(1))
else:
    print('Not found')
if os.path.exists(temp_html): os.remove(temp_html)
