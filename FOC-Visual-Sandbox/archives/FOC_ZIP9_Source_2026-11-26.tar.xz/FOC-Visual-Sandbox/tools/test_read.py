import re
import os

with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
    content = f.read()

print(f"Base file read: {len(content)} characters")
