# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('templateKey')
while idx != -1:
    print(text[idx-40:idx+80])
    idx = text.find('templateKey', idx+1)
    if idx > 300000: break
