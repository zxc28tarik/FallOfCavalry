# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('class Battle3DPreviewController')
idx_init = text.find('init() {', idx)
print(text[idx_init:idx_init+500])
