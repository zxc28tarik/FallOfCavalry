# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = 403922
start = text.rfind("runCase('", 0, idx)
print(text[start:idx+150])
