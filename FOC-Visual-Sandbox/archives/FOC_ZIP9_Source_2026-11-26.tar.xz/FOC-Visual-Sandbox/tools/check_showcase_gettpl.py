with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('const tplKey = getTpl(')
print(text[idx-400:idx+600])
