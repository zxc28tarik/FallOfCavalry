with open('G3D03J_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = 190014 + 900
print(text[pos:pos+2500])
