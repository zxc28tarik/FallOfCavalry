# -*- coding: utf-8 -*-
"""
tools/capture_in_game_soldiers.py
Captures a close-up screenshot of a platoon of soldiers in the live playable battlefield.
"""

import subprocess, os, tempfile, time

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), f'foc_zoom_{int(time.time())}')
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')
screenshot_path = r'C:\Users\zxc28\.gemini\antigravity\brain\991bada2-65ad-4998-90fb-0999f47003c5\g3d03l_closeup_zoom.png'

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

hook_script = """
<script>
window.__forceCloseupView = function() {
    const pre = document.getElementById('rtsPreBattleOverlay');
    if (pre) pre.style.display = 'none';
    const hud = document.getElementById('rtsBattleHUD');
    if (hud) hud.style.display = 'flex';

    if (window.focBattleEngine) {
        window.focBattleEngine.gameState = 'IN_BATTLE';
        window.focBattleEngine.battleStarted = true;
    }

    const ctrl = window.focPreviewController || (window.focBattleEngine ? window.focBattleEngine.controller : null);
    if (ctrl && ctrl.cameraController) {
        // Find first soldier in the sector
        const reg = ctrl.renderer ? ctrl.renderer.soldierRegistry : null;
        let targetX = -16, targetZ = -8;
        if (reg && reg.records && reg.records.size > 0) {
            const first = reg.records.values().next().value;
            if (first) {
                targetX = first.x;
                targetZ = first.z;
            }
        }
        ctrl.cameraController.setTarget(targetX, 1.2, targetZ);
        ctrl.cameraController.current.targetX = targetX;
        ctrl.cameraController.current.targetY = 1.2;
        ctrl.cameraController.current.targetZ = targetZ;
        ctrl.cameraController.current.yaw = 0.5;
        ctrl.cameraController.current.pitch = 0.35;
        ctrl.cameraController.current.dist = 4.8;
        ctrl.cameraController.targetDist = 4.8;
        ctrl.cameraController.update(0.016);

        // Override update so it stays zoomed in for the screenshot
        ctrl.cameraController.update = function() {
            const horizDist = 4.8 * Math.cos(0.35);
            const vertDist = 4.8 * Math.sin(0.35);
            this.camera.position.set(
                targetX + Math.sin(0.5) * horizDist,
                1.2 + vertDist,
                targetZ + Math.cos(0.5) * horizDist
            );
            this.camera.lookAt(targetX, 1.2, targetZ);
        };
    }
};

window.addEventListener('DOMContentLoaded', () => {
    setTimeout(window.__forceCloseupView, 400);
    setTimeout(window.__forceCloseupView, 1000);
});
</script>
"""

patched = content.replace('</head>', hook_script + '\n</head>')
temp_file = os.path.join(tempfile.gettempdir(), 'foc_zoom_test.html')
with open(temp_file, 'w', encoding='utf-8') as f:
    f.write(patched)

cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--window-size=1280,720',
    f'--screenshot={screenshot_path}',
    f'file:///{temp_file.replace(os.sep, "/")}'
]

print("Capturing closeup soldiers...")
subprocess.run(cmd, capture_output=True, timeout=20)
if os.path.exists(screenshot_path):
    print(f"Captured: {screenshot_path} ({os.path.getsize(screenshot_path)} bytes)")
else:
    print("Failed to capture.")
