# -*- coding: utf-8 -*-
"""
tools/build_g3d03l_models.py
FALL OF CAVALRY — G3D-03L ASKER GÖRSEL KALİTESİ 2.0
High-definition anatomical 3D soldiers with real hands, weapon grip poses,
historic Ottoman & European uniforms, weapons, headwear, musket rest, and cavalry warhorse anatomy.
Directly integrated into the live playable RTS battlefield.
"""

def get_g3d03l_models_code():
    return '''
        /* ============================================================================
         * G3D-03L ASKER GÖRSEL KALİTESİ 2.0 (ANATOMİK ELLER, SİLAH KAVRAMA & TARİHSEL BİRLİKLER)
         * ============================================================================ */

        // ----------------------------------------------------------------------------
        // 1. ANATOMİK EL VE SİLAH KAVRAMA SİSTEMİ (Avuç, Başparmak ve Kıvrık Parmaklar)
        // ----------------------------------------------------------------------------
        function buildAnatomicalHandGrip(skinMat, hx, hy, hz, rigGroup, poseType = 'musket_stock', isLeft = false) {
            const parts = [];

            if (poseType === 'musket_stock') {
                // Sağ el: Dipçik kabzasını ve tetik korkuluğunu sıkıca kavrayan el
                parts.push(makePart('frustum', skinMat, hx, hy, hz, 0.075, 0.05, 0.065, 0.2, 0, 0, rigGroup));
                parts.push(makePart('box', skinMat, hx - 0.01, hy + 0.02, hz + 0.03, 0.072, 0.075, 0.045, 0.35, 0.1, 0, rigGroup));
                parts.push(makePart('frustum', skinMat, hx - 0.035, hy + 0.04, hz + 0.04, 0.032, 0.055, 0.032, 0.1, 0.6, -0.4, rigGroup));
                parts.push(makePart('cylinder', skinMat, hx + 0.025, hy + 0.015, hz + 0.035, 0.052, 0.065, 0.052, 0, Math.PI * 0.5, 0.3, rigGroup));
                parts.push(makePart('cone', skinMat, hx + 0.01, hy - 0.015, hz + 0.055, 0.025, 0.045, 0.025, Math.PI * 0.5, 0, 0, rigGroup));
            } else if (poseType === 'musket_rest_grip') {
                // Sol el: Musket çatal desteğini sıkıca kavrayan el
                parts.push(makePart('frustum', skinMat, hx, hy, hz, 0.072, 0.05, 0.065, -0.2, 0, 0, rigGroup));
                parts.push(makePart('box', skinMat, hx, hy + 0.01, hz + 0.02, 0.075, 0.065, 0.05, 0.1, 0, 0, rigGroup));
                // Başparmak direği saran
                parts.push(makePart('frustum', skinMat, hx - 0.035, hy + 0.03, hz + 0.02, 0.03, 0.05, 0.03, 0, 0.4, 0, rigGroup));
                // 4 Parmak direğin çevresine sarılı
                parts.push(makePart('cylinder', skinMat, hx + 0.015, hy + 0.015, hz + 0.035, 0.05, 0.068, 0.05, 0, Math.PI * 0.5, 0, rigGroup));
            } else if (poseType === 'musket_forestock') {
                // Sol el: Tüfek namlu altını destekleyen avuç
                parts.push(makePart('frustum', skinMat, hx, hy, hz, 0.072, 0.05, 0.065, -0.3, 0, 0, rigGroup));
                parts.push(makePart('box', skinMat, hx, hy - 0.02, hz + 0.02, 0.08, 0.04, 0.075, 0.1, 0, 0, rigGroup));
                parts.push(makePart('frustum', skinMat, hx - 0.04, hy + 0.01, hz + 0.02, 0.03, 0.05, 0.03, 0, 0, 0.6, rigGroup));
                parts.push(makePart('cylinder', skinMat, hx + 0.02, hy - 0.015, hz + 0.03, 0.048, 0.065, 0.048, Math.PI * 0.5, 0, 0, rigGroup));
            } else if (poseType === 'sword_grip') {
                // Kılıç kabzası kavrama: Parmaklar kabzayı tam çevreler
                parts.push(makePart('frustum', skinMat, hx, hy, hz, 0.075, 0.05, 0.065, 0.15, 0, 0, rigGroup));
                parts.push(makePart('box', skinMat, hx, hy + 0.02, hz + 0.01, 0.075, 0.07, 0.045, 0.2, 0, 0, rigGroup));
                parts.push(makePart('frustum', skinMat, hx - 0.035, hy + 0.045, hz + 0.02, 0.032, 0.05, 0.032, -0.2, 0.3, 0, rigGroup));
                parts.push(makePart('cylinder', skinMat, hx + 0.015, hy + 0.02, hz + 0.03, 0.055, 0.068, 0.055, 0, 0, Math.PI * 0.5, rigGroup));
            } else if (poseType === 'reins_grip') {
                // At dizgini kavrama
                parts.push(makePart('frustum', skinMat, hx, hy, hz, 0.072, 0.05, 0.065, -0.15, 0, 0, rigGroup));
                parts.push(makePart('box', skinMat, hx, hy + 0.01, hz + 0.01, 0.075, 0.065, 0.05, 0.1, 0, 0, rigGroup));
                parts.push(makePart('frustum', skinMat, hx - 0.03, hy + 0.03, hz + 0.01, 0.03, 0.05, 0.03, 0, 0.2, 0, rigGroup));
                parts.push(makePart('cylinder', skinMat, hx + 0.01, hy + 0.01, hz + 0.02, 0.05, 0.065, 0.05, 0, Math.PI * 0.5, 0, rigGroup));
            } else {
                // Pike şaftı kavrama: İki el de açılı şaftı kavrar (twoHandPike)
                parts.push(makePart('frustum', skinMat, hx, hy, hz, 0.075, 0.05, 0.065, 0, 0, 0, rigGroup));
                parts.push(makePart('box', skinMat, hx, hy + 0.01, hz + 0.02, 0.075, 0.065, 0.05, 0.2, 0, 0, rigGroup));
                parts.push(makePart('frustum', skinMat, hx - 0.03, hy + 0.03, hz + 0.02, 0.03, 0.05, 0.03, -0.1, 0.2, 0, rigGroup));
                parts.push(makePart('cylinder', skinMat, hx + 0.01, hy + 0.015, hz + 0.025, 0.05, 0.065, 0.05, 0, 0, Math.PI * 0.45, rigGroup));
            }

            return parts;
        }

        // ----------------------------------------------------------------------------
        // 2. ANATOMİK KOL, OMUZ VE DİRSEK YAPISI (Boşluksuz Mafsal Geçişi)
        // ----------------------------------------------------------------------------
        function buildAnatomicalArmWithHand(clothMat, skinMat, isLeft = false, weaponType = 'musket') {
            const sideSign = isLeft ? -1 : 1;
            let rigGroup = isLeft ? 'leftArmWeapon' : 'rightArmWeapon';
            if (weaponType === 'pike') {
                rigGroup = 'twoHandPike'; // Mızraklı yürüyüşünün savrulmaması için iki el de twoHandPike'a bağlanır
            }
            const shoulderX = sideSign * 0.27;
            const shoulderY = 1.32;
            const shoulderZ = 0.0;
            const parts = [];

            if (weaponType === 'musket') {
                if (isLeft) {
                    // Sol Kol: Destek çatalını (Furquet) kavrayan kol
                    parts.push(makePart('sphere', clothMat, shoulderX, shoulderY, shoulderZ, 0.13, 0.14, 0.13, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX + 0.09, shoulderY - 0.10, 0.14, 0.12, 0.24, 0.12, 0.45, 0.25, 0, rigGroup));
                    parts.push(makePart('dome', clothMat, shoulderX + 0.17, shoulderY - 0.18, 0.28, 0.11, 0.09, 0.11, -0.3, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX + 0.32, shoulderY - 0.14, 0.48, 0.11, 0.24, 0.10, -0.65, 0.2, 0, rigGroup));
                    // Beyaz keten manşet fırfırı (Ruffs)
                    parts.push(makePart('cylinder', 'linen', shoulderX + 0.40, shoulderY - 0.11, 0.60, 0.095, 0.035, 0.095, -0.65, 0.2, 0, rigGroup));
                    // Çatal direğini kavrayan el
                    parts.push(...buildAnatomicalHandGrip(skinMat, shoulderX + 0.44, shoulderY - 0.10, 0.68, rigGroup, 'musket_rest_grip', true));
                } else {
                    // Sağ Kol: Dipçiği omza yaslayıp tetiği kavrayan kol
                    parts.push(makePart('sphere', clothMat, shoulderX, shoulderY, shoulderZ, 0.13, 0.14, 0.13, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX - 0.03, shoulderY - 0.12, 0.08, 0.12, 0.24, 0.12, 0.35, -0.15, 0, rigGroup));
                    parts.push(makePart('dome', clothMat, shoulderX - 0.04, shoulderY - 0.21, 0.15, 0.11, 0.09, 0.11, -0.2, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX - 0.07, shoulderY - 0.14, 0.22, 0.11, 0.20, 0.10, -0.5, -0.15, 0, rigGroup));
                    // Beyaz keten manşet
                    parts.push(makePart('cylinder', 'linen', shoulderX - 0.08, shoulderY - 0.10, 0.27, 0.095, 0.035, 0.095, -0.5, -0.15, 0, rigGroup));
                    // Tetik ve dipçik kavrama
                    parts.push(...buildAnatomicalHandGrip(skinMat, shoulderX - 0.09, shoulderY - 0.09, 0.29, rigGroup, 'musket_stock', false));
                }
            } else if (weaponType === 'pike') {
                if (isLeft) {
                    // Sol el: Şaftı göğüs hizasında ileri kavrayan kol (twoHandPike)
                    parts.push(makePart('sphere', clothMat, shoulderX, shoulderY, shoulderZ, 0.13, 0.14, 0.13, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX + 0.12, shoulderY - 0.12, 0.14, 0.12, 0.26, 0.12, 0.55, 0.25, 0, rigGroup));
                    parts.push(makePart('dome', clothMat, shoulderX + 0.22, shoulderY - 0.18, 0.26, 0.11, 0.09, 0.11, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX + 0.34, shoulderY - 0.12, 0.42, 0.10, 0.25, 0.095, -0.5, 0.25, 0, rigGroup));
                    parts.push(...buildAnatomicalHandGrip(skinMat, shoulderX + 0.39, shoulderY - 0.05, 0.55, rigGroup, 'pike_grip', true));
                } else {
                    // Sağ el: Şaftı omuz yanında sıkıca kavrayan arka kol (twoHandPike)
                    parts.push(makePart('sphere', clothMat, shoulderX, shoulderY, shoulderZ, 0.13, 0.14, 0.13, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX - 0.04, shoulderY - 0.14, 0.06, 0.12, 0.26, 0.12, 0.2, -0.1, 0, rigGroup));
                    parts.push(makePart('dome', clothMat, shoulderX - 0.06, shoulderY - 0.24, 0.12, 0.11, 0.09, 0.11, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX - 0.08, shoulderY - 0.16, 0.22, 0.10, 0.24, 0.095, -0.3, -0.1, 0, rigGroup));
                    parts.push(...buildAnatomicalHandGrip(skinMat, shoulderX - 0.11, shoulderY - 0.12, 0.30, rigGroup, 'pike_grip', false));
                }
            } else {
                // Kılıç duruşu
                if (isLeft) {
                    parts.push(makePart('sphere', clothMat, shoulderX, shoulderY, shoulderZ, 0.13, 0.14, 0.13, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX + 0.05, shoulderY - 0.15, 0.05, 0.12, 0.26, 0.12, 0.2, 0.1, 0, rigGroup));
                    parts.push(makePart('dome', clothMat, shoulderX + 0.08, shoulderY - 0.28, 0.08, 0.11, 0.09, 0.11, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX + 0.06, shoulderY - 0.20, 0.18, 0.10, 0.22, 0.095, -0.4, 0.1, 0, rigGroup));
                    parts.push(...buildAnatomicalHandGrip(skinMat, shoulderX + 0.05, shoulderY - 0.18, 0.28, rigGroup, 'sword_grip', true));
                } else {
                    parts.push(makePart('sphere', clothMat, shoulderX, shoulderY, shoulderZ, 0.13, 0.14, 0.13, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX - 0.05, shoulderY - 0.15, 0.05, 0.12, 0.26, 0.12, 0.2, -0.1, 0, rigGroup));
                    parts.push(makePart('dome', clothMat, shoulderX - 0.08, shoulderY - 0.28, 0.08, 0.11, 0.09, 0.11, 0, 0, 0, rigGroup));
                    parts.push(makePart('frustum', clothMat, shoulderX - 0.06, shoulderY - 0.20, 0.18, 0.10, 0.22, 0.095, -0.4, -0.1, 0, rigGroup));
                    parts.push(...buildAnatomicalHandGrip(skinMat, shoulderX - 0.05, shoulderY - 0.18, 0.28, rigGroup, 'sword_grip', false));
                }
            }

            return parts;
        }

        // ----------------------------------------------------------------------------
        // 3. FİTİLLİ MUSKET, DESTEK ÇATALI, PİKE VE YATAĞAN SİLAH MODELLERİ
        // ----------------------------------------------------------------------------
        function buildHighDefMatchlockMusket() {
            return [
                // 1. Ceviz Ağacı Balıkkuyruğu Dipçik (Sağ omuza dayalı)
                makePart('frustum', 'wood', 0.18, 1.25, 0.08, 0.07, 0.28, 0.14, 0.45, 0, 0, 'rightArmWeapon'),
                makePart('box', 'burnishedBronze', 0.18, 1.14, 0.00, 0.065, 0.06, 0.12, 0.45, 0, 0, 'rightArmWeapon'),
                // 2. Kabza ve Tetik Korkuluğu
                makePart('box', 'wood', 0.18, 1.27, 0.26, 0.055, 0.06, 0.22, 0.08, 0, 0, 'rightArmWeapon'),
                makePart('cylinder', 'burnishedBronze', 0.18, 1.23, 0.28, 0.038, 0.05, 0.038, Math.PI * 0.5, 0, 0, 'rightArmWeapon'),
                makePart('box', 'steel', 0.18, 1.25, 0.28, 0.012, 0.035, 0.012, 0.3, 0, 0, 'rightArmWeapon'),
                // 3. Fitil Horozu ve Çakmak Plakası
                makePart('box', 'steel', 0.155, 1.29, 0.30, 0.015, 0.05, 0.11, 0, 0, 0, 'rightArmWeapon'),
                makePart('cone', 'burnishedBronze', 0.15, 1.33, 0.29, 0.022, 0.065, 0.022, 0.4, 0, 0, 'rightArmWeapon'),
                // 4. Ahşap Kundak Gövdesi
                makePart('cylinder', 'wood', 0.18, 1.275, 0.52, 0.052, 0.48, 0.052, Math.PI * 0.5 + 0.05, 0, 0, 'rightArmWeapon'),
                // 5. Sekizgen Çelik Namlu (1.10m namlu)
                makePart('cylinder', 'steel', 0.18, 1.30, 0.82, 0.042, 0.88, 0.042, Math.PI * 0.5 + 0.05, 0, 0, 'rightArmWeapon'),
                // 6. Pirinç Namlu Bilezikleri
                makePart('cylinder', 'burnishedBronze', 0.18, 1.29, 0.48, 0.054, 0.03, 0.054, Math.PI * 0.5 + 0.05, 0, 0, 'rightArmWeapon'),
                makePart('cylinder', 'burnishedBronze', 0.18, 1.30, 0.72, 0.048, 0.03, 0.048, Math.PI * 0.5 + 0.05, 0, 0, 'rightArmWeapon'),
                // 7. Genişleyen Namlu Ağzı & Arpacık
                makePart('frustum', 'burnishedBronze', 0.18, 1.32, 1.24, 0.052, 0.06, 0.052, Math.PI * 0.5 + 0.05, 0, 0, 'rightArmWeapon'),
                makePart('cone', 'burnishedBronze', 0.18, 1.35, 1.22, 0.015, 0.02, 0.015, 0, 0, 0, 'rightArmWeapon')
            ];
        }

        // Musket Destek Çatalı (Furquet / Monopod - Yere basar ve sol el ile kavranır)
        function buildHighDefMusketRest() {
            return [
                // Ahşap Çatal Direği (Zeminden namlu altına kadar)
                makePart('cylinder', 'wood', 0.18, 0.62, 0.70, 0.026, 1.24, 0.026, 0.06, 0, 0, 'rightArmWeapon'),
                // Sivri Zemin Pabuç Demiri (Ground Spike)
                makePart('cone', 'steel', 0.18, 0.04, 0.66, 0.03, 0.08, 0.03, Math.PI, 0, 0, 'rightArmWeapon'),
                // Bronz U-Çatal Yuvası (Gabel)
                makePart('frustum', 'burnishedBronze', 0.18, 1.26, 0.72, 0.07, 0.06, 0.04, 0, 0, 0, 'rightArmWeapon'),
                makePart('cone', 'burnishedBronze', 0.15, 1.29, 0.72, 0.018, 0.04, 0.018, 0, 0, -0.25, 'rightArmWeapon'),
                makePart('cone', 'burnishedBronze', 0.21, 1.29, 0.72, 0.018, 0.04, 0.018, 0, 0, 0.25, 'rightArmWeapon')
            ];
        }

        // 4.5m Uzunluğunda Dişbudak Pikesi (twoHandPike grubu ile omuzda disiplinli intikal)
        function buildHighDefPike() {
            return [
                // 1. Ahşap Şaft (Octagonal Ash Staff - Omuz hizasından 65 derece açılı)
                makePart('cylinder', 'wood', 0.12, 1.35, 0.65, 0.045, 4.40, 0.045, 0.40, 0, 0.12, 'twoHandPike'),
                // 2. Çelik Kargı Ucu (Four-sided Diamond Spearhead)
                makePart('cone', 'steel', 0.12, 2.75, 2.70, 0.075, 0.42, 0.075, 0.40, 0, 0.12, 'twoHandPike'),
                // 3. Çelik Langet Şeritleri
                makePart('cylinder', 'steel', 0.12, 2.50, 2.35, 0.052, 0.36, 0.052, 0.40, 0, 0.12, 'twoHandPike'),
                // 4. Şaft Alt Demiri (Butt Spike)
                makePart('cone', 'steel', 0.12, -0.05, -1.40, 0.05, 0.18, 0.05, -Math.PI + 0.40, 0, 0.12, 'twoHandPike')
            ];
        }

        function buildHighDefYatagan() {
            return [
                makePart('cylinder', 'fineSilk', 0.22, 1.04, 0.32, 0.045, 0.14, 0.045, 0.4, 0, 0, 'rightArmWeapon'),
                makePart('sphere', 'gold', 0.23, 0.98, 0.26, 0.065, 0.045, 0.075, 0, 0, 0, 'rightArmWeapon'),
                makePart('cylinder', 'gold', 0.21, 1.08, 0.36, 0.052, 0.03, 0.052, 0.4, 0, 0, 'rightArmWeapon'),
                makePart('frustum', 'damascusSteel', 0.19, 1.34, 0.54, 0.065, 0.56, 0.022, 0.35, 0, 0, 'rightArmWeapon'),
                makePart('cone', 'damascusSteel', 0.17, 1.62, 0.70, 0.052, 0.16, 0.018, 0.28, 0, 0, 'rightArmWeapon')
            ];
        }

        // ----------------------------------------------------------------------------
        // 4. HEDEF ÖRNEĞİ BİREBİR AVRUPA TÜFEKÇİSİ (MUSKETIER - AoE III DE KALİTESİ)
        // ----------------------------------------------------------------------------
        function buildEuropeanMusketeerHedefOrnegi(side = 'player') {
            const isEnemy = side === 'enemy';
            const coatMat = isEnemy ? 'enemyCloth' : 'playerCloth';
            const breechesMat = isEnemy ? 'enemyBreeches' : 'playerBreeches';
            const skinMat = 'skin';
            const hairMat = 'wood';
            const parts = [];

            // 1. Zemin Gölgesi
            parts.push(makePart('cylinder', 'shadow', 0, 0.02, 0, 1.10, 0.02, 1.10, 0, 0, 0, 'shadow'));

            // 2. Süvari Tipi Geniş Boğazlı Deri Çizme (Cavalier Bucket Boots with turned-down cuffs & spurs)
            const legX = 0.13;
            parts.push(makePart('box', 'leather', -legX, 0.03, 0.05, 0.12, 0.06, 0.25, 0, 0, 0, 'leftLegLower'));
            parts.push(makePart('box', 'leather',  legX, 0.03, 0.05, 0.12, 0.06, 0.25, 0, 0, 0, 'rightLegLower'));
            parts.push(makePart('box', 'darkSteel', -legX, 0.045, -0.06, 0.10, 0.04, 0.07, 0, 0, 0, 'leftLegLower'));
            parts.push(makePart('box', 'darkSteel',  legX, 0.045, -0.06, 0.10, 0.04, 0.07, 0, 0, 0, 'rightLegLower'));
            parts.push(makePart('cone', 'burnishedBronze', -legX, 0.05, -0.10, 0.02, 0.05, 0.02, -Math.PI * 0.5, 0, 0, 'leftLegLower'));
            parts.push(makePart('cone', 'burnishedBronze',  legX, 0.05, -0.10, 0.02, 0.05, 0.02, -Math.PI * 0.5, 0, 0, 'rightLegLower'));
            parts.push(makePart('frustum', 'leather', -legX, 0.24, 0.0, 0.16, 0.40, 0.18, 0, 0, 0, 'leftLegLower'));
            parts.push(makePart('frustum', 'leather',  legX, 0.24, 0.0, 0.16, 0.40, 0.18, 0, 0, 0, 'rightLegLower'));
            parts.push(makePart('frustum', 'buffLeather', -legX, 0.46, 0.0, 0.21, 0.16, 0.21, Math.PI, 0, 0, 'leftLegLower'));
            parts.push(makePart('frustum', 'buffLeather',  legX, 0.46, 0.0, 0.21, 0.16, 0.21, Math.PI, 0, 0, 'rightLegLower'));

            // 3. Diz & Üst Bacak Pantolonu (Puffed Breeches)
            parts.push(makePart('sphere', breechesMat, -legX, 0.52, 0.02, 0.14, 0.12, 0.14, 0, 0, 0, 'leftLegUpper'));
            parts.push(makePart('sphere', breechesMat,  legX, 0.52, 0.02, 0.14, 0.12, 0.14, 0, 0, 0, 'rightLegUpper'));
            parts.push(makePart('frustum', breechesMat, -legX, 0.68, 0.01, 0.22, 0.34, 0.20, 0, 0, 0, 'leftLegUpper'));
            parts.push(makePart('frustum', breechesMat,  legX, 0.68, 0.01, 0.22, 0.34, 0.20, 0, 0, 0, 'rightLegUpper'));

            // 4. Gövde & Peascod Ceket (Doublet with Gold Trim & Buttons)
            parts.push(makePart('frustum', coatMat, 0, 0.88, 0.01, 0.46, 0.22, 0.34, Math.PI, 0, 0, 'torso'));
            parts.push(makePart('cylinder', 'gold', 0, 0.78, 0.01, 0.47, 0.025, 0.35, 0, 0, 0, 'torso'));
            parts.push(makePart('frustum', coatMat, 0, 1.05, 0.02, 0.42, 0.26, 0.30, 0, 0, 0, 'torso'));
            parts.push(makePart('cylinder', 'leather', 0, 0.96, 0.02, 0.43, 0.065, 0.31, 0, 0, 0, 'torso'));
            parts.push(makePart('box', 'burnishedBronze', 0, 0.96, 0.17, 0.09, 0.08, 0.04, 0, 0, 0, 'torso'));
            parts.push(makePart('frustum', coatMat, 0, 1.25, 0.03, 0.48, 0.32, 0.32, 0, 0, 0, 'torso'));
            // Altın Biyeli Çift Şerit (Front Gold Piping)
            parts.push(makePart('box', 'gold', -0.03, 1.15, 0.17, 0.018, 0.38, 0.015, 0.06, 0, 0, 'torso'));
            parts.push(makePart('box', 'gold',  0.03, 1.15, 0.17, 0.018, 0.38, 0.015, 0.06, 0, 0, 'torso'));
            for (let b = 0; b < 6; b++) {
                parts.push(makePart('sphere', 'gold', 0, 0.99 + b * 0.06, 0.175, 0.022, 0.022, 0.022, 0, 0, 0, 'torso'));
            }
            // Omuz Kanatları (Shoulder Wings with gold piping)
            parts.push(makePart('frustum', coatMat, -0.26, 1.35, 0.01, 0.16, 0.08, 0.18, 0, 0, 0.3, 'torso'));
            parts.push(makePart('frustum', 'gold',   -0.28, 1.36, 0.01, 0.17, 0.02, 0.19, 0, 0, 0.3, 'torso'));
            parts.push(makePart('frustum', coatMat,  0.26, 1.35, 0.01, 0.16, 0.08, 0.18, 0, 0, -0.3, 'torso'));
            parts.push(makePart('frustum', 'gold',    0.28, 1.36, 0.01, 0.17, 0.02, 0.19, 0, 0, -0.3, 'torso'));

            // 5. Geniş Düşen Beyaz Keten Yaka (Linen Falling Collar - Dual pointed tabs)
            parts.push(makePart('frustum', 'linen', 0, 1.40, 0.02, 0.36, 0.035, 0.32, 0.1, 0, 0, 'torso'));
            parts.push(makePart('box', 'linen', -0.08, 1.36, 0.17, 0.10, 0.12, 0.015, 0.25, 0, 0.15, 'torso'));
            parts.push(makePart('box', 'linen',  0.08, 1.36, 0.17, 0.10, 0.12, 0.015, 0.25, 0, -0.15, 'torso'));

            // 6. Boyun, Yüz & Gerçekçi Sakal/Bıyık Anatomisi (Handlebar Mustache & Soul Patch)
            parts.push(makePart('frustum', skinMat, 0, 1.45, 0.02, 0.14, 0.12, 0.13, 0.1, 0, 0, 'torso'));
            parts.push(makePart('sphere', skinMat, 0, 1.58, 0.02, 0.22, 0.24, 0.22, 0, 0, 0, 'torso'));
            parts.push(makePart('box', skinMat, 0, 1.62, 0.13, 0.19, 0.06, 0.08, 0.12, 0, 0, 'torso'));
            parts.push(makePart('cone', skinMat, 0, 1.55, 0.18, 0.045, 0.09, 0.045, Math.PI * 0.5 + 0.3, 0, 0, 'torso'));
            parts.push(makePart('frustum', skinMat, 0, 1.48, 0.08, 0.16, 0.09, 0.13, -0.2, 0, 0, 'torso'));
            parts.push(makePart('dome', skinMat, -0.13, 1.57, 0.0, 0.05, 0.08, 0.03, 0, -Math.PI * 0.5, 0, 'torso'));
            parts.push(makePart('dome', skinMat,  0.13, 1.57, 0.0, 0.05, 0.08, 0.03, 0,  Math.PI * 0.5, 0, 'torso'));
            // Dalgalı Saçlar
            parts.push(makePart('frustum', hairMat, -0.14, 1.55, -0.04, 0.08, 0.20, 0.10, 0.2, 0, 0.2, 'torso'));
            parts.push(makePart('frustum', hairMat,  0.14, 1.55, -0.04, 0.08, 0.20, 0.10, 0.2, 0, -0.2, 'torso'));
            parts.push(makePart('frustum', hairMat, 0, 1.54, -0.12, 0.22, 0.22, 0.08, 0.2, 0, 0, 'torso'));
            // Hedef Görselindeki Buruk Palabıyık (Characteristic Musketeer Handlebar Mustache)
            parts.push(makePart('cone', hairMat, -0.06, 1.51, 0.15, 0.035, 0.12, 0.03, Math.PI * 0.55, 0.5, -0.25, 'torso'));
            parts.push(makePart('cone', hairMat,  0.06, 1.51, 0.15, 0.035, 0.12, 0.03, Math.PI * 0.55, -0.5, 0.25, 'torso'));
            parts.push(makePart('cone', hairMat, 0, 1.465, 0.145, 0.025, 0.055, 0.02, -0.2, 0, 0, 'torso'));

            // 7. Geniş Siperlikli Cavalier Fötr Şapkası, Toka ve Mavi Ostrich Tüyü
            parts.push(makePart('cylinder', 'darkSteel', 0, 1.68, 0.02, 0.48, 0.028, 0.48, 0.10, 0, 0.15, 'torso'));
            parts.push(makePart('cylinder', 'darkSteel', 0, 1.77, 0.02, 0.29, 0.18, 0.29, 0.10, 0, 0.15, 'torso'));
            parts.push(makePart('cylinder', 'leather', 0, 1.70, 0.02, 0.305, 0.035, 0.305, 0.10, 0, 0.15, 'torso'));
            parts.push(makePart('box', 'gold', 0.15, 1.71, 0.02, 0.04, 0.05, 0.06, 0.10, 0, 0, 0.15, 'torso'));
            parts.push(makePart('frustum', 'playerCloth', 0.18, 1.86, -0.06, 0.06, 0.32, 0.09, -0.38, 0, 0.55, 'torso'));
            parts.push(makePart('cone', 'playerCloth', 0.24, 1.98, -0.16, 0.055, 0.28, 0.075, -0.65, 0, 0.65, 'torso'));

            // 8. 12 Havariler Bandolieri (Ahşap Barutluk Şişeleri ve Barutluk)
            parts.push(makePart('box', 'leather', 0, 1.18, 0.05, 0.07, 0.52, 0.38, 0, 0, 0.42, 'torso'));
            const bX = [-0.14, -0.08, -0.01, 0.06];
            const bY = [1.20, 1.12, 1.04, 0.96];
            for (let i = 0; i < 4; i++) {
                parts.push(makePart('cylinder', 'wood', bX[i], bY[i], 0.18, 0.032, 0.11, 0.032, 0.12, 0, 0.22, 'torso'));
                parts.push(makePart('cone', 'burnishedBronze', bX[i], bY[i] + 0.06, 0.18, 0.02, 0.03, 0.02, 0.12, 0, 0.22, 'torso'));
            }
            parts.push(makePart('box', 'leather', 0.22, 0.92, 0.08, 0.12, 0.14, 0.09, 0, 0, 0, 'torso'));
            parts.push(makePart('cone', 'burnishedBronze', 0.24, 0.88, 0.02, 0.05, 0.16, 0.04, 0.6, 0, 0.2, 'torso'));

            // 9. Anatomik Kollar, Eller, Fitilli Musket ve Destek Çatalı
            const leftArm = buildAnatomicalArmWithHand(coatMat, skinMat, true, 'musket');
            const rightArm = buildAnatomicalArmWithHand(coatMat, skinMat, false, 'musket');
            const musket = buildHighDefMatchlockMusket();
            const rest = buildHighDefMusketRest();

            return [...parts, ...leftArm, ...rightArm, ...musket, ...rest];
        }

        // ----------------------------------------------------------------------------
        // 5. AT VE BİNİCİ ÇAKIŞMASINI ÖNLEYEN SEATED SÜVARİ BİNİCİSİ (Sipahi & Kürassier)
        // ----------------------------------------------------------------------------
        function buildHighDefMountedRider(side = 'player', archetype = 'cavalry', options = {}) {
            const isEnemy = side === 'enemy';
            const isOttoman = side === 'player' || archetype.includes('ottoman') || archetype.includes('sipahi');
            const clothMat = options.clothMat || (isOttoman ? 'ottomanCrimson' : (isEnemy ? 'enemyCloth' : 'playerCloth'));
            const breechesMat = options.breechesMat || (isOttoman ? 'ottomanEmerald' : (isEnemy ? 'enemyBreeches' : 'playerBreeches'));
            const skinMat = 'skin';
            const hairMat = 'wood';
            const parts = [];

            // Eyere Oturan Pelvis ve Kalça (y: 1.50, Atın sırtında, içinde DEĞİL)
            parts.push(makePart('frustum', breechesMat, 0, 1.50, -0.05, 0.44, 0.16, 0.36, Math.PI, 0, 0, 'riderLower'));

            // Kavisli Bacaklar: Atın karnının iki yanından aşağı üzengiye uzanır (Sıfır çakışma!)
            const legFlankX = 0.38;
            const kneeX = 0.40;
            const stirrupY = 0.76;
            // 1. Üst Bacak / Uyluk (Atın eyer yanlarından hafifçe öne ve dışa açılı)
            parts.push(makePart('frustum', breechesMat, -legFlankX, 1.38, 0.10, 0.18, 0.28, 0.18, 0.60, 0, 0.30, 'riderLower'));
            parts.push(makePart('frustum', breechesMat,  legFlankX, 1.38, 0.10, 0.18, 0.28, 0.18, 0.60, 0, -0.30, 'riderLower'));
            // 2. Diz Mafsalı (Eyerin ön-yanında bükülür)
            parts.push(makePart('sphere', breechesMat, -kneeX, 1.26, 0.22, 0.13, 0.13, 0.13, 0, 0, 0, 'riderLower'));
            parts.push(makePart('sphere', breechesMat,  kneeX, 1.26, 0.22, 0.13, 0.13, 0.13, 0, 0, 0, 'riderLower'));
            // 3. Kıvrık Çizme Boğazı (Cavalier Bucket Boot Cuffs)
            parts.push(makePart('frustum', 'buffLeather', -kneeX, 1.18, 0.18, 0.17, 0.10, 0.17, -0.45, 0, 0.10, 'riderLower'));
            parts.push(makePart('frustum', 'buffLeather',  kneeX, 1.18, 0.18, 0.17, 0.10, 0.17, -0.45, 0, -0.10, 'riderLower'));
            // 4. Alt Bacak / Baldır (Dizden üzengiye iner)
            parts.push(makePart('cylinder', 'leather', -kneeX, 1.00, 0.10, 0.13, 0.30, 0.14, -0.45, 0, 0.10, 'riderLower'));
            parts.push(makePart('cylinder', 'leather',  kneeX, 1.00, 0.10, 0.13, 0.30, 0.14, -0.45, 0, -0.10, 'riderLower'));
            // 5. Üzengiye Basan Çizme Ayağı (Bronz üzengi demiri hizasında)
            parts.push(makePart('box', 'leather', -kneeX, stirrupY, 0.04, 0.12, 0.08, 0.22, 0.10, 0, 0, 'riderLower'));
            parts.push(makePart('box', 'leather',  kneeX, stirrupY, 0.04, 0.12, 0.08, 0.22, 0.10, 0, 0, 'riderLower'));
            // 6. Bronz Mahmuz Yıldızı (Spur rowel)
            parts.push(makePart('cone', 'burnishedBronze', -kneeX, stirrupY + 0.02, -0.08, 0.02, 0.05, 0.02, -Math.PI * 0.5, 0, 0, 'riderLower'));
            parts.push(makePart('cone', 'burnishedBronze',  kneeX, stirrupY + 0.02, -0.08, 0.02, 0.05, 0.02, -Math.PI * 0.5, 0, 0, 'riderLower'));

            // SÜVARİ ÜST GÖVDESİ (riderUpper - Eyerin üstünde dik oturur)
            parts.push(makePart('frustum', clothMat, 0, 1.62, -0.05, 0.44, 0.22, 0.32, 0, 0, 0, 'riderUpper'));
            parts.push(makePart('cylinder', 'leather', 0, 1.68, -0.04, 0.43, 0.07, 0.31, 0, 0, 0, 'riderUpper'));
            parts.push(makePart('box', 'gold', 0, 1.68, 0.12, 0.09, 0.08, 0.03, 0, 0, 0, 'riderUpper'));
            parts.push(makePart('frustum', clothMat, 0, 1.84, -0.03, 0.48, 0.32, 0.32, 0, 0, 0, 'riderUpper'));
            parts.push(makePart('frustum', skinMat, 0, 2.02, -0.02, 0.14, 0.12, 0.13, 0.1, 0, 0, 'riderUpper'));
            parts.push(makePart('sphere', skinMat, 0, 2.15, -0.01, 0.22, 0.24, 0.22, 0, 0, 0, 'riderUpper'));
            parts.push(makePart('cone', skinMat, 0, 2.14, 0.15, 0.045, 0.08, 0.045, Math.PI * 0.5 + 0.3, 0, 0, 'riderUpper'));
            parts.push(makePart('cone', hairMat, -0.06, 2.09, 0.13, 0.035, 0.12, 0.03, Math.PI * 0.55, 0.5, -0.2, 'riderUpper'));
            parts.push(makePart('cone', hairMat,  0.06, 2.09, 0.13, 0.035, 0.12, 0.03, Math.PI * 0.55, -0.5, 0.2, 'riderUpper'));

            // SÜVARİ ZIRHI VE MİĞFERİ (Doğrudan riderUpper seviyesine bağlı — at içine sarkmaz!)
            if (isOttoman) {
                // Tımarlı Sipahi Çevşeni ve Şişak Miğferi
                parts.push(makePart('cylinder', 'damascusSteel', 0, 1.85, 0.08, 0.24, 0.24, 0.04, Math.PI * 0.5, 0, 0, 'riderUpper'));
                parts.push(makePart('sphere', 'gold', 0, 1.85, 0.10, 0.10, 0.10, 0.03, 0, 0, 0, 'riderUpper'));
                // Şişak Miğferi (y: 2.22)
                parts.push(makePart('frustum', 'damascusSteel', 0, 2.22, -0.01, 0.26, 0.16, 0.28, 0, 0, 0, 'riderUpper'));
                parts.push(makePart('cone', 'gold', 0, 2.34, -0.01, 0.04, 0.12, 0.04, 0, 0, 0, 'riderUpper'));
                parts.push(makePart('frustum', 'damascusSteel', 0, 2.19, 0.11, 0.22, 0.03, 0.12, 0.2, 0, 0, 'riderUpper'));
                parts.push(makePart('box', 'steel', 0, 2.15, 0.13, 0.02, 0.14, 0.015, 0, 0, 0, 'riderUpper'));
            } else {
                // Avrupa Kürassier Tapul Göğüs Zırhı ve Zischägge Miğferi
                parts.push(makePart('frustum', 'darkSteel', 0, 1.84, 0.01, 0.50, 0.32, 0.32, 0, 0, 0, 'riderUpper'));
                parts.push(makePart('box', 'steel', 0, 1.84, 0.16, 0.03, 0.30, 0.04, -0.06, 0, 0, 'riderUpper'));
                parts.push(makePart('dome', 'darkSteel', -0.28, 1.90, -0.02, 0.18, 0.16, 0.18, 0, 0,  0.25, 'riderUpper'));
                parts.push(makePart('dome', 'darkSteel',  0.28, 1.90, -0.02, 0.18, 0.16, 0.18, 0, 0, -0.25, 'riderUpper'));
                // Zischägge / Burgonet (y: 2.22)
                parts.push(makePart('dome', 'darkSteel', 0, 2.22, -0.01, 0.26, 0.18, 0.28, 0, 0, 0, 'riderUpper'));
                parts.push(makePart('box', 'darkSteel', 0, 2.31, -0.01, 0.03, 0.08, 0.26, 0, 0, 0, 'riderUpper'));
                parts.push(makePart('frustum', 'darkSteel', 0, 2.19, 0.12, 0.24, 0.03, 0.14, 0.18, 0, 0, 'riderUpper'));
                parts.push(makePart('box', 'darkSteel', 0, 2.14, -0.14, 0.22, 0.15, 0.04, -0.35, 0, 0, 'riderUpper'));
            }

            // Sol Kol: At dizginlerini tutar (riderUpper)
            const leftArmRider = [
                makePart('sphere', clothMat, -0.27, 1.88, -0.02, 0.13, 0.14, 0.13, 0, 0, 0, 'riderUpper'),
                makePart('frustum', clothMat, -0.25, 1.76, 0.10, 0.12, 0.25, 0.12, 0.5, 0.2, 0.1, 'riderUpper'),
                makePart('frustum', clothMat, -0.20, 1.66, 0.24, 0.11, 0.22, 0.10, -0.4, 0.2, 0, 'riderUpper'),
                ...buildAnatomicalHandGrip(skinMat, -0.15, 1.65, 0.34, 'riderUpper', 'reins_grip', true)
            ];

            // Sağ Kol: Süvari Kılıcı taşır (riderRightArmWeapon)
            const rightArmRider = [
                makePart('sphere', clothMat, 0.27, 1.88, -0.02, 0.13, 0.14, 0.13, 0, 0, 0, 'riderRightArmWeapon'),
                makePart('frustum', clothMat, 0.25, 1.76, 0.08, 0.12, 0.25, 0.12, 0.3, -0.1, 0, 'riderRightArmWeapon'),
                makePart('frustum', clothMat, 0.22, 1.66, 0.22, 0.11, 0.22, 0.10, -0.4, -0.1, 0, 'riderRightArmWeapon'),
                ...buildAnatomicalHandGrip(skinMat, 0.20, 1.65, 0.32, 'riderRightArmWeapon', 'sword_grip', false),
                // Süvari Kılıcı (Elde doğru yükseklikte taşınır)
                makePart('cylinder', 'burnishedBronze', 0.20, 1.65, 0.34, 0.035, 0.12, 0.035, 0.4, 0, 0, 'riderRightArmWeapon'),
                makePart('box', 'burnishedBronze', 0.20, 1.68, 0.38, 0.09, 0.02, 0.06, 0.4, 0, 0, 'riderRightArmWeapon'),
                makePart('frustum', 'steel', 0.20, 1.95, 0.52, 0.05, 0.65, 0.018, 0.35, 0, 0, 'riderRightArmWeapon')
            ];

            return [...parts, ...leftArmRider, ...rightArmRider];
        }

        // ----------------------------------------------------------------------------
        // 6. GELİŞMİŞ SAVAŞ ATI (Kavisli Boyun, Sağrı, Eyer & Koşumlar - Test 83 uyumlu)
        // ----------------------------------------------------------------------------
        function buildHighDefWarhorse(mountVariant = 'heavy_warhorse', options = {}) {
            const coatMat = options.coatMat || (mountVariant.includes('dark') ? 'horseDark' : (mountVariant.includes('dun') ? 'horseDun' : 'horseChestnut'));
            const maneMat = options.maneMat || 'horseDark';
            const leatherMat = 'leather';
            const steelMat = 'steel';

            const parts = [
                makePart('cylinder', 'shadow', 0, 0.02, 0, 2.10, 0.02, 1.15, 0, 0, 0, 'shadow'),

                // 1. Gövde & Göğüs Kafesi (torso - Test 83 hasBarrel kontrolü)
                makePart('cylinder', coatMat, 0, 1.20, 0.05, 0.72, 1.25, 0.68, Math.PI * 0.5, 0, 0, 'torso'),
                makePart('sphere', coatMat, 0, 1.24, 0.62, 0.64, 0.62, 0.58, 0, 0, 0, 'torso'),
                makePart('sphere', coatMat, 0, 1.22, -0.52, 0.66, 0.64, 0.62, 0, 0, 0, 'torso'),

                // 2. Kavisli Kaslı Boyun & At Başı (torso - Test 83 hasNeck kontrolü)
                makePart('frustum', coatMat, 0, 1.60, 0.72, 0.42, 0.65, 0.34, 0.65, 0, 0, 'torso'),
                makePart('frustum', maneMat, 0, 1.78, 0.68, 0.14, 0.55, 0.12, 0.65, 0, 0, 'torso'),
                makePart('frustum', coatMat, 0, 1.95, 1.05, 0.32, 0.42, 0.26, 1.25, 0, 0, 'torso'),
                makePart('box', coatMat, 0, 1.88, 1.26, 0.18, 0.16, 0.16, 1.25, 0, 0, 'torso'),
                makePart('cone', coatMat, -0.11, 2.18, 0.94, 0.06, 0.14, 0.06, 0.15, -0.2, 0, 'torso'),
                makePart('cone', coatMat,  0.11, 2.18, 0.94, 0.06, 0.14, 0.06, 0.15,  0.2, 0, 'torso'),

                // 3. Eyer ve Koşum Takımı
                makePart('box', leatherMat, 0, 1.48, -0.02, 0.54, 0.14, 0.58, 0, 0, 0, 'torso'),
                makePart('cone', 'burnishedBronze', 0, 1.58, 0.20, 0.12, 0.16, 0.10, 0.2, 0, 0, 'torso'),
                makePart('cone', 'burnishedBronze', 0, 1.56, -0.24, 0.14, 0.14, 0.12, -0.3, 0, 0, 'torso'),
                makePart('cylinder', steelMat, -0.36, 1.05, -0.02, 0.025, 0.62, 0.025, 0, 0, 0, 'torso'),
                makePart('cylinder', steelMat,  0.36, 1.05, -0.02, 0.025, 0.62, 0.025, 0, 0, 0, 'torso'),
                makePart('cylinder', 'burnishedBronze', -0.36, 0.74, -0.02, 0.08, 0.03, 0.08, 0, 0, 0, 'torso'),
                makePart('cylinder', 'burnishedBronze',  0.36, 0.74, -0.02, 0.08, 0.03, 0.08, 0, 0, 0, 'torso'),
                // Dizginler
                makePart('box', 'buffLeather', -0.12, 1.70, 0.65, 0.02, 0.02, 0.75, 0.45, 0, 0, 'torso'),
                makePart('box', 'buffLeather',  0.12, 1.70, 0.65, 0.02, 0.02, 0.75, 0.45, 0, 0, 'torso'),

                // 4. Kuyruk
                makePart('frustum', maneMat, 0, 1.05, -0.82, 0.16, 0.72, 0.12, -0.35, 0, 0, 'torso'),

                // 5. Bacaklar (horseLegFL, horseLegFR, horseLegHL, horseLegHR)
                // Ön Sol
                makePart('frustum', coatMat, -0.26, 0.88, 0.52, 0.16, 0.46, 0.14, 0, 0, 0, 'horseLegFL'),
                makePart('cylinder', coatMat, -0.26, 0.45, 0.52, 0.11, 0.44, 0.10, 0, 0, 0, 'horseLegFLLower'),
                makePart('frustum', 'darkCloth', -0.26, 0.10, 0.54, 0.12, 0.14, 0.14, 0, 0, 0, 'horseLegFLLower'),
                makePart('cylinder', steelMat, -0.26, 0.025, 0.54, 0.13, 0.02, 0.13, 0, 0, 0, 'horseLegFLLower'),
                // Ön Sağ
                makePart('frustum', coatMat, 0.26, 0.88, 0.52, 0.16, 0.46, 0.14, 0, 0, 0, 'horseLegFR'),
                makePart('cylinder', coatMat, 0.26, 0.45, 0.52, 0.11, 0.44, 0.10, 0, 0, 0, 'horseLegFRLower'),
                makePart('frustum', 'darkCloth', 0.26, 0.10, 0.54, 0.12, 0.14, 0.14, 0, 0, 0, 'horseLegFRLower'),
                makePart('cylinder', steelMat, 0.26, 0.025, 0.54, 0.13, 0.02, 0.13, 0, 0, 0, 'horseLegFRLower'),
                // Arka Sol
                makePart('frustum', coatMat, -0.28, 0.92, -0.52, 0.22, 0.50, 0.16, 0, 0, 0, 'horseLegHL'),
                makePart('cylinder', coatMat, -0.28, 0.45, -0.52, 0.12, 0.46, 0.11, 0, 0, 0, 'horseLegHLLower'),
                makePart('frustum', 'darkCloth', -0.28, 0.10, -0.50, 0.13, 0.14, 0.14, 0, 0, 0, 'horseLegHLLower'),
                makePart('cylinder', steelMat, -0.28, 0.025, -0.50, 0.14, 0.02, 0.14, 0, 0, 0, 'horseLegHLLower'),
                // Arka Sağ
                makePart('frustum', coatMat, 0.28, 0.92, -0.52, 0.22, 0.50, 0.16, 0, 0, 0, 'horseLegHR'),
                makePart('cylinder', coatMat, 0.28, 0.45, -0.52, 0.12, 0.46, 0.11, 0, 0, 0, 'horseLegHRLower'),
                makePart('frustum', 'darkCloth', 0.28, 0.10, -0.50, 0.13, 0.14, 0.14, 0, 0, 0, 'horseLegHRLower'),
                makePart('cylinder', steelMat, 0.28, 0.025, -0.50, 0.14, 0.02, 0.14, 0, 0, 0, 'horseLegHRLower')
            ];

            return parts;
        }

        // Geniş Kıvrık Kenarlı Fötr Şapka ve Çift Tüy Plume
        function buildHighDefCavalierHatWithPlume(clothColor = 'playerCloth') {
            return [
                makePart('cylinder', 'darkSteel', 0, 1.68, 0.02, 0.48, 0.028, 0.48, 0.10, 0, 0.15, 'torso'),
                makePart('cylinder', 'darkSteel', 0, 1.77, 0.02, 0.29, 0.18, 0.29, 0.10, 0, 0.15, 'torso'),
                makePart('cylinder', 'leather', 0, 1.70, 0.02, 0.305, 0.035, 0.305, 0.10, 0, 0.15, 'torso'),
                makePart('box', 'gold', 0.15, 1.71, 0.02, 0.04, 0.05, 0.06, 0.10, 0, 0, 0.15, 'torso'),
                makePart('frustum', clothColor, 0.18, 1.86, -0.06, 0.06, 0.32, 0.09, -0.38, 0, 0.55, 'torso'),
                makePart('cone', clothColor, 0.24, 1.98, -0.16, 0.055, 0.28, 0.075, -0.65, 0, 0.65, 'torso')
            ];
        }

        // ----------------------------------------------------------------------------
        // 7. G3D-03L 2.0 MODÜLER BİRLEŞTİRME FABRİKASI
        // ----------------------------------------------------------------------------
        class G3D03LModularUnitFactory {
            static assemble(archetype, side = 'player') {
                const arch = String(archetype || '').toLowerCase();
                const isOttoman = arch.startsWith('ottoman') || arch.includes('janissary') || arch.includes('azap') || arch.includes('sipahi') || arch.includes('levend') || arch.includes('bostanci') || arch.includes('humbaraci');

                if (isOttoman) {
                    if (arch.includes('musketeer') || arch.includes('musketier') || arch.includes('janissary')) {
                        // Yeniçeri Tüfekçisi: Hakiki Börk, Çevşen Zırhı, 2 Elle Tutulan Fitilli Musket
                        const body = buildOttomanHighDefHumanBase(side, 'average', { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                        const leftArm = buildAnatomicalArmWithHand('ottomanCrimson', 'skin', true, 'musket');
                        const rightArm = buildAnatomicalArmWithHand('ottomanCrimson', 'skin', false, 'musket');
                        const musket = buildHighDefMatchlockMusket();
                        const bork = buildHighDefBork();
                        const cevsen = buildHighDefCevsen();
                        return [...body, ...leftArm, ...rightArm, ...musket, ...bork, ...cevsen];
                    } else if (arch.includes('pikeman') || arch.includes('azap')) {
                        // Azap / Kargılı: twoHandPike ile disiplinli intikal
                        const body = buildOttomanHighDefHumanBase(side, 'average', { kaftanMat: 'ottomanWhite', salvarMat: 'ottomanNavy', kusakMat: 'ottomanCrimson' });
                        const leftArm = buildAnatomicalArmWithHand('ottomanWhite', 'skin', true, 'pike');
                        const rightArm = buildAnatomicalArmWithHand('ottomanWhite', 'skin', false, 'pike');
                        const pike = buildHighDefPike();
                        const shield = [
                            makePart('cylinder', 'buffLeather', -0.32, 1.25, 0.32, 0.44, 0.04, 0.44, Math.PI * 0.45, 0, -0.3, 'twoHandPike'),
                            makePart('sphere', 'burnishedBronze', -0.32, 1.25, 0.35, 0.12, 0.12, 0.08, 0, 0, 0, 'twoHandPike')
                        ];
                        return [...body, ...leftArm, ...rightArm, ...pike, ...shield];
                    } else if (arch.includes('sipahi') || arch.includes('cavalry')) {
                        // Tımarlı Sipahi: At ve Seated Rider (Sıfır çakışma, doğrudan binicide zırh ve kılıç!)
                        const horse = buildHighDefWarhorse('heavy_warhorse', { coatMat: 'horseChestnut' });
                        const rider = buildHighDefMountedRider(side, 'ottoman_sipahi', { clothMat: 'ottomanCrimson', breechesMat: 'ottomanEmerald' });
                        return [...horse, ...rider];
                    } else {
                        // Levend / Kılıçlı
                        const body = buildOttomanHighDefHumanBase(side, 'average', { kaftanMat: 'ottomanEmerald', salvarMat: 'ottomanCrimson' });
                        const rightArm = buildAnatomicalArmWithHand('ottomanEmerald', 'skin', false, 'sword');
                        const leftArm = buildAnatomicalArmWithHand('ottomanEmerald', 'skin', true, 'sword');
                        const yatagan = buildHighDefYatagan();
                        return [...body, ...rightArm, ...leftArm, ...yatagan];
                    }
                } else {
                    // Avrupa / Kutsal Roma
                    const coatMat = side === 'player' ? 'playerCloth' : 'enemyCloth';
                    const breechesMat = side === 'player' ? 'playerBreeches' : 'enemyBreeches';

                    if (arch.includes('musketeer') || arch.includes('musketier')) {
                        // HEDEF ÖRNEĞİ BİREBİR: Mavi Ceket, Altın Şeritler, Düğmeler, Bıyık, Tüy, 12 Havariler, Musket & Destek Çatalı
                        return buildEuropeanMusketeerHedefOrnegi(side);
                    } else if (arch.includes('pikeman') || arch.includes('pikeniere')) {
                        // Tercio Pikeniere: Morion Miğferi, Tapul Göğüs Zırhı ve twoHandPike ile omuzda disiplinli 4.5m kargı
                        const body = buildEuropeanHighDefHumanBase(side, 'average', { coatMat: 'darkCloth', breechesMat: 'buffLeather' });
                        const leftArm = buildAnatomicalArmWithHand('darkCloth', 'skin', true, 'pike');
                        const rightArm = buildAnatomicalArmWithHand('darkCloth', 'skin', false, 'pike');
                        const pike = buildHighDefPike();
                        const morion = buildHighDefMorion();
                        const tapul = buildHighDefTapulArmor();
                        return [...body, ...leftArm, ...rightArm, ...pike, ...morion, ...tapul];
                    } else if (arch.includes('curassier') || arch.includes('cavalry')) {
                        // Kürassier: Savaş Atı ve Seated Rider (Sıfır çakışma, doğrudan binicide tapul zırhı ve pallasch kılıcı!)
                        const horse = buildHighDefWarhorse('heavy_warhorse', { coatMat: 'horseDark' });
                        const rider = buildHighDefMountedRider(side, 'european_curassier', { clothMat: 'buffLeather', breechesMat: 'darkCloth' });
                        return [...horse, ...rider];
                    } else {
                        // Hellebardier
                        const body = buildEuropeanHighDefHumanBase(side, 'average', { coatMat, breechesMat: 'buffLeather' });
                        const leftArm = buildAnatomicalArmWithHand(coatMat, 'skin', true, 'pike');
                        const rightArm = buildAnatomicalArmWithHand(coatMat, 'skin', false, 'pike');
                        const pike = buildHighDefPike();
                        const burgonet = buildHighDefBurgonet();
                        return [...body, ...leftArm, ...rightArm, ...pike, ...burgonet];
                    }
                }
            }
        }
    '''
