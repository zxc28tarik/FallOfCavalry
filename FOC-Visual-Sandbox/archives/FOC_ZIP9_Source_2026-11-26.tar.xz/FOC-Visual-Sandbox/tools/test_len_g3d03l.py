with open('tools/build_g3d03l_models.py', 'r', encoding='utf-8') as f:
    text = f.read()

print('Length of build_g3d03l_models.py:', len(text))
print('Number of lines:', len(text.splitlines()))
