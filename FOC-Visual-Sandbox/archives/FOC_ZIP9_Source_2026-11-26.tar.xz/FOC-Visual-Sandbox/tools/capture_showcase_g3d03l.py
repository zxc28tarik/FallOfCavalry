# -*- coding: utf-8 -*-
"""
tools/capture_showcase_g3d03l.py
Opens the Vitrin / Armory showcase in FallOfCavalry_PLAYABLE_RTS.html
and captures a screenshot to inspect the new high-def soldiers up close.
"""

import subprocess, os, tempfile, time

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), f'foc_showcase_{int(time.time())}')
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')
screenshot_path = r'C:\Users\zxc28\.gemini\antigravity\brain\991bada2-65ad-4998-90fb-0999f47003c5\g3d03l_vitrin_closeup.png'

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

hook_script = """
<script>
window.addEventListener('load', () => {
    setTimeout(() => {
        const btn = document.getElementById('btnPreBattleShowcase') || document.getElementById('btnOpenArmory');
        if (btn) btn.click();
    }, 600);
});
</script>
"""

patched = content.replace('</body>', hook_script + '\n</body>')
temp_file = os.path.join(tempfile.gettempdir(), 'foc_vitrin_test.html')
with open(temp_file, 'w', encoding='utf-8') as f:
    f.write(patched)

cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--window-size=1280,720',
    f'--screenshot={screenshot_path}',
    f'file:///{temp_file.replace(os.sep, "/")}'
]

print("Capturing showcase...")
subprocess.run(cmd, capture_output=True, timeout=20)
if os.path.exists(screenshot_path):
    print(f"Captured: {screenshot_path} ({os.path.getsize(screenshot_path)} bytes)")
else:
    print("Failed to capture.")
