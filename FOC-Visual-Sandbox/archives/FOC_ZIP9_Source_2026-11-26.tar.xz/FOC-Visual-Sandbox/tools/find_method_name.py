with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

needle = "let templateKey = (s.templateKey && this.templates[s.templateKey]) ? s.templateKey : `${side}:${archetype}`;"
idx = text.find(needle)
idx_method = text.rfind('\n', 0, text.rfind('(', 0, idx))
print('Method line:', text[idx_method:text.find('{', idx_method)+1])
