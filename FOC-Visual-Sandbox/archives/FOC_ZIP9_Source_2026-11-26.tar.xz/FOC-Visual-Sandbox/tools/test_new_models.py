import math

def limb(mat, x1, y1, z1, x2, y2, z2, r_start, r_end, rig):
    dx = x2 - x1
    dy = y2 - y1
    dz = z2 - z1
    length = math.hypot(dx, dy, dz)
    return {
        'prim': 'frustum',
        'mat': mat,
        'length': length,
        'rig': rig
    }

def m(prim, mat, x, y, z, sx, sy, sz, rx, ry, rz, rig):
    return {
        'prim': prim,
        'mat': mat,
        'x': x, 'y': y, 'z': z,
        'sx': sx, 'sy': sy, 'sz': sz,
        'rx': rx, 'ry': ry, 'rz': rz,
        'rig': rig
    }

print("Limb and m helper definitions OK")
