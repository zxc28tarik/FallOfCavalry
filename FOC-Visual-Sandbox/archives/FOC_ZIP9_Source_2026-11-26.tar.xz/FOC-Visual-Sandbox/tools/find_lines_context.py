with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

needle = "let templateKey = (s.templateKey && this.templates[s.templateKey]) ? s.templateKey : `${side}:${archetype}`;"
idx = text.find(needle)
lines = text[:idx].splitlines()
for l in lines[-40:]:
    print(l)
