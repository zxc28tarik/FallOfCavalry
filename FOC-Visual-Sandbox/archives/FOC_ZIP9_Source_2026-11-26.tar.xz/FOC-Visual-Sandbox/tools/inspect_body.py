with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Inspect body elements
pos_body = text.find('<body')
pos_script = text.find('<script>', pos_body)
print("=== BODY TOP ===")
print(text[pos_body:pos_body+2000])
