# -*- coding: utf-8 -*-
import subprocess, os, tempfile, time

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')
brain_dir = r'C:\Users\zxc28\.gemini\antigravity\brain\991bada2-65ad-4998-90fb-0999f47003c5'

with open(html_path, 'r', encoding='utf-8') as f:
    content = f.read()

def capture_target(unit_culture, unit_key, output_name, anim='idle'):
    screenshot_path = os.path.join(brain_dir, output_name)
    temp_profile = os.path.join(tempfile.gettempdir(), f'foc_cap_{unit_key}_{int(time.time()*1000)}')

    hook = f"""
    <style>
    #focStartScreen, #rtsPreBattleOverlay {{ display: none !important; }}
    </style>
    <script>
    window.addEventListener('DOMContentLoaded', () => {{
        function tryOpen() {{
            const sc = window.focShowcase || (window.focBattleEngine && window.focBattleEngine.controller ? window.focBattleEngine.controller.showcaseController : null);
            if (sc && sc.renderer) {{
                sc.open();
                sc.currentCulture = '{unit_culture}';
                sc.selectedUnitKey = '{unit_key}';
                sc.selectedAnim = '{anim}';
                sc.renderUnitList();
                sc.updateInfoCard();
                sc.syncShowcaseSoldiers();
                const rndr = sc.renderer;
                if (rndr && rndr.render) {{
                    rndr.render();
                }}
            }} else {{
                setTimeout(tryOpen, 100);
            }}
        }}
        setTimeout(tryOpen, 150);
    }});
    </script>
    """

    patched = content.replace('</head>', hook + '\n</head>')
    temp_file = os.path.join(tempfile.gettempdir(), f'foc_temp_{unit_key}.html')
    with open(temp_file, 'w', encoding='utf-8') as f:
        f.write(patched)

    cmd = [
        chrome_path,
        '--headless=new',
        '--disable-gpu',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--window-size=1280,720',
        '--virtual-time-budget=3000',
        f'--screenshot={screenshot_path}',
        f'file:///{temp_file.replace(os.sep, "/")}'
    ]
    subprocess.run(cmd, capture_output=True, timeout=25)
    if os.path.exists(screenshot_path):
        print(f"Captured {output_name} ({os.path.getsize(screenshot_path)} bytes)")
    else:
        print(f"Failed to capture {output_name}")

print("1. Capturing European Musketier (Hedef Örneği)...")
capture_target('european', 'musketier', 'hedef_ornegi_musketier_showcase.png')

print("2. Capturing European Kürassier (Süvari & At Çakışmasız)...")
capture_target('european', 'curassier', 'cavalry_curassier_seated_showcase.png')

print("3. Capturing Ottoman Sipahi (Tımarlı Sipahi)...")
capture_target('ottoman', 'sipahi', 'cavalry_sipahi_seated_showcase.png')

print("4. Capturing European Pikeniere (4.5m Kargı İntizamlı)...")
capture_target('european', 'pikeniere', 'pikeman_tercio_showcase.png', anim='walk')
