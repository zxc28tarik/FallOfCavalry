with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

needle = "let templateKey = (s.templateKey && this.templates[s.templateKey]) ? s.templateKey : `${side}:${archetype}`;"
idx = text.find(needle)
sub = text[max(0, idx-2000):idx]
import re
print("Recent functions/methods before line:")
for line in sub.splitlines():
    if any(k in line for k in ['function', 'class', 'sync', 'update', 'render', 'Snapshot']):
        print('  ', line)
