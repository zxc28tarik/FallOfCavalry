# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = re.findall(r'(\.length\s*===?\s*206|\.length\s*>=?\s*206|206\s*model)', text)
print('206 matches in HTML:', len(matches), matches)

matches2 = re.findall(r'templates\S*\.length', text)
print('templates length checks:', matches2)
