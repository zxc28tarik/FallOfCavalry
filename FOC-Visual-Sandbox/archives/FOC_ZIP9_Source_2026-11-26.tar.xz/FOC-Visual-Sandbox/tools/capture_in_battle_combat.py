# -*- coding: utf-8 -*-
import subprocess, os, tempfile, time

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')
screenshot_path = r'C:\Users\zxc28\.gemini\antigravity\brain\991bada2-65ad-4998-90fb-0999f47003c5\g3d03l_battlefield_combat_live.png'
temp_profile = os.path.join(tempfile.gettempdir(), f'foc_battle_act_{int(time.time()*1000)}')

with open(html_path, 'r', encoding='utf-8') as f:
    html = f.read()

hook = """
<style>
#focStartScreen, #rtsPreBattleOverlay { display: none !important; }
#rtsBattleHUD { display: flex !important; }
</style>
<script>
window.addEventListener('DOMContentLoaded', () => {
    function setupBattle() {
        const be = window.focBattleEngine;
        if (be && be.controller && be.controller.renderer) {
            be.startBattle();
            // Order player army to advance towards enemy
            be.issueMoveOrder(12, 0);

            // Simulate 3.2 seconds of intense combat
            let simTime = 0;
            const dt = 0.05;
            while (simTime < 3.2) {
                be.update(dt);
                if (be.controller.renderer.soldierRegistry) {
                    be.controller.renderer.soldierRegistry.update(dt);
                }
                simTime += dt;
            }

            const cam = be.controller.renderer.cameraController;
            if (cam) {
                cam.desired.distance = 28;
                cam.desired.targetY = 1.0;
                cam.desired.pitch = 0.42;
                cam.desired.yaw = 0.35;
                cam.desired.targetX = 6;
                cam.desired.targetZ = 0;
                if (typeof cam.syncTransform === 'function') cam.syncTransform(1.0);
            }
            be.syncLivingSoldiersToRenderer();
            if (be.controller.renderer.render) {
                be.controller.renderer.render();
            }
        }
    }
    setTimeout(setupBattle, 250);
});
</script>
"""

patched = html.replace('</head>', hook + '\n</head>')
temp_html = os.path.join(tempfile.gettempdir(), 'foc_temp_combat_live.html')
with open(temp_html, 'w', encoding='utf-8') as f:
    f.write(patched)

cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--window-size=1280,720',
    f'--screenshot={screenshot_path}',
    f'file:///{temp_html.replace(os.sep, "/")}'
]
res = subprocess.run(cmd, capture_output=True, timeout=25)
print(f"Captured live combat: {os.path.getsize(screenshot_path) if os.path.exists(screenshot_path) else 0} bytes")
