with open('tools/build_playable_rts.py', 'r', encoding='utf-8') as f:
    text = f.read()

import re
print("Length of build_playable_rts.py:", len(text))
print("Occurrences of g3d03l in build_playable_rts.py:", text.count('g3d03l'))

# Check where g3d03l templates are registered
idx = text.find('const g3d03lTemplates =')
if idx != -1:
    print(text[idx:idx+800])
