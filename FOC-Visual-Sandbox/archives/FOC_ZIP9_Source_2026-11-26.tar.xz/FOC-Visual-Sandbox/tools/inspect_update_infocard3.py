with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('updateInfoCard() {')
print(text[idx+500:idx+2000])
