with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('if (archetype.startsWith(\'cavalry\'))')
print(text[idx-100:idx+600])
