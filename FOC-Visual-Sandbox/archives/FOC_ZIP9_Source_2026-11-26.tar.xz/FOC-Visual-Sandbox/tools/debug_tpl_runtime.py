import subprocess, os, tempfile, time

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), f'foc_debug_tpls_{int(time.time())}')
html_path = os.path.abspath('FallOfCavalry_PLAYABLE_RTS.html')

hook = """
<script>
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const be = window.focBattleEngine;
        const reg = be && be.renderer ? be.renderer.soldierRegistry : null;
        const result = {
            hasJanissary: Boolean(reg && reg.templates['g3d03l:ottoman_janissary:high']),
            hasMusketier: Boolean(reg && reg.templates['g3d03l:european_musketier:high']),
            musketierParts: reg && reg.templates['g3d03l:european_musketier:high'] ? reg.templates['g3d03l:european_musketier:high'].length : 0,
            hasCurassier: Boolean(reg && reg.templates['g3d03l:european_curassier:high']),
            curassierParts: reg && reg.templates['g3d03l:european_curassier:high'] ? reg.templates['g3d03l:european_curassier:high'].length : 0,
            allKeys: reg ? Object.keys(reg.templates).length : 0
        };
        console.log('__TPL_RESULT__' + JSON.stringify(result));
    }, 500);
});
</script>
"""

with open(html_path, 'r', encoding='utf-8') as f:
    c = f.read()

temp_html = os.path.join(tempfile.gettempdir(), 'debug_tpl_test.html')
with open(temp_html, 'w', encoding='utf-8') as f:
    f.write(c.replace('</head>', hook + '\n</head>'))

cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--enable-logging=stderr',
    f'file:///{temp_html.replace(os.sep, "/")}'
]
proc = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
for line in (proc.stdout + proc.stderr).splitlines():
    if '__TPL_RESULT__' in line:
        print(line[line.find('__TPL_RESULT__'):])
