import subprocess
import os
import tempfile
import json
import re

def inspect_batch1():
    with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
        html = f.read()

    script = '''
<script>
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const c = window.__focBattle3DPreview;
        const reg = c.renderer.soldierRegistry;
        const b = reg.batchGroup.batches[1];
        const prim = Object.keys(reg.geometries).find(k => reg.geometries[k] === b.geometry);
        
        const templateUsage = {};
        for (let [k, parts] of Object.entries(reg.templates)) {
            parts.forEach((p, idx) => {
                if (p._batchIndex === 1) {
                    if (!templateUsage[k]) templateUsage[k] = [];
                    templateUsage[k].push({ idx, prim: p.prim, mat: p.mat, rigGroup: p.rigGroup });
                }
            });
        }
        
        const res = {
            batch1_prim: prim,
            batch1_count: b.count,
            batch1_transparent: b.transparent,
            templateUsage
        };
        const pre = document.createElement('pre');
        pre.id = 'batch1Info';
        pre.textContent = JSON.stringify(res, null, 2);
        document.body.appendChild(pre);
    }, 1000);
});
</script>
'''

    temp_html = 'test_batch1.html'
    with open(temp_html, 'w', encoding='utf-8') as f:
        f.write(html.replace('</body>', script + '</body>'))

    temp_profile = os.path.join(tempfile.gettempdir(), 'foc_b1_prof')
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    cmd = [
        chrome_path,
        '--headless=new',
        '--disable-gpu-sandbox',
        '--enable-webgl',
        '--use-gl=angle',
        '--use-angle=d3d11',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--virtual-time-budget=5000',
        '--dump-dom',
        'file:///' + os.path.abspath(temp_html).replace('\\', '/')
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=15, encoding='utf-8', errors='replace')
    m = re.search(r'<pre id="batch1Info">(.*?)</pre>', res.stdout, re.DOTALL)
    if m:
        with open('batch1_details.json', 'w') as out_f:
            out_f.write(m.group(1))
        print(m.group(1)[:1200])
    else:
        print('Not found')
    if os.path.exists(temp_html):
        os.remove(temp_html)

if __name__ == '__main__':
    inspect_batch1()
