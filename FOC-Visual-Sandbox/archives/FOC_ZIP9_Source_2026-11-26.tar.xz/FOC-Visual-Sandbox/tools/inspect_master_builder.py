with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = [m.start() for m in re.finditer(r'new RTSUnitShowcaseController', text)]
for m in matches:
    print('Match at:', m)
    print(text[m-50:m+150])
