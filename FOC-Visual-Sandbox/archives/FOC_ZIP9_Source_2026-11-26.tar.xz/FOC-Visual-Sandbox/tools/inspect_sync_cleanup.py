with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('seenViewIds')
pos2 = text.find('for (const [key] of this.records)', pos)
print(text[pos2-100:pos2+600])
