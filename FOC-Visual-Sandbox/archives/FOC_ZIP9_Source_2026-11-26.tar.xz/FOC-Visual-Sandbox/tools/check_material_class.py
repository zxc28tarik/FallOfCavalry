# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('class Material')
if idx != -1:
    print(text[idx:idx+300])
