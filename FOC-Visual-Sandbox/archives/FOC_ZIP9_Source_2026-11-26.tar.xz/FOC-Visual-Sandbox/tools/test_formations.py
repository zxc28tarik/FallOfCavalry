import math

def compute_formation_slots(formation_type, count, is_cavalry=False, facing_yaw=0.0):
    sp_x = 2.2 if is_cavalry else 1.1
    sp_z = 2.5 if is_cavalry else 1.3
    
    local_slots = []
    
    if formation_type == 'line':
        files = math.ceil(count / 2)
        for i in range(count):
            rank = i % 2
            col = i // 2
            lx = (col - (files - 1) / 2.0) * sp_x
            lz = -rank * sp_z
            local_slots.append((lx, lz, 0.0))
            
    elif formation_type == 'column':
        num_cols = 2 if count <= 4 else 3
        num_rows = math.ceil(count / num_cols)
        for i in range(count):
            col = i % num_cols
            row = i // num_cols
            lx = (col - (num_cols - 1) / 2.0) * sp_x
            lz = -row * sp_z
            local_slots.append((lx, lz, 0.0))
            
    elif formation_type == 'wedge':
        for i in range(count):
            if i == 0:
                local_slots.append((0.0, 0.0, 0.0))
            else:
                tier = (i + 1) // 2
                side = -1.0 if (i % 2 == 1) else 1.0
                lx = side * tier * sp_x * 0.9
                lz = -tier * sp_z * 1.1
                local_slots.append((lx, lz, 0.0))
                
    elif formation_type == 'loose':
        cols = math.ceil(math.sqrt(count * 1.5))
        for i in range(count):
            row = i // cols
            col = i % cols
            stagger = (row % 2) * 0.5 * sp_x
            lx = (col - (cols - 1) / 2.0) * (sp_x * 2.0) + stagger
            lz = -row * (sp_z * 1.8)
            local_slots.append((lx, lz, 0.0))
            
    elif formation_type == 'skirmish':
        max_r = math.sqrt(count) * sp_x * 1.2
        for i in range(count):
            r = math.sqrt((i + 0.5) / count) * max_r
            ang = i * 2.3999632
            lx = r * math.cos(ang)
            lz = r * math.sin(ang)
            local_slots.append((lx, lz, 0.0))
            
    elif formation_type == 'circle':
        r = max(3.0, (count * sp_x) / (2.0 * math.pi))
        for i in range(count):
            ang = (i / count) * 2.0 * math.pi
            lx = r * math.sin(ang)
            lz = r * math.cos(ang)
            local_slots.append((lx, lz, ang))
            
    # Rotate by facing_yaw
    world_slots = []
    cos_y = math.cos(facing_yaw)
    sin_y = math.sin(facing_yaw)
    for lx, lz, extra_yaw in local_slots:
        wx = lx * cos_y - lz * sin_y
        wz = lx * sin_y + lz * cos_y
        wyaw = facing_yaw + extra_yaw
        world_slots.append((wx, wz, wyaw))
        
    return world_slots

for form in ['line', 'column', 'wedge', 'loose', 'skirmish', 'circle']:
    slots = compute_formation_slots(form, 24, False, 0.5)
    assert len(slots) == 24, f"Slot count mismatch for {form}"
    # Verify no two slots are identical
    for i in range(24):
        for j in range(i + 1, 24):
            dist = math.hypot(slots[i][0] - slots[j][0], slots[i][1] - slots[j][1])
            assert dist > 0.3, f"Slots {i} and {j} too close in {form}: {dist}"
    print(f"Formation '{form}' PASSED (24 slots, min dist > 0.3m)")

print("All 6 formations verified successfully!")
