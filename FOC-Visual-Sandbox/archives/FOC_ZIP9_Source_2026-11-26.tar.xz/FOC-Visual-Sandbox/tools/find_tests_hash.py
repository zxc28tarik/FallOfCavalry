# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('#tests')
print("Found #tests at:", idx)
if idx != -1:
    print(text[idx-50:idx+350])
