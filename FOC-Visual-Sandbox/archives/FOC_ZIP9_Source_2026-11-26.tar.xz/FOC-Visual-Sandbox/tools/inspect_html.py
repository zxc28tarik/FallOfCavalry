with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('id="focFooter"')
print(text[idx+1000:idx+2500])
