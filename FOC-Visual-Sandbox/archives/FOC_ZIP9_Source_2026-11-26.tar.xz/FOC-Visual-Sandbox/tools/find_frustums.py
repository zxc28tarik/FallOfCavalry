import re

with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

matches = re.findall(r"m\(\s*['\"]frustum['\"].*?\)", text)
print(f'Total frustum parts in templates: {len(matches)}')
for m in matches[:25]:
    print(' ', m)
