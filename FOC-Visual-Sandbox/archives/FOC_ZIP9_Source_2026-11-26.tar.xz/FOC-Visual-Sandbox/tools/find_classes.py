# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
classes = re.findall(r'class\s+([A-Za-z0-9_]+)', text)
print('Classes found:', classes)
