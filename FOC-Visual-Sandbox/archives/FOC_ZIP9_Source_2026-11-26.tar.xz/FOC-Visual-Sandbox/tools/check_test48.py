# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
cases = re.findall(r"runCase\('([^']+)'", text)
for c in cases:
    if c.startswith('48.'):
        print(c)
        idx = text.find(f"runCase('{c}'")
        print(text[idx:idx+800])
