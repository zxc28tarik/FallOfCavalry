import os
import re

# Read clean base G3D03J_WORKING.html
with open('G3D03J_WORKING.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update Title and Header Strings
html = html.replace('FALL OF CAVALRY — G3D-03J', 'FALL OF CAVALRY (1650) — PLAYABLE RTS')
html = html.replace('G3D-03J: 6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & MODEL ÇEŞİTLİLİĞİ', 'FALL OF CAVALRY: 1650 MEYDAN MUHAREBESİ (PLAYABLE 3D RTS)')
html = html.replace('6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & VİTRİN (G3D-03J)', '1650 MEYDAN MUHAREBESİ — PLAYABLE 3D RTS')
html = html.replace('64 / 64', '78 / 78')
html = html.replace('64 doğrulama testi', '78 doğrulama testi')

# 2. Add Enhanced 1650 PBR Materials to this.materials
new_pbr_materials = '''
                    blackenedSteel: new FOC_THREE.Material({ color: 0x1e293b, metalness: 0.82 }),
                    burnishedBronze: new FOC_THREE.Material({ color: 0xd97706, metalness: 0.84 }),
                    buffLeather: new FOC_THREE.Material({ color: 0xb45309, metalness: 0.04 }),
                    fineSilk: new FOC_THREE.Material({ color: 0x0284c7, metalness: 0.12 }),
                    roughWool: new FOC_THREE.Material({ color: 0x475569, metalness: 0.02 }),
                    ottomanCrimson: new FOC_THREE.Material({ color: 0x991b1b, metalness: 0.05 }),
                    europeanBlue: new FOC_THREE.Material({ color: 0x1e40af, metalness: 0.05 }),
                    linen: new FOC_THREE.Material({ color: 0xf1f5f9, metalness: 0.02 }),
                    darkFeather: new FOC_THREE.Material({ color: 0x0f172a, metalness: 0.10 }),
'''
pos_mat = html.find('damascusSteel: new FOC_THREE.Material({ color: 0x64748b, metalness: 0.85 }),')
assert pos_mat != -1, "Could not find damascusSteel material in html"
html = html[:pos_mat] + new_pbr_materials + '                    ' + html[pos_mat:]

# 3. Add Human Base & Modular Builder code
# (We read it from build_playable_rts.py to preserve exact G3D-03K models)
with open('tools/build_playable_rts.py', 'r', encoding='utf-8') as f:
    old_build_script = f.read()

# Extract G3D-03K anatomical builder block
idx_start_builder = old_build_script.find('g3d03k_builder_code = \'\'\'') + len('g3d03k_builder_code = \'\'\'')
idx_end_builder = old_build_script.find('\'\'\'\n\n# 4. Insert RTSModularUnitBuilder into html')
g3d03k_builder_code = old_build_script[idx_start_builder:idx_end_builder].strip()

pos_builder_insert = html.find('class RTSModularUnitBuilder {')
if pos_builder_insert == -1:
    pos_builder_insert = html.find('class SoldierVisualRegistry {')
    html = html[:pos_builder_insert] + g3d03k_builder_code + '\n\n        ' + html[pos_builder_insert:]

# 4. Update sync in SoldierVisualRegistry
old_sync_template = "const template = this.templates[s.templateKey] || this.templates['infantry:spearman:v1'];"
new_sync_template = """let template = this.templates[s.templateKey];
                if (!template && s.templateKey && s.templateKey.startsWith('g3d03k:')) {
                    const parts = s.templateKey.split(':');
                    const arch = parts[1] || 'ottoman_janissary';
                    const side = s.side || 'player';
                    template = RTSModularUnitBuilder.assembleSoldier(arch, side, 42);
                    this.templates[s.templateKey] = template;
                }
                if (!template) template = this.templates['infantry:spearman:v1'];"""
html = html.replace(old_sync_template, new_sync_template)

# 5. Fix Showcase camera orbit & controls
old_cam_sync = "this.desired.targetY = 0;"
new_cam_sync = "this.desired.targetY = (this.showcaseMode ? 0.95 : 0);"
html = html.replace(old_cam_sync, new_cam_sync)

old_cam_interp = "this.current.targetY += (this.desired.targetY - this.current.targetY) * factor;"
new_cam_interp = """this.current.targetY += (this.desired.targetY - this.current.targetY) * factor;
            if (this.current.distance < 1.8) this.current.distance = 1.8;"""
html = html.replace(old_cam_interp, new_cam_interp)

old_mousedown = "if (e.altKey) {"
new_mousedown = """const isShowcaseActive = (typeof window !== 'undefined') && window.focShowcase && window.focShowcase.isOpen;
                if (e.altKey || (isShowcaseActive && e.button === 0)) {"""
html = html.replace(old_mousedown, new_mousedown)

old_controls_bar = """<button id="btnToggleShowcase" type="button" class="rts-btn" title="G3D-03J Asker Donanım Vitrinini Aç">🏛️ Asker Vitrini</button>"""
new_controls_bar = """<button id="btnToggleShowcase" type="button" class="rts-btn" title="G3D-03K Asker Donanım Vitrinini Aç">🏛️ Asker Vitrini</button>
            <button id="btnShowcaseQualityToggle" type="button" class="rts-btn" style="border-color: #38bdf8; color: #38bdf8;" title="Model Kalite Modunu Değiştir (G3D-03K Yüksek / Klasik)">⭐ Kalite: G3D-03K</button>"""
html = html.replace(old_controls_bar, new_controls_bar)

old_showcase_css = """        #rtsShowcaseOverlay {
            position: fixed;
            inset: 0;
            background: rgba(10, 15, 29, 0.88);
            backdrop-filter: blur(8px);
            z-index: 100;
            display: none;
            flex-direction: column;
            color: #f8fafc;
            font-family: inherit;
        }"""
new_showcase_css = """        #rtsShowcaseOverlay {
            position: fixed;
            inset: 0;
            background: linear-gradient(135deg, rgba(10, 15, 29, 0.45) 0%, rgba(15, 23, 42, 0.25) 50%, rgba(10, 15, 29, 0.45) 100%);
            backdrop-filter: blur(2px);
            z-index: 100;
            display: none;
            flex-direction: column;
            color: #f8fafc;
            font-family: inherit;
            pointer-events: none;
        }
        #rtsShowcaseOverlay > * {
            pointer-events: auto;
        }"""
html = html.replace(old_showcase_css, new_showcase_css)

# 6. Inject RTS Overlays CSS and HTML
idx_rts_css = old_build_script.find('new_rts_css = \'\'\'') + len('new_rts_css = \'\'\'')
idx_rts_css_end = old_build_script.find('\'\'\'\nhtml = html.replace(\'</style>\', new_rts_css + \'\\n    </style>\')')
new_rts_css = old_build_script[idx_rts_css:idx_rts_css_end].strip()
html = html.replace('</style>', new_rts_css + '\n    </style>')

idx_rts_html = old_build_script.find('rts_overlays_html = \'\'\'') + len('rts_overlays_html = \'\'\'')
idx_rts_html_end = old_build_script.find('\'\'\'\npos_mount = html.find(\'<div id="battle3dMount"\')')
rts_overlays_html = old_build_script[idx_rts_html:idx_rts_html_end].strip()
# Update test counts in buttons
rts_overlays_html = rts_overlays_html.replace('⚙️ Geliştirici (70 Test)', '⚙️ Geliştirici (78 Test)')
rts_overlays_html = rts_overlays_html.replace('⚙️ Geliştirici & Test Paneli (70 / 70 Test)', '⚙️ Geliştirici & Test Paneli (78 / 78 Test)')

pos_mount = html.find('<div id="battle3dMount"')
assert pos_mount != -1, "Could not find battle3dMount in html"
html = html[:pos_mount] + rts_overlays_html + '\n    ' + html[pos_mount:]

# 7. Comprehensive 8-Agent RTS Engine Implementation
rts_engines_code = '''
        /* ============================================================================
         * FALL OF CAVALRY — DİNAMİK 8-AJAN OYNANABİLİR RTS MOTORLARI
         * ============================================================================ */

        // AJAN 05: Web Audio API Prosedürel Taktik Ses Sentezleyicisi
        class RTSAudioEngine {
            constructor() {
                this.ctx = null;
                this.enabled = true;
            }
            init() {
                if (this.ctx) return;
                try {
                    const AudioContext = window.AudioContext || window.webkitAudioContext;
                    if (AudioContext) {
                        this.ctx = new AudioContext();
                    }
                } catch (e) {
                    this.enabled = false;
                }
            }
            playGunshot() {
                if (!this.enabled) return;
                this.init();
                if (!this.ctx) return;
                const now = this.ctx.currentTime;
                const bufferSize = this.ctx.sampleRate * 0.35;
                const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
                const data = buffer.getChannelData(0);
                for (let i = 0; i < bufferSize; i++) {
                    data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.07));
                }
                const noise = this.ctx.createBufferSource();
                noise.buffer = buffer;
                const filter = this.ctx.createBiquadFilter();
                filter.type = 'lowpass';
                filter.frequency.setValueAtTime(900, now);
                filter.frequency.exponentialRampToValueAtTime(120, now + 0.3);
                const gain = this.ctx.createGain();
                gain.gain.setValueAtTime(0.6, now);
                gain.gain.exponentialRampToValueAtTime(0.01, now + 0.32);
                noise.connect(filter);
                filter.connect(gain);
                gain.connect(this.ctx.destination);
                noise.start(now);
            }
            playVolleyFire() {
                if (!this.enabled) return;
                this.init();
                if (!this.ctx) return;
                for (let i = 0; i < 3; i++) {
                    setTimeout(() => this.playGunshot(), i * 65);
                }
            }
            playClash() {
                if (!this.enabled) return;
                this.init();
                if (!this.ctx) return;
                const now = this.ctx.currentTime;
                const osc = this.ctx.createOscillator();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(1100, now);
                osc.frequency.exponentialRampToValueAtTime(320, now + 0.14);
                const gain = this.ctx.createGain();
                gain.gain.setValueAtTime(0.35, now);
                gain.gain.exponentialRampToValueAtTime(0.01, now + 0.14);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now);
                osc.stop(now + 0.14);
            }
            playPikeClash() {
                if (!this.enabled) return;
                this.init();
                if (!this.ctx) return;
                try {
                    const now = this.ctx.currentTime;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'square';
                    osc.frequency.setValueAtTime(320, now);
                    osc.frequency.exponentialRampToValueAtTime(70, now + 0.22);
                    gain.gain.setValueAtTime(0.28, now);
                    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.22);
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + 0.22);
                } catch(e) {}
            }
            playOrderHorn() {
                if (!this.enabled) return;
                this.init();
                if (!this.ctx) return;
                try {
                    const now = this.ctx.currentTime;
                    const osc1 = this.ctx.createOscillator();
                    const osc2 = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc1.type = 'sawtooth';
                    osc2.type = 'triangle';
                    osc1.frequency.setValueAtTime(220.0, now);
                    osc1.frequency.setValueAtTime(329.63, now + 0.12);
                    osc2.frequency.setValueAtTime(440.0, now);
                    osc2.frequency.setValueAtTime(659.25, now + 0.12);
                    gain.gain.setValueAtTime(0.18, now);
                    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.38);
                    osc1.connect(gain);
                    osc2.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc1.start(now);
                    osc2.start(now);
                    osc1.stop(now + 0.38);
                    osc2.stop(now + 0.38);
                } catch(e) {}
            }
            playMoveConfirm() {
                if (!this.enabled) return;
                this.init();
                if (!this.ctx) return;
                try {
                    const now = this.ctx.currentTime;
                    const osc = this.ctx.createOscillator();
                    const gain = this.ctx.createGain();
                    osc.type = 'sine';
                    osc.frequency.setValueAtTime(587.33, now);
                    osc.frequency.exponentialRampToValueAtTime(880.00, now + 0.12);
                    gain.gain.setValueAtTime(0.15, now);
                    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + 0.18);
                } catch(e) {}
            }
            playVictory() {
                if (!this.enabled) return;
                this.init();
                if (!this.ctx) return;
                [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
                    const now = this.ctx.currentTime + i * 0.12;
                    const osc = this.ctx.createOscillator();
                    osc.type = 'sawtooth';
                    osc.frequency.setValueAtTime(freq, now);
                    const gain = this.ctx.createGain();
                    gain.gain.setValueAtTime(0.2, now);
                    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
                    osc.connect(gain);
                    gain.connect(this.ctx.destination);
                    osc.start(now);
                    osc.stop(now + 0.5);
                });
            }
        }

        /* ============================================================================
         * RTS BATTLE ENGINE (Dinamik Çok Ajanlı Oynanabilir Muharebe Sistemi)
         * ============================================================================ */
        class RTSBattleEngine {
            constructor(previewController) {
                this.controller = previewController;
                this.audio = new RTSAudioEngine();
                this.gameState = 'PRE_BATTLE'; // 'PRE_BATTLE' | 'IN_BATTLE' | 'POST_BATTLE'
                this.battleTime = 0;
                this.isPaused = false;
                this.aiCooldown = 0;
                this.selectedSoldierIds = [];
                this.controlGroups = new Map();
                this.lastGroupRecall = null;
                this.lastGroupRecallTime = 0;

                // AJAN 03: Mermi İzi (Tracer) Havuzu
                this.activeTracers = [];
                // AJAN 07: Zemin Darbe / Yanık İzleri
                this.scorchMarks = [];

                this.stats = {
                    initialPlayer: 150,
                    initialEnemy: 150,
                    playerAlive: 150,
                    enemyAlive: 150,
                    playerLosses: 0,
                    enemyLosses: 0,
                    duration: 0,
                    winner: null
                };

                this.initUI();
            }

            get activeSector() {
                const sm = this.controller ? this.controller.sectorManager : null;
                if (!sm || !sm.sectors) return null;
                return sm.sectors[sm.activeSectorIndex || 0] || null;
            }

            get playerSoldiers() {
                const s = this.activeSector;
                if (!s || !s.playerGroups) return [];
                const res = [];
                for (const g of s.playerGroups) {
                    if (g.soldiers) res.push(...g.soldiers);
                }
                return res;
            }

            get enemySoldiers() {
                const s = this.activeSector;
                if (!s || !s.enemyGroups) return [];
                const res = [];
                for (const g of s.enemyGroups) {
                    if (g.soldiers) res.push(...g.soldiers);
                }
                return res;
            }

            get friendlyUnits() { return this.playerSoldiers; }
            get enemyUnits() { return this.enemySoldiers; }
            get battleElapsedSec() { return this.battleTime; }

            // AJAN 01: Kontrol Grupları & Birim Seçimi
            assignControlGroup(groupNum) {
                const sel = (this.selectedSoldierIds && this.selectedSoldierIds.length > 0)
                    ? [...this.selectedSoldierIds]
                    : this.playerSoldiers.filter(s => s.alive).map(s => s.id);
                this.controlGroups.set(groupNum, sel);
                this.audio.playMoveConfirm();
            }

            recallControlGroup(groupNum) {
                if (!this.controlGroups.has(groupNum)) return;
                const ids = this.controlGroups.get(groupNum);
                this.selectedSoldierIds = ids;

                const now = performance.now();
                if (this.lastGroupRecall === groupNum && (now - (this.lastGroupRecallTime || 0)) < 380) {
                    // Çift basış: kamerayı grubun merkezine odakla
                    const soldiers = this.playerSoldiers.filter(s => ids.includes(s.id) && s.alive);
                    if (soldiers.length > 0) {
                        let sx = 0, sz = 0;
                        soldiers.forEach(s => { sx += s.position.x; sz += s.position.z; });
                        const cam = this.controller.renderer?.cameraController;
                        if (cam) {
                            cam.desired.targetX = sx / soldiers.length;
                            cam.desired.targetZ = sz / soldiers.length;
                        }
                    }
                }
                this.lastGroupRecall = groupNum;
                this.lastGroupRecallTime = now;
                this.updateUnitCard();
                this.audio.playMoveConfirm();
            }

            // AJAN 02: Dinamik Formasyon Motoru Slot Hesaplama
            computeSlotOffset(idx, count, formKey, spacing = 2.0) {
                if (formKey === 'line' || formKey === 'hat') {
                    const cols = Math.max(4, Math.ceil(count / 2));
                    const row = Math.floor(idx / cols);
                    const col = idx % cols;
                    return { dx: (col - (cols - 1) * 0.5) * spacing, dz: row * spacing * 1.2 };
                } else if (formKey === 'column' || formKey === 'kol') {
                    const cols = 3;
                    const row = Math.floor(idx / cols);
                    const col = idx % cols;
                    return { dx: (col - 1.0) * spacing * 0.9, dz: row * spacing * 1.1 };
                } else if (formKey === 'wedge' || formKey === 'kama') {
                    let row = 0, cur = 0;
                    while (cur + (row + 1) <= idx) {
                        cur += (row + 1);
                        row++;
                    }
                    const col = idx - cur;
                    const countInRow = row + 1;
                    return { dx: (col - (countInRow - 1) * 0.5) * spacing * 1.1, dz: row * spacing * 1.3 };
                } else if (formKey === 'loose' || formKey === 'gevsek' || formKey === 'skirmish' || formKey === 'daginik') {
                    const cols = Math.ceil(Math.sqrt(count * 1.5));
                    const row = Math.floor(idx / cols);
                    const col = idx % cols;
                    const jitter = (idx % 2 === 0 ? 0.4 : -0.4);
                    return { dx: (col - (cols - 1) * 0.5) * spacing * 1.6 + jitter, dz: row * spacing * 1.6 };
                } else if (formKey === 'circle' || formKey === 'cember') {
                    const angle = (idx / count) * Math.PI * 2;
                    const radius = Math.max(3.5, Math.sqrt(count) * 1.2);
                    return { dx: Math.cos(angle) * radius, dz: Math.sin(angle) * radius };
                }
                const cols = Math.ceil(Math.sqrt(count));
                return { dx: (idx % cols - (cols - 1) * 0.5) * spacing, dz: Math.floor(idx / cols) * spacing };
            }

            applyFormationToSelected(formKey, formName) {
                const elForm = document.getElementById('rtsUnitFormation');
                if (elForm) elForm.textContent = `Formasyon: ${formName}`;

                const targets = (this.selectedSoldierIds && this.selectedSoldierIds.length > 0)
                    ? this.playerSoldiers.filter(s => this.selectedSoldierIds.includes(s.id) && s.alive)
                    : this.playerSoldiers.filter(s => s.alive);

                if (targets.length === 0) return;

                let cx = 0, cz = 0;
                for (const s of targets) { cx += s.position.x; cz += s.position.z; }
                cx /= targets.length;
                cz /= targets.length;

                const count = targets.length;
                const facingYaw = targets[0]?.facingYaw || 0;

                targets.forEach((s, idx) => {
                    const offset = this.computeSlotOffset(idx, count, formKey, 2.1);
                    const cosY = Math.cos(facingYaw);
                    const sinY = Math.sin(facingYaw);
                    const rx = offset.dx * cosY - offset.dz * sinY;
                    const rz = offset.dx * sinY + offset.dz * cosY;

                    s.targetPos = { x: cx + rx, z: cz + rz };
                    s.targetWaypoints = [{ x: s.targetPos.x, z: s.targetPos.z }];
                    s.formation = formKey;
                });

                this.audio.playOrderHorn();
                this.syncLivingSoldiersToRenderer();
            }

            applyOrderToSelected(cmdKey, cmdName) {
                const elOrder = document.getElementById('rtsUnitOrder');
                if (elOrder) elOrder.textContent = `Emir: ${cmdName}`;

                const targets = (this.selectedSoldierIds && this.selectedSoldierIds.length > 0)
                    ? this.playerSoldiers.filter(s => this.selectedSoldierIds.includes(s.id) && s.alive)
                    : this.playerSoldiers.filter(s => s.alive);

                targets.forEach(s => {
                    s.currentOrder = cmdKey;
                    if (cmdKey === 'hold') {
                        s.targetPos = null;
                        s.isMoving = false;
                        s.walkBlend = 0;
                        s.isBraced = (s.unitClass === 'pikeman' || s.unitClass === 'azap');
                    } else if (cmdKey === 'retreat') {
                        s.targetPos = { x: s.position.x - 14, z: s.position.z };
                        s.isBraced = false;
                    } else if (cmdKey === 'regroup') {
                        s.targetPos = { x: 0, z: s.position.z };
                    }
                });

                if (cmdKey === 'hold') {
                    this.audio.playPikeClash();
                } else {
                    this.audio.playOrderHorn();
                }
            }

            // AJAN 03: Mermi İzi (Tracer) Oluşturma
            spawnTracer(startX, startY, startZ, endX, endY, endZ, color = '#fef08a') {
                this.activeTracers.push({
                    startX, startY, startZ,
                    endX, endY, endZ,
                    currentX: startX, currentY: startY, currentZ: startZ,
                    progress: 0,
                    speed: 4.8, // 4.8 birim/sn hızlı intikal
                    color,
                    life: 0.35
                });
            }

            // AJAN 04: Süvari Hücumu ve Karşı Hasar Hesaplama
            calculateChargeDamage(attacker, defender) {
                if (defender.isBraced && (defender.unitClass === 'pikeman' || defender.unitClass === 'azap')) {
                    // Braced pike süvari hücumunu kırar ve ağır karşı-hasar verir
                    return {
                        targetDamage: 12,
                        cavCounterDamage: 65,
                        chargeBroken: true
                    };
                }
                // Hafif piyadeye veya arkadan çarpan süvariye +%60 şok hasarı
                return {
                    targetDamage: 52,
                    cavCounterDamage: 8,
                    chargeBroken: false
                };
            }

            // AJAN 06: Taktik AI 3-Kol Düzeni (Merkez, Sol Kanat, Sağ Kanat)
            calculateAITacticalEchelons() {
                const enemies = this.enemySoldiers.filter(s => s.alive);
                const center = [];
                const leftFlank = [];
                const rightFlank = [];

                for (const s of enemies) {
                    if (s.mountType !== 'foot') {
                        // Süvariler kanatlara
                        if (s.position.z < 0) leftFlank.push(s);
                        else rightFlank.push(s);
                    } else {
                        // Piyadeler merkeze
                        center.push(s);
                    }
                }
                return { center, leftFlank, rightFlank };
            }

            // AJAN 07: Arazi Hız Çarpanı & Yükseklik Avantajı
            getTerrainSpeedModifier(x, z) {
                if (Math.abs(x) < 4.5) return 1.20; // Yol
                if (Math.abs(z) > 45) return 0.85; // Bataklık / engebe
                return 1.0; // Normal çayır
            }

            getElevationAdvantage(attX, attZ, defX, defZ) {
                // Hafif sırt avantajı
                const attElevation = Math.sin(attX * 0.05) * 0.8;
                const defElevation = Math.sin(defX * 0.05) * 0.8;
                if (attElevation > defElevation + 0.3) {
                    return { rangeBonus: 1.12, damageBonus: 1.10 };
                }
                return { rangeBonus: 1.0, damageBonus: 1.0 };
            }

            // AJAN 08: İnteraktif Taktik Radar (Minimap)
            minimapNormalizedToWorld(nx, ny) {
                const wx = (nx - 0.5) * 120;
                const wz = (ny - 0.5) * 120;
                return { x: wx, z: wz };
            }

            handleMinimapClick(nx, ny, button = 0) {
                const coords = this.minimapNormalizedToWorld(nx, ny);
                if (button === 0) {
                    // Sol tık: Kamerayı oraya kaydır
                    const cam = this.controller.renderer?.cameraController;
                    if (cam) {
                        cam.desired.targetX = coords.x;
                        cam.desired.targetZ = coords.z;
                    }
                } else if (button === 2) {
                    // Sağ tık: Seçili birlikleri intikal ettir
                    this.issueMoveOrder(coords.x, coords.z);
                }
            }

            updateUnitCard() {
                const elTitle = document.getElementById('rtsUnitTitle');
                const elBadge = document.getElementById('rtsUnitBadge');
                const elCount = document.getElementById('rtsUnitCount');

                const selected = this.playerSoldiers.filter(s => this.selectedSoldierIds.includes(s.id) && s.alive);
                if (selected.length === 0) {
                    if (elTitle) elTitle.textContent = 'Tüm Ordu (150 Dost / 150 Düşman)';
                    if (elBadge) elBadge.textContent = '⚔️';
                    if (elCount) elCount.textContent = `${this.stats.playerAlive} Asker Hazır`;
                } else {
                    const first = selected[0];
                    const isCav = first.mountType !== 'foot';
                    if (elBadge) elBadge.textContent = isCav ? '🐎' : '🇹🇷';
                    if (elTitle) elTitle.textContent = `${selected.length}x ${first.archetype || 'Asker'}`;
                    const avgHp = Math.round(selected.reduce((acc, s) => acc + (s.hp || 100), 0) / selected.length);
                    if (elCount) elCount.textContent = `%${avgHp} Ortalama Can • Hazır`;
                }
            }

            issueMoveOrder(targetX, targetZ, soldierIds = null) {
                let ids = soldierIds;
                if (!ids || ids.length === 0) {
                    const selList = this.controller?.renderer?.selectionManager?.getSelectedList() || [];
                    if (selList.length > 0) {
                        ids = selList.map(u => u.viewId || u.id);
                    }
                }

                const targets = (ids && ids.length > 0)
                    ? this.playerSoldiers.filter(s => ids.includes(s.id) && s.alive)
                    : this.playerSoldiers.filter(s => s.alive);

                if (targets.length === 0) return;

                let cx = 0, cz = 0;
                for (const s of targets) { cx += s.position.x; cz += s.position.z; }
                cx /= targets.length;
                cz /= targets.length;

                const facingYaw = Math.atan2(targetX - cx, targetZ - cz);
                const count = targets.length;
                const cols = Math.max(3, Math.ceil(Math.sqrt(count * 2.5)));
                const spacing = 1.95;

                targets.forEach((s, i) => {
                    const row = Math.floor(i / cols);
                    const col = i % cols;
                    const ox = (col - (cols - 1) * 0.5) * spacing;
                    const oz = row * spacing;

                    const cosY = Math.cos(facingYaw);
                    const sinY = Math.sin(facingYaw);
                    const rx = ox * cosY - oz * sinY;
                    const rz = ox * sinY + oz * cosY;

                    s.targetPos = { x: targetX + rx, z: targetZ + rz };
                    s.targetWaypoints = [{ x: s.targetPos.x, z: s.targetPos.z }];
                    s.facingYaw = facingYaw;
                    s.currentOrder = 'move';
                    s.isBraced = false;
                });

                if (this.controller?.renderer?.movementManager) {
                    this.controller.renderer.movementManager.triggerMovePing(targetX, targetZ);
                }
                this.audio.playMoveConfirm();
            }

            initUI() {
                const btnStart = document.getElementById('btnStartBattleMain');
                const btnRestart = document.getElementById('btnRestartBattle');
                const btnReturnMenu = document.getElementById('btnReturnToMenu');
                const btnPause = document.getElementById('btnPauseBattle');
                const btnArmory = document.getElementById('btnOpenArmory');
                const btnPreArmory = document.getElementById('btnPreBattleShowcase');
                const btnDev = document.getElementById('btnOpenDevModal');
                const btnPreDev = document.getElementById('btnPreBattleDev');
                const btnCloseDev = document.getElementById('btnCloseDevModal');

                if (btnStart) btnStart.addEventListener('click', () => this.startBattle());
                if (btnRestart) btnRestart.addEventListener('click', () => this.startBattle());
                if (btnReturnMenu) btnReturnMenu.addEventListener('click', () => this.returnToMenu());

                if (btnPause) {
                    btnPause.addEventListener('click', () => {
                        this.isPaused = !this.isPaused;
                        btnPause.textContent = this.isPaused ? '▶️ Devam Et' : '⏸️ Duraklat';
                    });
                }

                // 6 Formasyon Düğmesi Dinamik Bağlantısı (Ajan 02)
                const formButtons = [
                    { id: 'btnFormLine', form: 'line', name: 'Hat' },
                    { id: 'btnFormColumn', form: 'column', name: 'Kol' },
                    { id: 'btnFormWedge', form: 'wedge', name: 'Kama' },
                    { id: 'btnFormLoose', form: 'loose', name: 'Gevşek' },
                    { id: 'btnFormSkirmish', form: 'skirmish', name: 'Dağınık' },
                    { id: 'btnFormCircle', form: 'circle', name: 'Çember' }
                ];
                formButtons.forEach(fb => {
                    const btn = document.getElementById(fb.id);
                    if (btn) {
                        btn.addEventListener('click', () => {
                            formButtons.forEach(o => document.getElementById(o.id)?.classList.remove('active'));
                            btn.classList.add('active');
                            this.applyFormationToSelected(fb.form, fb.name);
                        });
                    }
                });

                // 8 Komut Düğmesi Dinamik Bağlantısı (Ajan 01 & 04)
                const cmdButtons = [
                    { id: 'btnCmdMove', cmd: 'move', name: 'Hareket' },
                    { id: 'btnCmdHold', cmd: 'hold', name: 'Konum Tut' },
                    { id: 'btnCmdAttack', cmd: 'attack', name: 'Saldır' },
                    { id: 'btnCmdAttackMove', cmd: 'attack_move', name: 'Saldır-İlerle' },
                    { id: 'btnCmdRetreat', cmd: 'retreat', name: 'Geri Çekil' },
                    { id: 'btnCmdFireAtWill', cmd: 'fire_at_will', name: 'Serbest Ateş' },
                    { id: 'btnCmdHoldFire', cmd: 'hold_fire', name: 'Ateşi Kes' },
                    { id: 'btnCmdRegroup', cmd: 'regroup', name: 'Topla' }
                ];
                cmdButtons.forEach(cb => {
                    const btn = document.getElementById(cb.id);
                    if (btn) {
                        btn.addEventListener('click', () => {
                            cmdButtons.forEach(o => document.getElementById(o.id)?.classList.remove('active'));
                            btn.classList.add('active');
                            this.applyOrderToSelected(cb.cmd, cb.name);
                        });
                    }
                });

                // İnteraktif Taktik Radar (Ajan 08)
                const minimap = document.getElementById('rtsMinimapCanvas');
                if (minimap) {
                    minimap.addEventListener('mousedown', (e) => {
                        const rect = minimap.getBoundingClientRect();
                        const nx = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                        const ny = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
                        if (e.button === 0) {
                            this.handleMinimapClick(nx, ny, 0);
                        } else if (e.button === 2) {
                            e.preventDefault();
                            this.handleMinimapClick(nx, ny, 2);
                        }
                    });
                    minimap.addEventListener('contextmenu', (e) => e.preventDefault());
                }

                // Klavye Kısayolları (1-9 Kontrol Grupları, F12 Geliştirici Modalı)
                window.addEventListener('keydown', (e) => {
                    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
                    const num = parseInt(e.key, 10);
                    if (!isNaN(num) && num >= 1 && num <= 9) {
                        if (e.ctrlKey) {
                            this.assignControlGroup(num);
                        } else {
                            this.recallControlGroup(num);
                        }
                    }
                    if (e.key === 'F12' || (e.ctrlKey && e.key.toLowerCase() === 'd')) {
                        e.preventDefault();
                        const modal = document.getElementById('devPanelModal');
                        if (modal) modal.style.display = modal.style.display === 'flex' ? 'none' : 'flex';
                    }
                });

                const openShowcase = () => {
                    if (this.controller && this.controller.showcaseController) {
                        this.controller.showcaseController.open();
                    }
                };
                if (btnArmory) btnArmory.addEventListener('click', openShowcase);
                if (btnPreArmory) btnPreArmory.addEventListener('click', openShowcase);

                const openDevModal = () => {
                    const modal = document.getElementById('devPanelModal');
                    if (modal) modal.style.display = 'flex';
                };
                const closeDevModal = () => {
                    const modal = document.getElementById('devPanelModal');
                    if (modal) modal.style.display = 'none';
                };
                if (btnDev) btnDev.addEventListener('click', openDevModal);
                if (btnPreDev) btnPreDev.addEventListener('click', openDevModal);
                if (btnCloseDev) btnCloseDev.addEventListener('click', closeDevModal);

                // Modal eylemleri
                const btnRunTests = document.getElementById('btnModalRunTests');
                if (btnRunTests) {
                    btnRunTests.addEventListener('click', () => {
                        if (this.controller) this.controller.executeUnitTests();
                        const src = document.getElementById('unitTestList');
                        const dst = document.getElementById('devModalResultsContainer');
                        if (src && dst) dst.innerHTML = src.innerHTML;
                    });
                }
                const btnProfile = document.getElementById('btnModalProfile');
                if (btnProfile) {
                    btnProfile.addEventListener('click', () => {
                        if (this.controller) this.controller.executePerformanceProfile();
                    });
                }
                const btnSimLoss = document.getElementById('btnModalSimContextLoss');
                if (btnSimLoss) {
                    btnSimLoss.addEventListener('click', () => {
                        if (this.controller) this.controller.triggerContextLossTest();
                    });
                }
                const btnEmpty = document.getElementById('btnModalEmptyData');
                if (btnEmpty) {
                    btnEmpty.addEventListener('click', () => {
                        if (this.controller) this.controller.applyDataMode('empty');
                    });
                }
            }

            returnToMenu() {
                this.gameState = 'PRE_BATTLE';
                this.isPaused = false;
                const preOverlay = document.getElementById('rtsPreBattleOverlay');
                if (preOverlay) preOverlay.style.display = 'flex';
                const postOverlay = document.getElementById('rtsPostBattleOverlay');
                if (postOverlay) postOverlay.style.display = 'none';
                const hud = document.getElementById('rtsBattleHUD');
                if (hud) hud.style.display = 'none';
            }

            startBattle() {
                this.gameState = 'IN_BATTLE';
                this.battleTime = 0;
                this.isPaused = false;
                this.audio.init();

                const preOverlay = document.getElementById('rtsPreBattleOverlay');
                if (preOverlay) preOverlay.style.display = 'none';
                const postOverlay = document.getElementById('rtsPostBattleOverlay');
                if (postOverlay) postOverlay.style.display = 'none';
                const hud = document.getElementById('rtsBattleHUD');
                if (hud) hud.style.display = 'flex';

                if (this.controller) {
                    this.controller._buildSectorManager('test');
                    this.initSoldierInstances();
                    this.syncLivingSoldiersToRenderer();

                    const cam = this.controller.renderer?.cameraController;
                    if (cam) {
                        cam.desired.targetX = 0;
                        cam.desired.targetZ = 0;
                        cam.desired.distance = 44;
                        cam.desired.pitch = 0.68;
                        cam.desired.yaw = 0.0;
                    }
                }
            }

            initSoldierInstances() {
                const sm = this.controller.sectorManager;
                if (!sm) return;
                const activeSector = sm.sectors[sm.activeSectorIndex || 0];
                if (!activeSector) return;

                const resetSoldiers = (groups) => {
                    for (const grp of groups) {
                        for (const s of grp.soldiers) {
                            s.hp = s.maxHp || 100;
                            s.alive = true;
                            s.state = 'ready';
                            s.isCombatActing = false;
                            s.timeSinceLastAttack = Math.random() * 2.0;
                            s.targetPos = null;
                            s.isCharging = false;
                            s.isBraced = false;
                        }
                    }
                };
                resetSoldiers(activeSector.playerGroups);
                resetSoldiers(activeSector.enemyGroups);
            }

            update(dt) {
                if (this.gameState !== 'IN_BATTLE' || this.isPaused) return;

                this.battleTime += dt;
                this.stats.duration = this.battleTime;

                // 1. Asker Hareketi & Arazi Hız Çarpanı (Ajan 02 & 07)
                this.updateMovement(dt);

                // 2. Mermi İzi (Tracer) Güncellemesi (Ajan 03)
                this.updateTracers(dt);

                // 3. Taktik Düşman Yapay Zekası (Ajan 06)
                this.aiCooldown -= dt;
                if (this.aiCooldown <= 0) {
                    this.aiCooldown = 0.9;
                    this.updateEnemyAI();
                }

                // 4. Çatışma, Yaylım Ateşi & Süvari Hücumu (Ajan 03 & 04)
                this.updateCombat(dt);

                // 5. RTS HUD & Birim Kartı (Ajan 08)
                this.updateHUD();

                // 6. Zafer / Yenilgi Değerlendirmesi
                this.checkBattleOutcome();
            }

            updateMovement(dt) {
                const sm = this.controller.sectorManager;
                if (!sm) return;
                const activeSector = sm.sectors[sm.activeSectorIndex || 0];
                if (!activeSector) return;

                let anyMoved = false;
                const allGroups = [...activeSector.playerGroups, ...activeSector.enemyGroups];
                const allLiving = [];

                for (const grp of allGroups) {
                    for (const s of grp.soldiers) {
                        if (!s.alive) continue;
                        allLiving.push(s);

                        if (s.targetPos && (Math.abs(s.targetPos.x - s.position.x) > 0.08 || Math.abs(s.targetPos.z - s.position.z) > 0.08)) {
                            const dx = s.targetPos.x - s.position.x;
                            const dz = s.targetPos.z - s.position.z;
                            const dist = Math.hypot(dx, dz);

                            // AJAN 07: Arazi Hız Çarpanı (Yolda 1.20x)
                            const terrainMult = this.getTerrainSpeedModifier(s.position.x, s.position.z);
                            // AJAN 04: Süvari Hücumu Hız Bonusu
                            const speedBonus = s.isCharging ? 1.45 : 1.0;
                            const baseSpeed = (s.mountType !== 'foot' ? 6.5 : 3.5);
                            const speed = baseSpeed * terrainMult * speedBonus;
                            const step = Math.min(dist, speed * dt);

                            s.position.x += (dx / dist) * step;
                            s.position.z += (dz / dist) * step;
                            s.facingYaw = Math.atan2(dx, dz);
                            s.isMoving = true;
                            s.walkBlend = 1.0;
                            anyMoved = true;
                        } else {
                            s.isMoving = false;
                            s.walkBlend = 0.0;
                            s.isCharging = false;
                        }
                    }
                }

                // AJAN 02: Yumuşak Ayrışma (Anti-Bunching)
                if (allLiving.length > 1) {
                    const minD = 0.90;
                    for (let i = 0; i < allLiving.length; i++) {
                        const a = allLiving[i];
                        for (let j = i + 1; j < Math.min(allLiving.length, i + 8); j++) {
                            const b = allLiving[j];
                            const dx = b.position.x - a.position.x;
                            const dz = b.position.z - a.position.z;
                            const d = Math.hypot(dx, dz);
                            if (d > 0.001 && d < minD) {
                                const push = (minD - d) * 0.22;
                                const nx = dx / d;
                                const nz = dz / d;
                                a.position.x -= nx * push;
                                a.position.z -= nz * push;
                                b.position.x += nx * push;
                                b.position.z += nz * push;
                                anyMoved = true;
                            }
                        }
                    }
                }

                if (anyMoved) {
                    this.syncLivingSoldiersToRenderer();
                }
            }

            updateTracers(dt) {
                for (let i = this.activeTracers.length - 1; i >= 0; i--) {
                    const t = this.activeTracers[i];
                    t.progress += dt * t.speed;
                    t.currentX = t.startX + (t.endX - t.startX) * Math.min(1.0, t.progress);
                    t.currentY = t.startY + (t.endY - t.startY) * Math.min(1.0, t.progress);
                    t.currentZ = t.startZ + (t.endZ - t.startZ) * Math.min(1.0, t.progress);
                    if (t.progress >= 1.0) {
                        this.activeTracers.splice(i, 1);
                    }
                }
            }

            updateEnemyAI() {
                const sm = this.controller.sectorManager;
                if (!sm) return;
                const activeSector = sm.sectors[sm.activeSectorIndex || 0];
                if (!activeSector) return;

                let px = 0, pz = 0, pCount = 0;
                for (const grp of activeSector.playerGroups) {
                    for (const s of grp.soldiers) {
                        if (s.alive) { px += s.position.x; pz += s.position.z; pCount++; }
                    }
                }
                if (pCount === 0) return;
                px /= pCount;
                pz /= pCount;

                // AJAN 06: 3 Kol Düzeni (Merkez, Sol Kanat, Sağ Kanat)
                for (const grp of activeSector.enemyGroups) {
                    let gx = 0, gz = 0, gCount = 0;
                    for (const s of grp.soldiers) {
                        if (s.alive) { gx += s.position.x; gz += s.position.z; gCount++; }
                    }
                    if (gCount === 0) continue;
                    gx /= gCount;
                    gz /= gCount;

                    const dist = Math.hypot(px - gx, pz - gz);
                    const isCavalry = grp.soldiers[0]?.mountType !== 'foot';

                    if (dist > 22.0) {
                        const dirX = (px - gx) / dist;
                        const dirZ = (pz - gz) / dist;
                        let targetAnchorX = gx + dirX * 7.5;
                        let targetAnchorZ = gz + dirZ * 7.5;

                        // Kanat süvarileri geniş açıyla oyuncu arkasına sarkar
                        if (isCavalry) {
                            const flankSign = gz > 0 ? 1 : -1;
                            targetAnchorZ += flankSign * 6.0;
                        }

                        let idx = 0;
                        for (const s of grp.soldiers) {
                            if (!s.alive) continue;
                            const offset = this.computeSlotOffset(idx, gCount, isCavalry ? 'wedge' : 'line', 1.95);
                            s.targetPos = {
                                x: targetAnchorX + offset.dx,
                                z: targetAnchorZ + offset.dz
                            };
                            idx++;
                        }
                    } else {
                        for (const s of grp.soldiers) {
                            if (!s.alive) continue;
                            s.targetPos = null;
                            s.currentOrder = 'attack';
                        }
                    }
                }
            }

            updateCombat(dt) {
                const sm = this.controller.sectorManager;
                if (!sm) return;
                const activeSector = sm.sectors[sm.activeSectorIndex || 0];
                if (!activeSector) return;

                const playerSoldiers = [];
                const enemySoldiers = [];

                for (const grp of activeSector.playerGroups) {
                    for (const s of grp.soldiers) {
                        if (s.alive && s.hp > 0) playerSoldiers.push(s);
                    }
                }
                for (const grp of activeSector.enemyGroups) {
                    for (const s of grp.soldiers) {
                        if (s.alive && s.hp > 0) enemySoldiers.push(s);
                    }
                }

                this.stats.playerAlive = playerSoldiers.length;
                this.stats.enemyAlive = enemySoldiers.length;
                this.stats.playerLosses = 150 - playerSoldiers.length;
                this.stats.enemyLosses = 150 - enemySoldiers.length;

                let casualtiesOccurred = false;

                const processSide = (attackers, defenders, isPlayerSide) => {
                    for (const att of attackers) {
                        if (!att.alive) continue;

                        const isRanged = att.unitClass === 'musketeer' || att.activeWeapon.includes('musket') || att.activeWeapon.includes('carbine') || att.activeWeapon.includes('pistol');
                        const isCav = att.mountType !== 'foot';
                        const range = isRanged ? 24.0 : (isCav ? 3.4 : 2.5);
                        const attackCooldown = isRanged ? 3.2 : 1.2;

                        att.timeSinceLastAttack = (att.timeSinceLastAttack || 0) + dt;

                        let target = null;
                        let minDist = Infinity;

                        for (const def of defenders) {
                            if (!def.alive) continue;
                            const d = Math.hypot(def.position.x - att.position.x, def.position.z - att.position.z);
                            if (d < minDist) {
                                minDist = d;
                                target = def;
                            }
                        }

                        if (target && minDist <= range) {
                            const dx = target.position.x - att.position.x;
                            const dz = target.position.z - att.position.z;
                            att.facingYaw = Math.atan2(dx, dz);
                            att.isCombatActing = true;
                            att.actionMode = 'attack';

                            if (att.timeSinceLastAttack >= attackCooldown) {
                                att.timeSinceLastAttack = 0;

                                let dmg = 18;
                                if (isRanged) {
                                    dmg = Math.floor(28 + Math.random() * 16);
                                    if (Math.random() < 0.35) this.audio.playVolleyFire();

                                    // AJAN 03: Mermi İzi ve Namlu Dumanı
                                    this.spawnTracer(
                                        att.position.x, 1.2, att.position.z,
                                        target.position.x, 1.0, target.position.z,
                                        isPlayerSide ? '#38bdf8' : '#f87171'
                                    );

                                    if (this.controller.renderer?.soldierRegistry?.powderFxPool) {
                                        this.controller.renderer.soldierRegistry.powderFxPool.spawn(
                                            att.position.x + dx * 0.2,
                                            (att.position.y || 0) + 1.2,
                                            att.position.z + dz * 0.2,
                                            att.facingYaw
                                        );
                                    }
                                } else if (isCav) {
                                    // AJAN 04: Süvari Hücumu
                                    const chargeCalc = this.calculateChargeDamage(att, target);
                                    dmg = chargeCalc.targetDamage;
                                    if (chargeCalc.cavCounterDamage > 0) {
                                        att.hp -= chargeCalc.cavCounterDamage;
                                        if (att.hp <= 0) {
                                            att.alive = false;
                                            att.hp = 0;
                                            casualtiesOccurred = true;
                                        }
                                        this.audio.playPikeClash();
                                    } else {
                                        this.audio.playClash();
                                    }
                                } else {
                                    dmg = Math.floor(18 + Math.random() * 12);
                                    if (Math.random() < 0.25) this.audio.playClash();
                                }

                                target.hp -= dmg;
                                if (target.hp <= 0) {
                                    target.alive = false;
                                    target.hp = 0;
                                    casualtiesOccurred = true;
                                }
                            }
                        } else {
                            att.isCombatActing = false;
                        }
                    }
                };

                processSide(playerSoldiers, enemySoldiers, true);
                processSide(enemySoldiers, playerSoldiers, false);

                if (casualtiesOccurred) {
                    this.syncLivingSoldiersToRenderer();
                }
            }

            syncLivingSoldiersToRenderer() {
                const sm = this.controller.sectorManager;
                if (!sm) return;
                const snap = projectActiveSector3D(sm);
                if (this.controller.renderer && this.controller.renderer.soldierRegistry) {
                    this.controller.renderer.soldierRegistry.sync(snap);
                }
            }

            updateHUD() {
                const elPlayer = document.getElementById('hudPlayerCount');
                const elEnemy = document.getElementById('hudEnemyCount');
                const elTimer = document.getElementById('hudTimer');

                if (elPlayer) elPlayer.textContent = this.stats.playerAlive;
                if (elEnemy) elEnemy.textContent = this.stats.enemyAlive;

                if (elTimer) {
                    const m = Math.floor(this.battleTime / 60);
                    const s = Math.floor(this.battleTime % 60);
                    elTimer.textContent = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
                }

                this.updateUnitCard();
            }

            checkBattleOutcome() {
                if (this.stats.enemyAlive <= 10) {
                    this.gameState = 'POST_BATTLE';
                    this.stats.winner = 'player';
                    this.audio.playVictory();
                    this.showPostBattleScreen(true);
                } else if (this.stats.playerAlive <= 10) {
                    this.gameState = 'POST_BATTLE';
                    this.stats.winner = 'enemy';
                    this.showPostBattleScreen(false);
                }
            }

            showPostBattleScreen(isVictory) {
                const modal = document.getElementById('rtsPostBattleOverlay');
                const title = document.getElementById('postBattleTitle');
                const desc = document.getElementById('postBattleDesc');
                const duration = document.getElementById('postBattleDuration');
                const pAlive = document.getElementById('postBattlePlayerAlive');
                const pLoss = document.getElementById('postBattlePlayerLosses');
                const eLoss = document.getElementById('postBattleEnemyLosses');

                if (!modal) return;
                modal.style.display = 'flex';

                if (title) {
                    title.textContent = isVictory ? '🏆 ŞANLI ZAFER!' : '💀 AĞIR YENİLGİ!';
                    title.className = 'post-battle-title ' + (isVictory ? 'victory' : 'defeat');
                }
                if (desc) {
                    desc.textContent = isVictory
                        ? 'Düşman ordusu ağır zayiat vererek savaş alanından ricat etti. 1650 meydanında mutlak üstünlük sağlandı!'
                        : 'Ordunuz ağır zayiat vererek mevzilerini kaybetti. Savaş alanı düşman birliklerinin eline geçti.';
                }
                if (duration) {
                    const m = Math.floor(this.battleTime / 60);
                    const s = Math.floor(this.battleTime % 60);
                    duration.textContent = `${m} dk ${s} sn`;
                }
                if (pAlive) pAlive.textContent = `${this.stats.playerAlive} / 150`;
                if (pLoss) pLoss.textContent = `${this.stats.playerLosses} Kayıp`;
                if (eLoss) eLoss.textContent = `${this.stats.enemyLosses} / 150`;
            }
        }
'''

pos_preview_ctrl = html.find('class Battle3DPreviewController {')
assert pos_preview_ctrl != -1, "Could not find class Battle3DPreviewController"
html = html[:pos_preview_ctrl] + rts_engines_code + '\n        ' + html[pos_preview_ctrl:]

# 8. Hook RTSBattleEngine into Battle3DPreviewController
pos_preview_ctrl = html.find('class Battle3DPreviewController {', pos_preview_ctrl + len(rts_engines_code))
assert pos_preview_ctrl != -1, "Could not find class Battle3DPreviewController after insertion"

pos_ctrl_ctor = html.find('constructor() {', pos_preview_ctrl)
assert pos_ctrl_ctor != -1, "Could not find Battle3DPreviewController constructor"
html = html[:pos_ctrl_ctor + len('constructor() {')] + '\n                this.battleEngine = null;' + html[pos_ctrl_ctor + len('constructor() {'):]

pos_start_scene = html.find('this.startScene();', pos_preview_ctrl)
assert pos_start_scene != -1, "Could not find this.startScene() in Battle3DPreviewController"
init_hook = '''
                if (this.showcaseController) {
                    this.showcaseController.renderer = this.renderer;
                }
                this.battleEngine = new RTSBattleEngine(this);
                window.focBattleEngine = this.battleEngine;
                window.rtsBattleEngine = this.battleEngine;

                // Smart Display: If normal player (not test runner), show pre-battle screen and hide old dev panels
                const isTestRunner = (typeof window !== 'undefined') && (
                    window.location.hash === '#tests' ||
                    window.location.search.includes('runTests=1') ||
                    window.location.hash === '#profile' ||
                    window.location.search.includes('profile=1')
                );

                if (!isTestRunner) {
                    const pre = document.getElementById('rtsPreBattleOverlay');
                    if (pre) pre.style.display = 'flex';
                    document.getElementById('focHeader')?.classList.add('dev-hidden');
                    document.getElementById('focSidebar')?.classList.add('dev-hidden');
                    document.getElementById('sidebar')?.classList.add('dev-hidden');
                    document.getElementById('focFooter')?.classList.add('dev-hidden');
                    document.querySelector('.foc-footer')?.classList.add('dev-hidden');
                } else {
                    const pre = document.getElementById('rtsPreBattleOverlay');
                    if (pre) pre.style.display = 'none';
                    document.getElementById('focHeader')?.classList.remove('dev-hidden');
                    document.getElementById('focSidebar')?.classList.remove('dev-hidden');
                    document.getElementById('sidebar')?.classList.remove('dev-hidden');
                    document.getElementById('focFooter')?.classList.remove('dev-hidden');
                    document.querySelector('.foc-footer')?.classList.remove('dev-hidden');
                }
'''
html = html[:pos_start_scene + len('this.startScene();')] + init_hook + html[pos_start_scene + len('this.startScene();'):]

pos_on_frame_tick = html.find('_onFrameTick(dt) {', pos_preview_ctrl)
assert pos_on_frame_tick != -1, "Could not find _onFrameTick(dt)"
frame_tick_hook = '''
                if (this.battleEngine) {
                    this.battleEngine.update(dt);
                }
'''
html = html[:pos_on_frame_tick + len('_onFrameTick(dt) {')] + frame_tick_hook + html[pos_on_frame_tick + len('_onFrameTick(dt) {'):]

# 9. Add Tests 65 to 78 (14 tests covering G3D-03K models + 8-agent RTS systems)
tests_65_78 = '''
            // ============================================================================
            // G3D-03K ASKER MODEL KALİTESİ, ANATOMİ, ZIRH & KIYAFET TESTLERİ (65 - 70)
            // ============================================================================

            // 65. Ajan 01: İnsan Anatomisi ve 3 Temel Vücut Profili (Slim, Average, Heavy)
            runCase('65. İnsan Anatomisi ve 3 Temel Vücut Profili (Slim, Average, Heavy)', () => {
                assert(typeof BODY_PROFILES === 'object', 'BODY_PROFILES nesnesi mevcut olmalı');
                assert(BODY_PROFILES.slim && BODY_PROFILES.average && BODY_PROFILES.heavy, '3 temel vücut profili (slim, average, heavy) tanımlı olmalı');
                assert(BODY_PROFILES.heavy.shoulderWidth > BODY_PROFILES.average.shoulderWidth, 'Ağır profil daha geniş omuz genişliğine sahip olmalı');
                assert(BODY_PROFILES.average.shoulderWidth > BODY_PROFILES.slim.shoulderWidth, 'Ortalama profil ince profilden daha geniş omuz genişliğine sahip olmalı');

                const slimModel = buildAnatomicalHumanBase('player', 'slim');
                const heavyModel = buildAnatomicalHumanBase('player', 'heavy');
                assert(slimModel.length >= 22, 'Anatomik insan modeli en az 22 parçadan oluşmalı');
                assert(heavyModel.length >= 22, 'Ağır anatomik insan modeli en az 22 parçadan oluşmalı');
                const hasKnee = slimModel.some(p => p.rigGroup === 'leftLegLower' && p.prim === 'dome');
                assert(hasKnee, 'Diz kapağı mafsal kubbesi (dome) tanımlı olmalı');
            });

            // 66. Ajan 02: Osmanlı Çok Katmanlı Kıyafet ve Zırh Geometrisi (Kaftan, Kuşak, Çevşen, Börk)
            runCase('66. Osmanlı Çok Katmanlı Kıyafet ve Zırh Geometrisi (Kaftan, Kuşak, Çevşen, Börk)', () => {
                const reg = new SoldierVisualRegistry();
                const ottomanHigh = buildOttomanHighDefHumanBase('player', 'average');
                assert(Array.isArray(ottomanHigh) && ottomanHigh.length >= 24, 'Osmanlı yüksek detaylı gövdesi katmanlı kıyafet parçalarına sahip olmalı');
                const hasFlaredSkirt = ottomanHigh.some(p => p.mat === 'ottomanCrimson' && p.prim === 'frustum' && p.rigGroup === 'torso');
                const hasGoldBorder = ottomanHigh.some(p => p.mat === 'gold' && p.prim === 'frustum' && p.rigGroup === 'torso');
                assert(hasFlaredSkirt && hasGoldBorder, 'Hacimli kaftan alt eteği ve altın sırma kenarlığı bulunmalı');

                const borkParts = buildHighDefBork();
                assert(borkParts.length >= 5, 'Yüksek detaylı Börk en az 5 parçaya sahip olmalı');
                const cevsenParts = buildHighDefCevsen();
                assert(cevsenParts.length >= 5, 'Yüksek detaylı Çevşen çelik disk ve bazuband kolçaklarına sahip olmalı');
            });

            // 67. Ajan 03: Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları (Doublet, Morion, Tapul)
            runCase('67. Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları (Doublet, Morion, Tapul)', () => {
                const euroHigh = buildEuropeanHighDefHumanBase('enemy', 'average');
                assert(Array.isArray(euroHigh) && euroHigh.length >= 24, 'Avrupa yüksek detaylı gövdesi katmanlı kıyafet parçalarına sahip olmalı');
                const hasCollar = euroHigh.some(p => p.mat === 'linen' && p.rigGroup === 'torso');
                const hasBaldric = euroHigh.some(p => p.mat === 'buffLeather' && p.rigGroup === 'torso');
                assert(hasCollar && hasBaldric, 'Düşen keten yaka ve deri süvari baldriği mevcut olmalı');

                const morionParts = buildHighDefMorion();
                const hasComb = morionParts.some(p => p.mat === 'steel' && p.prim === 'box');
                assert(hasComb, 'Morion miğferi yüksek çelik ibiğe sahip olmalı');

                const tapulParts = buildHighDefTapulArmor();
                const hasSpine = tapulParts.some(p => p.mat === 'steel' && p.prim === 'box');
                assert(hasSpine, 'Tapul zırhı mermi saptırıcı çelik omurgaya ve tasset plakalarına sahip olmalı');
            });

            // 68. Ajan 04: Baş, Yüz Anatomisi, Yüz Kılları ve Miğfer Oturumu
            runCase('68. Baş, Yüz Anatomisi, Yüz Kılları ve Miğfer Oturumu', () => {
                const headMustache = buildAnatomicalHead('skin', 'wood', 'ottoman_pala');
                const headVandyke = buildAnatomicalHead('skin', 'wood', 'vandyke');
                const headBeard = buildAnatomicalHead('skin', 'wood', 'full_beard');

                assert(headMustache.length >= 9, 'Pala bıyıklı baş modeli anatomik yüz detaylarını içermeli');
                assert(headVandyke.length >= 9, 'Van Dyke sakallı Avrupa baş modeli anatomik yüz detaylarını içermeli');
                assert(headBeard.length >= 8, 'Tam sakallı gazi/veteran baş modeli tanımlı olmalı');

                const hasNose = headMustache.some(p => p.prim === 'cone' && p.mat === 'skin');
                const hasEars = headMustache.filter(p => p.prim === 'dome' && p.mat === 'skin').length === 2;
                assert(hasNose && hasEars, 'Belirgin burun köprüsü ve iki kulak kubbesi bulunmalı');
            });

            // 69. Ajan 05: 1650 İleri Malzeme Kütüphanesi ve PBR Yüzey Özellikleri
            runCase('69. 1650 İleri Malzeme Kütüphanesi ve PBR Yüzey Özellikleri', () => {
                const reg = new SoldierVisualRegistry();
                const expectedPBR = ['blackenedSteel', 'burnishedBronze', 'buffLeather', 'fineSilk', 'roughWool'];
                for (const matKey of expectedPBR) {
                    assert(reg.materials[matKey], `${matKey} PBR materyali kayıtlı olmalı`);
                    assert(reg.materials[matKey].color && typeof reg.materials[matKey].color.r === 'number', `${matKey} geçerli Color nesnesi içermeli`);
                }
                assert(reg.materials.blackenedSteel.metalness > 0.75, 'blackenedSteel yüksek metalness içermeli');
                assert(reg.materials.buffLeather.metalness < 0.10, 'buffLeather mat deri olarak düşük metalness içermeli');
                assert(Object.keys(reg.templates).length === 206, '206 temel model şablonu tam olarak korunmalı');
            });

            // 70. Ajan 06: Modüler Asker Birleştirme Motoru ve Vitrin Model Kalitesi Kıyaslaması
            runCase('70. Modüler Asker Birleştirme Motoru ve Vitrin Model Kalitesi Kıyaslaması', () => {
                assert(typeof RTSModularUnitBuilder === 'function', 'RTSModularUnitBuilder sınıfı tanımlı olmalı');
                const soldier1 = RTSModularUnitBuilder.assembleSoldier('ottoman_janissary', 'player', 10);
                const soldier2 = RTSModularUnitBuilder.assembleSoldier('european_pikeniere', 'enemy', 11);
                assert(Array.isArray(soldier1) && soldier1.length >= 30, 'Modüler Yeniçeri en az 30 yüksek detaylı parçadan oluşmalı');
                assert(Array.isArray(soldier2) && soldier2.length >= 30, 'Modüler Pikeniere en az 30 yüksek detaylı parçadan oluşmalı');

                const mockRenderer = { cameraController: new RTSCamera3D() };
                const showcase = new RTSUnitShowcaseController(mockRenderer);
                assert(showcase.qualityMode === 'high', 'Asker vitrini varsayılan olarak G3D-03K yüksek kalite modunda başlamalı');
                const btnQuality = document.getElementById('btnShowcaseQualityToggle');
                assert(btnQuality, 'Model kalitesi geçiş butonu arayüzde mevcut olmalı');
            });

            // ============================================================================
            // DİNAMİK 8-AJAN OYNANABİLİR RTS ENTEGRASYON TESTLERİ (71 - 78)
            // ============================================================================

            // 71. Ajan 01: Çoklu Birim Seçimi, Kontrol Grupları (1-9) ve Hızlı Erişim
            runCase('71. Ajan 01: Çoklu Birim Seçimi, Kontrol Grupları ve Hızlı Erişim', () => {
                const be = window.focBattleEngine;
                assert(be && typeof be.assignControlGroup === 'function', 'assignControlGroup metodu tanımlı olmalı');
                assert(typeof be.recallControlGroup === 'function', 'recallControlGroup metodu tanımlı olmalı');

                be.selectedSoldierIds = ['s_001', 's_002', 's_003'];
                be.assignControlGroup(1);
                assert(be.controlGroups.get(1).length === 3, 'Grup 1 üç askeri hafızaya almalı');

                be.selectedSoldierIds = [];
                be.recallControlGroup(1);
                assert(be.selectedSoldierIds.length === 3, 'Grup 1 geri çağrıldığında seçim güncellenmeli');
            });

            // 72. Ajan 02: Dinamik Formasyon Motoru Slot Hesaplama & Dağılım
            runCase('72. Ajan 02: Dinamik Formasyon Motoru Slot Hesaplama & Dağılım', () => {
                const be = window.focBattleEngine;
                assert(be && typeof be.computeSlotOffset === 'function', 'computeSlotOffset metodu tanımlı olmalı');

                const slotLine = be.computeSlotOffset(0, 10, 'line', 2.0);
                const slotWedge = be.computeSlotOffset(0, 10, 'wedge', 2.0);
                const slotCircle = be.computeSlotOffset(0, 10, 'circle', 2.0);

                assert(typeof slotLine.dx === 'number' && typeof slotLine.dz === 'number', 'Hat slot koordinatları sayı olmalı');
                assert(typeof slotWedge.dx === 'number' && typeof slotWedge.dz === 'number', 'Kama slot koordinatları sayı olmalı');
                assert(typeof slotCircle.dx === 'number' && typeof slotCircle.dz === 'number', 'Çember slot koordinatları sayı olmalı');

                const slotLineEnd = be.computeSlotOffset(4, 10, 'line', 2.0);
                assert(Math.abs(slotLineEnd.dx - slotLine.dx) > 1.5, 'Hat formasyonu askerleri yan yana dizmeli');
            });

            // 73. Ajan 03: Balistik Motoru & Mermi İzi (Tracer) Yaşam Döngüsü
            runCase('73. Ajan 03: Balistik Motoru & Mermi İzi (Tracer) Yaşam Döngüsü', () => {
                const be = window.focBattleEngine;
                assert(be && typeof be.spawnTracer === 'function', 'spawnTracer metodu tanımlı olmalı');

                const tCountBefore = be.activeTracers ? be.activeTracers.length : 0;
                be.spawnTracer(0, 1.2, 0, 15, 1.0, 15, '#fef08a');
                assert(be.activeTracers.length === tCountBefore + 1, 'Mermi izi havuza eklenmeli');
                const tracer = be.activeTracers[be.activeTracers.length - 1];
                assert(tracer.progress === 0 && tracer.speed > 0, 'Tracer başlangıç parametreleri doğru olmalı');
            });

            // 74. Ajan 04: Süvari Hücumu (Charge) ve Pike Karşı-Duruşu
            runCase('74. Ajan 04: Süvari Hücumu (Charge) ve Pike Karşı-Duruşu', () => {
                const be = window.focBattleEngine;
                const testCav = { id: 'test_cav', unitClass: 'cavalry', mountType: 'horse', position: { x: 0, z: 0 }, isCharging: true, hp: 100 };
                const bracedPike = { id: 'test_pike', unitClass: 'pikeman', isBraced: true, hp: 100 };
                const normalInf = { id: 'test_musket', unitClass: 'musketeer', isBraced: false, hp: 100 };

                const cavDamageOnPike = be.calculateChargeDamage(testCav, bracedPike);
                assert(cavDamageOnPike.cavCounterDamage > 40, 'Pikeler süvari hücumuna yüksek karşı-hasar vermeli');

                const cavDamageOnMusket = be.calculateChargeDamage(testCav, normalInf);
                assert(cavDamageOnMusket.targetDamage >= 45, 'Süvari hücumu hafif piyadeye +%50 şok hasarı vermeli');
            });

            // 75. Ajan 05: Web Audio API Prosedürel Taktik Ses Sentezleyicisi
            runCase('75. Ajan 05: Web Audio API Prosedürel Taktik Ses Sentezleyicisi', () => {
                const be = window.focBattleEngine;
                assert(be && be.audio, 'RTSAudioEngine mevcut olmalı');
                assert(typeof be.audio.playOrderHorn === 'function', 'playOrderHorn fonksiyonu mevcut olmalı');
                assert(typeof be.audio.playVolleyFire === 'function', 'playVolleyFire fonksiyonu mevcut olmalı');
                assert(typeof be.audio.playPikeClash === 'function', 'playPikeClash fonksiyonu mevcut olmalı');
                assert(typeof be.audio.playMoveConfirm === 'function', 'playMoveConfirm fonksiyonu mevcut olmalı');
            });

            // 76. Ajan 06: Taktik Savaş Yapay Zekası ve Kanat Kuşatma Manevraları
            runCase('76. Ajan 06: Taktik Savaş Yapay Zekası ve Kanat Kuşatma Manevraları', () => {
                const be = window.focBattleEngine;
                assert(be && typeof be.calculateAITacticalEchelons === 'function', 'calculateAITacticalEchelons metodu tanımlı olmalı');

                const echelons = be.calculateAITacticalEchelons();
                assert(echelons.center && echelons.leftFlank && echelons.rightFlank, 'AI kuvvetleri merkez, sol kanat ve sağ kanat olarak 3 kola ayrılmalı');
            });

            // 77. Ajan 07: Arazi Hız Çarpanı (Yol / Çayır) & Yükseklik Avantajı
            runCase('77. Ajan 07: Arazi Hız Çarpanı (Yol / Çayır) & Yükseklik Avantajı', () => {
                const be = window.focBattleEngine;
                assert(be && typeof be.getTerrainSpeedModifier === 'function', 'getTerrainSpeedModifier metodu tanımlı olmalı');
                assert(typeof be.getElevationAdvantage === 'function', 'getElevationAdvantage metodu tanımlı olmalı');

                const roadSpeed = be.getTerrainSpeedModifier(0, 0); // Merkez yol (|x| < 4.5)
                const grassSpeed = be.getTerrainSpeedModifier(20, 0); // Çayır
                assert(roadSpeed > grassSpeed, 'Yol üzerindeki birlikler çayıra göre daha hızlı ilerlemeli');
                assert(roadSpeed === 1.20, 'Yol hız bonusu tam olarak 1.20x olmalı');
            });

            // 78. Ajan 08: İnteraktif Taktik Radar (Tıkla-Kaydır & Sağ Tık İntikal)
            runCase('78. Ajan 08: İnteraktif Taktik Radar (Tıkla-Kaydır & Sağ Tık İntikal)', () => {
                const be = window.focBattleEngine;
                assert(be && typeof be.handleMinimapClick === 'function', 'handleMinimapClick metodu tanımlı olmalı');

                const coords = be.minimapNormalizedToWorld(0.5, 0.5);
                assert(Math.abs(coords.x) < 0.1 && Math.abs(coords.z) < 0.1, 'Minimap merkezi dünya (0,0) konumuna denk gelmeli');

                const coordsEdge = be.minimapNormalizedToWorld(1.0, 1.0);
                assert(coordsEdge.x > 50 && coordsEdge.z > 50, 'Minimap köşesi dünya sınırlarına doğru orantılanmalı');
            });
'''

idx_test64 = html.find("showcase.toggleCompare();")
assert idx_test64 != -1, "Could not find Test 64 in html"

idx_test64_end = html.find('});', idx_test64) + 3
html = html[:idx_test64_end] + '\n' + tests_65_78 + '\n' + html[idx_test64_end:]

with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(html)

with open('FallOfCavalry_PLAYABLE_RTS.html', 'w', encoding='utf-8') as f:
    f.write(html)

print(f"Successfully generated clean 8-Agent Playable RTS: G3D03K_WORKING.html ({len(html)} bytes) and FallOfCavalry_PLAYABLE_RTS.html.")
