import subprocess
import os
import tempfile
import json
import re
import base64

def run_diag(target_file='G3D03G_WORKING.html'):
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    temp_profile = os.path.join(tempfile.gettempdir(), 'foc_debug_profile')

    with open(target_file, 'r', encoding='utf-8') as f:
        content = f.read()

    diag_code = '''
<script>
window.addEventListener('load', () => {
    setTimeout(() => {
        const c = window.__focBattle3DPreview;
        const reg = c ? c.renderer.soldierRegistry : null;
        const diag = {
            hasController: !!c,
            recordCount: reg ? reg.records.size : 0,
            batches: [],
            recordsSample: [],
            consoleErrors: window.__diagErrors || []
        };
        
        if (reg) {
            for (let [id, rec] of Array.from(reg.records.entries()).slice(0, 5)) {
                diag.recordsSample.push({
                    id, x: rec.x, y: rec.y, z: rec.z, yaw: rec.yaw,
                    targetX: rec.targetX, targetZ: rec.targetZ, isMoving: rec.isMoving,
                    worldMat: Array.from(rec.worldMat).slice(0, 16)
                });
            }
            for (let b of reg.batchGroup.batches) {
                let nanCount = 0;
                let infCount = 0;
                let minVal = Infinity;
                let maxVal = -Infinity;
                for (let i = 0; i < b.instanceData.length; i++) {
                    const v = b.instanceData[i];
                    if (Number.isNaN(v)) nanCount++;
                    if (!Number.isFinite(v)) infCount++;
                    if (v < minVal) minVal = v;
                    if (v > maxVal) maxVal = v;
                }
                diag.batches.push({
                    count: b.count,
                    len: b.instanceData.length,
                    nanCount,
                    infCount,
                    minVal,
                    maxVal,
                    first16: Array.from(b.instanceData.slice(0, 16))
                });
            }
        }
        
        try {
            const cvs = document.querySelector('canvas');
            diag.screenshotBase64 = cvs ? cvs.toDataURL('image/png') : null;
            diag.canvasFound = !!cvs;
        } catch(e) {
            diag.screenshotErr = String(e);
        }
        
        const pre = document.createElement('pre');
        pre.id = 'diagOutput';
        pre.textContent = JSON.stringify(diag);
        document.body.appendChild(pre);
    }, 1500);
});
</script>
'''
    temp_html = 'G3D03G_TEMP_DIAG.html'
    with open(temp_html, 'w', encoding='utf-8') as f:
        f.write(content.replace('</body>', diag_code + '</body>'))

    cmd = [
        chrome_path,
        '--headless=new',
        '--disable-gpu-sandbox',
        '--enable-webgl',
        '--use-gl=angle',
        '--use-angle=d3d11',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--virtual-time-budget=10000',
        '--dump-dom',
        'file:///' + os.path.abspath(temp_html).replace('\\', '/')
    ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=20, encoding='utf-8', errors='replace')
        m = re.search(r'<pre id="diagOutput">(.*?)</pre>', res.stdout, re.DOTALL)
        if m:
            data = json.loads(m.group(1))
            if 'screenshotBase64' in data and data['screenshotBase64']:
                raw = base64.b64decode(data['screenshotBase64'].split(',')[1])
                with open('diag_screenshot.png', 'wb') as img_f:
                    img_f.write(raw)
                del data['screenshotBase64']
                print('Saved diag_screenshot.png!')
            print(json.dumps(data, indent=2))
        else:
            print('No diag output found. stdout length:', len(res.stdout), 'stderr:', res.stderr[:500])
    finally:
        if os.path.exists(temp_html):
            os.remove(temp_html)

if __name__ == '__main__':
    run_diag()
