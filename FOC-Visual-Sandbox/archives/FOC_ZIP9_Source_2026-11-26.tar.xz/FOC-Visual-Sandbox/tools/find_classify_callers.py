with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = [m.start() for m in re.finditer(r'classifySoldierArchetype', text)]
print('classifySoldierArchetype matches:', len(matches))
for m in matches:
    idx = text.rfind('function ', 0, m)
    fn = text[idx:text.find('{', idx)] if idx != -1 else 'none'
    print('Called in:', fn)
    print(text[m-50:m+200])
