with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
for m in re.finditer(r'resolveCavalryVisualVariant', text):
    print(text[m.start()-50:m.start()+150])
