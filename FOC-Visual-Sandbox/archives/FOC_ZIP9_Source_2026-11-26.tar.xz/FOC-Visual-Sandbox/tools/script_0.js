
    (function () {
        'use strict';

        /* ============================================================================
         * 1. EMBEDDED ZERO-DEPENDENCY WEBGL 3D ENGINE WITH IN-PLACE BUFFER SUBDATA
         *    AND SYNCHRONIZED CONTEXT LOSS / RESTORE LIFECYCLE (G3D-03C)
         * ============================================================================ */
        const Mat4 = {
            create() {
                const out = new Float32Array(16);
                out[0] = out[5] = out[10] = out[15] = 1;
                return out;
            },
            identity(out) {
                out.fill(0);
                out[0] = out[5] = out[10] = out[15] = 1;
                return out;
            },
            perspective(out, fovyRad, aspect, near, far) {
                const f = 1.0 / Math.tan(fovyRad * 0.5);
                const nf = 1 / (near - far);
                out.fill(0);
                out[0] = f / aspect;
                out[5] = f;
                out[10] = (far + near) * nf;
                out[11] = -1;
                out[14] = 2 * far * near * nf;
                return out;
            },
            lookAt(out, eye, center, up) {
                let zx = eye[0] - center[0];
                let zy = eye[1] - center[1];
                let zz = eye[2] - center[2];
                let len = Math.hypot(zx, zy, zz);
                if (len < 1e-6) {
                    zz = 1;
                } else {
                    zx /= len; zy /= len; zz /= len;
                }

                let xx = up[1] * zz - up[2] * zy;
                let xy = up[2] * zx - up[0] * zz;
                let xz = up[0] * zy - up[1] * zx;
                len = Math.hypot(xx, xy, xz);
                if (len < 1e-6) {
                    xx = 1; xy = 0; xz = 0;
                } else {
                    xx /= len; xy /= len; xz /= len;
                }

                const yx = zy * xz - zz * xy;
                const yy = zz * xx - zx * xz;
                const yz = zx * xy - zy * xx;

                out[0] = xx; out[1] = yx; out[2] = zx; out[3] = 0;
                out[4] = xy; out[5] = yy; out[6] = zy; out[7] = 0;
                out[8] = xz; out[9] = yz; out[10] = zz; out[11] = 0;
                out[12] = -(xx * eye[0] + xy * eye[1] + xz * eye[2]);
                out[13] = -(yx * eye[0] + yy * eye[1] + yz * eye[2]);
                out[14] = -(zx * eye[0] + zy * eye[1] + zz * eye[2]);
                out[15] = 1;
                return out;
            },
            compose(out, pos, scale) {
                out.fill(0);
                out[0] = scale.x;
                out[5] = scale.y;
                out[10] = scale.z;
                out[12] = pos.x;
                out[13] = pos.y;
                out[14] = pos.z;
                out[15] = 1;
                return out;
            },
            fromEulerTranslationScale(out, rx, ry, rz, tx, ty, tz, sx, sy, sz) {
                const cx = Math.cos(rx), sxr = Math.sin(rx);
                const cy = Math.cos(ry), syr = Math.sin(ry);
                const cz = Math.cos(rz), szr = Math.sin(rz);

                const r00 = cz * cy;
                const r10 = szr * cy;
                const r20 = -syr;

                const r01 = cz * syr * sxr - szr * cx;
                const r11 = szr * syr * sxr + cz * cx;
                const r21 = cy * sxr;

                const r02 = cz * syr * cx + szr * sxr;
                const r12 = szr * syr * cx - cz * sxr;
                const r22 = cy * cx;

                out[0] = r00 * sx;
                out[1] = r10 * sx;
                out[2] = r20 * sx;
                out[3] = 0;

                out[4] = r01 * sy;
                out[5] = r11 * sy;
                out[6] = r21 * sy;
                out[7] = 0;

                out[8] = r02 * sz;
                out[9] = r12 * sz;
                out[10] = r22 * sz;
                out[11] = 0;

                out[12] = tx;
                out[13] = ty;
                out[14] = tz;
                out[15] = 1;
                return out;
            },
            fromYawTranslation(out, yaw, wx, wy, wz) {
                const c = Math.cos(yaw);
                const s = Math.sin(yaw);
                out[0] = c;  out[1] = 0; out[2] = -s; out[3] = 0;
                out[4] = 0;  out[5] = 1; out[6] = 0;  out[7] = 0;
                out[8] = s;  out[9] = 0; out[10] = c; out[11] = 0;
                out[12] = wx; out[13] = wy; out[14] = wz; out[15] = 1;
                return out;
            },
            fromPivotEulerOffset(out, px, py, pz, rx, ry, dx, dy, dz) {
                const cx = Math.cos(rx), sx = Math.sin(rx);
                const cy = Math.cos(ry), sy = Math.sin(ry);

                const r00 = cy;
                const r10 = 0;
                const r20 = -sy;

                const r01 = sy * sx;
                const r11 = cx;
                const r21 = cy * sx;

                const r02 = sy * cx;
                const r12 = -sx;
                const r22 = cy * cx;

                out[0] = r00; out[1] = r10; out[2] = r20; out[3] = 0;
                out[4] = r01; out[5] = r11; out[6] = r21; out[7] = 0;
                out[8] = r02; out[9] = r12; out[10] = r22; out[11] = 0;

                out[12] = px + dx - (r00 * px + r01 * py + r02 * pz);
                out[13] = py + dy - (r10 * px + r11 * py + r12 * pz);
                out[14] = pz + dz - (r20 * px + r21 * py + r22 * pz);
                out[15] = 1;
                return out;
            },
            fromPivotEulerRollOffset(out, px, py, pz, rx, ry, rz, dx, dy, dz) {
                const cx = Math.cos(rx), sx = Math.sin(rx);
                const cy = Math.cos(ry), sy = Math.sin(ry);
                const cz = Math.cos(rz), sz = Math.sin(rz);

                const r00 = cz * cy;
                const r10 = sz * cy;
                const r20 = -sy;

                const r01 = cz * sy * sx - sz * cx;
                const r11 = sz * sy * sx + cz * cx;
                const r21 = cy * sx;

                const r02 = cz * sy * cx + sz * sx;
                const r12 = sz * sy * cx - cz * sx;
                const r22 = cy * cx;

                out[0] = r00; out[1] = r10; out[2] = r20; out[3] = 0;
                out[4] = r01; out[5] = r11; out[6] = r21; out[7] = 0;
                out[8] = r02; out[9] = r12; out[10] = r22; out[11] = 0;

                out[12] = px + dx - (r00 * px + r01 * py + r02 * pz);
                out[13] = py + dy - (r10 * px + r11 * py + r12 * pz);
                out[14] = pz + dz - (r20 * px + r21 * py + r22 * pz);
                out[15] = 1;
                return out;
            },
            multiply(out, a, b) {
                const a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3];
                const a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7];
                const a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11];
                const a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];

                let b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3];
                out[0] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
                out[1] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
                out[2] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
                out[3] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;

                b0 = b[4]; b1 = b[5]; b2 = b[6]; b3 = b[7];
                out[4] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
                out[5] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
                out[6] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
                out[7] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;

                b0 = b[8]; b1 = b[9]; b2 = b[10]; b3 = b[11];
                out[8] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
                out[9] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
                out[10] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
                out[11] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;

                b0 = b[12]; b1 = b[13]; b2 = b[14]; b3 = b[15];
                out[12] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
                out[13] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
                out[14] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
                out[15] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
                return out;
            }
        };

        class Color {
            constructor(hex = 0xffffff) {
                this.r = 1;
                this.g = 1;
                this.b = 1;
                this.setHex(hex);
            }
            setHex(hex) {
                this.r = ((hex >> 16) & 255) / 255;
                this.g = ((hex >> 8) & 255) / 255;
                this.b = (hex & 255) / 255;
                return this;
            }
            getHex() {
                const r = Math.round(this.r * 255) & 255;
                const g = Math.round(this.g * 255) & 255;
                const b = Math.round(this.b * 255) & 255;
                return (r << 16) | (g << 8) | b;
            }
        }

        /* ============================================================================
         * 1650 HISTORIC BATTLEFIELD VISUAL, TERRAIN & ATMOSPHERE CONFIGURATION (G3D-SAHA-06)
         * ============================================================================ */
        const BATTLEFIELD_VISUAL_CONFIG = Object.freeze({
            terrain: Object.freeze({
                span: 260,
                subdivisions: 72,
                baseColor: 0x3d492c,      // Fallback earthy-olive ground albedo
                grassCenter: '#485533',    // Core meadow turf tone (temperate 1650 European meadow)
                grassMid: '#3e4a2b',       // Trampled turf & damp sod mid-tier tone
                grassEdge: '#2e381f',      // Loamy earth perimeter shade for natural vignette & depth
                gridColor: 0x766f5e,       // Tactical range grid line tone
                gridOpacity: 0.16          // Low-noise tactical grid opacity
            }),
            atmosphere: Object.freeze({
                skyColor: 0x94a9be,        // Overcast historical slate blue
                fogColor: 0x9cb1c3,        // Distant atmospheric horizon mist
                fogDensity: 0.0048         // Carefully calibrated density preserving silhouette depth at 60-120m
            }),
            lighting: Object.freeze({
                sunColor: 0xfff2dc,        // Warm low-angle autumn morning sun
                sunDirection: Object.freeze([-0.52, 0.68, 0.51]), // Raking sunlight creating plastic sculpturing on pikes/horses
                hemiSkyColor: 0xd6e5f7,    // Cool sky vault ambient bounce
                hemiGroundColor: 0x3a422a  // Warm loamy-turf under-bounce preventing black shadows
            })
        });

        class FogExp2 {
            constructor(colorHex, density = 0.005) {
                this.color = new Color(colorHex);
                this.density = density;
            }
        }

        class PerspectiveCamera {
            constructor(fov = 42, aspect = 1, near = 0.5, far = 340) {
                this.fov = fov;
                this.aspect = aspect;
                this.near = near;
                this.far = far;
                this.position = {
                    x: 0,
                    y: 35,
                    z: 35,
                    set(x, y, z) {
                        this.x = x;
                        this.y = y;
                        this.z = z;
                    }
                };
                this.target = [0, 0, 0];
                this.projectionMatrix = Mat4.create();
                this.viewMatrix = Mat4.create();
                this.updateProjectionMatrix();
            }
            updateProjectionMatrix() {
                Mat4.perspective(
                    this.projectionMatrix,
                    (this.fov * Math.PI) / 180,
                    Math.max(0.01, this.aspect),
                    this.near,
                    this.far
                );
            }
            lookAt(x, y, z) {
                this.target = [x, y, z];
                Mat4.lookAt(
                    this.viewMatrix,
                    [this.position.x, this.position.y, this.position.z],
                    this.target,
                    [0, 1, 0]
                );
            }
            projectWorldToScreen(wx, wy, wz, viewportWidth, viewportHeight) {
                const vm = this.viewMatrix;
                const pm = this.projectionMatrix;

                const vx = vm[0] * wx + vm[4] * wy + vm[8] * wz + vm[12];
                const vy = vm[1] * wx + vm[5] * wy + vm[9] * wz + vm[13];
                const vz = vm[2] * wx + vm[6] * wy + vm[10] * wz + vm[14];
                const vw = vm[3] * wx + vm[7] * wy + vm[11] * wz + vm[15];

                const cx = pm[0] * vx + pm[4] * vy + pm[8] * vz + pm[12] * vw;
                const cy = pm[1] * vx + pm[5] * vy + pm[9] * vz + pm[13] * vw;
                const cz = pm[2] * vx + pm[6] * vy + pm[10] * vz + pm[14] * vw;
                const cw = pm[3] * vx + pm[7] * vy + pm[11] * vz + pm[15] * vw;

                if (cw <= 1e-6) {
                    return { x: -9999, y: -9999, ndcX: -99, ndcY: -99, ndcZ: 2, inFront: false };
                }

                const ndcX = cx / cw;
                const ndcY = cy / cw;
                const ndcZ = cz / cw;

                return {
                    x: (ndcX * 0.5 + 0.5) * viewportWidth,
                    y: (-ndcY * 0.5 + 0.5) * viewportHeight,
                    ndcX,
                    ndcY,
                    ndcZ,
                    inFront: ndcZ >= -1 && ndcZ <= 1
                };
            }
        }

        class CanvasTexture {
            constructor(canvas) {
                this.image = canvas;
                this._glTexture = null;
                this._gl = null;
                this.needsUpdate = true;
            }
            invalidateGpuHandle() {
                this._glTexture = null;
                this._gl = null;
                this.needsUpdate = true;
            }
            dispose() {
                if (this._gl && this._glTexture) {
                    try {
                        this._gl.deleteTexture(this._glTexture);
                    } catch (err) {
                        // Ignore on lost context
                    }
                }
                this._glTexture = null;
                this._gl = null;
            }
        }

        class BufferGeometry {
            constructor() {
                this.positions = new Float32Array(0);
                this.normals = new Float32Array(0);
                this.uvs = new Float32Array(0);
                this.indices = null;
                this.drawMode = 'TRIANGLES';
                this._buffers = null;
                this._gl = null;
            }
            setFromPoints(points) {
                const arr = new Float32Array(points.length * 3);
                for (let i = 0; i < points.length; i++) {
                    arr[i * 3] = points[i].x;
                    arr[i * 3 + 1] = points[i].y;
                    arr[i * 3 + 2] = points[i].z;
                }
                this.positions = arr;
                this.drawMode = 'LINE_STRIP';
                return this;
            }
            invalidateGpuHandle() {
                this._buffers = null;
                this._gl = null;
            }
            dispose() {
                if (this._gl && this._buffers) {
                    try {
                        if (this._buffers.pos) this._gl.deleteBuffer(this._buffers.pos);
                        if (this._buffers.norm) this._gl.deleteBuffer(this._buffers.norm);
                        if (this._buffers.uv) this._gl.deleteBuffer(this._buffers.uv);
                        if (this._buffers.idx) this._gl.deleteBuffer(this._buffers.idx);
                    } catch (err) {
                        // Ignore on lost context
                    }
                }
                this._buffers = null;
                this._gl = null;
            }
        }

        const PrimitiveGeometries = {
            createUnitBox() {
                const geo = new BufferGeometry();
                const p = [
                    -0.5, -0.5,  0.5,   0.5, -0.5,  0.5,   0.5,  0.5,  0.5,  -0.5,  0.5,  0.5,
                     0.5, -0.5, -0.5,  -0.5, -0.5, -0.5,  -0.5,  0.5, -0.5,   0.5,  0.5, -0.5,
                    -0.5,  0.5,  0.5,   0.5,  0.5,  0.5,   0.5,  0.5, -0.5,  -0.5,  0.5, -0.5,
                    -0.5, -0.5, -0.5,   0.5, -0.5, -0.5,   0.5, -0.5,  0.5,  -0.5, -0.5,  0.5,
                     0.5, -0.5,  0.5,   0.5, -0.5, -0.5,   0.5,  0.5, -0.5,   0.5,  0.5,  0.5,
                    -0.5, -0.5, -0.5,  -0.5, -0.5,  0.5,  -0.5,  0.5,  0.5,  -0.5,  0.5, -0.5
                ];
                const n = [
                     0,  0,  1,   0,  0,  1,   0,  0,  1,   0,  0,  1,
                     0,  0, -1,   0,  0, -1,   0,  0, -1,   0,  0, -1,
                     0,  1,  0,   0,  1,  0,   0,  1,  0,   0,  1,  0,
                     0, -1,  0,   0, -1,  0,   0, -1,  0,   0, -1,  0,
                     1,  0,  0,   1,  0,  0,   1,  0,  0,   1,  0,  0,
                    -1,  0,  0,  -1,  0,  0,  -1,  0,  0,  -1,  0,  0
                ];
                const idx = [];
                for (let f = 0; f < 6; f++) {
                    const o = f * 4;
                    idx.push(o, o + 1, o + 2, o, o + 2, o + 3);
                }
                geo.positions = new Float32Array(p);
                geo.normals = new Float32Array(n);
                geo.indices = new Uint16Array(idx);
                return geo;
            },

            createUnitCylinder(radialSegs = 8) {
                const geo = new BufferGeometry();
                const pos = [];
                const norm = [];
                const idx = [];

                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    const x = Math.cos(a) * 0.5;
                    const z = Math.sin(a) * 0.5;
                    const nx = Math.cos(a);
                    const nz = Math.sin(a);

                    pos.push(x, 0.5, z, x, -0.5, z);
                    norm.push(nx, 0, nz, nx, 0, nz);
                }
                for (let i = 0; i < radialSegs; i++) {
                    const o = i * 2;
                    idx.push(o, o + 1, o + 3, o, o + 3, o + 2);
                }

                const topCenter = pos.length / 3;
                pos.push(0, 0.5, 0);
                norm.push(0, 1, 0);
                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    pos.push(Math.cos(a) * 0.5, 0.5, Math.sin(a) * 0.5);
                    norm.push(0, 1, 0);
                }
                for (let i = 0; i < radialSegs; i++) {
                    idx.push(topCenter, topCenter + i + 2, topCenter + i + 1);
                }

                const botCenter = pos.length / 3;
                pos.push(0, -0.5, 0);
                norm.push(0, -1, 0);
                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    pos.push(Math.cos(a) * 0.5, -0.5, Math.sin(a) * 0.5);
                    norm.push(0, -1, 0);
                }
                for (let i = 0; i < radialSegs; i++) {
                    idx.push(botCenter, botCenter + i + 1, botCenter + i + 2);
                }

                geo.positions = new Float32Array(pos);
                geo.normals = new Float32Array(norm);
                geo.indices = new Uint16Array(idx);
                return geo;
            },

            createUnitFrustum(radialSegs = 10, topRatio = 0.68) {
                const geo = new BufferGeometry();
                const pos = [];
                const norm = [];
                const idx = [];
                const rTop = 0.5 * topRatio;
                const rBot = 0.5;
                const slope = rBot - rTop;
                const ny = slope / Math.hypot(1.0, slope);
                const nr = 1.0 / Math.hypot(1.0, slope);

                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    const ca = Math.cos(a);
                    const sa = Math.sin(a);

                    pos.push(ca * rTop, 0.5, sa * rTop, ca * rBot, -0.5, sa * rBot);
                    norm.push(ca * nr, ny, sa * nr, ca * nr, ny, sa * nr);
                }
                for (let i = 0; i < radialSegs; i++) {
                    const o = i * 2;
                    idx.push(o, o + 1, o + 3, o, o + 3, o + 2);
                }

                const topCenter = pos.length / 3;
                pos.push(0, 0.5, 0);
                norm.push(0, 1, 0);
                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    pos.push(Math.cos(a) * rTop, 0.5, Math.sin(a) * rTop);
                    norm.push(0, 1, 0);
                }
                for (let i = 0; i < radialSegs; i++) {
                    idx.push(topCenter, topCenter + i + 2, topCenter + i + 1);
                }

                const botCenter = pos.length / 3;
                pos.push(0, -0.5, 0);
                norm.push(0, -1, 0);
                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    pos.push(Math.cos(a) * rBot, -0.5, Math.sin(a) * rBot);
                    norm.push(0, -1, 0);
                }
                for (let i = 0; i < radialSegs; i++) {
                    idx.push(botCenter, botCenter + i + 1, botCenter + i + 2);
                }

                geo.positions = new Float32Array(pos);
                geo.normals = new Float32Array(norm);
                geo.indices = new Uint16Array(idx);
                return geo;
            },

            createUnitCone(radialSegs = 8) {
                const geo = new BufferGeometry();
                const pos = [];
                const norm = [];
                const idx = [];

                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    const x = Math.cos(a) * 0.5;
                    const z = Math.sin(a) * 0.5;
                    const ny = 0.4472;
                    const nr = 0.8944;
                    pos.push(0, 0.5, 0, x, -0.5, z);
                    norm.push(Math.cos(a) * nr, ny, Math.sin(a) * nr, Math.cos(a) * nr, ny, Math.sin(a) * nr);
                }
                for (let i = 0; i < radialSegs; i++) {
                    const o = i * 2;
                    idx.push(o, o + 3, o + 1);
                }

                const botCenter = pos.length / 3;
                pos.push(0, -0.5, 0);
                norm.push(0, -1, 0);
                for (let i = 0; i <= radialSegs; i++) {
                    const a = (i / radialSegs) * Math.PI * 2;
                    pos.push(Math.cos(a) * 0.5, -0.5, Math.sin(a) * 0.5);
                    norm.push(0, -1, 0);
                }
                for (let i = 0; i < radialSegs; i++) {
                    idx.push(botCenter, botCenter + i + 1, botCenter + i + 2);
                }

                geo.positions = new Float32Array(pos);
                geo.normals = new Float32Array(norm);
                geo.indices = new Uint16Array(idx);
                return geo;
            },

            createUnitSphere(latSegs = 6, lonSegs = 8) {
                const geo = new BufferGeometry();
                const pos = [];
                const norm = [];
                const idx = [];

                for (let lat = 0; lat <= latSegs; lat++) {
                    const theta = (lat / latSegs) * Math.PI;
                    const sinT = Math.sin(theta);
                    const cosT = Math.cos(theta);
                    for (let lon = 0; lon <= lonSegs; lon++) {
                        const phi = (lon / lonSegs) * Math.PI * 2;
                        const nx = sinT * Math.cos(phi);
                        const ny = cosT;
                        const nz = sinT * Math.sin(phi);
                        pos.push(nx * 0.5, ny * 0.5, nz * 0.5);
                        norm.push(nx, ny, nz);
                    }
                }

                const stride = lonSegs + 1;
                for (let lat = 0; lat < latSegs; lat++) {
                    for (let lon = 0; lon < lonSegs; lon++) {
                        const a = lat * stride + lon;
                        const b = a + stride;
                        idx.push(a, a + 1, b, a + 1, b + 1, b);
                    }
                }

                geo.positions = new Float32Array(pos);
                geo.normals = new Float32Array(norm);
                geo.indices = new Uint16Array(idx);
                return geo;
            },

            createUnitDome(latSegs = 5, lonSegs = 10) {
                const geo = new BufferGeometry();
                const pos = [];
                const norm = [];
                const idx = [];

                for (let lat = 0; lat <= latSegs; lat++) {
                    const theta = (lat / latSegs) * (Math.PI * 0.5);
                    const sinT = Math.sin(theta);
                    const cosT = Math.cos(theta);
                    for (let lon = 0; lon <= lonSegs; lon++) {
                        const phi = (lon / lonSegs) * Math.PI * 2;
                        const nx = sinT * Math.cos(phi);
                        const ny = cosT;
                        const nz = sinT * Math.sin(phi);
                        pos.push(nx * 0.5, ny * 0.5, nz * 0.5);
                        norm.push(nx, ny, nz);
                    }
                }

                const stride = lonSegs + 1;
                for (let lat = 0; lat < latSegs; lat++) {
                    for (let lon = 0; lon < lonSegs; lon++) {
                        const a = lat * stride + lon;
                        const b = a + stride;
                        idx.push(a, a + 1, b, a + 1, b + 1, b);
                    }
                }

                const botCenter = pos.length / 3;
                pos.push(0, 0, 0);
                norm.push(0, -1, 0);
                for (let lon = 0; lon <= lonSegs; lon++) {
                    const phi = (lon / lonSegs) * Math.PI * 2;
                    pos.push(Math.cos(phi) * 0.5, 0, Math.sin(phi) * 0.5);
                    norm.push(0, -1, 0);
                }
                for (let lon = 0; lon < lonSegs; lon++) {
                    idx.push(botCenter, botCenter + lon + 1, botCenter + lon + 2);
                }

                geo.positions = new Float32Array(pos);
                geo.normals = new Float32Array(norm);
                geo.indices = new Uint16Array(idx);
                return geo;
            }
        };

        class TerrainPlaneGeometry extends BufferGeometry {
            constructor(width, depth, segX, segZ, heightFn) {
                super();
                const cols = segX + 1;
                const rows = segZ + 1;
                const vertCount = cols * rows;

                const positions = new Float32Array(vertCount * 3);
                const normals = new Float32Array(vertCount * 3);
                const uvs = new Float32Array(vertCount * 2);

                const halfW = width * 0.5;
                const halfD = depth * 0.5;

                for (let r = 0; r < rows; r++) {
                    const v = r / segZ;
                    const z = -halfD + v * depth;
                    for (let c = 0; c < cols; c++) {
                        const u = c / segX;
                        const x = -halfW + u * width;
                        const y = typeof heightFn === 'function' ? heightFn(x, z) : 0;

                        const idx = r * cols + c;
                        positions[idx * 3] = x;
                        positions[idx * 3 + 1] = y;
                        positions[idx * 3 + 2] = z;

                        uvs[idx * 2] = u;
                        uvs[idx * 2 + 1] = v;
                    }
                }

                const stepX = width / segX;
                const stepZ = depth / segZ;
                for (let r = 0; r < rows; r++) {
                    for (let c = 0; c < cols; c++) {
                        const idx = r * cols + c;
                        const cL = Math.max(0, c - 1);
                        const cR = Math.min(cols - 1, c + 1);
                        const rU = Math.max(0, r - 1);
                        const rD = Math.min(rows - 1, r + 1);

                        const hL = positions[(r * cols + cL) * 3 + 1];
                        const hR = positions[(r * cols + cR) * 3 + 1];
                        const hU = positions[(rU * cols + c) * 3 + 1];
                        const hD = positions[(rD * cols + c) * 3 + 1];

                        const nx = (hL - hR) / ((cR - cL) * stepX || 1);
                        const ny = 1.0;
                        const nz = (hU - hD) / ((rD - rU) * stepZ || 1);
                        const len = Math.hypot(nx, ny, nz) || 1;

                        normals[idx * 3] = nx / len;
                        normals[idx * 3 + 1] = ny / len;
                        normals[idx * 3 + 2] = nz / len;
                    }
                }

                const indices = new Uint16Array(segX * segZ * 6);
                let ptr = 0;
                for (let r = 0; r < segZ; r++) {
                    for (let c = 0; c < segX; c++) {
                        const a = r * cols + c;
                        const b = a + 1;
                        const d = (r + 1) * cols + c;
                        const e = d + 1;
                        indices[ptr++] = a;
                        indices[ptr++] = d;
                        indices[ptr++] = b;
                        indices[ptr++] = b;
                        indices[ptr++] = d;
                        indices[ptr++] = e;
                    }
                }

                this.positions = positions;
                this.normals = normals;
                this.uvs = uvs;
                this.indices = indices;
                this.drawMode = 'TRIANGLES';
            }
        }

        class Material {
            constructor(opts = {}) {
                this.color = new Color(opts.color !== undefined ? opts.color : 0xffffff);
                this.map = opts.map || null;
                this.transparent = Boolean(opts.transparent);
                this.opacity = opts.opacity !== undefined ? opts.opacity : 1.0;
                this.isLine = Boolean(opts.isLine);
                this.metalness = opts.metalness || 0.0;
            }
            dispose() {
                if (this.map && typeof this.map.dispose === 'function') {
                    this.map.dispose();
                }
            }
        }

        class SceneNode {
            constructor() {
                this.children = [];
                this.position = {
                    x: 0,
                    y: 0,
                    z: 0,
                    set(x, y, z) {
                        this.x = x;
                        this.y = y;
                        this.z = z;
                    }
                };
                this.scale = {
                    x: 1,
                    y: 1,
                    z: 1,
                    set(x, y, z) {
                        this.x = x;
                        this.y = y;
                        this.z = z;
                    }
                };
                this.visible = true;
                this.modelMatrix = Mat4.create();
            }
            add(child) {
                if (child) this.children.push(child);
                return this;
            }
            updateMatrix() {
                Mat4.compose(this.modelMatrix, this.position, this.scale);
            }
        }

        class Mesh extends SceneNode {
            constructor(geometry, material) {
                super();
                this.geometry = geometry;
                this.material = material;
            }
        }

        class Line extends SceneNode {
            constructor(geometry, material) {
                super();
                this.geometry = geometry;
                this.material = material;
                this.material.isLine = true;
            }
        }

        const INSTANCE_STRIDE_FLOATS = 21; // 16 matrix + 4 rgba + 1 metalness = 84 bytes

        class InstancedBatchGroup extends SceneNode {
            constructor() {
                super();
                this.isInstancedBatchGroup = true;
                this.batches = [];
                this.totalInstances = 0;
            }

            setBatches(batchList) {
                this.clearBatches();
                this.batches = batchList;
                this.totalInstances = batchList.reduce((acc, b) => acc + b.count, 0);
            }

            invalidateGpuHandles() {
                if (!this.batches) return;
                for (let i = 0; i < this.batches.length; i++) {
                    this.batches[i]._gl = null;
                    this.batches[i]._glInstanceBuffer = null;
                    this.batches[i]._needsUpload = true;
                }
            }

            clearBatches() {
                if (this.batches) {
                    for (let i = 0; i < this.batches.length; i++) {
                        const b = this.batches[i];
                        if (b._gl && b._glInstanceBuffer) {
                            try {
                                b._gl.deleteBuffer(b._glInstanceBuffer);
                            } catch (err) {
                                // Ignore on lost context
                            }
                        }
                        b._gl = null;
                        b._glInstanceBuffer = null;
                    }
                }
                this.batches = [];
                this.totalInstances = 0;
            }

            dispose() {
                this.clearBatches();
            }
        }

        class Scene extends SceneNode {
            constructor() {
                super();
                this.background = new Color(BATTLEFIELD_VISUAL_CONFIG.atmosphere.skyColor);
                this.fog = new FogExp2(BATTLEFIELD_VISUAL_CONFIG.atmosphere.fogColor, BATTLEFIELD_VISUAL_CONFIG.atmosphere.fogDensity);
                this.hemiSkyColor = new Color(BATTLEFIELD_VISUAL_CONFIG.lighting.hemiSkyColor);
                this.hemiGroundColor = new Color(BATTLEFIELD_VISUAL_CONFIG.lighting.hemiGroundColor);
                this.sunColor = new Color(BATTLEFIELD_VISUAL_CONFIG.lighting.sunColor);
                this.sunDirection = [...BATTLEFIELD_VISUAL_CONFIG.lighting.sunDirection];
            }
        }

        class WebGLRenderer {
            constructor(options = {}) {
                this.domElement = document.createElement('canvas');
                this.pixelRatio = 1;
                this.width = 800;
                this.height = 600;
                this._contextLost = false;
                this._contextLossSource = 'none';
                this._pendingSimulatedLoss = false;
                this._intentionalContextLoss = false;
                this._disposed = false;
                this._restoreCount = 0;
                this._maxRestoreAttempts = 2;
                this.drawCallsLastFrame = 0;
                this.lastRenderMode = 'none';

                this.onContextLost = typeof options.onContextLost === 'function' ? options.onContextLost : null;
                this.onContextRestored = typeof options.onContextRestored === 'function' ? options.onContextRestored : null;

                const gl = options.gl ||
                    this.domElement.getContext('webgl', {
                        antialias: options.antialias !== false,
                        alpha: false,
                        powerPreference: options.powerPreference || 'high-performance'
                    }) ||
                    this.domElement.getContext('experimental-webgl');

                if (!gl) {
                    throw new Error('WebGL bağlamı (context) oluşturulamadı.');
                }

                if (typeof gl.isContextLost === 'function' && gl.isContextLost()) {
                    throw new Error('WebGL bağlamı (context) başlangıçta kayıp durumda.');
                }

                this.gl = gl;
                this.meshProg = null;
                this.instancedProg = null;
                this.lineProg = null;

                this._boundHandleContextLost = this._handleContextLost.bind(this);
                this._boundHandleContextRestored = this._handleContextRestored.bind(this);

                if (this.domElement && typeof this.domElement.addEventListener === 'function') {
                    this.domElement.addEventListener('webglcontextlost', this._boundHandleContextLost, false);
                    this.domElement.addEventListener('webglcontextrestored', this._boundHandleContextRestored, false);
                }

                try {
                    this.instancedExt = typeof gl.getExtension === 'function'
                        ? gl.getExtension('ANGLE_instanced_arrays')
                        : null;
                    this._initShaders();
                    gl.enable(gl.DEPTH_TEST);
                    gl.depthFunc(gl.LEQUAL);
                } catch (err) {
                    this.dispose();
                    throw err;
                }
            }

            isContextLost() {
                return Boolean(this._contextLost);
            }

            isInstancedSupported() {
                return Boolean(this.instancedExt);
            }

            _compileShader(type, src) {
                const gl = this.gl;
                const sh = gl.createShader(type);
                if (!sh) {
                    throw new Error('WebGL shader nesnesi oluşturulamadı.');
                }
                gl.shaderSource(sh, src);
                gl.compileShader(sh);
                if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
                    const info = (typeof gl.getShaderInfoLog === 'function' ? gl.getShaderInfoLog(sh) : '') || 'Bilinmeyen derleme hatası';
                    gl.deleteShader(sh);
                    throw new Error(`Shader derleme hatası: ${info}`);
                }
                return sh;
            }

            _createProgram(vsSrc, fsSrc) {
                const gl = this.gl;
                let vs = null;
                let fs = null;
                let prog = null;
                try {
                    vs = this._compileShader(gl.VERTEX_SHADER, vsSrc);
                    fs = this._compileShader(gl.FRAGMENT_SHADER, fsSrc);
                    prog = gl.createProgram();
                    if (!prog) {
                        throw new Error('WebGL shader programı oluşturulamadı.');
                    }
                    gl.attachShader(prog, vs);
                    gl.attachShader(prog, fs);
                    gl.linkProgram(prog);
                    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
                        const info = (typeof gl.getProgramInfoLog === 'function' ? gl.getProgramInfoLog(prog) : '') || 'Bilinmeyen link hatası';
                        throw new Error(`Shader program link hatası: ${info}`);
                    }
                    gl.deleteShader(vs);
                    gl.deleteShader(fs);
                    return prog;
                } catch (err) {
                    if (prog) {
                        try { gl.deleteProgram(prog); } catch (e) {}
                    }
                    if (vs) {
                        try { gl.deleteShader(vs); } catch (e) {}
                    }
                    if (fs) {
                        try { gl.deleteShader(fs); } catch (e) {}
                    }
                    throw err;
                }
            }

            _cleanupPrograms() {
                const gl = this.gl;
                if (!gl) return;
                if (this.meshProg) {
                    try { gl.deleteProgram(this.meshProg); } catch (e) {}
                    this.meshProg = null;
                }
                if (this.instancedProg) {
                    try { gl.deleteProgram(this.instancedProg); } catch (e) {}
                    this.instancedProg = null;
                }
                if (this.lineProg) {
                    try { gl.deleteProgram(this.lineProg); } catch (e) {}
                    this.lineProg = null;
                }
            }

            _initShaders() {
                const meshVS = `
                    attribute vec3 aPosition;
                    attribute vec3 aNormal;
                    attribute vec2 aUv;
                    uniform mat4 uModelMatrix;
                    uniform mat4 uViewMatrix;
                    uniform mat4 uProjectionMatrix;
                    varying vec2 vUv;
                    varying vec3 vNormal;
                    varying float vFogDepth;
                    void main() {
                        vec4 worldPos = uModelMatrix * vec4(aPosition, 1.0);
                        vec4 viewPos = uViewMatrix * worldPos;
                        vUv = aUv;
                        vNormal = normalize(mat3(uModelMatrix) * aNormal);
                        vFogDepth = length(viewPos.xyz);
                        gl_Position = uProjectionMatrix * viewPos;
                    }
                `;

                const meshFS = `
                    precision mediump float;
                    varying vec2 vUv;
                    varying vec3 vNormal;
                    varying float vFogDepth;
                    uniform sampler2D uMap;
                    uniform int uHasMap;
                    uniform vec3 uBaseColor;
                    uniform float uOpacity;
                    uniform float uMetalness;
                    uniform vec3 uHemiSky;
                    uniform vec3 uHemiGround;
                    uniform vec3 uSunColor;
                    uniform vec3 uSunDir;
                    uniform vec3 uFogColor;
                    uniform float uFogDensity;
                    void main() {
                        vec3 texColor = uHasMap == 1 ? texture2D(uMap, vUv).rgb : vec3(1.0);
                        vec3 albedo = texColor * uBaseColor;
                        vec3 n = normalize(vNormal);
                        float hemiBlend = n.y * 0.5 + 0.5;
                        vec3 ambient = mix(uHemiGround, uHemiSky, hemiBlend) * 0.74;
                        float sunDot = max(dot(n, normalize(uSunDir)), 0.0);
                        vec3 diffuse = uSunColor * sunDot * (0.85 + uMetalness * 0.25);
                        vec3 lit = albedo * (ambient + diffuse);
                        float fogFactor = 1.0 - exp(-(uFogDensity * vFogDepth) * (uFogDensity * vFogDepth));
                        fogFactor = clamp(fogFactor, 0.0, 1.0);
                        gl_FragColor = vec4(mix(lit, uFogColor, fogFactor), uOpacity);
                    }
                `;

                const instancedVS = `
                    attribute vec3 aPosition;
                    attribute vec3 aNormal;
                    attribute vec4 aInstCol0;
                    attribute vec4 aInstCol1;
                    attribute vec4 aInstCol2;
                    attribute vec4 aInstCol3;
                    attribute vec4 aInstColor;
                    attribute float aInstMetalness;
                    uniform mat4 uViewMatrix;
                    uniform mat4 uProjectionMatrix;
                    varying vec3 vNormal;
                    varying float vFogDepth;
                    varying vec4 vInstColor;
                    varying float vInstMetalness;
                    varying vec3 vViewDir;
                    void main() {
                        mat4 instanceMat = mat4(aInstCol0, aInstCol1, aInstCol2, aInstCol3);
                        vec4 worldPos = instanceMat * vec4(aPosition, 1.0);
                        vec4 viewPos = uViewMatrix * worldPos;
                        vNormal = normalize(mat3(instanceMat) * aNormal);
                        vFogDepth = length(viewPos.xyz);
                        vViewDir = -viewPos.xyz;
                        vInstColor = aInstColor;
                        vInstMetalness = aInstMetalness;
                        gl_Position = uProjectionMatrix * viewPos;
                    }
                `;

                const instancedFS = `
                    precision mediump float;
                    varying vec3 vNormal;
                    varying float vFogDepth;
                    varying vec4 vInstColor;
                    varying float vInstMetalness;
                    varying vec3 vViewDir;
                    uniform vec3 uHemiSky;
                    uniform vec3 uHemiGround;
                    uniform vec3 uSunColor;
                    uniform vec3 uSunDir;
                    uniform vec3 uFogColor;
                    uniform float uFogDensity;
                    void main() {
                        vec3 albedo = vInstColor.rgb;
                        vec3 n = normalize(vNormal);
                        vec3 vDir = normalize(vViewDir);
                        vec3 sDir = normalize(uSunDir);
                        float hemiBlend = n.y * 0.5 + 0.5;
                        vec3 ambient = mix(uHemiGround, uHemiSky, hemiBlend) * 0.74;
                        float sunDot = max(dot(n, sDir), 0.0);
                        vec3 diffuse = uSunColor * sunDot * (0.88 + vInstMetalness * 0.28);

                        // High-quality metallic specular highlight (AoE III: DE shader)
                        vec3 halfDir = normalize(sDir + vDir);
                        float specDot = max(dot(n, halfDir), 0.0);
                        float specPower = 16.0 + 48.0 * vInstMetalness;
                        float specIntensity = pow(specDot, specPower) * vInstMetalness;
                        vec3 specular = uSunColor * (specIntensity * 0.75);

                        // Subtle edge rim lighting for distant soldier & horse silhouette readability
                        float rimDot = 1.0 - max(dot(n, vDir), 0.0);
                        float rimFactor = pow(rimDot, 3.2) * 0.32;
                        vec3 rimLight = mix(uHemiSky, vec3(1.0), 0.40) * (rimFactor * (0.75 + 0.35 * vInstMetalness));

                        vec3 lit = albedo * (ambient + diffuse) + specular + rimLight;
                        float fogFactor = 1.0 - exp(-(uFogDensity * vFogDepth) * (uFogDensity * vFogDepth));
                        fogFactor = clamp(fogFactor, 0.0, 1.0);
                        gl_FragColor = vec4(mix(lit, uFogColor, fogFactor), vInstColor.a);
                    }
                `;

                const lineVS = `
                    attribute vec3 aPosition;
                    uniform mat4 uModelMatrix;
                    uniform mat4 uViewMatrix;
                    uniform mat4 uProjectionMatrix;
                    varying float vFogDepth;
                    void main() {
                        vec4 viewPos = uViewMatrix * uModelMatrix * vec4(aPosition, 1.0);
                        vFogDepth = length(viewPos.xyz);
                        gl_Position = uProjectionMatrix * viewPos;
                    }
                `;

                const lineFS = `
                    precision mediump float;
                    varying float vFogDepth;
                    uniform vec3 uColor;
                    uniform float uOpacity;
                    uniform vec3 uFogColor;
                    uniform float uFogDensity;
                    void main() {
                        float fogFactor = 1.0 - exp(-(uFogDensity * vFogDepth) * (uFogDensity * vFogDepth));
                        fogFactor = clamp(fogFactor, 0.0, 1.0);
                        vec3 col = mix(uColor, uFogColor, fogFactor);
                        gl_FragColor = vec4(col, uOpacity * (1.0 - fogFactor * 0.7));
                    }
                `;

                try {
                    this.meshProg = this._createProgram(meshVS, meshFS);
                    this.instancedProg = this._createProgram(instancedVS, instancedFS);
                    this.lineProg = this._createProgram(lineVS, lineFS);
                } catch (err) {
                    this._cleanupPrograms();
                    throw err;
                }
            }

            _handleContextLost(event) {
                if (this._disposed || this._intentionalContextLoss) return;
                if (event && typeof event.preventDefault === 'function') {
                    event.preventDefault();
                }
                if (this._contextLost && this._contextLossSource === 'hardware') {
                    return;
                }

                const isSimulated = Boolean(this._pendingSimulatedLoss);
                this._pendingSimulatedLoss = false;
                this._contextLost = true;
                this._contextLossSource = isSimulated ? 'simulated' : 'hardware';

                this.meshProg = null;
                this.instancedProg = null;
                this.lineProg = null;
                this.instancedExt = null;

                if (this.onContextLost) {
                    const msg = isSimulated
                        ? 'Simüle edilmiş WebGL context kaybı tetiklendi.'
                        : 'WebGL bağlamı (context) kayboldu.';
                    this.onContextLost(msg, {
                        simulated: isSimulated,
                        source: this._contextLossSource
                    });
                }
            }

            _handleContextRestored() {
                if (this._disposed || this._intentionalContextLoss || !this._contextLost) {
                    return false;
                }
                if (this._restoreCount >= this._maxRestoreAttempts) {
                    if (this.onContextLost) {
                        this.onContextLost(
                            'WebGL bağlamı tekrarlı kayıp nedeniyle otomatik kurtarma sınırına ulaştı.',
                            { simulated: this._contextLossSource === 'simulated', source: this._contextLossSource }
                        );
                    }
                    return false;
                }

                this._restoreCount++;
                try {
                    const gl = this.gl;
                    if (!gl) {
                        throw new Error('WebGL bağlamı bulunamadı.');
                    }
                    if (typeof gl.isContextLost === 'function' && gl.isContextLost()) {
                        throw new Error('WebGL bağlamı hâlâ kayıp durumda.');
                    }

                    this._cleanupPrograms();
                    this.instancedExt = typeof gl.getExtension === 'function'
                        ? gl.getExtension('ANGLE_instanced_arrays')
                        : null;
                    this._initShaders();
                    gl.enable(gl.DEPTH_TEST);
                    gl.depthFunc(gl.LEQUAL);
                    gl.viewport(0, 0, this.domElement.width, this.domElement.height);

                    this._contextLost = false;
                    this._contextLossSource = 'none';

                    if (this.onContextRestored) {
                        this.onContextRestored();
                    }
                    return true;
                } catch (err) {
                    this._cleanupPrograms();
                    this._contextLost = true;
                    if (this.onContextLost) {
                        this.onContextLost(
                            `WebGL bağlamı geri yüklenemedi: ${err.message}`,
                            { simulated: this._contextLossSource === 'simulated', source: this._contextLossSource }
                        );
                    }
                    return false;
                }
            }

            simulateContextLoss() {
                if (this._disposed || this._contextLost || !this.gl) {
                    return null;
                }

                if (typeof this.gl.getExtension === 'function') {
                    const ext = this.gl.getExtension('WEBGL_lose_context');
                    if (ext && typeof ext.loseContext === 'function') {
                        this._pendingSimulatedLoss = true;
                        ext.loseContext();
                        if (!this._contextLost) {
                            this._handleContextLost(null);
                        }
                        return { simulated: true, usedExtension: true, source: this._contextLossSource };
                    }
                }

                this._cleanupPrograms();
                this.instancedExt = null;
                this._contextLost = true;
                this._contextLossSource = 'simulated';

                if (this.onContextLost) {
                    this.onContextLost(
                        'Simüle edilmiş WebGL context kaybı tetiklendi (WEBGL_lose_context uzantısı yok).',
                        { simulated: true, source: 'simulated' }
                    );
                }
                return { simulated: true, usedExtension: false, source: 'simulated' };
            }

            setPixelRatio(ratio) {
                this.pixelRatio = Math.max(1, ratio || 1);
                this.setSize(this.width, this.height);
            }

            setSize(width, height) {
                this.width = Math.max(1, Math.floor(width));
                this.height = Math.max(1, Math.floor(height));
                this.domElement.width = Math.floor(this.width * this.pixelRatio);
                this.domElement.height = Math.floor(this.height * this.pixelRatio);
                if (this.gl && !this._contextLost && !this._disposed) {
                    this.gl.viewport(0, 0, this.domElement.width, this.domElement.height);
                }
            }

            _ensureGeometryBuffers(geo) {
                if (geo._buffers && geo._gl === this.gl) return geo._buffers;
                const gl = this.gl;
                geo._gl = gl;

                const pos = gl.createBuffer();
                gl.bindBuffer(gl.ARRAY_BUFFER, pos);
                gl.bufferData(gl.ARRAY_BUFFER, geo.positions, gl.STATIC_DRAW);

                let norm = null;
                if (geo.normals && geo.normals.length > 0) {
                    norm = gl.createBuffer();
                    gl.bindBuffer(gl.ARRAY_BUFFER, norm);
                    gl.bufferData(gl.ARRAY_BUFFER, geo.normals, gl.STATIC_DRAW);
                }

                let uv = null;
                if (geo.uvs && geo.uvs.length > 0) {
                    uv = gl.createBuffer();
                    gl.bindBuffer(gl.ARRAY_BUFFER, uv);
                    gl.bufferData(gl.ARRAY_BUFFER, geo.uvs, gl.STATIC_DRAW);
                }

                let idx = null;
                if (geo.indices) {
                    idx = gl.createBuffer();
                    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idx);
                    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, geo.indices, gl.STATIC_DRAW);
                }

                geo._buffers = { pos, norm, uv, idx };
                return geo._buffers;
            }

            _ensureTexture(tex) {
                const gl = this.gl;
                if (!tex._glTexture || tex._gl !== gl) {
                    tex._gl = gl;
                    tex._glTexture = gl.createTexture();
                    tex.needsUpdate = true;
                }
                if (tex.needsUpdate && tex.image) {
                    gl.bindTexture(gl.TEXTURE_2D, tex._glTexture);
                    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, tex.image);
                    gl.generateMipmap(gl.TEXTURE_2D);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
                    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
                    tex.needsUpdate = false;
                }
                return tex._glTexture;
            }

            _renderInstancedBatches(batchGroup, scene, camera) {
                const gl = this.gl;
                const ext = this.instancedExt;
                if (!batchGroup.batches || batchGroup.batches.length === 0) return;

                if (ext && this.instancedProg) {
                    this.lastRenderMode = 'instanced';
                    gl.useProgram(this.instancedProg);
                    gl.uniformMatrix4fv(gl.getUniformLocation(this.instancedProg, 'uViewMatrix'), false, camera.viewMatrix);
                    gl.uniformMatrix4fv(gl.getUniformLocation(this.instancedProg, 'uProjectionMatrix'), false, camera.projectionMatrix);
                    gl.uniform3f(gl.getUniformLocation(this.instancedProg, 'uHemiSky'), scene.hemiSkyColor.r, scene.hemiSkyColor.g, scene.hemiSkyColor.b);
                    gl.uniform3f(gl.getUniformLocation(this.instancedProg, 'uHemiGround'), scene.hemiGroundColor.r, scene.hemiGroundColor.g, scene.hemiGroundColor.b);
                    gl.uniform3f(gl.getUniformLocation(this.instancedProg, 'uSunColor'), scene.sunColor.r, scene.sunColor.g, scene.sunColor.b);
                    gl.uniform3fv(gl.getUniformLocation(this.instancedProg, 'uSunDir'), scene.sunDirection);
                    gl.uniform3f(gl.getUniformLocation(this.instancedProg, 'uFogColor'), scene.fog.color.r, scene.fog.color.g, scene.fog.color.b);
                    gl.uniform1f(gl.getUniformLocation(this.instancedProg, 'uFogDensity'), scene.fog.density);

                    const aPos = gl.getAttribLocation(this.instancedProg, 'aPosition');
                    const aNorm = gl.getAttribLocation(this.instancedProg, 'aNormal');
                    const colLocs = [
                        gl.getAttribLocation(this.instancedProg, 'aInstCol0'),
                        gl.getAttribLocation(this.instancedProg, 'aInstCol1'),
                        gl.getAttribLocation(this.instancedProg, 'aInstCol2'),
                        gl.getAttribLocation(this.instancedProg, 'aInstCol3')
                    ];
                    const aInstColor = gl.getAttribLocation(this.instancedProg, 'aInstColor');
                    const aInstMetal = gl.getAttribLocation(this.instancedProg, 'aInstMetalness');

                    for (let i = 0; i < batchGroup.batches.length; i++) {
                        const batch = batchGroup.batches[i];
                        if (!batch) continue;

                        const buffers = this._ensureGeometryBuffers(batch.geometry);

                        if (!batch._glInstanceBuffer || batch._gl !== gl) {
                            batch._gl = gl;
                            batch._glInstanceBuffer = gl.createBuffer();
                            gl.bindBuffer(gl.ARRAY_BUFFER, batch._glInstanceBuffer);
                            gl.bufferData(gl.ARRAY_BUFFER, batch.instanceData, gl.DYNAMIC_DRAW);
                            batch._needsUpload = false;
                        } else if (batch._needsUpload && typeof gl.bufferSubData === 'function') {
                            gl.bindBuffer(gl.ARRAY_BUFFER, batch._glInstanceBuffer);
                            gl.bufferSubData(gl.ARRAY_BUFFER, 0, batch.instanceData);
                            batch._needsUpload = false;
                        }

                        if (batch.count <= 0) continue;

                        if (batch.transparent) {
                            gl.enable(gl.BLEND);
                            gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
                            gl.depthMask(false);
                        }

                        if (aPos >= 0) {
                            gl.bindBuffer(gl.ARRAY_BUFFER, buffers.pos);
                            gl.enableVertexAttribArray(aPos);
                            gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
                        }

                        if (buffers.norm && aNorm >= 0) {
                            gl.bindBuffer(gl.ARRAY_BUFFER, buffers.norm);
                            gl.enableVertexAttribArray(aNorm);
                            gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);
                        }

                        gl.bindBuffer(gl.ARRAY_BUFFER, batch._glInstanceBuffer);
                        const stride = INSTANCE_STRIDE_FLOATS * 4;
                        for (let c = 0; c < 4; c++) {
                            if (colLocs[c] >= 0) {
                                gl.enableVertexAttribArray(colLocs[c]);
                                gl.vertexAttribPointer(colLocs[c], 4, gl.FLOAT, false, stride, c * 16);
                                ext.vertexAttribDivisorANGLE(colLocs[c], 1);
                            }
                        }

                        if (aInstColor >= 0) {
                            gl.enableVertexAttribArray(aInstColor);
                            gl.vertexAttribPointer(aInstColor, 4, gl.FLOAT, false, stride, 64);
                            ext.vertexAttribDivisorANGLE(aInstColor, 1);
                        }

                        if (aInstMetal >= 0) {
                            gl.enableVertexAttribArray(aInstMetal);
                            gl.vertexAttribPointer(aInstMetal, 1, gl.FLOAT, false, stride, 80);
                            ext.vertexAttribDivisorANGLE(aInstMetal, 1);
                        }

                        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.idx);
                        ext.drawElementsInstancedANGLE(gl.TRIANGLES, batch.geometry.indices.length, gl.UNSIGNED_SHORT, 0, batch.count);
                        this.drawCallsLastFrame++;

                        for (let c = 0; c < 4; c++) {
                            if (colLocs[c] >= 0) {
                                ext.vertexAttribDivisorANGLE(colLocs[c], 0);
                                gl.disableVertexAttribArray(colLocs[c]);
                            }
                        }
                        if (aInstColor >= 0) {
                            ext.vertexAttribDivisorANGLE(aInstColor, 0);
                            gl.disableVertexAttribArray(aInstColor);
                        }
                        if (aInstMetal >= 0) {
                            ext.vertexAttribDivisorANGLE(aInstMetal, 0);
                            gl.disableVertexAttribArray(aInstMetal);
                        }

                        if (batch.transparent) {
                            gl.depthMask(true);
                            gl.disable(gl.BLEND);
                        }
                    }
                } else if (this.meshProg) {
                    this.lastRenderMode = 'fallback_non_instanced';
                    gl.useProgram(this.meshProg);
                    gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProg, 'uViewMatrix'), false, camera.viewMatrix);
                    gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProg, 'uProjectionMatrix'), false, camera.projectionMatrix);
                    gl.uniform1i(gl.getUniformLocation(this.meshProg, 'uHasMap'), 0);
                    gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uHemiSky'), scene.hemiSkyColor.r, scene.hemiSkyColor.g, scene.hemiSkyColor.b);
                    gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uHemiGround'), scene.hemiGroundColor.r, scene.hemiGroundColor.g, scene.hemiGroundColor.b);
                    gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uSunColor'), scene.sunColor.r, scene.sunColor.g, scene.sunColor.b);
                    gl.uniform3fv(gl.getUniformLocation(this.meshProg, 'uSunDir'), scene.sunDirection);
                    gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uFogColor'), scene.fog.color.r, scene.fog.color.g, scene.fog.color.b);
                    gl.uniform1f(gl.getUniformLocation(this.meshProg, 'uFogDensity'), scene.fog.density);

                    const aPos = gl.getAttribLocation(this.meshProg, 'aPosition');
                    const aNorm = gl.getAttribLocation(this.meshProg, 'aNormal');
                    const uModel = gl.getUniformLocation(this.meshProg, 'uModelMatrix');
                    const uBaseColor = gl.getUniformLocation(this.meshProg, 'uBaseColor');
                    const uOpacity = gl.getUniformLocation(this.meshProg, 'uOpacity');
                    const uMetalness = gl.getUniformLocation(this.meshProg, 'uMetalness');

                    for (let i = 0; i < batchGroup.batches.length; i++) {
                        const batch = batchGroup.batches[i];
                        if (!batch || batch.count <= 0) continue;

                        if (batch.transparent) {
                            gl.enable(gl.BLEND);
                            gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
                            gl.depthMask(false);
                        }

                        const buffers = this._ensureGeometryBuffers(batch.geometry);
                        if (aPos >= 0) {
                            gl.bindBuffer(gl.ARRAY_BUFFER, buffers.pos);
                            gl.enableVertexAttribArray(aPos);
                            gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
                        }
                        if (buffers.norm && aNorm >= 0) {
                            gl.bindBuffer(gl.ARRAY_BUFFER, buffers.norm);
                            gl.enableVertexAttribArray(aNorm);
                            gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);
                        }
                        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.idx);

                        for (let m = 0; m < batch.count; m++) {
                            const base = m * INSTANCE_STRIDE_FLOATS;
                            const subMat = batch.instanceData.subarray(base, base + 16);
                            gl.uniformMatrix4fv(uModel, false, subMat);
                            gl.uniform3f(
                                uBaseColor,
                                batch.instanceData[base + 16],
                                batch.instanceData[base + 17],
                                batch.instanceData[base + 18]
                            );
                            gl.uniform1f(uOpacity, batch.instanceData[base + 19]);
                            gl.uniform1f(uMetalness, batch.instanceData[base + 20]);
                            gl.drawElements(gl.TRIANGLES, batch.geometry.indices.length, gl.UNSIGNED_SHORT, 0);
                            this.drawCallsLastFrame++;
                        }

                        if (batch.transparent) {
                            gl.depthMask(true);
                            gl.disable(gl.BLEND);
                        }
                    }
                }
            }

            render(scene, camera) {
                const gl = this.gl;
                if (!gl || this._contextLost || this._disposed) return;
                if (typeof gl.isContextLost === 'function' && gl.isContextLost()) {
                    this._handleContextLost(null);
                    return;
                }
                if (!this.meshProg || !this.lineProg) return;

                this.drawCallsLastFrame = 0;
                this.lastRenderMode = this.instancedExt ? 'instanced' : 'fallback_non_instanced';

                const bg = scene.background;
                gl.clearColor(bg.r, bg.g, bg.b, 1.0);
                gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

                const renderNode = (node) => {
                    if (!node.visible) return;
                    node.updateMatrix();

                    if (node.isInstancedBatchGroup) {
                        this._renderInstancedBatches(node, scene, camera);
                        return;
                    }

                    if (node.geometry && node.material) {
                        const buffers = this._ensureGeometryBuffers(node.geometry);
                        const mat = node.material;

                        if (mat.isLine) {
                            gl.useProgram(this.lineProg);
                            gl.enable(gl.BLEND);
                            gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

                            const aPos = gl.getAttribLocation(this.lineProg, 'aPosition');
                            if (aPos >= 0) {
                                gl.bindBuffer(gl.ARRAY_BUFFER, buffers.pos);
                                gl.enableVertexAttribArray(aPos);
                                gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
                            }

                            gl.uniformMatrix4fv(gl.getUniformLocation(this.lineProg, 'uModelMatrix'), false, node.modelMatrix);
                            gl.uniformMatrix4fv(gl.getUniformLocation(this.lineProg, 'uViewMatrix'), false, camera.viewMatrix);
                            gl.uniformMatrix4fv(gl.getUniformLocation(this.lineProg, 'uProjectionMatrix'), false, camera.projectionMatrix);
                            gl.uniform3f(gl.getUniformLocation(this.lineProg, 'uColor'), mat.color.r, mat.color.g, mat.color.b);
                            gl.uniform1f(gl.getUniformLocation(this.lineProg, 'uOpacity'), mat.opacity);
                            gl.uniform3f(gl.getUniformLocation(this.lineProg, 'uFogColor'), scene.fog.color.r, scene.fog.color.g, scene.fog.color.b);
                            gl.uniform1f(gl.getUniformLocation(this.lineProg, 'uFogDensity'), scene.fog.density);

                            const mode = node.geometry.drawMode === 'LINES' ? gl.LINES : gl.LINE_STRIP;
                            gl.drawArrays(mode, 0, node.geometry.positions.length / 3);
                            this.drawCallsLastFrame++;
                            gl.disable(gl.BLEND);
                        } else {
                            gl.useProgram(this.meshProg);

                            const aPos = gl.getAttribLocation(this.meshProg, 'aPosition');
                            if (aPos >= 0) {
                                gl.bindBuffer(gl.ARRAY_BUFFER, buffers.pos);
                                gl.enableVertexAttribArray(aPos);
                                gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
                            }

                            const aNorm = gl.getAttribLocation(this.meshProg, 'aNormal');
                            if (buffers.norm && aNorm >= 0) {
                                gl.bindBuffer(gl.ARRAY_BUFFER, buffers.norm);
                                gl.enableVertexAttribArray(aNorm);
                                gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);
                            }

                            const aUv = gl.getAttribLocation(this.meshProg, 'aUv');
                            if (buffers.uv && aUv >= 0) {
                                gl.bindBuffer(gl.ARRAY_BUFFER, buffers.uv);
                                gl.enableVertexAttribArray(aUv);
                                gl.vertexAttribPointer(aUv, 2, gl.FLOAT, false, 0, 0);
                            }

                            gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProg, 'uModelMatrix'), false, node.modelMatrix);
                            gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProg, 'uViewMatrix'), false, camera.viewMatrix);
                            gl.uniformMatrix4fv(gl.getUniformLocation(this.meshProg, 'uProjectionMatrix'), false, camera.projectionMatrix);

                            if (mat.map) {
                                const glTex = this._ensureTexture(mat.map);
                                gl.activeTexture(gl.TEXTURE0);
                                gl.bindTexture(gl.TEXTURE_2D, glTex);
                                gl.uniform1i(gl.getUniformLocation(this.meshProg, 'uMap'), 0);
                                gl.uniform1i(gl.getUniformLocation(this.meshProg, 'uHasMap'), 1);
                            } else {
                                gl.uniform1i(gl.getUniformLocation(this.meshProg, 'uHasMap'), 0);
                            }

                            gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uBaseColor'), mat.color.r, mat.color.g, mat.color.b);
                            gl.uniform1f(gl.getUniformLocation(this.meshProg, 'uOpacity'), mat.opacity);
                            gl.uniform1f(gl.getUniformLocation(this.meshProg, 'uMetalness'), mat.metalness || 0.0);
                            gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uHemiSky'), scene.hemiSkyColor.r, scene.hemiSkyColor.g, scene.hemiSkyColor.b);
                            gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uHemiGround'), scene.hemiGroundColor.r, scene.hemiGroundColor.g, scene.hemiGroundColor.b);
                            gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uSunColor'), scene.sunColor.r, scene.sunColor.g, scene.sunColor.b);
                            gl.uniform3fv(gl.getUniformLocation(this.meshProg, 'uSunDir'), scene.sunDirection);
                            gl.uniform3f(gl.getUniformLocation(this.meshProg, 'uFogColor'), scene.fog.color.r, scene.fog.color.g, scene.fog.color.b);
                            gl.uniform1f(gl.getUniformLocation(this.meshProg, 'uFogDensity'), scene.fog.density);

                            if (buffers.idx) {
                                gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.idx);
                                gl.drawElements(gl.TRIANGLES, node.geometry.indices.length, gl.UNSIGNED_SHORT, 0);
                            } else {
                                gl.drawArrays(gl.TRIANGLES, 0, node.geometry.positions.length / 3);
                            }
                            this.drawCallsLastFrame++;
                        }
                    }

                    for (let i = 0; i < node.children.length; i++) {
                        renderNode(node.children[i]);
                    }
                };

                renderNode(scene);
                this._restoreCount = 0;
            }

            forceContextLoss() {
                if (this.gl && !this._contextLost && typeof this.gl.getExtension === 'function') {
                    const ext = this.gl.getExtension('WEBGL_lose_context');
                    if (ext && typeof ext.loseContext === 'function') {
                        ext.loseContext();
                        return true;
                    }
                }
                return false;
            }

            dispose() {
                if (this._disposed) return;
                this._disposed = true;
                this._intentionalContextLoss = true;
                this._contextLost = false;
                this._contextLossSource = 'none';

                if (this.domElement && typeof this.domElement.removeEventListener === 'function') {
                    this.domElement.removeEventListener('webglcontextlost', this._boundHandleContextLost, false);
                    this.domElement.removeEventListener('webglcontextrestored', this._boundHandleContextRestored, false);
                }

                this._cleanupPrograms();
                this.instancedExt = null;
                this.onContextLost = null;
                this.onContextRestored = null;
            }
        }

        const FOC_THREE = {
            Mat4,
            Color,
            FogExp2,
            PerspectiveCamera,
            CanvasTexture,
            BufferGeometry,
            PrimitiveGeometries,
            TerrainPlaneGeometry,
            Material,
            SceneNode,
            Mesh,
            Line,
            InstancedBatchGroup,
            Scene,
            WebGLRenderer
        };

        /* ============================================================================
         * 2. PREVIEW BATTLE SECTOR DATA (PRESERVED UNCHANGED) & G3D-01 ADAPTER
         * ============================================================================ */
        class SoldierInstance {
            constructor(config) {
                this.id = config.id;
                this.groupId = config.groupId;
                this.side = config.side;
                this.sectorIndex = config.sectorIndex !== undefined ? config.sectorIndex : 0;
                this.unitClass = config.unitClass || 'pikeman';
                this.combatRole = config.combatRole || 'melee';
                this.bodyType = config.bodyType || 'human';
                this.mountType = config.mountType || 'foot';
                this.activeWeapon = config.activeWeapon || 'pike';
                this.weaponLoadout = Array.isArray(config.weaponLoadout) ? [...config.weaponLoadout] : [this.activeWeapon];
                this.armorLoadout = Array.isArray(config.armorLoadout) ? [...config.armorLoadout] : ['cuirass'];
                this.state = config.state || 'idle';
                this.hp = config.hp !== undefined ? config.hp : 100;
                this.maxHp = config.maxHp !== undefined ? config.maxHp : 100;
                this.alive = this.hp > 0 && config.alive !== false;
                this.position = {
                    x: config.position && Number.isFinite(config.position.x) ? config.position.x : 0,
                    y: config.position && Number.isFinite(config.position.y) ? config.position.y : 0,
                    z: config.position && Number.isFinite(config.position.z) ? config.position.z : 0
                };
            }
        }

        class FormationController {
            static computeSlotOffset(index, totalCount, formationType = 'line', spacing = 2.0) {
                const cols = formationType === 'box'
                    ? Math.max(2, Math.ceil(Math.sqrt(totalCount)))
                    : Math.min(10, Math.max(1, totalCount));
                const row = Math.floor(index / cols);
                const col = index % cols;
                const rowCols = Math.min(cols, totalCount - row * cols);
                const spread = formationType === 'spread' ? spacing * 1.45 : spacing;
                return {
                    dx: (col - (rowCols - 1) * 0.5) * spread,
                    dz: row * spread
                };
            }
        }

        class UnitGroup {
            constructor(config) {
                this.id = config.id;
                this.name = config.name || config.id;
                this.side = config.side;
                this.sectorIndex = config.sectorIndex !== undefined ? config.sectorIndex : 0;
                this.unitClass = config.unitClass || 'pikeman';
                this.formation = config.formation || 'line';
                this.anchor = {
                    x: config.anchor ? config.anchor.x : 0,
                    z: config.anchor ? config.anchor.z : 0
                };
                this.soldiers = [];

                const count = config.count || 0;
                const dirSign = this.side === 'player' ? -1 : 1;
                for (let i = 0; i < count; i++) {
                    const offset = FormationController.computeSlotOffset(i, count, this.formation, 1.95);
                    this.soldiers.push(new SoldierInstance({
                        id: `${this.id}_s${i + 1}`,
                        groupId: this.id,
                        side: this.side,
                        sectorIndex: this.sectorIndex,
                        unitClass: this.unitClass,
                        combatRole: config.combatRole || 'melee',
                        bodyType: config.bodyType || 'human',
                        mountType: config.mountType || 'foot',
                        activeWeapon: config.activeWeapon || 'pike',
                        weaponLoadout: config.weaponLoadout || ['pike', 'sword'],
                        armorLoadout: config.armorLoadout || ['buff_coat', 'cuirass'],
                        state: 'ready',
                        hp: config.maxHp || 100,
                        maxHp: config.maxHp || 100,
                        position: {
                            x: Math.round((this.anchor.x + dirSign * offset.dz) * 100) / 100,
                            y: 0,
                            z: Math.round((this.anchor.z + offset.dx) * 100) / 100
                        }
                    }));
                }
            }
        }

        class SectorState {
            constructor(index, sectorId, label) {
                this.index = index;
                this.sectorId = sectorId;
                this.label = label;
                this.playerGroups = [];
                this.enemyGroups = [];
            }
            getAllSoldiers() {
                const list = [];
                this.playerGroups.forEach((g) => g.soldiers.forEach((s) => list.push(s)));
                this.enemyGroups.forEach((g) => g.soldiers.forEach((s) => list.push(s)));
                return list;
            }
        }

        class SectorManager {
            constructor() {
                this.sectors = [];
                this.activeSectorIndex = 0;
            }

            initSectors(sectorCount, playerGroups = [], enemyGroups = []) {
                const count = Math.max(1, Number(sectorCount) || 1);
                const labels = ['MERKEZ MEYDAN (1650)', 'BATI KANAT TEPESİ', 'DOĞU OVASI'];
                this.sectors = [];

                for (let i = 0; i < count; i++) {
                    const id = `SECTOR_1650_0${i + 1}`;
                    this.sectors.push(new SectorState(i, id, labels[i] || `SEKTÖR ${i + 1}`));
                }

                playerGroups.forEach((grp) => {
                    const targetIdx = Math.max(0, Math.min(count - 1, grp.sectorIndex || 0));
                    this.sectors[targetIdx].playerGroups.push(grp);
                });

                enemyGroups.forEach((grp) => {
                    const targetIdx = Math.max(0, Math.min(count - 1, grp.sectorIndex || 0));
                    this.sectors[targetIdx].enemyGroups.push(grp);
                });

                this.activeSectorIndex = 0;
                return this.sectors;
            }

            setActiveSector(index) {
                if (index >= 0 && index < this.sectors.length) {
                    this.activeSectorIndex = index;
                }
            }

            getActiveSector() {
                return this.sectors[this.activeSectorIndex] || null;
            }
        }

        function createTestBattleData() {
            const playerGroups = [
                new UnitGroup({
                    id: 'grp_p_pikemen_center',
                    side: 'player',
                    sectorIndex: 0,
                    unitClass: 'pikeman',
                    combatRole: 'melee',
                    bodyType: 'human',
                    mountType: 'foot',
                    activeWeapon: 'pike',
                    weaponLoadout: ['pike', 'tuck_sword'],
                    armorLoadout: ['morion_helmet', 'iron_cuirass'],
                    formation: 'box',
                    anchor: { x: -16, z: -8 },
                    count: 54
                }),
                new UnitGroup({
                    id: 'grp_p_musketeers_left',
                    side: 'player',
                    sectorIndex: 0,
                    unitClass: 'musketeer',
                    combatRole: 'ranged',
                    bodyType: 'human',
                    mountType: 'foot',
                    activeWeapon: 'matchlock_musket',
                    weaponLoadout: ['matchlock_musket', 'rapier'],
                    armorLoadout: ['felt_hat', 'buff_coat'],
                    formation: 'line',
                    anchor: { x: -24, z: -22 },
                    count: 42
                }),
                new UnitGroup({
                    id: 'grp_p_musketeers_right',
                    side: 'player',
                    sectorIndex: 0,
                    unitClass: 'musketeer',
                    combatRole: 'ranged',
                    bodyType: 'human',
                    mountType: 'foot',
                    activeWeapon: 'matchlock_musket',
                    weaponLoadout: ['matchlock_musket', 'rapier'],
                    armorLoadout: ['felt_hat', 'buff_coat'],
                    formation: 'line',
                    anchor: { x: -24, z: 16 },
                    count: 40
                }),
                new UnitGroup({
                    id: 'grp_p_cuirassiers_reserve',
                    side: 'player',
                    sectorIndex: 0,
                    unitClass: 'cuirassier',
                    combatRole: 'heavy_cavalry',
                    bodyType: 'mounted',
                    mountType: 'warhorse',
                    activeWeapon: 'cavalry_sabre',
                    weaponLoadout: ['cavalry_sabre', 'wheellock_pistol'],
                    armorLoadout: ['lobster_tail_pot', 'three_quarter_plate'],
                    formation: 'line',
                    anchor: { x: -34, z: 4 },
                    count: 32
                }),
                new UnitGroup({
                    id: 'grp_p_harquebusiers_west',
                    side: 'player',
                    sectorIndex: 1,
                    unitClass: 'harquebusier',
                    combatRole: 'medium_cavalry',
                    bodyType: 'mounted',
                    mountType: 'courser',
                    activeWeapon: 'carbine',
                    weaponLoadout: ['carbine', 'broadsword'],
                    armorLoadout: ['burgonet', 'breastplate'],
                    formation: 'spread',
                    anchor: { x: -42, z: -30 },
                    count: 28
                }),
                new UnitGroup({
                    id: 'grp_p_dragoon_east',
                    side: 'player',
                    sectorIndex: 2,
                    unitClass: 'dragoon',
                    combatRole: 'mounted_infantry',
                    bodyType: 'mounted',
                    mountType: 'rouncey',
                    activeWeapon: 'flintlock_carbine',
                    weaponLoadout: ['flintlock_carbine', 'hanger_sword'],
                    armorLoadout: ['leather_jerkin'],
                    formation: 'line',
                    anchor: { x: 26, z: 32 },
                    count: 24
                })
            ];

            const enemyGroups = [
                new UnitGroup({
                    id: 'grp_e_tercio_pikemen',
                    side: 'enemy',
                    sectorIndex: 0,
                    unitClass: 'tercio_pikeman',
                    combatRole: 'melee',
                    bodyType: 'human',
                    mountType: 'foot',
                    activeWeapon: 'ash_pike',
                    weaponLoadout: ['ash_pike', 'side_sword'],
                    armorLoadout: ['cabasset', 'corselet'],
                    formation: 'box',
                    anchor: { x: 16, z: -6 },
                    count: 56
                }),
                new UnitGroup({
                    id: 'grp_e_arquebusiers_north',
                    side: 'enemy',
                    sectorIndex: 0,
                    unitClass: 'arquebusier',
                    combatRole: 'ranged',
                    bodyType: 'human',
                    mountType: 'foot',
                    activeWeapon: 'arquebus',
                    weaponLoadout: ['arquebus', 'dagger'],
                    armorLoadout: ['cloth_doublet'],
                    formation: 'line',
                    anchor: { x: 24, z: -20 },
                    count: 38
                }),
                new UnitGroup({
                    id: 'grp_e_arquebusiers_south',
                    side: 'enemy',
                    sectorIndex: 0,
                    unitClass: 'arquebusier',
                    combatRole: 'ranged',
                    bodyType: 'human',
                    mountType: 'foot',
                    activeWeapon: 'arquebus',
                    weaponLoadout: ['arquebus', 'dagger'],
                    armorLoadout: ['cloth_doublet'],
                    formation: 'line',
                    anchor: { x: 24, z: 18 },
                    count: 38
                }),
                new UnitGroup({
                    id: 'grp_e_lancers_guard',
                    side: 'enemy',
                    sectorIndex: 0,
                    unitClass: 'demi_lancer',
                    combatRole: 'heavy_cavalry',
                    bodyType: 'mounted',
                    mountType: 'destrier',
                    activeWeapon: 'war_lance',
                    weaponLoadout: ['war_lance', 'arming_sword'],
                    armorLoadout: ['close_helm', 'half_plate'],
                    formation: 'line',
                    anchor: { x: 35, z: 2 },
                    count: 30
                }),
                new UnitGroup({
                    id: 'grp_e_reiters_west',
                    side: 'enemy',
                    sectorIndex: 1,
                    unitClass: 'reiter',
                    combatRole: 'pistol_cavalry',
                    bodyType: 'mounted',
                    mountType: 'charger',
                    activeWeapon: 'wheellock_pistol',
                    weaponLoadout: ['wheellock_pistol', 'reitschwert'],
                    armorLoadout: ['blackened_cuirass'],
                    formation: 'box',
                    anchor: { x: -18, z: -34 },
                    count: 34
                }),
                new UnitGroup({
                    id: 'grp_e_cossack_skirmishers_east',
                    side: 'enemy',
                    sectorIndex: 2,
                    unitClass: 'light_cavalry',
                    combatRole: 'skirmisher',
                    bodyType: 'mounted',
                    mountType: 'steppe_horse',
                    activeWeapon: 'sabre',
                    weaponLoadout: ['sabre', 'short_carbine'],
                    armorLoadout: ['mail_shirt'],
                    formation: 'spread',
                    anchor: { x: 46, z: 28 },
                    count: 26
                })
            ];

            return {
                sectorCount: 3,
                playerGroups,
                enemyGroups
            };
        }

        function projectActiveSector3D(sectorManager) {
            const limits = { player: 150, enemy: 150 };
            if (!sectorManager || typeof sectorManager.getActiveSector !== 'function') {
                return {
                    sectorId: null,
                    soldiers: [],
                    limits,
                    visible: { player: 0, enemy: 0 },
                    hiddenAlive: { player: 0, enemy: 0 },
                    dataAuthority: 'existing_battle_simulation'
                };
            }

            const activeSector = sectorManager.getActiveSector();
            if (!activeSector) {
                return {
                    sectorId: null,
                    soldiers: [],
                    limits,
                    visible: { player: 0, enemy: 0 },
                    hiddenAlive: { player: 0, enemy: 0 },
                    dataAuthority: 'existing_battle_simulation'
                };
            }

            const soldiers = [];
            const visible = { player: 0, enemy: 0 };
            const hiddenAlive = { player: 0, enemy: 0 };
            const allSoldiers = activeSector.getAllSoldiers();

            for (let i = 0; i < allSoldiers.length; i++) {
                const s = allSoldiers[i];
                if (!s || !s.alive || s.hp <= 0) continue;

                const side = s.side === 'enemy' ? 'enemy' : 'player';
                if (visible[side] >= limits[side]) {
                    hiddenAlive[side]++;
                    continue;
                }

                visible[side]++;
                soldiers.push({
                    viewId: `${activeSector.sectorId}:${s.id}`,
                    sectorId: activeSector.sectorId,
                    side,
                    groupId: s.groupId,
                    soldierId: s.id,
                    unitClass: s.unitClass,
                    combatRole: s.combatRole,
                    bodyType: s.bodyType,
                    mountType: s.mountType,
                    activeWeapon: s.activeWeapon,
                    weaponLoadout: [...s.weaponLoadout],
                    armorLoadout: [...s.armorLoadout],
                    state: s.state,
                    hp: s.hp,
                    position: {
                        x: s.position.x,
                        y: s.position.y,
                        z: s.position.z
                    }
                });
            }

            return {
                sectorId: activeSector.sectorId,
                soldiers,
                limits,
                visible,
                hiddenAlive,
                dataAuthority: 'existing_battle_simulation'
            };
        }

        /* ============================================================================
         * 3. PRESERVED 3D MODELS (44/43/41 INFANTRY + 200 CAVALRY) & DATA-DRIVEN
         *    INFANTRY WALKING + CAVALRY WALK/TROT + INFANTRY COMBAT POSES (G3D-03C)
         * ============================================================================ */
        function classifySoldierArchetype(soldier) {
            const bodyType = String(soldier.bodyType || '').toLowerCase();
            const mountType = String(soldier.mountType || '').toLowerCase();
            const unitClass = String(soldier.unitClass || '').toLowerCase();
            const weapon = String(soldier.activeWeapon || '').toLowerCase();

            const isMounted = bodyType === 'mounted' ||
                (mountType && mountType !== 'foot') ||
                unitClass.includes('cuirassier') ||
                unitClass.includes('harquebusier') ||
                unitClass.includes('dragoon') ||
                unitClass.includes('lancer') ||
                unitClass.includes('reiter') ||
                unitClass.includes('cavalry');

            if (isMounted) {
                if (weapon === 'war_lance' || weapon.includes('lance')) {
                    return 'cavalry_lance';
                }
                if (
                    weapon === 'carbine' ||
                    weapon === 'flintlock_carbine' ||
                    weapon === 'short_carbine' ||
                    weapon.includes('carbine')
                ) {
                    return 'cavalry_carbine';
                }
                if (weapon === 'wheellock_pistol' || weapon.includes('pistol')) {
                    return 'cavalry_pistol';
                }
                if (weapon === 'cavalry_sabre' || weapon === 'sabre' || weapon.includes('sabre')) {
                    return 'cavalry_sabre';
                }
                return 'cavalry_sabre';
            }

            if (weapon.includes('pike') || unitClass.includes('pike')) {
                return 'infantry_pikeman';
            }

            if (
                weapon.includes('musket') ||
                weapon.includes('arquebus') ||
                weapon.includes('carbine') ||
                unitClass.includes('musketeer') ||
                unitClass.includes('arquebusier')
            ) {
                return 'infantry_musketeer';
            }

            return 'infantry_swordsman';
        }

        function resolveCavalryVisualVariant(soldier) {
            const side = soldier.side === 'enemy' ? 'enemy' : 'player';
            const weaponArchetype = classifySoldierArchetype(soldier);
            const mountType = String(soldier.mountType || 'warhorse').toLowerCase();
            const unitClass = String(soldier.unitClass || '').toLowerCase();
            const armorList = Array.isArray(soldier.armorLoadout)
                ? soldier.armorLoadout.map((a) => String(a).toLowerCase())
                : [];

            let mountVariant = 'warhorse';
            if (mountType === 'destrier' || mountType === 'warhorse') {
                mountVariant = 'heavy_warhorse';
            } else if (mountType === 'charger') {
                mountVariant = 'charger_horse';
            } else if (mountType === 'courser') {
                mountVariant = 'courser_horse';
            } else if (mountType === 'rouncey') {
                mountVariant = 'rouncey_horse';
            } else if (mountType === 'steppe_horse') {
                mountVariant = 'steppe_horse';
            }

            let riderVariant = 'cuirassier';
            if (
                unitClass.includes('dragoon') ||
                armorList.includes('leather_jerkin')
            ) {
                riderVariant = 'dragoon';
            } else if (
                unitClass.includes('light_cavalry') ||
                armorList.includes('mail_shirt')
            ) {
                riderVariant = 'light_skirmisher';
            } else if (
                unitClass.includes('reiter') ||
                armorList.includes('blackened_cuirass')
            ) {
                riderVariant = 'reiter';
            } else if (
                unitClass.includes('harquebusier') ||
                armorList.includes('burgonet')
            ) {
                riderVariant = 'harquebusier';
            } else {
                riderVariant = 'heavy_cuirassier';
            }

            return `${side}:${weaponArchetype}:${mountVariant}:${riderVariant}`;
        }

        
        function makePart(prim, mat, tx, ty, tz, sx, sy, sz, rx = 0, ry = 0, rz = 0, rigGroup = 'static') {
            return {
                prim,
                mat,
                rigGroup,
                localMat: FOC_THREE.Mat4.fromEulerTranslationScale(
                    FOC_THREE.Mat4.create(),
                    rx, ry, rz,
                    tx, ty, tz,
                    sx, sy, sz
                )
            };
        }

        /* ============================================================================
         * G3D-03K İLERİ DÜZEY ANATOMİK VE TARİHSEL MODEL ŞABLONLARI
         * ============================================================================ */

        // ----------------------------------------------------------------------------
        // AGENT 01: İNSAN ANATOMİSİ VE 3 TEMEL VÜCUT PROFİLİ (Slim, Average, Heavy)
        // ----------------------------------------------------------------------------
        const BODY_PROFILES = {
            slim: {
                shoulderWidth: 0.46,
                chestWidth: 0.44,
                chestDepth: 0.28,
                waistWidth: 0.36,
                waistDepth: 0.24,
                limbRadiusScale: 0.88,
                headScale: 0.96
            },
            average: {
                shoulderWidth: 0.52,
                chestWidth: 0.50,
                chestDepth: 0.32,
                waistWidth: 0.40,
                waistDepth: 0.27,
                limbRadiusScale: 1.0,
                headScale: 1.0
            },
            heavy: {
                shoulderWidth: 0.58,
                chestWidth: 0.56,
                chestDepth: 0.38,
                waistWidth: 0.46,
                waistDepth: 0.32,
                limbRadiusScale: 1.15,
                headScale: 1.05
            }
        };

        // Articulated hand builder with defined palm and angled thumb grip
        function buildArticulatedHand(mat, x, y, z, rigGroup, isLeft = false) {
            const sideSign = isLeft ? 1 : -1;
            return [
                // Palm
                makePart('box', mat, x, y, z, 0.08, 0.09, 0.05, 0, 0, 0, rigGroup),
                // Thumb joint
                makePart('box', mat, x + sideSign * 0.045, y - 0.015, z + 0.02, 0.035, 0.045, 0.035, 0.3, sideSign * 0.4, 0, rigGroup),
                // Finger cluster
                makePart('box', mat, x, y + 0.045, z + 0.005, 0.075, 0.05, 0.04, 0, 0, 0, rigGroup)
            ];
        }

        // Detailed anatomical head with brow, nose bridge, jawline and ears
        function buildAnatomicalHead(skinMat, hairMat, beardType = 'mustache', options = {}) {
            const hScale = options.headScale || 1.0;
            const parts = [
                // Neck with cervical taper
                makePart('frustum', skinMat, 0, 1.45, 0.015, 0.15 * hScale, 0.13, 0.13 * hScale, 0.1, 0, 0, 'torso'),
                // Cranium / Skull vault
                makePart('sphere', skinMat, 0, 1.58, 0.01, 0.23 * hScale, 0.25 * hScale, 0.24 * hScale, 0, 0, 0, 'torso'),
                // Forehead & Brow ridge
                makePart('box', skinMat, 0, 1.62, 0.12 * hScale, 0.20 * hScale, 0.06 * hScale, 0.08 * hScale, 0.15, 0, 0, 'torso'),
                // Nose bridge
                makePart('cone', skinMat, 0, 1.55, 0.16 * hScale, 0.05 * hScale, 0.09 * hScale, 0.05 * hScale, Math.PI * 0.5 + 0.35, 0, 0, 'torso'),
                // Jawline and Chin
                makePart('frustum', skinMat, 0, 1.49, 0.07 * hScale, 0.18 * hScale, 0.10 * hScale, 0.14 * hScale, -0.2, 0, 0, 'torso'),
                // Left Ear
                makePart('dome', skinMat, -0.13 * hScale, 1.57, -0.01, 0.05 * hScale, 0.08 * hScale, 0.03 * hScale, 0, -Math.PI * 0.5, 0, 'torso'),
                // Right Ear
                makePart('dome', skinMat,  0.13 * hScale, 1.57, -0.01, 0.05 * hScale, 0.08 * hScale, 0.03 * hScale, 0,  Math.PI * 0.5, 0, 'torso')
            ];

            // Facial hair variations
            if (beardType === 'mustache' || beardType === 'ottoman_pala') {
                // Broad drooping Ottoman mustache
                parts.push(
                    makePart('cone', hairMat, -0.06 * hScale, 1.505, 0.135 * hScale, 0.045 * hScale, 0.12 * hScale, 0.035 * hScale, Math.PI * 0.6, 0.5, -0.3, 'torso'),
                    makePart('cone', hairMat,  0.06 * hScale, 1.505, 0.135 * hScale, 0.045 * hScale, 0.12 * hScale, 0.035 * hScale, Math.PI * 0.6, -0.5, 0.3, 'torso')
                );
            } else if (beardType === 'vandyke') {
                // European pointed goatee and upturned mustache
                parts.push(
                    makePart('box', hairMat, 0, 1.52, 0.14 * hScale, 0.11 * hScale, 0.03 * hScale, 0.02 * hScale, 0, 0, 0, 'torso'),
                    makePart('cone', hairMat, 0, 1.45, 0.12 * hScale, 0.05 * hScale, 0.09 * hScale, 0.04 * hScale, -Math.PI * 0.4, 0, 0, 'torso')
                );
            } else if (beardType === 'full_beard') {
                // Full trimmed veteran beard
                parts.push(
                    makePart('frustum', hairMat, 0, 1.47, 0.08 * hScale, 0.20 * hScale, 0.12 * hScale, 0.15 * hScale, -0.25, 0, 0, 'torso')
                );
            }

            return parts;
        }

        // Master Anatomical Human Base
        const buildAnatomicalHumanBase = (side, profileKey = 'average', options = {}) => {
            const isEnemy = side === 'enemy';
            const prof = BODY_PROFILES[profileKey] || BODY_PROFILES.average;
            const skinMat = options.skinMat || 'skin';
            const hairMat = options.hairMat || 'wood';
            const clothMat = options.clothMat || (isEnemy ? 'enemyCloth' : 'playerCloth');
            const breechesMat = options.breechesMat || (isEnemy ? 'enemyBreeches' : 'playerBreeches');
            const leatherMat = options.leatherMat || 'leather';
            const beardType = options.beardType || (isEnemy ? 'vandyke' : 'ottoman_pala');

            const legX = prof.shoulderWidth * 0.34;
            const rScale = prof.limbRadiusScale;

            const baseParts = [
                // Ground Contact Shadow
                makePart('cylinder', 'shadow', 0, 0.02, 0, 1.08, 0.02, 1.08, 0, 0, 0, 'shadow'),

                // Footwear: Leather shoes / boots with distinct sole & heel
                makePart('box', leatherMat, -legX, 0.025, 0.04, 0.11 * rScale, 0.05, 0.24, 0, 0, 0, 'leftLegLower'),
                makePart('box', leatherMat,  legX, 0.025, 0.04, 0.11 * rScale, 0.05, 0.24, 0, 0, 0, 'rightLegLower'),
                makePart('box', 'darkCloth', -legX, 0.045, -0.05, 0.10 * rScale, 0.04, 0.08, 0, 0, 0, 'leftLegLower'),
                makePart('box', 'darkCloth',  legX, 0.045, -0.05, 0.10 * rScale, 0.04, 0.08, 0, 0, 0, 'rightLegLower'),

                // Lower Leg & Gastrocnemius Calf Contour
                makePart('frustum', breechesMat, -legX, 0.24, 0.0, 0.17 * rScale, 0.42, 0.19 * rScale, 0, 0, 0, 'leftLegLower'),
                makePart('frustum', breechesMat,  legX, 0.24, 0.0, 0.17 * rScale, 0.42, 0.19 * rScale, 0, 0, 0, 'rightLegLower'),
                // Knee Cap Articulation
                makePart('dome', breechesMat, -legX, 0.48, 0.04, 0.12 * rScale, 0.08, 0.12 * rScale, 0.3, 0, 0, 'leftLegLower'),
                makePart('dome', breechesMat,  legX, 0.48, 0.04, 0.12 * rScale, 0.08, 0.12 * rScale, 0.3, 0, 0, 'rightLegLower'),

                // Thigh / Quadriceps Muscle Mass
                makePart('frustum', breechesMat, -legX, 0.68, 0.0, 0.22 * rScale, 0.38, 0.23 * rScale, Math.PI, 0, 0, 'leftLegUpper'),
                makePart('frustum', breechesMat,  legX, 0.68, 0.0, 0.22 * rScale, 0.38, 0.23 * rScale, Math.PI, 0, 0, 'rightLegUpper'),

                // Pelvis & Lower Torso
                makePart('frustum', clothMat, 0, 0.88, 0.0, prof.waistWidth, 0.26, prof.waistDepth, 0, 0, 0, 'torso'),

                // Waist Belt / Sash Layer
                makePart('cylinder', leatherMat, 0, 0.98, 0.0, prof.waistWidth * 0.92, 0.09, prof.waistDepth * 0.92, 0, 0, 0, 'torso'),
                makePart('box', 'gold', 0, 0.98, prof.waistDepth * 0.48, 0.09, 0.08, 0.035, 0, 0, 0, 'torso'),

                // Upper Chest with Natural Taper (Broad shoulders tapering down to waist)
                makePart('frustum', clothMat, 0, 1.20, 0.0, prof.shoulderWidth, 0.44, prof.chestDepth, Math.PI, 0, 0, 'torso'),

                // Deltoid Shoulder Muscle Caps
                makePart('sphere', clothMat, -prof.shoulderWidth * 0.52, 1.34, 0.0, 0.12 * rScale, 0.13 * rScale, 0.12 * rScale, 0, 0, 0, 'torso'),
                makePart('sphere', clothMat,  prof.shoulderWidth * 0.52, 1.34, 0.0, 0.12 * rScale, 0.13 * rScale, 0.12 * rScale, 0, 0, 0, 'torso'),

                // Detailed Anatomical Head & Neck
                ...buildAnatomicalHead(skinMat, hairMat, beardType, { headScale: prof.headScale })
            ];

            return baseParts;
        };

        // ----------------------------------------------------------------------------
        // AGENT 02: OSMANLI ÇOK KATMANLI KIYAFET VE ZIRH KALİTESİ
        // ----------------------------------------------------------------------------
        const buildOttomanHighDefHumanBase = (side, profileKey = 'average', options = {}) => {
            const isEnemy = side === 'enemy';
            const kaftanColor = options.kaftanMat || (isEnemy ? 'enemyCloth' : 'ottomanCrimson');
            const salvarColor = options.salvarMat || 'ottomanNavy';
            const kusakColor = options.kusakMat || 'ottomanSaffron';

            const base = buildAnatomicalHumanBase(side, profileKey, {
                clothMat: kaftanColor,
                breechesMat: salvarColor,
                leatherMat: 'leather',
                beardType: 'ottoman_pala',
                ...options
            });

            const prof = BODY_PROFILES[profileKey] || BODY_PROFILES.average;

            // Add Flared Pleated Kaftan Skirt with Split Front
            const kaftanSkirt = [
                // Lower Flared Skirt
                makePart('frustum', kaftanColor, 0, 0.84, -0.01, prof.waistWidth * 1.26, 0.34, prof.waistDepth * 1.30, 0, 0, 0, 'torso'),
                // Gold Embroidered Border Hem
                makePart('frustum', 'gold', 0, 0.68, -0.01, prof.waistWidth * 1.28, 0.03, prof.waistDepth * 1.32, 0, 0, 0, 'torso'),
                // Split Lapel Front Opening
                makePart('box', 'ottomanWhite', 0, 1.18, prof.chestDepth * 0.51, 0.06, 0.40, 0.02, 0, 0, 0, 'torso'),
                // Three-Dimensional Wrapped Silk Kuşak
                makePart('cylinder', kusakColor, 0, 0.98, 0.0, prof.waistWidth * 1.05, 0.12, prof.waistDepth * 1.06, 0, 0, 0, 'torso'),
                makePart('box', 'gold', 0, 0.98, prof.waistDepth * 0.54, 0.10, 0.09, 0.04, 0, 0, 0, 'torso')
            ];

            return [...base, ...kaftanSkirt];
        };

        // ----------------------------------------------------------------------------
        // AGENT 03: AVRUPA / HRE ASKER KIYAFETLERİ VE ZIRHLARI
        // ----------------------------------------------------------------------------
        const buildEuropeanHighDefHumanBase = (side, profileKey = 'average', options = {}) => {
            const isEnemy = side === 'enemy';
            const coatColor = options.coatMat || (isEnemy ? 'enemyCloth' : 'playerCloth');
            const breechesColor = options.breechesMat || (isEnemy ? 'enemyBreeches' : 'playerBreeches');

            const base = buildAnatomicalHumanBase(side, profileKey, {
                clothMat: coatColor,
                breechesMat: breechesColor,
                leatherMat: 'buffLeather',
                beardType: 'vandyke',
                ...options
            });

            const prof = BODY_PROFILES[profileKey] || BODY_PROFILES.average;

            // European Peascod Doublet Flared Tabs & Falling Linen Collar
            const europeanDetails = [
                // Starched Falling White Collar
                makePart('frustum', 'linen', 0, 1.40, 0.02, prof.shoulderWidth * 0.52, 0.05, prof.chestDepth * 0.72, 0, 0, 0, 'torso'),
                // Peascod Doublet Waist Skirt Tabs (Peplos)
                makePart('frustum', coatColor, 0, 0.88, 0.0, prof.waistWidth * 1.15, 0.22, prof.waistDepth * 1.18, 0, 0, 0, 'torso'),
                // Leather Cross-Belt Baldric for Sword Hanger
                makePart('box', 'buffLeather', -0.06, 1.16, 0.0, 0.07, 0.44, prof.chestDepth * 1.05, 0, 0, -0.42, 'torso'),
                makePart('box', 'steel', -0.06, 0.98, prof.chestDepth * 0.52, 0.08, 0.06, 0.03, 0, 0, -0.42, 'torso')
            ];

            return [...base, ...europeanDetails];
        };

        // ----------------------------------------------------------------------------
        // AGENT 04 & 05: TARİHSEL MİĞFERLER, BAŞLIKLAR VE ZIRH SETLERİ
        // ----------------------------------------------------------------------------

        // 1. White Felt Börk (Janissary) with Hollow Fit
        function buildHighDefBork() {
            return [
                // Brass Spoon Holder (Zarf)
                makePart('box', 'burnishedBronze', 0, 1.68, 0.16, 0.065, 0.18, 0.045, 0.1, 0, 0, 'torso'),
                makePart('sphere', 'gold', 0, 1.76, 0.17, 0.05, 0.05, 0.035, 0, 0, 0, 'torso'),
                // White Felt Tapered Crown
                makePart('frustum', 'ottomanWhite', 0, 1.82, 0.02, 0.29, 0.32, 0.30, 0, 0, 0, 'torso'),
                // Draping Rear Fabric Flap (Over Neck & Shoulders)
                makePart('frustum', 'ottomanWhite', 0, 1.56, -0.16, 0.25, 0.48, 0.085, -0.34, 0, 0, 'torso'),
                makePart('box', 'ottomanCrimson', 0, 1.34, -0.22, 0.22, 0.04, 0.03, -0.34, 0, 0, 'torso')
            ];
        }

        // 2. High-Comb Morion Helmet (HRE Pikeniere)
        function buildHighDefMorion() {
            return [
                // Helmet Skull Bowl
                makePart('dome', 'steel', 0, 1.70, 0.02, 0.30, 0.22, 0.32, 0, 0, 0, 'torso'),
                // Curved Swept-Wing Brim (Fore & Aft Peaks)
                makePart('frustum', 'steel', 0, 1.63, 0.02, 0.40, 0.05, 0.44, 0, 0, 0, 'torso'),
                // Prominent High Crescent Comb
                makePart('box', 'steel', 0, 1.82, 0.02, 0.035, 0.18, 0.34, 0, 0, 0, 'torso'),
                makePart('frustum', 'steel', 0, 1.88, 0.02, 0.03, 0.08, 0.28, 0, 0, 0, 'torso'),
                // Rivet Band along Rim
                makePart('cylinder', 'burnishedBronze', 0, 1.64, 0.02, 0.31, 0.025, 0.33, 0, 0, 0, 'torso')
            ];
        }

        // 3. Peaked Burgonet Helmet (HRE Hellebardier)
        function buildHighDefBurgonet() {
            return [
                // Skull Bowl
                makePart('dome', 'steel', 0, 1.70, 0.02, 0.30, 0.22, 0.31, 0, 0, 0, 'torso'),
                // Fixed Brow Peak Visor
                makePart('box', 'steel', 0, 1.64, 0.16, 0.28, 0.04, 0.12, 0.35, 0, 0, 'torso'),
                // Neck Lames (Lobster Tail)
                makePart('frustum', 'steel', 0, 1.54, -0.13, 0.26, 0.14, 0.10, -0.4, 0, 0, 'torso'),
                // Hinged Cheek Guards
                makePart('box', 'steel', -0.14, 1.54, 0.05, 0.03, 0.14, 0.10, 0, 0, 0, 'torso'),
                makePart('box', 'steel',  0.14, 1.54, 0.05, 0.03, 0.14, 0.10, 0, 0, 0, 'torso')
            ];
        }

        // 4. Şişak / Tolga Helmet with Nasal Bar (Sipahi)
        function buildHighDefSisak() {
            return [
                // Pointed Fluted Bowl
                makePart('cone', 'damascusSteel', 0, 2.32, -0.03, 0.28, 0.32, 0.28, 0, 0, 0, 'riderUpper'),
                makePart('cone', 'burnishedBronze', 0, 2.44, -0.03, 0.08, 0.16, 0.08, 0, 0, 0, 'riderUpper'),
                // Brow Visor & Sliding Nasal Bar
                makePart('box', 'damascusSteel', 0, 2.18, 0.12, 0.26, 0.04, 0.08, 0.25, 0, 0, 'riderUpper'),
                makePart('box', 'burnishedBronze', 0, 2.10, 0.16, 0.025, 0.18, 0.025, 0, 0, 0, 'riderUpper'),
                // Mail Camail Neck Drape
                makePart('cylinder', 'darkSteel', 0, 2.05, -0.04, 0.31, 0.22, 0.31, 0, 0, 0, 'riderUpper')
            ];
        }

        // 5. Broad Cavalier Hat with Ostrich Plume (Musketier)
        function buildHighDefCavalierHat() {
            return [
                // Wide Upturned Felt Brim
                makePart('cylinder', 'darkCloth', 0, 1.66, 0.02, 0.46, 0.03, 0.46, 0.1, 0, 0.15, 'torso'),
                // Crown
                makePart('cylinder', 'darkCloth', 0, 1.74, 0.02, 0.28, 0.16, 0.28, 0.1, 0, 0.15, 'torso'),
                // Flowing Ostrich Feather Plume
                makePart('frustum', 'linen', 0.14, 1.82, -0.06, 0.06, 0.28, 0.10, -0.4, 0, 0.6, 'torso'),
                makePart('frustum', 'ottomanCrimson', 0.18, 1.88, -0.12, 0.05, 0.24, 0.08, -0.6, 0, 0.7, 'torso')
            ];
        }

        // 6. Çevşen Breastplate Armor (Janissary / Bostancı)
        function buildHighDefCevsen() {
            return [
                // Interlocking Mail Vest
                makePart('cylinder', 'damascusSteel', 0, 1.20, 0.005, 0.52, 0.38, 0.34, 0, 0, 0, 'torso'),
                // Central Steel Disc Plate
                makePart('cylinder', 'damascusSteel', 0, 1.22, 0.175, 0.26, 0.025, 0.26, Math.PI * 0.5, 0, 0, 'torso'),
                makePart('sphere', 'burnishedBronze', 0, 1.22, 0.19, 0.07, 0.07, 0.07, 0, 0, 0, 'torso'),
                // Arm bazuband bracers
                makePart('cylinder', 'damascusSteel', -0.32, 1.12, 0.10, 0.07, 0.18, 0.07, 0, 0, 0, 'torso'),
                makePart('cylinder', 'damascusSteel',  0.32, 1.12, 0.10, 0.07, 0.18, 0.07, 0, 0, 0, 'torso')
            ];
        }

        // 7. Tapul Ridged Breastplate with Tassets (HRE Pikeniere)
        function buildHighDefTapulArmor() {
            return [
                // Peascod Ridged Front Breastplate
                makePart('frustum', 'steel', 0, 1.22, 0.02, 0.52, 0.42, 0.36, Math.PI, 0, 0, 'torso'),
                // Deflection Central Spine Ridge
                makePart('box', 'steel', 0, 1.22, 0.20, 0.035, 0.40, 0.05, 0.12, 0, 0, 'torso'),
                // Articulated Thigh Tassets (Laminated Plates)
                makePart('frustum', 'steel', -0.14, 0.82, 0.08, 0.20, 0.24, 0.14, -0.2, 0, 0, 'leftLegUpper'),
                makePart('frustum', 'steel',  0.14, 0.82, 0.08, 0.20, 0.24, 0.14, -0.2, 0, 0, 'rightLegUpper')
            ];
        }

        // ----------------------------------------------------------------------------
        // AGENT 06: MODÜLER ASKER BİRLEŞTİRME MOTORU (RTSModularUnitBuilder)
        // ----------------------------------------------------------------------------
        class RTSModularUnitBuilder {
            static assembleSoldier(archetype, side, seed = 0) {
                const isOttoman = archetype.includes('ottoman') || archetype.includes('janissary') || archetype.includes('azap') || archetype.includes('sipahi') || archetype.includes('deli') || archetype.includes('bostanci') || archetype.includes('humbaraci') || archetype.includes('levend') || archetype.includes('ciritci') || archetype.includes('akinci');

                // Determine profile deterministically from seed
                const profiles = ['slim', 'average', 'heavy'];
                const profile = profiles[Math.abs(seed) % profiles.length];

                if (isOttoman) {
                    if (archetype.includes('janissary')) {
                        const base = buildOttomanHighDefHumanBase(side, profile, { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                        return [...base, ...buildHighDefBork(), ...buildHighDefCevsen()];
                    } else if (archetype.includes('bostanci')) {
                        const base = buildOttomanHighDefHumanBase(side, 'heavy', { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                        return [...base, ...buildHighDefCevsen()];
                    } else {
                        return buildOttomanHighDefHumanBase(side, profile);
                    }
                } else {
                    if (archetype.includes('pikeniere')) {
                        const base = buildEuropeanHighDefHumanBase(side, profile, { coatMat: 'playerCloth', breechesMat: 'playerBreeches' });
                        return [...base, ...buildHighDefMorion(), ...buildHighDefTapulArmor()];
                    } else if (archetype.includes('hellebardier')) {
                        const base = buildEuropeanHighDefHumanBase(side, profile, { coatMat: 'darkCloth', breechesMat: 'buffLeather' });
                        return [...base, ...buildHighDefBurgonet()];
                    } else if (archetype.includes('musketier')) {
                        const base = buildEuropeanHighDefHumanBase(side, profile, { coatMat: 'playerCloth', breechesMat: 'playerBreeches' });
                        return [...base, ...buildHighDefCavalierHat()];
                    } else {
                        return buildEuropeanHighDefHumanBase(side, profile);
                    }
                }
            }
        }
    
function createSoldierPartTemplates() {
            const m = makePart; const m_legacy = (prim, mat, tx, ty, tz, sx, sy, sz, rx = 0, ry = 0, rz = 0, rigGroup = 'static') => ({
                prim,
                mat,
                rigGroup,
                localMat: FOC_THREE.Mat4.fromEulerTranslationScale(
                    FOC_THREE.Mat4.create(),
                    rx, ry, rz,
                    tx, ty, tz,
                    sx, sy, sz
                )
            });

            const limb = (mat, ax, ay, az, bx, by, bz, rStart, rEnd, rigGroup = 'static') => {
                const dx = bx - ax;
                const dy = by - ay;
                const dz = bz - az;
                const len = Math.hypot(dx, dy, dz) || 0.001;
                const mx = (ax + bx) * 0.5;
                const my = (ay + by) * 0.5;
                const mz = (az + bz) * 0.5;
                const rx = Math.atan2(dz, dy);
                const rz = -Math.atan2(dx, Math.hypot(dy, dz));
                const avgScale = Math.max(rStart, rEnd) * 2.0;
                const flip = rStart > rEnd ? Math.PI : 0;
                return m('frustum', mat, mx, my, mz, avgScale, len, avgScale, rx + flip, 0, rz, rigGroup);
            };

            const humanBase1650 = (side) => {
                const isEnemy = side === 'enemy';
                const coatMat = isEnemy ? 'enemyCloth' : 'playerCloth';
                const breechesMat = isEnemy ? 'enemyBreeches' : 'playerBreeches';
                return [
                    m('cylinder', 'shadow', 0, 0.02, 0, 1.08, 0.02, 1.08, 0, 0, 0, 'shadow'),
                    m('box', 'darkSteel', -0.14, 0.025, 0.04, 0.13, 0.05, 0.25, 0, 0, 0, 'leftLegLower'),
                    m('box', 'darkSteel',  0.14, 0.025, 0.04, 0.13, 0.05, 0.25, 0, 0, 0, 'rightLegLower'),
                    m('frustum', 'leather', -0.14, 0.24, 0.0, 0.16, 0.42, 0.17, 0, 0, 0, 'leftLegLower'),
                    m('frustum', 'leather',  0.14, 0.24, 0.0, 0.16, 0.42, 0.17, 0, 0, 0, 'rightLegLower'),
                    m('frustum', 'leather', -0.14, 0.46, 0.01, 0.20, 0.10, 0.21, Math.PI, 0, 0, 'leftLegLower'),
                    m('frustum', 'leather',  0.14, 0.46, 0.01, 0.20, 0.10, 0.21, Math.PI, 0, 0, 'rightLegLower'),
                    m('frustum', breechesMat, -0.14, 0.66, 0.0, 0.22, 0.36, 0.23, Math.PI, 0, 0, 'leftLegUpper'),
                    m('frustum', breechesMat,  0.14, 0.66, 0.0, 0.22, 0.36, 0.23, Math.PI, 0, 0, 'rightLegUpper'),
                    m('frustum', coatMat, 0, 0.86, -0.01, 0.52, 0.28, 0.38, 0, 0, 0, 'torso'),
                    m('frustum', 'gold', 0, 0.73, -0.01, 0.53, 0.025, 0.39, 0, 0, 0, 'torso'),
                    m('frustum', coatMat, 0, 1.20, 0.0, 0.52, 0.44, 0.34, Math.PI, 0, 0, 'torso'),
                    m('cylinder', 'leather', 0, 0.98, 0.0, 0.42, 0.08, 0.31, 0, 0, 0, 'torso'),
                    m('box', 'gold', 0, 0.98, 0.16, 0.10, 0.09, 0.035, 0, 0, 0, 'torso'),
                    m('frustum', 'linen', 0, 1.42, 0.015, 0.32, 0.065, 0.30, 0.05, 0, 0, 'torso'),
                    m('cylinder', 'skin', 0, 1.48, 0.01, 0.13, 0.11, 0.13, 0, 0, 0, 'torso'),
                    m('sphere', 'skin', 0, 1.58, 0.02, 0.24, 0.26, 0.25, 0, 0, 0, 'torso'),
                    m('cone', 'wood', 0, 1.50, 0.12, 0.12, 0.10, 0.08, Math.PI + 0.2, 0, 0, 'torso')
                ];
            };

            const buildInfantryPikeman = (side) => {
                const coatMat = side === 'enemy' ? 'enemyCloth' : 'playerCloth';
                const pikeAngleX = Math.atan2(0.38, 0.24);
                const cosP = Math.cos(pikeAngleX);
                const sinP = Math.sin(pikeAngleX);
                const px = -0.32;
                const p1y = 1.08;
                const p1z = 0.18;

                return [
                    ...humanBase1650(side),
                    m('frustum', 'steel', 0, 1.20, 0.005, 0.545, 0.405, 0.365, Math.PI, 0, 0, 'torso'),
                    m('box', 'steel', 0, 1.20, 0.188, 0.060, 0.365, 0.050, -0.06, 0, 0, 'torso'),
                    m('frustum', 'steel', 0, 1.41, 0.01, 0.33, 0.07, 0.30, 0, 0, 0, 'torso'),
                    m('box', 'steel', -0.15, 0.85, 0.165, 0.17, 0.20, 0.03, -0.22, -0.12, 0.06, 'torso'),
                    m('box', 'steel',  0.15, 0.85, 0.165, 0.17, 0.20, 0.03, -0.22,  0.12, -0.06, 'torso'),
                    m('box', 'gold',  -0.15, 0.76, 0.185, 0.17, 0.025, 0.035, -0.22, -0.12, 0.06, 'torso'),
                    m('box', 'gold',   0.15, 0.76, 0.185, 0.17, 0.025, 0.035, -0.22,  0.12, -0.06, 'torso'),
                    m('dome', 'steel', -0.27, 1.32, 0.0, 0.24, 0.20, 0.25, 0, 0,  0.22, 'torso'),
                    m('dome', 'steel',  0.27, 1.32, 0.0, 0.24, 0.20, 0.25, 0, 0, -0.22, 'torso'),
                    m('frustum', 'steel', -0.29, 1.26, 0.0, 0.22, 0.09, 0.23, 0, 0,  0.18, 'torso'),
                    m('frustum', 'steel',  0.29, 1.26, 0.0, 0.22, 0.09, 0.23, 0, 0, -0.18, 'torso'),
                    m('dome', 'steel', 0, 1.60, 0.01, 0.27, 0.24, 0.29, 0, 0, 0, 'torso'),
                    m('box', 'steel', 0, 1.74, 0.01, 0.035, 0.12, 0.30, 0, 0, 0, 'torso'),
                    m('box', 'gold',  0, 1.80, 0.01, 0.04, 0.025, 0.31, 0, 0, 0, 'torso'),
                    m('frustum', 'steel', 0, 1.60, 0.01, 0.42, 0.04, 0.48, -0.08, 0, 0, 'torso'),
                    m('frustum', 'gold',  0, 1.595, 0.01, 0.43, 0.015, 0.49, -0.08, 0, 0, 'torso'),
                    limb(coatMat, -0.27, 1.32, 0.0, -0.34, 1.12, -0.04, 0.075, 0.062, 'twoHandPike'),
                    limb('steel', -0.34, 1.12, -0.04, px, p1y, p1z, 0.062, 0.052, 'twoHandPike'),
                    m('sphere', 'leather', px, p1y, p1z, 0.11, 0.11, 0.11, 0, 0, 0, 'twoHandPike'),
                    limb(coatMat, 0.27, 1.32, 0.0, 0.08, 1.18, 0.26, 0.075, 0.062, 'twoHandPike'),
                    limb('steel', 0.08, 1.18, 0.26, px, 1.32, 0.56, 0.062, 0.052, 'twoHandPike'),
                    m('sphere', 'leather', px, 1.32, 0.56, 0.11, 0.11, 0.11, 0, 0, 0, 'twoHandPike'),
                    m('cylinder', 'wood', px, p1y + 1.18 * cosP, p1z + 1.18 * sinP, 0.042, 4.15, 0.042, pikeAngleX, 0, 0, 'twoHandPike'),
                    m('cone', 'steel', px, p1y - 0.92 * cosP, p1z - 0.92 * sinP, 0.065, 0.14, 0.065, pikeAngleX + Math.PI, 0, 0, 'twoHandPike'),
                    m('box', 'steel', px, p1y + 3.05 * cosP, p1z + 3.05 * sinP, 0.055, 0.36, 0.025, pikeAngleX, 0, 0, 'twoHandPike'),
                    m('cone', 'steel', px, p1y + 3.38 * cosP, p1z + 3.38 * sinP, 0.11, 0.38, 0.055, pikeAngleX, 0, 0, 'twoHandPike')
                ];
            };

            const buildInfantryMusketeer = (side) => {
                const coatMat = side === 'enemy' ? 'enemyCloth' : 'playerCloth';
                const barrelYaw = Math.atan2(0.16, 1.32);
                const barrelPitch = Math.PI * 0.5 - Math.atan2(0.07, 1.32);

                return [
                    ...humanBase1650(side),
                    m('frustum', coatMat, -0.26, 1.36, 0.0, 0.16, 0.12, 0.24, 0, 0,  0.35, 'torso'),
                    m('frustum', coatMat,  0.26, 1.36, 0.0, 0.16, 0.12, 0.24, 0, 0, -0.35, 'torso'),
                    m('box', 'leather', 0.0, 1.19, 0.158, 0.46, 0.065, 0.035, 0, 0, -0.68, 'torso'),
                    m('cylinder', 'wood', -0.09, 1.07, 0.18, 0.045, 0.12, 0.045, 0.1, 0, -0.15, 'torso'),
                    m('cylinder', 'wood',  0.00, 1.12, 0.18, 0.045, 0.12, 0.045, 0.1, 0, -0.15, 'torso'),
                    m('cylinder', 'wood',  0.09, 1.18, 0.18, 0.045, 0.12, 0.045, 0.1, 0, -0.15, 'torso'),
                    m('cylinder', 'gold',  0.00, 1.18, 0.18, 0.048, 0.025, 0.048, 0.1, 0, -0.15, 'torso'),
                    m('frustum', 'darkSteel', 0.0, 1.65, 0.0, 0.58, 0.03, 0.58, -0.08, 0.1, -0.06, 'torso'),
                    m('frustum', 'darkSteel', 0.0, 1.74, -0.01, 0.29, 0.18, 0.30, -0.06, 0, -0.04, 'torso'),
                    m('cylinder', 'gold', 0.0, 1.68, -0.005, 0.30, 0.03, 0.31, -0.06, 0, -0.04, 'torso'),
                    m('cone', coatMat, 0.14, 1.77, -0.14, 0.11, 0.36, 0.06, -1.15, 0.35, -0.3, 'torso'),
                    limb(coatMat, -0.26, 1.33, 0.0, -0.32, 1.14, 0.08, 0.075, 0.062, 'twoHandMusket'),
                    limb('linen', -0.32, 1.14, 0.08, -0.17, 1.24, 0.28, 0.058, 0.048, 'twoHandMusket'),
                    m('sphere', 'skin', -0.17, 1.24, 0.28, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandMusket'),
                    limb(coatMat, 0.26, 1.33, 0.0, 0.16, 1.14, 0.36, 0.075, 0.062, 'twoHandMusket'),
                    limb('linen', 0.16, 1.14, 0.36, -0.10, 1.27, 0.72, 0.058, 0.048, 'twoHandMusket'),
                    m('sphere', 'skin', -0.10, 1.27, 0.72, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandMusket'),
                    m('box', 'wood', -0.185, 1.22, 0.14, 0.075, 0.15, 0.34, -0.26, barrelYaw, 0, 'twoHandMusket'),
                    m('box', 'steel', -0.20, 1.18, -0.02, 0.08, 0.17, 0.03, -0.26, barrelYaw, 0, 'twoHandMusket'),
                    m('frustum', 'wood', -0.115, 1.275, 0.64, 0.082, 0.81, 0.092, barrelPitch, barrelYaw, 0, 'twoHandMusket'),
                    m('cylinder', 'darkSteel', -0.095, 1.305, 0.82, 0.056, 1.19, 0.056, barrelPitch, barrelYaw, 0, 'twoHandMusket'),
                    m('cylinder', 'gold', -0.035, 1.332, 1.34, 0.062, 0.05, 0.062, barrelPitch, barrelYaw, 0, 'twoHandMusket'),
                    m('box', 'gold', -0.15, 1.29, 0.36, 0.07, 0.045, 0.08, 0, barrelYaw, 0, 'twoHandMusket'),
                    m('cylinder', 'wood', -0.10, 0.63, 0.72, 0.035, 1.26, 0.035, 0, 0, 0, 'twoHandMusket'),
                    m('box', 'darkSteel', -0.10, 1.27, 0.72, 0.11, 0.07, 0.04, 0, barrelYaw, 0, 'twoHandMusket')
                ];
            };

            const buildInfantrySwordsman = (side) => {
                const coatMat = side === 'enemy' ? 'enemyCloth' : 'playerCloth';
                const swordPitch = Math.PI * 0.5 - 0.45;
                const sinS = Math.sin(swordPitch);
                const cosS = Math.cos(swordPitch);
                const hx = -0.30;
                const hy = 1.12;
                const hz = 0.30;

                return [
                    ...humanBase1650(side),
                    m('frustum', 'steel', 0, 1.20, 0.005, 0.545, 0.405, 0.365, Math.PI, 0, 0, 'torso'),
                    m('box', 'steel', 0, 1.20, 0.188, 0.060, 0.365, 0.050, -0.06, 0, 0, 'torso'),
                    m('frustum', 'steel', 0, 1.41, 0.01, 0.33, 0.07, 0.30, 0, 0, 0, 'torso'),
                    m('dome', 'steel', -0.27, 1.32, 0.0, 0.24, 0.20, 0.25, 0, 0,  0.22, 'torso'),
                    m('dome', 'steel',  0.27, 1.32, 0.0, 0.24, 0.20, 0.25, 0, 0, -0.22, 'torso'),
                    m('dome', 'steel', 0, 1.60, 0.01, 0.27, 0.25, 0.29, 0, 0, 0, 'torso'),
                    m('box', 'gold', 0, 1.75, 0.01, 0.04, 0.13, 0.31, 0, 0, 0, 'torso'),
                    m('box', 'steel', 0, 1.61, 0.16, 0.24, 0.03, 0.12, 0.22, 0, 0, 'torso'),
                    m('box', 'steel', -0.13, 1.54, 0.04, 0.03, 0.13, 0.11, 0, 0, 0.1, 'torso'),
                    m('box', 'steel',  0.13, 1.54, 0.04, 0.03, 0.13, 0.11, 0, 0, -0.1, 'torso'),
                    limb(coatMat, 0.27, 1.32, 0.0, 0.34, 1.15, 0.10, 0.075, 0.062, 'leftArmWeapon'),
                    limb('steel', 0.34, 1.15, 0.10, 0.36, 1.16, 0.28, 0.062, 0.052, 'leftArmWeapon'),
                    m('dome', 'steel', 0.39, 1.16, 0.30, 0.64, 0.14, 0.64, Math.PI * 0.5, 0.36, 0, 'leftArmWeapon'),
                    m('cylinder', coatMat, 0.41, 1.16, 0.31, 0.48, 0.04, 0.48, Math.PI * 0.5, 0.36, 0, 'leftArmWeapon'),
                    m('sphere', 'gold', 0.44, 1.16, 0.32, 0.14, 0.14, 0.12, 0, 0, 0, 'leftArmWeapon'),
                    limb(coatMat, -0.27, 1.32, 0.0, -0.34, 1.14, 0.08, 0.075, 0.062, 'rightArmWeapon'),
                    limb('steel', -0.34, 1.14, 0.08, hx, hy, hz, 0.062, 0.052, 'rightArmWeapon'),
                    m('sphere', 'leather', hx, hy, hz, 0.10, 0.10, 0.10, 0, 0, 0, 'rightArmWeapon'),
                    m('sphere', 'gold', hx, hy - 0.12 * cosS, hz - 0.12 * sinS, 0.075, 0.075, 0.075, 0, 0, 0, 'rightArmWeapon'),
                    m('cylinder', 'wood', hx, hy, hz, 0.045, 0.22, 0.045, swordPitch, 0, 0, 'rightArmWeapon'),
                    m('box', 'gold', hx, hy + 0.12 * cosS, hz + 0.12 * sinS, 0.26, 0.045, 0.055, -0.45, 0, 0, 'rightArmWeapon'),
                    m('box', 'gold', hx, hy + 0.02, hz + 0.08, 0.03, 0.20, 0.03, -0.45, 0, 0, 'rightArmWeapon'),
                    m('frustum', 'steel', hx, hy + 0.62 * cosS, hz + 0.62 * sinS, 0.085, 0.96, 0.03, swordPitch, 0, 0, 'rightArmWeapon')
                ];
            };

            const buildAnatomicalHorse1650 = (side, mountVariant) => {
                const isEnemy = side === 'enemy';
                const isHeavy = mountVariant === 'heavy_warhorse' || mountVariant === 'charger_horse';
                const isSteppe = mountVariant === 'steppe_horse';
                const isRouncey = mountVariant === 'rouncey_horse';

                let horseMat = isEnemy ? 'horseDark' : 'horseBay';
                if (mountVariant === 'charger_horse') horseMat = 'horseDark';
                if (mountVariant === 'courser_horse') horseMat = 'horseChestnut';
                if (mountVariant === 'steppe_horse') horseMat = 'horseDun';
                if (mountVariant === 'rouncey_horse') horseMat = 'horseBay';

                const clothMat = isEnemy ? 'enemyCloth' : 'playerCloth';
                const maneMat = (horseMat === 'horseDun') ? 'wood' : 'darkSteel';

                const wScale = isHeavy ? 1.04 : (isSteppe ? 0.93 : 0.96);
                const chestR = 0.37 * wScale;
                const croupR = 0.36 * wScale;
                const barrelW = 0.68 * wScale;
                const legX = 0.23 * wScale;

                const parts = [
                    m('cylinder', 'shadow', 0, 0.02, 0.02, isHeavy ? 1.56 : 1.42, 0.02, isHeavy ? 2.34 : 2.18, 0, 0, 0, 'shadow'),

                    m('sphere', horseMat, 0, 1.12, 0.54, chestR * 2.0, 0.72, 0.68, 0, 0, 0, 'horseBody'),
                    m('frustum', horseMat, 0, 1.04, 0.70, 0.44 * wScale, 0.46, 0.56 * wScale, 0.55, 0, 0, 'horseBody'),
                    m('cylinder', horseMat, 0, 1.10, -0.02, barrelW, 1.24, 0.72, Math.PI * 0.5, 0, 0, 'horseBody'),
                    m('sphere', horseMat, 0, 1.13, -0.58, croupR * 2.0, 0.70, 0.68, 0, 0, 0, 'horseBody'),
                    m('dome', horseMat, 0, 1.38, 0.38, 0.42 * wScale, 0.22, 0.48, 0, 0, 0, 'horseBody'),

                    limb(horseMat, -legX, 1.00, 0.54, -legX, 0.52, 0.59, 0.135 * wScale, 0.088 * wScale, 'horseLegFLUpper'),
                    limb(horseMat,  legX, 1.00, 0.54,  legX, 0.52, 0.59, 0.135 * wScale, 0.088 * wScale, 'horseLegFRUpper'),
                    m('sphere', horseMat, -legX, 0.52, 0.59, 0.16 * wScale, 0.15, 0.17, 0, 0, 0, 'horseLegFLLower'),
                    m('sphere', horseMat,  legX, 0.52, 0.59, 0.16 * wScale, 0.15, 0.17, 0, 0, 0, 'horseLegFRLower'),
                    limb(horseMat, -legX, 0.52, 0.59, -legX, 0.11, 0.57, 0.084 * wScale, 0.068 * wScale, 'horseLegFLLower'),
                    limb(horseMat,  legX, 0.52, 0.59,  legX, 0.11, 0.57, 0.084 * wScale, 0.068 * wScale, 'horseLegFRLower'),
                    m('sphere', horseMat, -legX, 0.12, 0.56, 0.13 * wScale, 0.11, 0.14, 0, 0, 0, 'horseLegFLLower'),
                    m('sphere', horseMat,  legX, 0.12, 0.56, 0.13 * wScale, 0.11, 0.14, 0, 0, 0, 'horseLegFRLower'),
                    m('frustum', 'darkSteel', -legX, 0.05, 0.58, 0.16 * wScale, 0.10, 0.18 * wScale, 0, 0, 0, 'horseLegFLLower'),
                    m('frustum', 'darkSteel',  legX, 0.05, 0.58, 0.16 * wScale, 0.10, 0.18 * wScale, 0, 0, 0, 'horseLegFRLower'),

                    limb(horseMat, -legX, 1.08, -0.54, -legX, 0.54, -0.68, 0.165 * wScale, 0.095 * wScale, 'horseLegHLUpper'),
                    limb(horseMat,  legX, 1.08, -0.54,  legX, 0.54, -0.68, 0.165 * wScale, 0.095 * wScale, 'horseLegHRUpper'),
                    m('sphere', horseMat, -legX, 0.54, -0.68, 0.17 * wScale, 0.17, 0.19, 0, 0, 0, 'horseLegHLLower'),
                    m('sphere', horseMat,  legX, 0.54, -0.68, 0.17 * wScale, 0.17, 0.19, 0, 0, 0, 'horseLegHRLower'),
                    limb(horseMat, -legX, 0.54, -0.68, -legX, 0.11, -0.60, 0.086 * wScale, 0.068 * wScale, 'horseLegHLLower'),
                    limb(horseMat,  legX, 0.54, -0.68,  legX, 0.11, -0.60, 0.086 * wScale, 0.068 * wScale, 'horseLegHRLower'),
                    m('sphere', horseMat, -legX, 0.12, -0.61, 0.13 * wScale, 0.11, 0.14, 0, 0, 0, 'horseLegHLLower'),
                    m('sphere', horseMat,  legX, 0.12, -0.61, 0.13 * wScale, 0.11, 0.14, 0, 0, 0, 'horseLegHRLower'),
                    m('frustum', 'darkSteel', -legX, 0.05, -0.59, 0.16 * wScale, 0.10, 0.18 * wScale, 0, 0, 0, 'horseLegHLLower'),
                    m('frustum', 'darkSteel',  legX, 0.05, -0.59, 0.16 * wScale, 0.10, 0.18 * wScale, 0, 0, 0, 'horseLegHRLower'),

                    limb(horseMat, 0, 1.24, 0.62, 0, 1.84, 1.00, 0.26 * wScale, 0.15 * wScale, 'horseNeckHead'),
                    m('box', maneMat, 0, 1.62, 0.72, 0.075, 0.76, 0.21, 0.56, 0, 0, 'horseNeckHead'),
                    m('cone', maneMat, 0, 1.94, 0.96, 0.085, 0.25, 0.17, 0.25, 0, 0, 'horseNeckHead'),
                    m('sphere', horseMat, 0, 1.84, 1.04, 0.29, 0.31, 0.35, 0, 0, 0, 'horseNeckHead'),
                    limb(horseMat, 0, 1.81, 1.08, 0, 1.65, 1.40, 0.145, 0.10, 'horseNeckHead'),
                    m('sphere', horseMat, 0, 1.64, 1.41, 0.185, 0.175, 0.195, 0, 0, 0, 'horseNeckHead'),
                    m('cone', horseMat, -0.09, 1.99, 1.00, 0.068, 0.19, 0.082, -0.15, 0,  0.16, 'horseNeckHead'),
                    m('cone', horseMat,  0.09, 1.99, 1.00, 0.068, 0.19, 0.082, -0.15, 0, -0.16, 'horseNeckHead'),

                    limb(maneMat, 0, 1.30, -0.86, 0, 0.96, -1.11, 0.078, 0.145, 'horseTail'),
                    limb(maneMat, 0, 0.96, -1.11, 0, 0.50, -1.22, 0.145, 0.068, 'horseTail'),

                    m('box', clothMat, 0, 1.18, -0.08, barrelW + 0.08, isHeavy ? 0.56 : 0.46, isHeavy ? 1.08 : 0.94, 0, 0, 0, 'horseBody'),
                    m('box', 'gold', 0, isHeavy ? 0.90 : 0.95, -0.08, barrelW + 0.10, 0.045, isHeavy ? 1.10 : 0.96, 0, 0, 0, 'horseBody'),
                    m('box', 'leather', 0, 1.43, -0.06, 0.54 * wScale, 0.11, 0.56, 0, 0, 0, 'horseBody'),
                    m('frustum', 'leather', 0, 1.50, 0.18, 0.44 * wScale, 0.14, 0.14, 0.25, 0, 0, 'horseBody'),
                    m('frustum', 'leather', 0, 1.52, -0.30, 0.46 * wScale, 0.18, 0.14, -0.28, 0, 0, 'horseBody'),
                    m('box', 'leather', 0, 1.15, 0.84, 0.54 * wScale, 0.06, 0.05, -0.35, 0, 0, 'horseBody'),
                    m('sphere', 'gold', 0, 1.14, 0.87, 0.11, 0.11, 0.05, 0, 0, 0, 'horseBody'),
                    m('cylinder', 'leather', 0, 1.71, 1.28, 0.22, 0.045, 0.24, 0.52, 0, 0, 'horseNeckHead'),
                    m('cylinder', 'leather', 0, 1.85, 1.12, 0.28, 0.045, 0.28, 0.52, 0, 0, 'horseNeckHead'),
                    m('sphere', 'gold', -0.11, 1.67, 1.32, 0.06, 0.06, 0.06, 0, 0, 0, 'horseNeckHead'),
                    m('sphere', 'gold',  0.11, 1.67, 1.32, 0.06, 0.06, 0.06, 0, 0, 0, 'horseNeckHead'),
                    limb('leather', -0.11, 1.67, 1.32, -0.07, 1.66, 0.34, 0.016, 0.016, 'horseBody'),
                    limb('leather',  0.11, 1.67, 1.32, -0.05, 1.66, 0.34, 0.016, 0.016, 'horseBody'),
                    m('box', 'leather', -0.40 * wScale, 1.18, 0.02, 0.03, 0.48, 0.05, -0.08, 0, -0.06, 'riderSaddle'),
                    m('box', 'leather',  0.40 * wScale, 1.18, 0.02, 0.03, 0.48, 0.05, -0.08, 0,  0.06, 'riderSaddle'),
                    m('box', 'steel', -0.41 * wScale, 0.93, 0.04, 0.04, 0.11, 0.13, 0, 0, 0, 'riderSaddle'),
                    m('box', 'steel',  0.41 * wScale, 0.93, 0.04, 0.04, 0.11, 0.13, 0, 0, 0, 'riderSaddle')
                ];

                if (isHeavy) {
                    parts.push(
                        m('box', 'steel', 0, 1.82, 1.18, 0.22, 0.07, 0.44, 0.52, 0, 0, 'horseNeckHead'),
                        m('box', 'gold',  0, 1.84, 1.18, 0.04, 0.08, 0.45, 0.52, 0, 0, 'horseNeckHead'),
                        m('box', 'steel', 0, 1.62, 0.77, 0.16, 0.58, 0.08, 0.56, 0, 0, 'horseNeckHead')
                    );
                }

                if (isRouncey || isSteppe) {
                    parts.push(
                        m('cylinder', 'linen', 0, 1.46, -0.46, 0.16, 0.54, 0.16, 0, 0, Math.PI * 0.5, 'horseBody'),
                        m('cylinder', 'leather', -0.14, 1.46, -0.46, 0.17, 0.03, 0.17, 0, 0, Math.PI * 0.5, 'horseBody'),
                        m('cylinder', 'leather',  0.14, 1.46, -0.46, 0.17, 0.03, 0.17, 0, 0, Math.PI * 0.5, 'horseBody')
                    );
                }

                return parts;
            };

            const buildCavalryUnit1650 = (side, weaponArchetype, mountVariant, riderVariant) => {
                const isEnemy = side === 'enemy';
                const isHeavyMount = mountVariant === 'heavy_warhorse' || mountVariant === 'charger_horse';
                const isSteppeMount = mountVariant === 'steppe_horse';
                const wScale = isHeavyMount ? 1.04 : (isSteppeMount ? 0.93 : 0.96);

                const coatMat = isEnemy ? 'enemyCloth' : 'playerCloth';
                const breechesMat = isEnemy ? 'enemyBreeches' : 'playerBreeches';
                const bootX = 0.41 * wScale;
                const kneeX = 0.39 * wScale;

                const parts = [
                    ...buildAnatomicalHorse1650(side, mountVariant),

                    m('frustum', breechesMat, 0, 1.48, -0.06, 0.44, 0.16, 0.34, Math.PI, 0, 0, 'riderLower'),

                    limb(breechesMat, -0.18, 1.48, -0.06, -kneeX, 1.24, 0.12, 0.11, 0.088, 'riderLower'),
                    limb(breechesMat,  0.18, 1.48, -0.06,  kneeX, 1.24, 0.12, 0.11, 0.088, 'riderLower'),
                    limb('leather', -kneeX, 1.24, 0.12, -bootX, 0.96, 0.03, 0.082, 0.066, 'riderLower'),
                    limb('leather',  kneeX, 1.24, 0.12,  bootX, 0.96, 0.03, 0.082, 0.066, 'riderLower'),
                    m('frustum', 'leather', -kneeX, 1.25, 0.11, 0.21, 0.10, 0.21, Math.PI, 0,  0.15, 'riderLower'),
                    m('frustum', 'leather',  kneeX, 1.25, 0.11, 0.21, 0.10, 0.21, Math.PI, 0, -0.15, 'riderLower'),
                    m('box', 'leather', -bootX, 0.93, 0.07, 0.11, 0.07, 0.23, 0.08, 0, 0, 'riderLower'),
                    m('box', 'leather',  bootX, 0.93, 0.07, 0.11, 0.07, 0.23, 0.08, 0, 0, 'riderLower'),

                    m('frustum', coatMat, 0, 1.56, -0.07, 0.48, 0.22, 0.36, 0, 0, 0, 'riderUpper'),
                    m('frustum', coatMat, 0, 1.82, -0.05, 0.48, 0.38, 0.31, Math.PI, 0, 0, 'riderUpper'),
                    m('cylinder', 'leather', 0, 1.63, -0.05, 0.40, 0.07, 0.30, 0, 0, 0, 'riderUpper'),
                    m('box', 'gold', 0, 1.63, 0.10, 0.085, 0.08, 0.03, 0, 0, 0, 'riderUpper'),

                    m('frustum', 'linen', 0, 2.02, -0.04, 0.28, 0.055, 0.26, 0, 0, 0, 'riderUpper'),
                    m('cylinder', 'skin', 0, 2.07, -0.04, 0.13, 0.09, 0.13, 0, 0, 0, 'riderUpper'),
                    m('sphere', 'skin', 0, 2.16, -0.03, 0.22, 0.25, 0.23, 0, 0, 0, 'riderUpper'),
                    m('cone', 'wood', 0, 2.08, 0.06, 0.10, 0.09, 0.07, Math.PI + 0.2, 0, 0, 'riderUpper')
                ];

                if (riderVariant === 'heavy_cuirassier') {
                    parts.push(
                        m('frustum', 'steel', 0, 1.82, -0.045, 0.50, 0.35, 0.33, Math.PI, 0, 0, 'riderUpper'),
                        m('box', 'steel', 0, 1.82, 0.12, 0.05, 0.31, 0.04, -0.06, 0, 0, 'riderUpper'),
                        m('box', 'steel', -0.16, 1.54, 0.10, 0.16, 0.18, 0.03, -0.35, -0.15, 0.08, 'riderUpper'),
                        m('box', 'steel',  0.16, 1.54, 0.10, 0.16, 0.18, 0.03, -0.35,  0.15, -0.08, 'riderUpper'),
                        m('dome', 'steel', -0.26, 1.94, -0.05, 0.23, 0.19, 0.24, 0, 0,  0.22, 'riderUpper'),
                        m('dome', 'steel',  0.26, 1.94, -0.05, 0.23, 0.19, 0.24, 0, 0, -0.22, 'riderUpper'),
                        m('dome', 'steel', 0, 2.19, -0.03, 0.26, 0.23, 0.28, 0, 0, 0, 'riderUpper'),
                        m('box', 'steel', 0, 2.19, 0.12, 0.24, 0.025, 0.12, 0.20, 0, 0, 'riderUpper'),
                        m('box', 'gold',  0, 2.14, 0.14, 0.025, 0.14, 0.025, 0, 0, 0, 'riderUpper'),
                        m('frustum', 'steel', 0, 2.09, -0.16, 0.26, 0.16, 0.18, -0.45, 0, 0, 'riderUpper'),
                        m('box', coatMat, 0, 2.33, -0.08, 0.07, 0.18, 0.24, 0, 0, 0, 'riderUpper')
                    );
                } else if (riderVariant === 'harquebusier') {
                    parts.push(
                        m('frustum', 'steel', 0, 1.83, -0.04, 0.49, 0.33, 0.32, Math.PI, 0, 0, 'riderUpper'),
                        m('dome', 'steel', -0.25, 1.94, -0.05, 0.20, 0.16, 0.21, 0, 0,  0.20, 'riderUpper'),
                        m('dome', 'steel',  0.25, 1.94, -0.05, 0.20, 0.16, 0.21, 0, 0, -0.20, 'riderUpper'),
                        m('dome', 'steel', 0, 2.19, -0.03, 0.26, 0.23, 0.28, 0, 0, 0, 'riderUpper'),
                        m('box', 'gold', 0, 2.32, -0.03, 0.035, 0.10, 0.28, 0, 0, 0, 'riderUpper'),
                        m('box', 'steel', 0, 2.19, 0.12, 0.23, 0.025, 0.11, 0.22, 0, 0, 'riderUpper')
                    );
                } else if (riderVariant === 'reiter') {
                    parts.push(
                        m('frustum', 'darkSteel', 0, 1.83, -0.04, 0.50, 0.34, 0.33, Math.PI, 0, 0, 'riderUpper'),
                        m('box', 'gold', 0, 1.83, 0.125, 0.04, 0.30, 0.03, -0.06, 0, 0, 'riderUpper'),
                        m('dome', 'darkSteel', -0.25, 1.94, -0.05, 0.21, 0.17, 0.22, 0, 0,  0.20, 'riderUpper'),
                        m('dome', 'darkSteel',  0.25, 1.94, -0.05, 0.21, 0.17, 0.22, 0, 0, -0.20, 'riderUpper'),
                        m('dome', 'darkSteel', 0, 2.19, -0.03, 0.26, 0.23, 0.28, 0, 0, 0, 'riderUpper'),
                        m('box', 'gold', 0, 2.32, -0.03, 0.035, 0.10, 0.28, 0, 0, 0, 'riderUpper'),
                        m('frustum', 'leather', 0.24, 1.46, 0.22, 0.10, 0.26, 0.10, 0.45, 0, -0.2, 'riderLower')
                    );
                } else if (riderVariant === 'dragoon') {
                    parts.push(
                        m('frustum', 'leather', 0, 1.82, -0.045, 0.49, 0.35, 0.32, Math.PI, 0, 0, 'riderUpper'),
                        m('box', 'wood', 0, 1.82, 0.115, 0.42, 0.055, 0.03, 0, 0, -0.68, 'riderUpper'),
                        m('frustum', 'darkSteel', 0, 2.23, -0.03, 0.54, 0.03, 0.54, -0.08, 0.1, -0.06, 'riderUpper'),
                        m('frustum', 'darkSteel', 0, 2.31, -0.04, 0.27, 0.16, 0.28, 0, 0, 0, 'riderUpper'),
                        m('cylinder', 'gold', 0, 2.26, -0.035, 0.28, 0.025, 0.29, 0, 0, 0, 'riderUpper'),
                        m('cone', coatMat, 0.13, 2.34, -0.16, 0.10, 0.32, 0.05, -1.15, 0.35, -0.3, 'riderUpper')
                    );
                } else {
                    parts.push(
                        m('frustum', 'darkSteel', 0, 1.82, -0.045, 0.48, 0.34, 0.31, Math.PI, 0, 0, 'riderUpper'),
                        m('cylinder', 'leather', 0, 2.23, -0.03, 0.28, 0.11, 0.29, 0, 0, 0, 'riderUpper'),
                        m('dome', coatMat, 0, 2.27, -0.03, 0.24, 0.18, 0.25, 0, 0, 0, 'riderUpper'),
                        m('sphere', 'gold', 0, 2.36, -0.03, 0.06, 0.06, 0.06, 0, 0, 0, 'riderUpper')
                    );
                }

                const armMat = (riderVariant === 'heavy_cuirassier') ? 'steel' : coatMat;
                if (weaponArchetype !== 'cavalry_carbine') {
                    parts.push(
                        limb(coatMat, 0.25, 1.92, -0.04, 0.24, 1.72, 0.14, 0.072, 0.058, 'riderUpper'),
                        limb(armMat, 0.24, 1.72, 0.14, -0.06, 1.66, 0.34, 0.058, 0.048, 'riderUpper'),
                        m('sphere', 'leather', -0.06, 1.66, 0.34, 0.10, 0.10, 0.10, 0, 0, 0, 'riderUpper')
                    );
                }

                if (weaponArchetype === 'cavalry_lance') {
                    const lanceAngle = 1.32;
                    const lanceArmParts = [
                        limb(coatMat, -0.25, 1.92, -0.04, -0.33, 1.72, 0.06, 0.072, 0.058, 'riderUpper'),
                        limb(armMat, -0.33, 1.72, 0.06, -0.31, 1.68, 0.30, 0.058, 0.048, 'riderUpper'),
                        m('sphere', 'leather', -0.31, 1.68, 0.30, 0.10, 0.10, 0.10, 0, 0, 0, 'riderUpper'),
                        m('cone', 'steel', -0.31, 1.71, 0.42, 0.18, 0.14, 0.18, lanceAngle, 0, 0, 'riderUpper'),
                        m('cylinder', 'wood', -0.31, 1.90, 1.15, 0.045, 3.45, 0.045, lanceAngle, 0, 0, 'riderUpper'),
                        m('cone', 'steel', -0.31, 2.34, 2.86, 0.10, 0.32, 0.06, lanceAngle, 0, 0, 'riderUpper'),
                        m('box', coatMat, -0.31, 2.16, 2.38, 0.025, 0.24, 0.44, lanceAngle, 0, 0, 'riderUpper'),
                        m('box', 'gold',  -0.31, 2.26, 2.38, 0.028, 0.04, 0.44, lanceAngle, 0, 0, 'riderUpper')
                    ];
                    for (let i = 0; i < lanceArmParts.length; i++) {
                        lanceArmParts[i].subGroup = 'lance';
                    }
                    parts.push(...lanceArmParts);
                } else if (weaponArchetype === 'cavalry_carbine') {
                    const cYaw = 0.14;
                    const cPitch = Math.PI * 0.5 - 0.08;
                    parts.push(
                        limb(coatMat, -0.25, 1.92, -0.04, -0.30, 1.75, 0.10, 0.072, 0.058, 'riderUpper'),
                        limb(armMat, -0.30, 1.75, 0.10, -0.17, 1.82, 0.28, 0.056, 0.046, 'riderUpper'),
                        m('sphere', 'leather', -0.17, 1.82, 0.28, 0.095, 0.095, 0.095, 0, 0, 0, 'riderUpper'),
                        limb(coatMat, 0.25, 1.92, -0.04, 0.14, 1.74, 0.30, 0.072, 0.058, 'riderUpper'),
                        limb(armMat, 0.14, 1.74, 0.30, -0.10, 1.85, 0.62, 0.056, 0.046, 'riderUpper'),
                        m('sphere', 'leather', -0.10, 1.85, 0.62, 0.095, 0.095, 0.095, 0, 0, 0, 'riderUpper'),
                        m('box', 'wood', -0.18, 1.80, 0.14, 0.07, 0.14, 0.32, -0.24, cYaw, 0, 'riderUpper'),
                        m('frustum', 'wood', -0.12, 1.85, 0.54, 0.068, 0.56, 0.078, cPitch, cYaw, 0, 'riderUpper'),
                        m('cylinder', 'darkSteel', -0.10, 1.88, 0.68, 0.048, 0.84, 0.048, cPitch, cYaw, 0, 'riderUpper'),
                        m('cylinder', 'gold', -0.045, 1.91, 1.07, 0.056, 0.045, 0.056, cPitch, cYaw, 0, 'riderUpper'),
                        m('box', 'gold', -0.15, 1.87, 0.34, 0.065, 0.04, 0.07, 0, cYaw, 0, 'riderUpper')
                    );
                } else if (weaponArchetype === 'cavalry_pistol') {
                    const pPitch = Math.PI * 0.5 - 0.12;
                    parts.push(
                        limb(coatMat, -0.25, 1.92, -0.04, -0.30, 1.86, 0.22, 0.072, 0.058, 'riderUpper'),
                        limb(armMat, -0.30, 1.86, 0.22, -0.28, 1.90, 0.46, 0.056, 0.046, 'riderUpper'),
                        m('sphere', 'leather', -0.28, 1.90, 0.46, 0.095, 0.095, 0.095, 0, 0, 0, 'riderUpper'),
                        m('cylinder', 'wood', -0.28, 1.84, 0.44, 0.052, 0.20, 0.062, -0.55, 0, 0, 'riderUpper'),
                        m('sphere', 'gold', -0.28, 1.75, 0.39, 0.085, 0.085, 0.085, 0, 0, 0, 'riderUpper'),
                        m('cylinder', 'darkSteel', -0.28, 1.93, 0.68, 0.046, 0.46, 0.046, pPitch, 0, 0, 'riderUpper'),
                        m('cylinder', 'gold', -0.255, 1.92, 0.54, 0.065, 0.025, 0.065, 0, 0, Math.PI * 0.5, 'riderUpper')
                    );
                } else {
                    const sabrePitch = Math.PI * 0.5 - 0.48;
                    const sinSb = Math.sin(sabrePitch);
                    const cosSb = Math.cos(sabrePitch);
                    const hx = -0.32;
                    const hy = 1.84;
                    const hz = 0.34;
                    parts.push(
                        limb(coatMat, -0.25, 1.92, -0.04, -0.34, 1.80, 0.14, 0.072, 0.058, 'riderRightArmWeapon'),
                        limb(armMat, -0.34, 1.80, 0.14, hx, hy, hz, 0.056, 0.046, 'riderRightArmWeapon'),
                        m('sphere', 'leather', hx, hy, hz, 0.095, 0.095, 0.095, 0, 0, 0, 'riderRightArmWeapon'),
                        m('sphere', 'gold', hx, hy - 0.11 * cosSb, hz - 0.11 * sinSb, 0.07, 0.07, 0.07, 0, 0, 0, 'riderRightArmWeapon'),
                        m('cylinder', 'wood', hx, hy, hz, 0.042, 0.20, 0.042, sabrePitch, 0, 0, 'riderRightArmWeapon'),
                        m('box', 'gold', hx, hy + 0.11 * cosSb, hz + 0.11 * sinSb, 0.24, 0.04, 0.05, -0.48, 0, 0, 'riderRightArmWeapon'),
                        m('box', 'gold', hx, hy + 0.02, hz + 0.07, 0.028, 0.18, 0.028, -0.48, 0, 0, 'riderRightArmWeapon'),
                        m('frustum', 'steel', hx, hy + 0.60 * cosSb, hz + 0.60 * sinSb, 0.08, 0.94, 0.028, sabrePitch, 0, 0, 'riderRightArmWeapon')
                    );
                }

                return parts;
            };


            /* ============================================================================
             * G3D-03J OSMANLI VE AVRUPA / HRE TARİHSEL MODEL ŞABLONLARI
             * ============================================================================ */

            const ottomanHumanBase = (side, options = {}) => {
                const isEnemy = side === 'enemy';
                const kaftanMat = options.kaftanMat || (isEnemy ? 'enemyCloth' : 'ottomanCrimson');
                const salvarMat = options.salvarMat || 'ottomanNavy';
                const kusakMat = options.kusakMat || 'ottomanSaffron';

                return [
                    m('cylinder', 'shadow', 0, 0.02, 0, 1.08, 0.02, 1.08, 0, 0, 0, 'shadow'),
                    // Yemeni leather shoes
                    m('box', 'leather', -0.14, 0.025, 0.04, 0.12, 0.05, 0.24, 0, 0, 0, 'leftLegLower'),
                    m('box', 'leather',  0.14, 0.025, 0.04, 0.12, 0.05, 0.24, 0, 0, 0, 'rightLegLower'),
                    // Salvar baggy trousers
                    m('frustum', salvarMat, -0.14, 0.24, 0.0, 0.19, 0.42, 0.21, 0, 0, 0, 'leftLegLower'),
                    m('frustum', salvarMat,  0.14, 0.24, 0.0, 0.19, 0.42, 0.21, 0, 0, 0, 'rightLegLower'),
                    m('sphere', salvarMat, -0.14, 0.48, 0.01, 0.22, 0.12, 0.23, 0, 0, 0, 'leftLegLower'),
                    m('sphere', salvarMat,  0.14, 0.48, 0.01, 0.22, 0.12, 0.23, 0, 0, 0, 'rightLegLower'),
                    m('frustum', salvarMat, -0.14, 0.68, 0.0, 0.24, 0.38, 0.25, Math.PI, 0, 0, 'leftLegUpper'),
                    m('frustum', salvarMat,  0.14, 0.68, 0.0, 0.24, 0.38, 0.25, Math.PI, 0, 0, 'rightLegUpper'),
                    // Draped Kaftan lower skirt (split front)
                    m('frustum', kaftanMat, 0, 0.86, -0.01, 0.54, 0.32, 0.40, 0, 0, 0, 'torso'),
                    m('frustum', 'gold', 0, 0.71, -0.01, 0.55, 0.025, 0.41, 0, 0, 0, 'torso'),
                    // Upper Dolaman jacket torso
                    m('frustum', kaftanMat, 0, 1.20, 0.0, 0.52, 0.44, 0.34, Math.PI, 0, 0, 'torso'),
                    // Broad silk Kusak sash
                    m('cylinder', kusakMat, 0, 0.98, 0.0, 0.44, 0.10, 0.33, 0, 0, 0, 'torso'),
                    m('box', 'gold', 0, 0.98, 0.17, 0.10, 0.09, 0.04, 0, 0, 0, 'torso'),
                    // Yatagan scabbard tucked in sash
                    m('box', 'leather', 0.22, 0.98, 0.10, 0.04, 0.12, 0.38, 0.42, 0.25, -0.2, 'torso'),
                    m('box', 'gold', 0.23, 0.99, 0.28, 0.05, 0.14, 0.08, 0.42, 0.25, -0.2, 'torso'),
                    // Neck
                    m('cylinder', 'skin', 0, 1.46, 0.01, 0.13, 0.12, 0.13, 0, 0, 0, 'torso'),
                    // Head
                    m('sphere', 'skin', 0, 1.58, 0.02, 0.24, 0.26, 0.25, 0, 0, 0, 'torso'),
                    // Drooping Ottoman mustache
                    m('cone', 'wood', 0, 1.51, 0.13, 0.14, 0.08, 0.07, Math.PI + 0.3, 0, 0, 'torso')
                ];
            };

            // 1. Yeniçeri (Janissary)
            const buildOttomanJanissary = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                const borkParts = [
                    // Zarf (brass spoon holder)
                    m('box', 'gold', 0, 1.68, 0.15, 0.06, 0.18, 0.04, 0.1, 0, 0, 'torso'),
                    // White felt Bork crown
                    m('frustum', 'ottomanWhite', 0, 1.82, 0.02, 0.28, 0.32, 0.29, 0, 0, 0, 'torso'),
                    // Rear flowing flap
                    m('frustum', 'ottomanWhite', 0, 1.58, -0.15, 0.24, 0.46, 0.08, -0.35, 0, 0, 'torso'),
                    m('sphere', 'gold', 0, 1.76, 0.16, 0.05, 0.05, 0.03, 0, 0, 0, 'torso')
                ];

                if (variant === 1) {
                    // Tufenkli Janissary (Ranged)
                    const bYaw = 0.14;
                    const bPitch = Math.PI * 0.5 - 0.08;
                    return [
                        ...base,
                        ...borkParts,
                        limb('ottomanCrimson', -0.26, 1.33, 0.0, -0.32, 1.14, 0.08, 0.075, 0.062, 'twoHandMusket'),
                        limb('linen', -0.32, 1.14, 0.08, -0.17, 1.24, 0.28, 0.058, 0.048, 'twoHandMusket'),
                        m('sphere', 'skin', -0.17, 1.24, 0.28, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandMusket'),
                        limb('ottomanCrimson', 0.26, 1.33, 0.0, 0.16, 1.14, 0.36, 0.075, 0.062, 'twoHandMusket'),
                        limb('linen', 0.16, 1.14, 0.36, -0.10, 1.27, 0.72, 0.058, 0.048, 'twoHandMusket'),
                        m('sphere', 'skin', -0.10, 1.27, 0.72, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandMusket'),
                        // Long Ottoman Tufenk musket
                        m('box', 'wood', -0.185, 1.22, 0.14, 0.075, 0.15, 0.34, -0.26, bYaw, 0, 'twoHandMusket'),
                        m('cylinder', 'damascusSteel', -0.095, 1.305, 0.82, 0.052, 1.26, 0.052, bPitch, bYaw, 0, 'twoHandMusket'),
                        m('cylinder', 'bronze', -0.095, 1.305, 0.65, 0.056, 0.04, 0.056, bPitch, bYaw, 0, 'twoHandMusket'),
                        m('cylinder', 'bronze', -0.035, 1.332, 1.34, 0.058, 0.05, 0.058, bPitch, bYaw, 0, 'twoHandMusket'),
                        m('box', 'leather', 0.18, 1.05, -0.08, 0.12, 0.14, 0.08, 0, 0, 0, 'torso')
                    ];
                } else {
                    // Yataganli & Cevsenli Janissary (Melee)
                    return [
                        ...base,
                        ...borkParts,
                        // Steel cevsen chest disc
                        m('cylinder', 'damascusSteel', 0, 1.22, 0.175, 0.26, 0.025, 0.26, Math.PI * 0.5, 0, 0, 'torso'),
                        m('sphere', 'gold', 0, 1.22, 0.19, 0.07, 0.07, 0.07, 0, 0, 0, 'torso'),
                        // Left arm holding round kalkan shield
                        limb('ottomanCrimson', 0.27, 1.32, 0.0, 0.34, 1.15, 0.10, 0.075, 0.062, 'leftArmWeapon'),
                        limb('leather', 0.34, 1.15, 0.10, 0.36, 1.16, 0.28, 0.062, 0.052, 'leftArmWeapon'),
                        m('dome', 'damascusSteel', 0.39, 1.16, 0.30, 0.58, 0.12, 0.58, Math.PI * 0.5, 0.36, 0, 'leftArmWeapon'),
                        m('sphere', 'bronze', 0.44, 1.16, 0.32, 0.14, 0.14, 0.12, 0, 0, 0, 'leftArmWeapon'),
                        // Right arm holding curved yatagan
                        limb('ottomanCrimson', -0.27, 1.32, 0.0, -0.34, 1.14, 0.08, 0.075, 0.062, 'rightArmWeapon'),
                        limb('skin', -0.34, 1.14, 0.08, -0.30, 1.12, 0.30, 0.062, 0.052, 'rightArmWeapon'),
                        m('sphere', 'skin', -0.30, 1.12, 0.30, 0.10, 0.10, 0.10, 0, 0, 0, 'rightArmWeapon'),
                        // Yatagan forward blade
                        m('box', 'gold', -0.30, 1.12, 0.38, 0.04, 0.12, 0.05, 0, 0, 0, 'rightArmWeapon'),
                        m('frustum', 'damascusSteel', -0.30, 1.16, 0.72, 0.07, 0.68, 0.025, Math.PI * 0.5 - 0.2, 0, 0, 'rightArmWeapon')
                    ];
                }
            };

            // 2. Azap (Azap Hafif Piyadesi)
            const buildOttomanAzap = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'linen', salvarMat: 'leather', kusakMat: 'ottomanCrimson' });
                const sarikParts = [
                    m('cylinder', 'ottomanWhite', 0, 1.66, 0.02, 0.32, 0.12, 0.32, 0, 0, 0, 'torso'),
                    m('cone', 'ottomanCrimson', 0, 1.76, 0.02, 0.18, 0.18, 0.18, 0, 0, 0, 'torso')
                ];

                if (variant === 1) {
                    // Tirpanli / Kargili Azap
                    const pAngleX = Math.atan2(0.38, 0.24);
                    const cosP = Math.cos(pAngleX);
                    const sinP = Math.sin(pAngleX);
                    const px = -0.32, p1y = 1.08, p1z = 0.18;
                    return [
                        ...base,
                        ...sarikParts,
                        limb('linen', -0.27, 1.32, 0.0, -0.34, 1.12, -0.04, 0.075, 0.062, 'twoHandPike'),
                        limb('skin', -0.34, 1.12, -0.04, px, p1y, p1z, 0.062, 0.052, 'twoHandPike'),
                        m('sphere', 'skin', px, p1y, p1z, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                        limb('linen', 0.27, 1.32, 0.0, 0.08, 1.18, 0.26, 0.075, 0.062, 'twoHandPike'),
                        limb('skin', 0.08, 1.18, 0.26, px, 1.32, 0.56, 0.062, 0.052, 'twoHandPike'),
                        m('sphere', 'skin', px, 1.32, 0.56, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                        m('cylinder', 'wood', px, p1y + 1.18 * cosP, p1z + 1.18 * sinP, 0.042, 3.85, 0.042, pAngleX, 0, 0, 'twoHandPike'),
                        m('cone', 'damascusSteel', px, p1y + 3.05 * cosP, p1z + 3.05 * sinP, 0.09, 0.42, 0.04, pAngleX, 0, 0, 'twoHandPike')
                    ];
                } else {
                    // Kilicli Azap
                    return [
                        ...base,
                        ...sarikParts,
                        limb('linen', 0.27, 1.32, 0.0, 0.34, 1.15, 0.10, 0.075, 0.062, 'leftArmWeapon'),
                        limb('skin', 0.34, 1.15, 0.10, 0.36, 1.16, 0.28, 0.062, 0.052, 'leftArmWeapon'),
                        m('dome', 'leather', 0.39, 1.16, 0.30, 0.52, 0.11, 0.52, Math.PI * 0.5, 0.36, 0, 'leftArmWeapon'),
                        limb('linen', -0.27, 1.32, 0.0, -0.34, 1.14, 0.08, 0.075, 0.062, 'rightArmWeapon'),
                        limb('skin', -0.34, 1.14, 0.08, -0.30, 1.12, 0.30, 0.062, 0.052, 'rightArmWeapon'),
                        m('sphere', 'skin', -0.30, 1.12, 0.30, 0.10, 0.10, 0.10, 0, 0, 0, 'rightArmWeapon'),
                        m('frustum', 'damascusSteel', -0.30, 1.16, 0.65, 0.065, 0.74, 0.024, Math.PI * 0.5 - 0.3, 0, 0, 'rightArmWeapon')
                    ];
                }
            };

            // 3. Humbaracı (Bombardier / Grenadier)
            const buildOttomanHumbaraci = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanEmerald', salvarMat: 'leather', kusakMat: 'leather' });
                return [
                    ...base,
                    // Leather apron
                    m('box', 'leather', 0, 1.05, 0.18, 0.36, 0.42, 0.04, 0, 0, 0, 'torso'),
                    // Sarik
                    m('cylinder', 'ottomanWhite', 0, 1.66, 0.02, 0.32, 0.12, 0.32, 0, 0, 0, 'torso'),
                    m('cone', 'ottomanEmerald', 0, 1.76, 0.02, 0.18, 0.16, 0.18, 0, 0, 0, 'torso'),
                    // Grenade pouch
                    m('box', 'leather', -0.22, 0.94, 0.05, 0.14, 0.16, 0.14, 0, 0, 0, 'torso'),
                    // Arm holding Humbara (iron grenade)
                    limb('ottomanEmerald', -0.27, 1.32, 0.0, -0.34, 1.20, 0.15, 0.075, 0.062, 'rightArmWeapon'),
                    limb('skin', -0.34, 1.20, 0.15, -0.28, 1.28, 0.38, 0.062, 0.052, 'rightArmWeapon'),
                    m('sphere', 'skin', -0.28, 1.28, 0.38, 0.10, 0.10, 0.10, 0, 0, 0, 'rightArmWeapon'),
                    // Iron sphere grenade with burning fuse
                    m('sphere', 'darkSteel', -0.28, 1.40, 0.42, 0.16, 0.16, 0.16, 0, 0, 0, 'rightArmWeapon'),
                    m('cone', 'gold', -0.28, 1.50, 0.42, 0.04, 0.08, 0.04, 0, 0, 0, 'rightArmWeapon')
                ];
            };

            // 4. Bostancı (Palace Elite Guard)
            const buildOttomanBostanci = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                const bostanciHead = [
                    // Tall red Bostanci kulah
                    m('cone', 'ottomanCrimson', 0, 1.88, 0.02, 0.26, 0.52, 0.26, 0, 0, 0, 'torso'),
                    m('cylinder', 'gold', 0, 1.63, 0.02, 0.28, 0.04, 0.28, 0, 0, 0, 'torso'),
                    // Heavy cevsen mail & plate armor
                    m('frustum', 'damascusSteel', 0, 1.20, 0.005, 0.54, 0.40, 0.36, Math.PI, 0, 0, 'torso'),
                    m('cylinder', 'gold', 0, 1.24, 0.185, 0.22, 0.02, 0.22, Math.PI * 0.5, 0, 0, 'torso')
                ];

                const pAngleX = Math.atan2(0.38, 0.24);
                const cosP = Math.cos(pAngleX);
                const sinP = Math.sin(pAngleX);
                const px = -0.32, p1y = 1.08, p1z = 0.18;

                return [
                    ...base,
                    ...bostanciHead,
                    limb('ottomanCrimson', -0.27, 1.32, 0.0, -0.34, 1.12, -0.04, 0.075, 0.062, 'twoHandPike'),
                    limb('damascusSteel', -0.34, 1.12, -0.04, px, p1y, p1z, 0.062, 0.052, 'twoHandPike'),
                    m('sphere', 'skin', px, p1y, p1z, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                    limb('ottomanCrimson', 0.27, 1.32, 0.0, 0.08, 1.18, 0.26, 0.075, 0.062, 'twoHandPike'),
                    limb('damascusSteel', 0.08, 1.18, 0.26, px, 1.32, 0.56, 0.062, 0.052, 'twoHandPike'),
                    m('sphere', 'skin', px, 1.32, 0.56, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                    // Heavy Teber (crescent poleaxe)
                    m('cylinder', 'wood', px, p1y + 1.18 * cosP, p1z + 1.18 * sinP, 0.045, 3.20, 0.045, pAngleX, 0, 0, 'twoHandPike'),
                    m('cone', 'gold', px, p1y + 2.70 * cosP, p1z + 2.70 * sinP, 0.26, 0.38, 0.05, pAngleX, 0, 0, 'twoHandPike')
                ];
            };

            // 5. Levend (Irregular / Coastal Skirmisher)
            const buildOttomanLevend = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanNavy', salvarMat: 'linen', kusakMat: 'ottomanCrimson' });
                return [
                    ...base,
                    // Striped headwrap
                    m('cylinder', 'ottomanSaffron', 0, 1.66, 0.02, 0.32, 0.12, 0.32, 0, 0, 0, 'torso'),
                    m('cone', 'ottomanNavy', 0, 1.74, 0.02, 0.20, 0.16, 0.20, 0, 0, 0, 'torso'),
                    // Dual pistols in sash
                    m('box', 'wood', 0.12, 1.04, 0.18, 0.05, 0.16, 0.08, 0.45, 0, -0.2, 'torso'),
                    m('box', 'wood', -0.12, 1.04, 0.18, 0.05, 0.16, 0.08, 0.45, 0, 0.2, 'torso')
                ];
            };

            // 6. Sipahi (Timarlı Süvari)
            const buildOttomanSipahi = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'courser_horse', 'harquebusier');
                return [
                    ...cavBase,
                    // Şişak Tolga Helmet spike
                    m('cone', 'gold', 0, 2.36, -0.03, 0.12, 0.26, 0.12, 0, 0, 0, 'riderUpper'),
                    m('cylinder', 'damascusSteel', 0, 2.22, -0.03, 0.28, 0.06, 0.28, 0, 0, 0, 'riderUpper'),
                    // Wicker Kalkan on left arm
                    m('dome', 'gold', 0.36, 1.74, 0.26, 0.52, 0.12, 0.52, Math.PI * 0.5, 0.36, 0, 'riderUpper')
                ];
            };

            // 7. Kapıkulu Sipahisi (Imperial Heavy Guard Cavalry)
            const buildOttomanKapikuluSipahi = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'heavy_warhorse', 'heavy_cuirassier');
                return [
                    ...cavBase,
                    // Char-aina mirror breastplate
                    m('box', 'damascusSteel', 0, 1.84, 0.17, 0.32, 0.34, 0.05, 0, 0, 0, 'riderUpper'),
                    m('cylinder', 'gold', 0, 1.84, 0.198, 0.18, 0.02, 0.18, Math.PI * 0.5, 0, 0, 'riderUpper'),
                    // Horse steel chamfron (alınlık)
                    m('cone', 'damascusSteel', 0, 1.58, 1.56, 0.22, 0.42, 0.14, 0.65, 0, 0, 'horseNeckHead')
                ];
            };

            // 8. Deli Süvarisi (Daring Vanguard Shock Cavalry)
            const buildOttomanDeli = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'courser_horse', 'light_skirmisher');
                return [
                    ...cavBase,
                    // Leopard Pelt draped over torso
                    m('frustum', 'leopardPelt', 0, 1.84, -0.04, 0.52, 0.36, 0.34, Math.PI, 0, 0, 'riderUpper'),
                    // Winged headdress (Deli kartal kanatları)
                    m('box', 'ottomanWhite', -0.18, 2.38, -0.06, 0.03, 0.38, 0.16, -0.3, 0, 0.2, 'riderUpper'),
                    m('box', 'ottomanWhite',  0.18, 2.38, -0.06, 0.03, 0.38, 0.16, -0.3, 0, -0.2, 'riderUpper'),
                    m('cone', 'ottomanCrimson', 0, 2.32, -0.03, 0.18, 0.32, 0.18, 0, 0, 0, 'riderUpper')
                ];
            };

            // 9. Ciritçi (Javelin Light Skirmisher Cavalry)
            const buildOttomanCiritci = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'steppe_horse', 'light_skirmisher');
                return [
                    ...cavBase,
                    // Saddle quiver with 3 javelins
                    m('cylinder', 'leather', 0.26, 1.34, -0.20, 0.12, 0.55, 0.12, 0.35, 0, 0.2, 'horseBody'),
                    m('cylinder', 'wood', 0.26, 1.62, -0.12, 0.03, 0.85, 0.03, 0.35, 0, 0.2, 'horseBody')
                ];
            };

            // 10. Akıncı (Mounted Archer / Steppe Cavalry)
            const buildOttomanAkinci = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_carbine', 'steppe_horse', 'light_skirmisher');
                return [
                    ...cavBase,
                    // Composite recurve bow & arrow quiver (tirkeş)
                    m('box', 'leather', -0.28, 1.38, -0.15, 0.14, 0.60, 0.12, -0.3, 0, -0.2, 'horseBody'),
                    m('cylinder', 'wood', -0.28, 1.72, -0.08, 0.04, 0.80, 0.04, -0.3, 0, -0.2, 'horseBody')
                ];
            };

            // 11. HRE Pikeniere
            const buildHREPikeniere = (side, variant = 1) => {
                return buildInfantryPikeman(side);
            };

            // 12. HRE Musketier
            const buildHREMusketier = (side, variant = 1) => {
                return buildInfantryMusketeer(side);
            };

            // 13. HRE Hellebardier (Halberdier)
            const buildHREHellebardier = (side, variant = 1) => {
                const base = buildInfantrySwordsman(side);
                return [
                    ...base,
                    // Halberd ax blade on weapon
                    m('box', 'steel', -0.30, 1.72, 0.65, 0.24, 0.28, 0.03, -0.45, 0, 0, 'rightArmWeapon')
                ];
            };

            // 14. HRE Kürassier (Heavy Cuirassier)
            const buildHRECurassier = (side, variant = 1) => {
                return buildCavalryUnit1650(side, 'cavalry_pistol', 'heavy_warhorse', 'heavy_cuirassier');
            };

            // 15. HRE Reiter (Blackened Carbine Cavalry)
            const buildHREReiter = (side, variant = 1) => {
                return buildCavalryUnit1650(side, 'cavalry_carbine', 'charger_horse', 'reiter');
            };
    
            const templates = {
                'player:infantry_pikeman': buildInfantryPikeman('player'),
                'enemy:infantry_pikeman': buildInfantryPikeman('enemy'),
                'player:infantry_musketeer': buildInfantryMusketeer('player'),
                'enemy:infantry_musketeer': buildInfantryMusketeer('enemy'),
                'player:infantry_swordsman': buildInfantrySwordsman('player'),
                'enemy:infantry_swordsman': buildInfantrySwordsman('enemy')
            };

            const sides = ['player', 'enemy'];
            const weapons = ['cavalry_lance', 'cavalry_sabre', 'cavalry_carbine', 'cavalry_pistol'];
            const mounts = ['heavy_warhorse', 'charger_horse', 'courser_horse', 'rouncey_horse', 'steppe_horse'];
            const riders = ['heavy_cuirassier', 'harquebusier', 'reiter', 'dragoon', 'light_skirmisher'];

            for (let s = 0; s < sides.length; s++) {
                for (let w = 0; w < weapons.length; w++) {
                    for (let mt = 0; mt < mounts.length; mt++) {
                        for (let rd = 0; rd < riders.length; rd++) {
                            const key = `${sides[s]}:${weapons[w]}:${mounts[mt]}:${riders[rd]}`;
                            templates[key] = buildCavalryUnit1650(sides[s], weapons[w], mounts[mt], riders[rd]);
                        }
                    }
                }
            }


            // ============================================================================
            // G3D-03J OSMANLI VE AVRUPA TARİHSEL ŞABLONLARININ KAYDI
            // (206 Orijinal Temel Şablonu Korumak İçin Non-Enumerable Olarak Eklenir)
            // ============================================================================
            const historicalTemplatesG3D03J = {
                'ottoman:janissary:v1': buildOttomanJanissary('player', 1),
                'ottoman:janissary:v2': buildOttomanJanissary('player', 2),
                'ottoman:azap:v1': buildOttomanAzap('player', 1),
                'ottoman:azap:v2': buildOttomanAzap('player', 2),
                'ottoman:humbaraci:v1': buildOttomanHumbaraci('player', 1),
                'ottoman:humbaraci:v2': buildOttomanHumbaraci('player', 2),
                'ottoman:bostanci:v1': buildOttomanBostanci('player', 1),
                'ottoman:bostanci:v2': buildOttomanBostanci('player', 2),
                'ottoman:levend:v1': buildOttomanLevend('player', 1),
                'ottoman:levend:v2': buildOttomanLevend('player', 2),

                'ottoman:sipahi:v1': buildOttomanSipahi('player', 1),
                'ottoman:sipahi:v2': buildOttomanSipahi('player', 2),
                'ottoman:kapikulu_sipahi:v1': buildOttomanKapikuluSipahi('player', 1),
                'ottoman:kapikulu_sipahi:v2': buildOttomanKapikuluSipahi('player', 2),
                'ottoman:deli:v1': buildOttomanDeli('player', 1),
                'ottoman:deli:v2': buildOttomanDeli('player', 2),
                'ottoman:ciritci:v1': buildOttomanCiritci('player', 1),
                'ottoman:ciritci:v2': buildOttomanCiritci('player', 2),
                'ottoman:akinci:v1': buildOttomanAkinci('player', 1),
                'ottoman:akinci:v2': buildOttomanAkinci('player', 2),

                'european:musketier:v1': buildHREMusketier('enemy', 1),
                'european:musketier:v2': buildHREMusketier('enemy', 2),
                'european:pikeniere:v1': buildHREPikeniere('enemy', 1),
                'european:pikeniere:v2': buildHREPikeniere('enemy', 2),
                'european:hellebardier:v1': buildHREHellebardier('enemy', 1),
                'european:hellebardier:v2': buildHREHellebardier('enemy', 2),
                'european:curassier:v1': buildHRECurassier('enemy', 1),
                'european:curassier:v2': buildHRECurassier('enemy', 2),
                'european:reiter:v1': buildHREReiter('enemy', 1),
                'european:reiter:v2': buildHREReiter('enemy', 2),

                // Side Aliases
                'player:ottoman_janissary': buildOttomanJanissary('player', 1),
                'enemy:ottoman_janissary': buildOttomanJanissary('enemy', 1),
                'player:ottoman_sipahi': buildOttomanSipahi('player', 1),
                'enemy:ottoman_sipahi': buildOttomanSipahi('enemy', 1),
                'player:european_musketier': buildHREMusketier('player', 1),
                'enemy:european_musketier': buildHREMusketier('enemy', 1),
                'player:european_pikeniere': buildHREPikeniere('player', 1),
                'enemy:european_pikeniere': buildHREPikeniere('enemy', 1)
            };

            for (const hKey of Object.keys(historicalTemplatesG3D03J)) {
                Object.defineProperty(templates, hKey, {
                    value: historicalTemplatesG3D03J[hKey],
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }


            // ============================================================================
            // G3D-03K YÜKSEK DETAYLI ANATOMİK MODEL ŞABLONLARININ KAYDI
            // (206 Orijinal Temel Şablon Sayısını Korumak İçin Non-Enumerable Tanımlanır)
            // ============================================================================
            const g3d03kTemplates = {
                'g3d03k:ottoman_janissary:high': RTSModularUnitBuilder.assembleSoldier('ottoman_janissary', 'player', 1),
                'g3d03k:ottoman_azap:high': RTSModularUnitBuilder.assembleSoldier('ottoman_azap', 'player', 2),
                'g3d03k:ottoman_bostanci:high': RTSModularUnitBuilder.assembleSoldier('ottoman_bostanci', 'player', 3),
                'g3d03k:ottoman_sipahi:high': buildOttomanHighDefHumanBase('player', 'heavy', { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy' }),
                'g3d03k:european_musketier:high': RTSModularUnitBuilder.assembleSoldier('european_musketier', 'player', 4),
                'g3d03k:european_pikeniere:high': RTSModularUnitBuilder.assembleSoldier('european_pikeniere', 'player', 5),
                'g3d03k:european_hellebardier:high': RTSModularUnitBuilder.assembleSoldier('european_hellebardier', 'player', 6),
                'g3d03k:european_curassier:high': buildEuropeanHighDefHumanBase('player', 'heavy', { coatMat: 'darkCloth', breechesMat: 'buffLeather' })
            };

            for (const kKey of Object.keys(g3d03kTemplates)) {
                Object.defineProperty(templates, kKey, {
                    value: g3d03kTemplates[kKey],
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }

            return templates;
        }

        function smoothStep01(t) {
            const x = Math.max(0, Math.min(1, t));
            return x * x * (3 - 2 * x);
        }

        /**
         * Evaluates class-specific visual combat action kinematics for the three
         * 1650 infantry classes (G3D-03C) over normalized cycle phase `u` in [0, 1):
         * 1) Pikeman (`infantry_pikeman`):
         *    - [0.00..0.25]: Wind-up / chambering (pike draws back, levels down)
         *    - [0.25..0.50]: Forward pike thrust lunge (pike + hands drive forward)
         *    - [0.50..0.70]: Brief hold at full extension
         *    - [0.70..1.00]: Smooth retraction back to ready stance
         * 2) Musketeer / Arquebusier (`infantry_musketeer`):
         *    - [0.00..0.28]: Raise & aim musket/arquebus to shoulder
         *    - [0.28..0.44]: Crisp visual fire & recoil kick
         *    - [0.44..0.62]: Lower weapon to waist/loading position
         *    - [0.62..0.86]: Reloading ramrod / priming motion
         *    - [0.86..1.00]: Return to ready stance
         * 3) Swordsman & Shield (`infantry_swordsman`):
         *    - Right sword arm (`rightArmWeapon`): Controlled wind-up [0..0.25],
         *      diagonal/overhead sword slash [0.25..0.52], follow-through & recovery.
         *    - Left shield arm (`leftArmWeapon`): Independent defensive shield guard
         *      pose raising the buckler across the chest during attack or guard mode.
         */
        function evaluateInfantryCombatPose(archetype, actionPhase, actionMode = 'attack') {
            const u = ((actionPhase % 1) + 1) % 1;

            let torsoPitch = 0;
            let torsoYaw = 0;
            let torsoDy = 0;
            let leftHipPitch = 0;
            let rightHipPitch = 0;
            let leftKneePitch = 0;
            let rightKneePitch = 0;

            let weaponPitch = 0;
            let weaponYaw = 0;
            let weaponRoll = 0;
            let weaponDx = 0;
            let weaponDy = 0;
            let weaponDz = 0;

            let shieldPitch = 0;
            let shieldYaw = 0;
            let shieldRoll = 0;
            let shieldDx = 0;
            let shieldDy = 0;
            let shieldDz = 0;

            if (archetype === 'infantry_pikeman') {
                // Normalized thrust envelope: negative = chambered back, positive = extended forward
                let thrust = 0;
                let levelPitch = 0;

                if (u < 0.25) {
                    const k = smoothStep01(u / 0.25);
                    thrust = -0.42 * k;
                    levelPitch = -0.02 * k;
                } else if (u < 0.50) {
                    const k = smoothStep01((u - 0.25) / 0.25);
                    thrust = -0.42 + 1.42 * k; // reaches +1.0 full extension
                    levelPitch = 0.36 * k;
                } else if (u < 0.70) {
                    thrust = 1.0;
                    levelPitch = 0.36;
                } else {
                    const k = smoothStep01((u - 0.70) / 0.30);
                    thrust = 1.0 * (1 - k);
                    levelPitch = 0.36 * (1 - k);
                }

                // Pike shaft axis is tilted at ~57.7 deg from +Y: sin(57.7)=0.845 (+Z), cos(57.7)=0.534 (+Y)
                weaponDz = thrust * 0.75;
                weaponDy = thrust * 0.18 - Math.max(0, thrust) * 0.08;
                weaponPitch = levelPitch;
                weaponYaw = -thrust * 0.06;

                // Coordinated grounded lunge footwork & torso lean
                const lunge = Math.max(0, thrust);
                const brace = Math.min(0, thrust);
                torsoPitch = (-0.18 * lunge) + (-0.08 * brace);
                torsoYaw = (-0.14 * lunge) + (-0.16 * brace);
                torsoDy = -0.045 * lunge;

                leftHipPitch = -0.34 * lunge + 0.10 * brace;
                leftKneePitch = 0.36 * lunge;
                rightHipPitch = 0.28 * lunge - 0.12 * brace;
                rightKneePitch = 0.12 * lunge;
            } else if (archetype === 'infantry_musketeer') {
                let aimFactor = 0;
                let recoilFactor = 0;
                let reloadFactor = 0;
                let ramrodOsc = 0;

                if (u < 0.28) {
                    // Phase 1: Raise musket/arquebus to shoulder and aim
                    aimFactor = smoothStep01(u / 0.28);
                } else if (u < 0.44) {
                    // Phase 2: Visual fire & sharp recoil kick
                    aimFactor = 1.0;
                    const rk = (u - 0.28) / 0.16;
                    recoilFactor = Math.sin(rk * Math.PI);
                } else if (u < 0.62) {
                    // Phase 3: Lower weapon to waist/reloading posture
                    const k = smoothStep01((u - 0.44) / 0.18);
                    aimFactor = 1.0 - k;
                    reloadFactor = k;
                } else if (u < 0.86) {
                    // Phase 4: Reloading ramrod / priming motion
                    reloadFactor = 1.0;
                    const rl = (u - 0.62) / 0.24;
                    ramrodOsc = Math.sin(rl * Math.PI * 2);
                } else {
                    // Phase 5: Return smoothly to ready stance
                    const k = smoothStep01((u - 0.86) / 0.14);
                    reloadFactor = 1.0 - k;
                }

                // Aiming raises & levels barrel; recoil kicks backward (-dz) & muzzle upward (-pitch);
                // reloading lowers & tilts barrel upright near chest with ramming motion
                weaponDy = 0.14 * aimFactor + 0.04 * recoilFactor - 0.16 * reloadFactor + 0.03 * ramrodOsc * reloadFactor;
                weaponDz = -0.06 * aimFactor - 0.22 * recoilFactor - 0.12 * reloadFactor;
                weaponPitch = -0.14 * aimFactor - 0.16 * recoilFactor - 0.58 * reloadFactor + 0.05 * ramrodOsc * reloadFactor;
                weaponYaw = 0.05 * aimFactor + 0.24 * reloadFactor;

                torsoPitch = -0.06 * aimFactor + 0.11 * recoilFactor - 0.09 * reloadFactor;
                torsoYaw = 0.12 * aimFactor - 0.18 * reloadFactor + 0.05 * ramrodOsc * reloadFactor;
                torsoDy = -0.015 * aimFactor - 0.02 * reloadFactor;

                leftHipPitch = -0.16 * (aimFactor + reloadFactor * 0.6);
                leftKneePitch = 0.16 * (aimFactor + reloadFactor * 0.6);
                rightHipPitch = 0.14 * (aimFactor + reloadFactor * 0.6);
                rightKneePitch = 0.08 * (aimFactor + reloadFactor * 0.6);
            } else if (archetype === 'infantry_swordsman') {
                if (actionMode === 'guard') {
                    // Pure defensive shield-wall / guard pose
                    shieldPitch = -0.42;
                    shieldYaw = -0.32;
                    shieldRoll = -0.15;
                    shieldDx = -0.16;
                    shieldDy = 0.08;
                    shieldDz = 0.10;

                    weaponPitch = -0.55;
                    weaponYaw = -0.25;
                    torsoPitch = -0.06;
                    torsoYaw = -0.22;
                    leftHipPitch = -0.18;
                    leftKneePitch = 0.18;
                    rightHipPitch = 0.16;
                } else {
                    // Controlled sword slash (rightArmWeapon) + independent defensive shield guard (leftArmWeapon)
                    let windup = 0;
                    let slash = 0;

                    if (u < 0.25) {
                        windup = smoothStep01(u / 0.25);
                    } else if (u < 0.52) {
                        const k = smoothStep01((u - 0.25) / 0.27);
                        windup = 1.0 - k;
                        slash = k;
                    } else if (u < 0.72) {
                        slash = 1.0;
                    } else {
                        const k = smoothStep01((u - 0.72) / 0.28);
                        slash = 1.0 * (1 - k);
                    }

                    // Right sword arm: cocks high/back on windup (-pitch), sweeps forward/down on slash (+pitch)
                    weaponPitch = -1.18 * windup + 0.92 * slash;
                    weaponYaw = -0.24 * windup + 0.32 * slash;

                    // Left shield arm: independent defensive guard trajectory (braces inward across chest
                    // during windup, shifts counter-balancing back/guard during slash)
                    const guardEnvelope = Math.min(1, windup * 1.1 + slash * 0.95);
                    shieldPitch = -0.38 * guardEnvelope + 0.12 * slash;
                    shieldYaw = -0.28 * windup - 0.15 * slash;
                    shieldRoll = -0.16 * guardEnvelope;
                    shieldDx = -0.14 * windup - 0.06 * slash;
                    shieldDy = 0.07 * guardEnvelope;
                    shieldDz = 0.09 * windup - 0.04 * slash;

                    torsoPitch = 0.07 * windup - 0.14 * slash;
                    torsoYaw = -0.26 * windup + 0.30 * slash;
                    torsoDy = -0.025 * slash;

                    leftHipPitch = -0.24 * slash - 0.08 * windup;
                    leftKneePitch = 0.24 * slash;
                    rightHipPitch = 0.20 * slash + 0.06 * windup;
                    rightKneePitch = 0.10 * slash;
                }
            }

            return {
                torsoPitch,
                torsoYaw,
                torsoDy,
                leftHipPitch,
                rightHipPitch,
                leftKneePitch,
                rightKneePitch,
                weaponPitch,
                weaponYaw,
                weaponRoll,
                weaponDx,
                weaponDy,
                weaponDz,
                shieldPitch,
                shieldYaw,
                shieldRoll,
                shieldDx,
                shieldDy,
                shieldDz
            };
        }

        /**
         * Articulated 1650 Infantry Walk + Visual Combat Action Pose Evaluator (G3D-03C):
         * - Blends smoothly between resting ready stance (`walkBlend=0, actionBlend=0`),
         *   articulated marching (`walkBlend > 0`), and class-specific combat poses
         *   (`actionBlend > 0`).
         * - Zero heap allocations per call (reuses caller-provided `outMat`, `scratchA`, `scratchB`).
         */
        function computeInfantryPartLocalMatrix(
            outMat,
            part,
            archetype,
            walkPhase,
            walkBlend,
            scratchA,
            scratchB,
            actionPhase = 0,
            actionBlend = 0,
            actionMode = 'attack'
        ) {
            const hasWalk = walkBlend > 1e-4;
            const hasAction = actionBlend > 1e-4;

            if ((!hasWalk && !hasAction) || !archetype || !archetype.startsWith('infantry_') || part.rigGroup === 'static' || part.rigGroup === 'shadow') {
                outMat.set(part.localMat);
                return outMat;
            }

            const rig = part.rigGroup;

            // Walk kinematic terms
            const wb = hasWalk ? walkBlend : 0;
            const wp = walkPhase;
            const walkBobY = hasWalk ? Math.abs(Math.cos(wp)) * 0.028 * wb : 0;
            const walkTorsoPitch = -0.045 * wb;
            const walkTorsoYaw = hasWalk ? Math.sin(wp) * 0.065 * wb : 0;

            // Combat action kinematic terms
            const ab = hasAction ? actionBlend : 0;
            const pose = hasAction ? evaluateInfantryCombatPose(archetype, actionPhase, actionMode) : null;

            const totalBobY = walkBobY + (pose ? pose.torsoDy * ab : 0);
            const totalTorsoPitch = walkTorsoPitch + (pose ? pose.torsoPitch * ab : 0);
            const totalTorsoYaw = walkTorsoYaw + (pose ? pose.torsoYaw * ab : 0);

            if (rig === 'leftLegUpper' || rig === 'leftLegLower' || rig === 'rightLegUpper' || rig === 'rightLegLower') {
                const isLeft = rig === 'leftLegUpper' || rig === 'leftLegLower';
                const isLower = rig === 'leftLegLower' || rig === 'rightLegLower';
                const legX = isLeft ? -0.14 : 0.14;

                let hipPitch = 0;
                let kneePitch = 0;
                let hipDy = 0;

                if (hasWalk) {
                    const theta = isLeft ? wp : (wp + Math.PI);
                    const swingForward = Math.sin(theta);
                    const swingPhase = Math.max(0, Math.cos(theta));
                    const wHip = -swingForward * 0.42 * wb;
                    const stanceDrop = -(0.84 * (1 - Math.cos(wHip))) * (1 - swingPhase);
                    const swingLift = 0.075 * swingPhase * wb;

                    hipPitch += wHip;
                    hipDy += walkBobY * 0.45 + stanceDrop + swingLift;
                    if (isLower) {
                        kneePitch += swingPhase * 0.56 * wb;
                    }
                }

                if (pose) {
                    const aHip = (isLeft ? pose.leftHipPitch : pose.rightHipPitch) * ab;
                    const aKnee = (isLeft ? pose.leftKneePitch : pose.rightKneePitch) * ab;
                    hipPitch += aHip;
                    hipDy += -(0.84 * (1 - Math.cos(aHip))) * 0.5 + pose.torsoDy * 0.35 * ab;
                    if (isLower) {
                        kneePitch += aKnee;
                    }
                }

                FOC_THREE.Mat4.fromPivotEulerOffset(
                    scratchA,
                    legX, 0.84, 0.0,
                    hipPitch, 0,
                    0, hipDy, 0
                );

                if (isLower) {
                    FOC_THREE.Mat4.fromPivotEulerOffset(
                        scratchB,
                        legX, 0.46, 0.0,
                        kneePitch, 0,
                        0, 0, 0
                    );
                    FOC_THREE.Mat4.multiply(scratchA, scratchA, scratchB);
                }

                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            if (rig === 'torso') {
                FOC_THREE.Mat4.fromPivotEulerOffset(
                    scratchA,
                    0, 0.88, 0.0,
                    totalTorsoPitch, totalTorsoYaw,
                    0, totalBobY, 0
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            if (rig === 'leftArmWeapon') {
                const armPitch = (hasWalk ? Math.sin(wp) * 0.34 * wb : 0) +
                    totalTorsoPitch * 0.5 +
                    (pose ? pose.shieldPitch * ab : 0);
                const armYaw = totalTorsoYaw * 0.8 + (pose ? pose.shieldYaw * ab : 0);
                const armRoll = pose ? pose.shieldRoll * ab : 0;
                const dx = pose ? pose.shieldDx * ab : 0;
                const dy = totalBobY + (pose ? pose.shieldDy * ab : 0);
                const dz = pose ? pose.shieldDz * ab : 0;

                FOC_THREE.Mat4.fromPivotEulerRollOffset(
                    scratchA,
                    0.27, 1.32, 0.0,
                    armPitch, armYaw, armRoll,
                    dx, dy, dz
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            if (rig === 'rightArmWeapon') {
                const armPitch = (hasWalk ? -Math.sin(wp) * 0.38 * wb : 0) +
                    totalTorsoPitch * 0.5 +
                    (pose ? pose.weaponPitch * ab : 0);
                const armYaw = totalTorsoYaw * 0.8 + (pose ? pose.weaponYaw * ab : 0);
                const armRoll = pose ? pose.weaponRoll * ab : 0;
                const dx = pose ? pose.weaponDx * ab : 0;
                const dy = totalBobY + (pose ? pose.weaponDy * ab : 0);
                const dz = pose ? pose.weaponDz * ab : 0;

                FOC_THREE.Mat4.fromPivotEulerRollOffset(
                    scratchA,
                    -0.27, 1.32, 0.0,
                    armPitch, armYaw, armRoll,
                    dx, dy, dz
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            if (rig === 'twoHandPike') {
                const pikePitch = (hasWalk ? Math.cos(2 * wp) * 0.028 * wb : 0) +
                    totalTorsoPitch * 0.45 +
                    (pose ? pose.weaponPitch * ab : 0);
                const pikeYaw = totalTorsoYaw * 0.65 + (pose ? pose.weaponYaw * ab : 0);
                const dx = pose ? pose.weaponDx * ab : 0;
                const dy = totalBobY + (pose ? pose.weaponDy * ab : 0);
                const dz = pose ? pose.weaponDz * ab : 0;

                FOC_THREE.Mat4.fromPivotEulerOffset(
                    scratchA,
                    -0.32, 1.20, 0.36,
                    pikePitch, pikeYaw,
                    dx, dy, dz
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            if (rig === 'twoHandMusket') {
                const musketPitch = (hasWalk ? Math.cos(2 * wp) * 0.025 * wb : 0) +
                    totalTorsoPitch * 0.45 +
                    (pose ? pose.weaponPitch * ab : 0);
                const musketYaw = totalTorsoYaw * 0.65 + (pose ? pose.weaponYaw * ab : 0);
                const dx = pose ? pose.weaponDx * ab : 0;
                const dy = totalBobY + (pose ? pose.weaponDy * ab : 0);
                const dz = pose ? pose.weaponDz * ab : 0;

                FOC_THREE.Mat4.fromPivotEulerOffset(
                    scratchA,
                    -0.14, 1.24, 0.24,
                    musketPitch, musketYaw,
                    dx, dy, dz
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            outMat.set(part.localMat);
            return outMat;
        }

                /* ============================================================================
         * 1650 CAVALRY COMBAT POSE EVALUATORS (G3D-03D: AJAN 1, 2, 3)
         * ============================================================================
         * - cavalry_lance: Couching, explosive forward lunge, recovery, rest
         * - cavalry_sabre: Wind-up, downward diagonal slash, recovery, safe clearance
         * - cavalry_carbine: Mounted aiming, muzzle climb, light recoil, recovery
         * - cavalry_pistol: Wheellock pistol aim, sharp discharge kick, recovery
         */
        function evaluateCavalryCombatPose(archetype, actionPhase, actionMode = 'attack') {
            // Defensive parameter sniffing: if archetype was passed as numeric actionPhase
            if (typeof archetype === 'number') {
                actionMode = actionPhase || 'attack';
                actionPhase = archetype;
                archetype = 'cavalry_sabre';
            }

            const u = ((actionPhase % 1) + 1) % 1;

            // 1. ATLI MIZRAK (01_ATLI_MIZRAK)
            if (archetype === 'cavalry_lance') {
                let torsoPitch = 0, torsoYaw = 0, torsoDy = 0;
                let weaponPitch = 0, weaponYaw = 0, weaponRoll = 0, weaponDx = 0, weaponDy = 0, weaponDz = 0;

                if (actionMode === 'guard') {
                    weaponPitch = 0.28; weaponYaw = -0.05; weaponDy = -0.08; weaponDz = 0.20;
                    torsoPitch = -0.08; torsoYaw = -0.06;
                } else {
                    let thrust = 0, levelPitch = 0;
                    if (u < 0.25) {
                        const k = smoothStep01(u / 0.25);
                        thrust = -0.32 * k; levelPitch = 0.12 * k; torsoPitch = -0.06 * k; torsoYaw = -0.04 * k;
                    } else if (u < 0.50) {
                        const k = smoothStep01((u - 0.25) / 0.25);
                        thrust = -0.32 + 1.32 * k; levelPitch = 0.12 + 0.26 * k;
                        torsoPitch = -0.06 - 0.12 * k; torsoYaw = -0.04 - 0.08 * k; torsoDy = -0.025 * k;
                    } else if (u < 0.70) {
                        thrust = 1.0; levelPitch = 0.38; torsoPitch = -0.18; torsoYaw = -0.12; torsoDy = -0.025;
                    } else {
                        const k = smoothStep01((u - 0.70) / 0.30);
                        const inv = 1.0 - k;
                        thrust = 1.0 * inv; levelPitch = 0.38 * inv;
                        torsoPitch = -0.18 * inv; torsoYaw = -0.12 * inv; torsoDy = -0.025 * inv;
                    }
                    weaponDz = thrust * 0.72;
                    weaponDy = -0.10 * Math.max(0, thrust);
                    weaponPitch = levelPitch;
                    weaponYaw = -thrust * 0.05;
                }
                return {
                    torsoPitch, torsoYaw, torsoRoll: 0, torsoDy,
                    weaponPitch, weaponYaw, weaponRoll, weaponDx, weaponDy, weaponDz,
                    pitch: torsoPitch, yaw: torsoYaw, roll: 0, dx: 0, dy: torsoDy, dz: 0
                };
            }

            // 2. ATLI KILIÇ (02_ATLI_KILIC)
            if (archetype === 'cavalry_sabre') {
                let torsoPitch = 0, torsoYaw = 0, torsoRoll = 0, torsoDy = 0;
                let weaponPitch = 0, weaponYaw = 0, weaponRoll = 0, weaponDx = 0, weaponDy = 0, weaponDz = 0;

                if (actionMode === 'guard') {
                    weaponPitch = -0.65; weaponYaw = -0.12; weaponRoll = 0.28;
                    weaponDx = -0.05; weaponDy = 0.12; weaponDz = 0.05;
                    torsoPitch = -0.03; torsoYaw = -0.08; torsoRoll = -0.05;
                } else {
                    let windup = 0, slash = 0;
                    if (u < 0.28) {
                        windup = smoothStep01(u / 0.28);
                    } else if (u < 0.58) {
                        const k = smoothStep01((u - 0.28) / 0.30);
                        windup = 1.0 - k; slash = k;
                    } else if (u < 0.76) {
                        slash = 1.0;
                    } else {
                        const k = smoothStep01((u - 0.76) / 0.24);
                        slash = 1.0 * (1 - k);
                    }
                    weaponPitch = -1.15 * windup + 0.88 * slash;
                    weaponYaw   = -0.18 * windup - 0.06 * slash;
                    weaponRoll  =  0.18 * windup + 0.34 * slash;
                    weaponDx    = -0.06 * windup - 0.14 * slash;
                    weaponDy    =  0.12 * windup - 0.18 * slash;
                    weaponDz    = -0.14 * windup + 0.24 * slash;

                    torsoPitch =  0.04 * windup - 0.12 * slash;
                    torsoYaw   = -0.15 * windup + 0.12 * slash;
                    torsoRoll  = -0.05 * windup + 0.08 * slash;
                    torsoDy    = -0.02 * slash;
                }
                return {
                    torsoPitch, torsoYaw, torsoRoll, torsoDy,
                    weaponPitch, weaponYaw, weaponRoll, weaponDx, weaponDy, weaponDz,
                    pitch: torsoPitch, yaw: torsoYaw, roll: torsoRoll, dx: 0, dy: torsoDy, dz: 0
                };
            }

            // 3. ATLI ATEŞLİ SİLAHLAR (03_ATLI_ATESLI)
            if (archetype === 'cavalry_carbine' || archetype === 'cavalry_pistol') {
                let pitch = 0, yaw = 0, roll = 0, dx = 0, dy = 0, dz = 0;
                const isCarbine = archetype === 'cavalry_carbine';

                if (u < 0.32) {
                    const aimFactor = smoothStep01(u / 0.32);
                    if (isCarbine) {
                        pitch = -0.10 * aimFactor; yaw = 0.07 * aimFactor; dy = 0.10 * aimFactor; dz = 0.05 * aimFactor;
                    } else {
                        pitch = -0.08 * aimFactor; yaw = -0.04 * aimFactor; dy = 0.08 * aimFactor; dz = 0.06 * aimFactor;
                    }
                } else if (u < 0.50) {
                    const rk = (u - 0.32) / 0.18;
                    const recoilFactor = Math.sin(rk * Math.PI);
                    if (isCarbine) {
                        pitch = -0.10 - 0.12 * recoilFactor; yaw = 0.07 - 0.02 * recoilFactor;
                        roll = -0.02 * recoilFactor; dy = 0.10 + 0.03 * recoilFactor; dz = 0.05 - 0.14 * recoilFactor;
                    } else {
                        pitch = -0.08 - 0.14 * recoilFactor; yaw = -0.04 - 0.02 * recoilFactor;
                        roll = 0.03 * recoilFactor; dy = 0.08 + 0.02 * recoilFactor; dz = 0.06 - 0.11 * recoilFactor;
                    }
                } else {
                    const recoveryFactor = 1.0 - smoothStep01((u - 0.50) / 0.50);
                    if (isCarbine) {
                        pitch = -0.10 * recoveryFactor; yaw = 0.07 * recoveryFactor; dy = 0.10 * recoveryFactor; dz = 0.05 * recoveryFactor;
                    } else {
                        pitch = -0.08 * recoveryFactor; yaw = -0.04 * recoveryFactor; dy = 0.08 * recoveryFactor; dz = 0.06 * recoveryFactor;
                    }
                }

                return { pitch, yaw, roll, dx, dy, dz };
            }

            return null;
        }

        function evaluateCavalryLanceCombatPose(actionPhase, actionMode = 'attack') {
            return evaluateCavalryCombatPose('cavalry_lance', actionPhase, actionMode);
        }

        /* ============================================================================
         * UNIFIED CAVALRY PART LOCAL MATRIX KINEMATICS (G3D-03D)
         * ============================================================================
         * Combines:
         * - Agent 4: 4-beat walk, 2-beat diagonal trot, suspension, hoof ground contact, nodding
         * - Agent 1: Mounted lance preparation, thrust, penetration, recovery, weld & stirrup lock
         * - Agent 2: Sabre slash, windup, lateral clearance (>20cm from horse neck)
         * - Agent 3: Mounted carbine & wheellock pistol aiming, muzzle climb, recoil kick, recovery
         */
        function computeCavalryPartLocalMatrix(
            outMat,
            part,
            walkPhase,
            walkBlend,
            trotBlend,
            scratchA,
            scratchB,
            actionPhase = 0,
            actionBlend = 0,
            actionMode = 'attack',
            archetype = 'cavalry_lance',
            partIndex = -1,
            totalParts = 0
        ) {
            // Defensive parameter sniffing: if archetype was passed in 8th position
            if (typeof actionPhase === 'string' && typeof archetype === 'number') {
                const tmpArch = actionPhase;
                actionPhase = actionBlend;
                actionBlend = actionMode;
                actionMode = archetype;
                archetype = tmpArch;
            }

            const hasWalk = walkBlend > 1e-4;
            const hasAction = actionBlend > 1e-4;

            if ((!hasWalk && !hasAction) || part.rigGroup === 'static' || part.rigGroup === 'shadow') {
                outMat.set(part.localMat);
                return outMat;
            }

            const b = hasWalk ? walkBlend : 0;
            const tb = Math.max(0, Math.min(1, trotBlend || 0));
            const p = walkPhase;
            const rig = part.rigGroup;

            const ab = hasAction ? actionBlend : 0;
            const pose = (hasAction && archetype) ? evaluateCavalryCombatPose(archetype, actionPhase, actionMode) : null;

            // 4-beat walk vertical oscillation with subtle 4-footfall micro-cadence (cos(4p))
            // and 2-beat diagonal trot energetic vertical bounce (Agent 4)
            const walkBob = Math.abs(Math.cos(2 * p)) * 0.022 + Math.abs(Math.sin(4 * p)) * 0.004;
            const trotBob = Math.pow(Math.abs(Math.cos(p)), 1.15) * 0.058;
            const bodyDy = ((1 - tb) * walkBob + tb * trotBob) * b;

            // Longitudinal body pitch: gentle rocking in walk; spring-like forward thrust in trot (Agent 4)
            const walkPitch = Math.sin(2 * p) * 0.015;
            const trotPitch = Math.sin(2 * p) * 0.028;
            const bodyPitch = ((1 - tb) * walkPitch + tb * trotPitch) * b;

            // Lateral body roll: weight transfer toward stance side in walk; balanced diagonal sway in trot (Agent 4)
            const walkRoll = Math.sin(p) * 0.020;
            const trotRoll = Math.sin(p) * 0.012;
            const bodyRoll = ((1 - tb) * walkRoll + tb * trotRoll) * b;

            // 1. AT BACAKLARI (Agent 4)
            if (rig.startsWith('horseLeg')) {
                const isFront = rig.startsWith('horseLegF');
                const isLeft = rig.charAt(9) === 'L';
                const isLower = rig.endsWith('Lower');

                // 4-beat walk sequence: HL(0) -> FL(-0.5*PI) -> HR(-PI) -> FR(-1.5*PI)
                const walkOffset = isFront
                    ? (isLeft ? -Math.PI * 0.5 : -Math.PI * 1.5)
                    : (isLeft ? 0.0 : -Math.PI);

                // 2-beat diagonal trot: Diagonal A (FL + HR) vs Diagonal B (FR + HL)
                const trotOffset = ((isFront && isLeft) || (!isFront && !isLeft)) ? 0.0 : -Math.PI;

                const theta = p + (1 - tb) * walkOffset + tb * trotOffset;
                const swingForward = Math.sin(theta);
                const swingPhase = Math.max(0, Math.cos(theta));

                const strideAmp = (isFront ? 0.34 : 0.36) + 0.14 * tb;
                const upperPitch = -swingForward * strideAmp * b;

                const legX = isLeft ? -0.23 : 0.23;
                const pivotY = isFront ? 1.00 : 1.08;
                const pivotZ = isFront ? 0.54 : -0.54;

                // Hoof ground contact feel: arc-compensation + elastic suspension yield
                const stanceDrop = -(pivotY * (1 - Math.cos(upperPitch))) * (1 - swingPhase);
                const swingLift = (0.046 + 0.046 * tb) * swingPhase * b;
                const legDy = bodyDy * 0.45 + stanceDrop + swingLift;

                FOC_THREE.Mat4.fromPivotEulerOffset(
                    scratchA,
                    legX, pivotY, pivotZ,
                    upperPitch, 0, 0,
                    0, legDy, 0
                );

                if (isLower) {
                    const jointY = isFront ? 0.52 : 0.54;
                    const jointZ = isFront ? 0.59 : -0.68;
                    const jointAmp = (isFront ? 0.56 : 0.50) + 0.24 * tb;
                    const jointBend = swingPhase * jointAmp * b;
                    FOC_THREE.Mat4.fromPivotEulerOffset(scratchB, legX, jointY, jointZ, jointBend, 0, 0, 0, 0);
                    FOC_THREE.Mat4.multiply(scratchA, scratchA, scratchB);
                }

                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            // 2. AT GÖVDESİ, BOYUN/BAŞ, KUYRUK (Agent 4)
            if (rig === 'horseBody') {
                FOC_THREE.Mat4.fromPivotEulerRollOffset(scratchA, 0, 1.12, 0.0, bodyPitch, 0, bodyRoll, 0, bodyDy, 0);
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            if (rig === 'horseNeckHead') {
                const walkNeckPitch = Math.cos(2 * p) * 0.044;
                const trotNeckPitch = -Math.cos(p) * 0.052;
                const neckPitch = ((1 - tb) * walkNeckPitch + tb * trotNeckPitch) * b;
                const neckYaw = Math.sin(p) * 0.028 * b;
                const neckRoll = bodyRoll * 0.45;

                FOC_THREE.Mat4.fromPivotEulerRollOffset(
                    scratchA, 0, 1.24, 0.62,
                    neckPitch + bodyPitch * 0.4, neckYaw, neckRoll,
                    0, bodyDy, 0
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            if (rig === 'horseTail') {
                const tailPitch = (0.07 + (0.06 + 0.08 * tb) * Math.abs(Math.sin(p))) * b;
                const tailYaw = Math.sin(p) * (0.12 + 0.06 * tb) * b;
                FOC_THREE.Mat4.fromPivotEulerRollOffset(
                    scratchA, 0, 1.26, -0.86,
                    tailPitch, tailYaw, bodyRoll * 0.5,
                    0, bodyDy, 0
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            // 3. EYER VE BİNİCİ ALT GÖVDESİ (EYERE SABİT, SAVAŞ EYLEMİNDEN ETKİLENMEZ — TEST 28 / TEST 38 BÜTÜNLÜĞÜ)
            if (rig === 'riderSaddle' || rig === 'riderLower') {
                FOC_THREE.Mat4.fromPivotEulerRollOffset(
                    scratchA, 0, 1.45, -0.06,
                    bodyPitch * 0.35, 0, bodyRoll * 0.65,
                    0, bodyDy, 0
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            // 4. SAĞ KOL VE KILIÇ (Ajan 2 'riderRightArmWeapon' Grubu)
            if (rig === 'riderRightArmWeapon') {
                const riderLean = (0.028 + 0.045 * tb * Math.abs(Math.cos(p))) * b;
                const basePitch = hasWalk ? (-bodyPitch * 0.55 - riderLean) : 0;
                const baseYaw = hasWalk ? -Math.sin(p) * 0.036 * b : 0;
                const baseRoll = hasWalk ? -bodyRoll * 0.35 : 0;

                const armPitch = basePitch * 0.5 + (pose ? pose.weaponPitch * ab : 0);
                const armYaw = baseYaw * 0.8 + (pose ? pose.weaponYaw * ab : 0);
                const armRoll = baseRoll * 0.5 + (pose ? pose.weaponRoll * ab : 0);
                const dx = (pose ? pose.weaponDx * ab : 0);
                const dy = bodyDy + (pose ? pose.weaponDy * ab : 0);
                const dz = (pose ? pose.weaponDz * ab : 0);

                FOC_THREE.Mat4.fromPivotEulerRollOffset(
                    scratchA, -0.25, 1.92, -0.04, // Sağ omuz pivotu
                    armPitch, armYaw, armRoll,
                    dx, dy, dz
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            // 5. BİNİCİ ÜST GÖVDESİ (Mızrak, Ateşli Silahlar ve Genel Gövde)
            if (rig === 'riderUpper') {
                const riderLean = (0.028 + 0.045 * tb * Math.abs(Math.cos(p))) * b;
                const riderGaitPitch = hasWalk ? (-bodyPitch * 0.55 - riderLean) : 0;
                const riderGaitYaw = hasWalk ? -Math.sin(p) * 0.036 * b : 0;
                const riderGaitRoll = hasWalk ? -bodyRoll * 0.35 : 0;

                // A) Mızrak Kolu ve Silah Parçaları (Ajan 1)
                const isLancePart = (archetype === 'cavalry_lance') &&
                    ((part && part.subGroup === 'lance') || (totalParts > 0 && partIndex >= totalParts - 8));

                if (isLancePart && pose && ab > 1e-4) {
                    const armPitch = riderGaitPitch * 0.5 + pose.weaponPitch * ab;
                    const armYaw = riderGaitYaw * 0.8 + pose.weaponYaw * ab;
                    const armRoll = (pose.weaponRoll * ab) + riderGaitRoll;
                    const armDx = pose.weaponDx * ab;
                    const armDy = bodyDy + (pose.torsoDy * 0.5 + pose.weaponDy) * ab;
                    const armDz = pose.weaponDz * ab;

                    FOC_THREE.Mat4.fromPivotEulerRollOffset(
                        scratchA, -0.25, 1.92, -0.04, // Sağ omuz pivotu
                        armPitch, armYaw, armRoll,
                        armDx, armDy, armDz
                    );
                    FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                    return outMat;
                }

                // B) Ateşli Silahlar (Ajan 3) veya Gövde Yatışları (Ajan 1, 2, 3)
                const isFirearm = archetype === 'cavalry_carbine' || archetype === 'cavalry_pistol';
                const totalPitch = riderGaitPitch + (pose ? (isFirearm ? pose.pitch : (pose.torsoPitch ?? pose.pitch ?? 0)) * ab : 0);
                const totalYaw   = riderGaitYaw   + (pose ? (isFirearm ? pose.yaw   : (pose.torsoYaw   ?? pose.yaw   ?? 0)) * ab : 0);
                const totalRoll  = riderGaitRoll  + (pose ? (isFirearm ? pose.roll  : (pose.torsoRoll  ?? pose.roll  ?? 0)) * ab : 0);
                const totalDx    = (pose ? (isFirearm ? pose.dx : (pose.dx ?? 0)) * ab : 0);
                const totalDy    = bodyDy + (pose ? (isFirearm ? pose.dy : (pose.torsoDy ?? pose.dy ?? 0)) * ab : 0);
                const totalDz    = (pose ? (isFirearm ? pose.dz : (pose.dz ?? 0)) * ab : 0);

                FOC_THREE.Mat4.fromPivotEulerRollOffset(
                    scratchA, 0, 1.48, -0.06, // Bel pivotu
                    totalPitch, totalYaw, totalRoll,
                    totalDx, totalDy, totalDz
                );
                FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
                return outMat;
            }

            outMat.set(part.localMat);
            return outMat;
        }

        function shortestAngleDelta(fromYaw, toYaw) {
            return Math.atan2(Math.sin(toYaw - fromYaw), Math.cos(toYaw - fromYaw));
        }

        function parseSnapshotCombatState(stateStr) {
            const st = String(stateStr || '').toLowerCase();
            if (st === 'guard' || st === 'defend' || st === 'shield_guard') {
                return { active: true, mode: 'guard' };
            }
            if (
                st === 'attack' ||
                st === 'attacking' ||
                st === 'thrust' ||
                st === 'fire' ||
                st === 'shoot' ||
                st === 'reload' ||
                st === 'slash' ||
                st === 'combat'
            ) {
                return { active: true, mode: 'attack' };
            }
            return { active: false, mode: 'attack' };
        }

        class BlackPowderFxPool {
            constructor(capacity = 64, sphereGeo = null) {
                this.capacity = capacity;
                this.sphereGeo = sphereGeo || FOC_THREE.PrimitiveGeometries.createUnitSphere(6, 8);
                this.particles = [];
                for (let i = 0; i < capacity; i++) {
                    this.particles.push({
                        active: false,
                        isFlash: false,
                        x: 0, y: 0, z: 0,
                        vx: 0, vy: 0, vz: 0,
                        life: 0,
                        maxLife: 0.5,
                        startSize: 0.1,
                        endSize: 0.35,
                        size: 0.1,
                        r: 0.8, g: 0.8, b: 0.8,
                        startAlpha: 0.6,
                        alpha: 0.6
                    });
                }

                this.activeCount = 0;
                this.instanceData = new Float32Array(this.capacity * INSTANCE_STRIDE_FLOATS);
                this._tmpMat = FOC_THREE.Mat4.create();

                this.batch = {
                    geometry: this.sphereGeo,
                    transparent: true,
                    instanceData: this.instanceData,
                    count: 0,
                    _gl: null,
                    _glInstanceBuffer: null,
                    _needsUpload: false
                };

                this.batchGroup = new FOC_THREE.InstancedBatchGroup();
                this.batchGroup.setBatches([this.batch]);
            }

            spawnMuzzleFlashAndSmoke(x, y, z, dirX, dirZ) {
                // 1) Namlu Parlaması (Muzzle Flash): Tek bir parlak, kısa ömürlü alev
                this._spawnParticle({
                    isFlash: true,
                    x: x + dirX * 0.05,
                    y: y,
                    z: z + dirZ * 0.05,
                    vx: dirX * 0.6,
                    vy: 0.04,
                    vz: dirZ * 0.6,
                    life: 0,
                    maxLife: 0.07,
                    startSize: 0.18,
                    endSize: 0.06,
                    r: 1.0,
                    g: 0.88,
                    b: 0.48,
                    startAlpha: 0.95
                });

                // 2) Kara Barut Dumanı (Black Powder Smoke): 3 adet genişleyen duman kümesi
                const smokePuffs = 3;
                for (let i = 0; i < smokePuffs; i++) {
                    const spreadAngle = (i - 1) * 0.32 + (Math.random() - 0.5) * 0.12;
                    const cosS = Math.cos(spreadAngle);
                    const sinS = Math.sin(spreadAngle);
                    const pdirX = dirX * cosS - dirZ * sinS;
                    const pdirZ = dirX * sinS + dirZ * cosS;
                    const speed = 0.85 + Math.random() * 0.65;

                    this._spawnParticle({
                        isFlash: false,
                        x: x + (Math.random() - 0.5) * 0.04,
                        y: y + (Math.random() - 0.5) * 0.04,
                        z: z + (Math.random() - 0.5) * 0.04,
                        vx: pdirX * speed,
                        vy: 0.22 + Math.random() * 0.18,
                        vz: pdirZ * speed,
                        life: 0,
                        maxLife: 0.45 + Math.random() * 0.18,
                        startSize: 0.08 + Math.random() * 0.03,
                        endSize: 0.32 + Math.random() * 0.08,
                        r: 0.76 + Math.random() * 0.08,
                        g: 0.76 + Math.random() * 0.08,
                        b: 0.73 + Math.random() * 0.08,
                        startAlpha: 0.58 + Math.random() * 0.12
                    });
                }
            }

            _spawnParticle(cfg) {
                let p = null;
                for (let i = 0; i < this.capacity; i++) {
                    if (!this.particles[i].active) {
                        p = this.particles[i];
                        break;
                    }
                }
                if (!p) {
                    let maxRatio = -1;
                    let oldest = 0;
                    for (let i = 0; i < this.capacity; i++) {
                        const ratio = this.particles[i].life / this.particles[i].maxLife;
                        if (ratio > maxRatio) {
                            maxRatio = ratio;
                            oldest = i;
                        }
                    }
                    p = this.particles[oldest];
                }

                p.active = true;
                p.isFlash = cfg.isFlash;
                p.x = cfg.x;
                p.y = cfg.y;
                p.z = cfg.z;
                p.vx = cfg.vx;
                p.vy = cfg.vy;
                p.vz = cfg.vz;
                p.life = 0;
                p.maxLife = cfg.maxLife;
                p.startSize = cfg.startSize;
                p.endSize = cfg.endSize;
                p.size = cfg.startSize;
                p.r = cfg.r;
                p.g = cfg.g;
                p.b = cfg.b;
                p.startAlpha = cfg.startAlpha;
                p.alpha = cfg.startAlpha;

                let count = 0;
                for (let i = 0; i < this.capacity; i++) {
                    if (this.particles[i].active) count++;
                }
                this.activeCount = count;
            }

            update(dt) {
                const safeDt = Math.min(0.05, Math.max(0.001, dt || 0.016));
                let active = 0;

                for (let i = 0; i < this.capacity; i++) {
                    const p = this.particles[i];
                    if (!p.active) continue;

                    p.life += safeDt;
                    if (p.life >= p.maxLife) {
                        p.active = false;
                        continue;
                    }

                    const t = p.life / p.maxLife;

                    if (p.isFlash) {
                        p.size = p.startSize * (1.0 - t * 0.7);
                        p.alpha = p.startAlpha * (1.0 - t);
                        p.x += p.vx * safeDt;
                        p.y += p.vy * safeDt;
                        p.z += p.vz * safeDt;
                    } else {
                        const drag = Math.max(0, 1.0 - safeDt * 3.2);
                        p.vx *= drag;
                        p.vz *= drag;
                        p.vy = Math.max(0.08, p.vy * drag + safeDt * 0.12);

                        p.x += p.vx * safeDt;
                        p.y += p.vy * safeDt;
                        p.z += p.vz * safeDt;

                        p.size = p.startSize + (p.endSize - p.startSize) * Math.sin(t * Math.PI * 0.5);
                        p.alpha = p.startAlpha * (1.0 - t) * (1.0 - t * 0.5);
                    }

                    const base = active * INSTANCE_STRIDE_FLOATS;
                    FOC_THREE.Mat4.identity(this._tmpMat);
                    this._tmpMat[0] = p.size;
                    this._tmpMat[5] = p.size;
                    this._tmpMat[10] = p.size;
                    this._tmpMat[12] = p.x;
                    this._tmpMat[13] = p.y;
                    this._tmpMat[14] = p.z;

                    this.instanceData.set(this._tmpMat, base);
                    this.instanceData[base + 16] = p.r;
                    this.instanceData[base + 17] = p.g;
                    this.instanceData[base + 18] = p.b;
                    this.instanceData[base + 19] = p.alpha;
                    this.instanceData[base + 20] = 0.0;

                    active++;
                }

                this.activeCount = active;
                this.batch.count = active;
                if (active > 0 || this.batch._needsUpload) {
                    this.batch._needsUpload = true;
                }

                return active;
            }

            clear() {
                for (let i = 0; i < this.capacity; i++) {
                    this.particles[i].active = false;
                }
                this.activeCount = 0;
                this.batch.count = 0;
                this.batch._needsUpload = false;
            }

            reset() {
                this.clear();
            }

            invalidateGpuHandles() {
                if (this.batch) {
                    this.batch._gl = null;
                    this.batch._glInstanceBuffer = null;
                    this.batch._needsUpload = true;
                }
                if (this.batchGroup) {
                    this.batchGroup.invalidateGpuHandles();
                }
            }

            dispose() {
                this.clear();
                this.batchGroup.dispose();
            }
        }

        class SoldierVisualRegistry {
            constructor() {
                this.records = new Map();
                this.templates = createSoldierPartTemplates();

                this.geometries = {
                    box: FOC_THREE.PrimitiveGeometries.createUnitBox(),
                    cylinder: FOC_THREE.PrimitiveGeometries.createUnitCylinder(8),
                    frustum: FOC_THREE.PrimitiveGeometries.createUnitFrustum(10, 0.68),
                    cone: FOC_THREE.PrimitiveGeometries.createUnitCone(8),
                    sphere: FOC_THREE.PrimitiveGeometries.createUnitSphere(6, 8),
                    dome: FOC_THREE.PrimitiveGeometries.createUnitDome(5, 10)
                };

                this.materials = {
                    playerCloth: new FOC_THREE.Material({ color: 0x2563eb, metalness: 0.08 }),
                    playerBreeches: new FOC_THREE.Material({ color: 0x1d4ed8, metalness: 0.04 }),
                    enemyCloth: new FOC_THREE.Material({ color: 0xdc2626, metalness: 0.08 }),
                    enemyBreeches: new FOC_THREE.Material({ color: 0x991b1b, metalness: 0.04 }),
                    steel: new FOC_THREE.Material({ color: 0xdbeafe, metalness: 0.88 }),
                    darkSteel: new FOC_THREE.Material({ color: 0x334155, metalness: 0.62 }),
                    skin: new FOC_THREE.Material({ color: 0xf5caa6, metalness: 0.0 }),
                    linen: new FOC_THREE.Material({ color: 0xf8fafc, metalness: 0.0 }),
                    leather: new FOC_THREE.Material({ color: 0x713f12, metalness: 0.12 }),
                    wood: new FOC_THREE.Material({ color: 0x854d0e, metalness: 0.02 }),
                    gold: new FOC_THREE.Material({ color: 0xfbbf24, metalness: 0.85 }),
                    horseBay: new FOC_THREE.Material({ color: 0x7c2d12, metalness: 0.08 }),
                    horseDark: new FOC_THREE.Material({ color: 0x1c1917, metalness: 0.12 }),
                    horseChestnut: new FOC_THREE.Material({ color: 0x9a3412, metalness: 0.09 }),
                    horseDun: new FOC_THREE.Material({ color: 0xb45309, metalness: 0.06 }),
                    shadow: new FOC_THREE.Material({ color: 0x0f140d, transparent: true, opacity: 0.42 }),
                    ottomanCrimson: new FOC_THREE.Material({ color: 0xb91c1c, metalness: 0.08 }),
                    ottomanEmerald: new FOC_THREE.Material({ color: 0x047857, metalness: 0.08 }),
                    ottomanSaffron: new FOC_THREE.Material({ color: 0xd97706, metalness: 0.12 }),
                    ottomanNavy: new FOC_THREE.Material({ color: 0x1e3a8a, metalness: 0.08 }),
                    ottomanWhite: new FOC_THREE.Material({ color: 0xf8fafc, metalness: 0.0 }),
                    leopardPelt: new FOC_THREE.Material({ color: 0xca8a04, metalness: 0.05 }),
                    bronze: new FOC_THREE.Material({ color: 0xb45309, metalness: 0.82 }),
                    damascusSteel: new FOC_THREE.Material({ color: 0x64748b, metalness: 0.85 }),
                    blackenedSteel: new FOC_THREE.Material({ color: 0x1e293b, metalness: 0.82 }),
                    burnishedBronze: new FOC_THREE.Material({ color: 0xd97706, metalness: 0.84 }),
                    buffLeather: new FOC_THREE.Material({ color: 0xb45309, metalness: 0.04 }),
                    fineSilk: new FOC_THREE.Material({ color: 0xf59e0b, metalness: 0.20 }),
                    roughWool: new FOC_THREE.Material({ color: 0x991b1b, metalness: 0.02 }),


                };

                this.batchGroup = new FOC_THREE.InstancedBatchGroup();
                this.powderFxPool = new BlackPowderFxPool(64, this.geometries.sphere);
                this._batchWriteOffsets = new Int32Array(16);

                this._tmpPartLocalMat = FOC_THREE.Mat4.create();
                this._tmpWorldPartMat = FOC_THREE.Mat4.create();
                this._scratchA = FOC_THREE.Mat4.create();
                this._scratchB = FOC_THREE.Mat4.create();

                this.stats = {
                    activeCount: 0,
                    infantryCount: 0,
                    cavalryCount: 0,
                    movingCount: 0,
                    combatPosingCount: 0,
                    cavalryWeapons: {
                        lance: 0,
                        sabre: 0,
                        carbine: 0,
                        pistol: 0
                    },
                    batchCount: 0,
                    lastCreated: 0,
                    lastUpdated: 0,
                    lastRemoved: 0
                };
            }

            invalidateGpuHandles() {
                Object.values(this.geometries).forEach((g) => g.invalidateGpuHandle());
                this.batchGroup.invalidateGpuHandles();
                if (this.powderFxPool) this.powderFxPool.invalidateGpuHandles();
            }

            getSoldierVisualState(viewId) {
                return this.records.get(viewId) || null;
            }

            /**
             * Allows visual-only triggering or clearing of an infantry combat pose on an
             * existing visual record without mutating any SectorManager or simulation data.
             */
            setSoldierVisualCombatAction(viewId, active, mode = 'attack', phaseOffset = 0) {
                const rec = this.records.get(viewId);
                if (!rec) return false;
                const isSupported = rec.archetype.startsWith('infantry_') || rec.archetype.startsWith('cavalry');
                if (!isSupported) return false;
                rec.isCombatActing = Boolean(active);
                rec.actionMode = mode === 'guard' ? 'guard' : 'attack';
                rec.combatFinished = false;
                rec.muzzleFired = false;
                if (active && Number.isFinite(phaseOffset) && phaseOffset > 0) {
                    rec.actionPhase = phaseOffset % 1;
                    rec.actionBlend = 1.0;
                } else if (active) {
                    rec.actionPhase = 0;
                }
                return true;
            }

            evaluateSoldierPartMatrix(viewId, partIndex, outMat = null) {
                const rec = this.records.get(viewId);
                if (!rec) return null;
                const parts = this.templates[rec.templateKey] || this.templates['player:infantry_pikeman'];
                const part = parts[partIndex];
                if (!part) return null;
                const target = outMat || FOC_THREE.Mat4.create();
                if (rec.archetype.startsWith('cavalry')) {
                    return computeCavalryPartLocalMatrix(
                        target,
                        part,
                        rec.walkPhase,
                        rec.walkBlend,
                        rec.trotBlend,
                        this._scratchA,
                        this._scratchB,
                        rec.actionPhase,
                        rec.actionBlend,
                        rec.actionMode,
                        rec.archetype,
                        partIndex,
                        parts.length
                    );
                }
                return computeInfantryPartLocalMatrix(
                    target,
                    part,
                    rec.archetype,
                    rec.walkPhase,
                    rec.walkBlend,
                    this._scratchA,
                    this._scratchB,
                    rec.actionPhase,
                    rec.actionBlend,
                    rec.actionMode
                );
            }

            sync(snapshot) {
                const soldiers = snapshot && Array.isArray(snapshot.soldiers) ? snapshot.soldiers : [];
                const seenViewIds = new Set();

                let created = 0;
                let updated = 0;
                let removed = 0;
                let visiblePlayer = 0;
                let visibleEnemy = 0;
                let infantryCount = 0;
                let cavalryCount = 0;
                let movingCount = 0;
                let combatPosingCount = 0;
                const cavalryWeapons = { lance: 0, sabre: 0, carbine: 0, pistol: 0 };
                let structureDirty = false;
                let transformsDirty = false;

                for (let i = 0; i < soldiers.length; i++) {
                    const s = soldiers[i];
                    if (!s || typeof s !== 'object') continue;

                    const side = s.side === 'enemy' ? 'enemy' : 'player';
                    if (side === 'player' && visiblePlayer >= 150) continue;
                    if (side === 'enemy' && visibleEnemy >= 150) continue;

                    const viewId = s.viewId || `${s.sectorId || 'sec'}:${s.soldierId || i}`;
                    if (seenViewIds.has(viewId)) continue;
                    seenViewIds.add(viewId);

                    if (side === 'player') visiblePlayer++;
                    else visibleEnemy++;

                    const tx = s.position && Number.isFinite(s.position.x) ? s.position.x : 0;
                    const ty = s.position && Number.isFinite(s.position.y) ? s.position.y : 0;
                    const tz = s.position && Number.isFinite(s.position.z) ? s.position.z : 0;
                    const hasTargetPos = Boolean(s.targetPosition && Number.isFinite(s.targetPosition.x) && Number.isFinite(s.targetPosition.z));
                    const targetX = hasTargetPos ? s.targetPosition.x : tx;
                    const targetY = hasTargetPos && Number.isFinite(s.targetPosition.y) ? s.targetPosition.y : ty;
                    const targetZ = hasTargetPos ? s.targetPosition.z : tz;
                    const restingYaw = side === 'enemy' ? -Math.PI * 0.5 : Math.PI * 0.5;

                    const archetype = classifySoldierArchetype(s);
                    let templateKey = `${side}:${archetype}`;

                    if (archetype.startsWith('cavalry')) {
                        cavalryCount++;
                        templateKey = resolveCavalryVisualVariant(s);
                        if (archetype === 'cavalry_lance') cavalryWeapons.lance++;
                        else if (archetype === 'cavalry_carbine') cavalryWeapons.carbine++;
                        else if (archetype === 'cavalry_pistol') cavalryWeapons.pistol++;
                        else cavalryWeapons.sabre++;
                    } else {
                        infantryCount++;
                    }

                    const combatInfo = parseSnapshotCombatState(s.state);
                    const isInfantry = archetype.startsWith('infantry_');

                    const existing = this.records.get(viewId);
                    if (existing) {
                        if (existing.templateKey !== templateKey || existing.side !== side) {
                            existing.archetype = archetype;
                            existing.templateKey = templateKey;
                            existing.side = side;
                            structureDirty = true;
                        }

                        if (hasTargetPos) {
                            const targetDelta = Math.hypot(
                                targetX - existing.targetX,
                                targetY - existing.targetY,
                                targetZ - existing.targetZ
                            );
                            if (targetDelta > 1e-4 || !existing.isMoving) {
                                existing.targetX = targetX;
                                existing.targetY = targetY;
                                existing.targetZ = targetZ;
                                existing.lastSnapshotX = tx;
                                existing.lastSnapshotY = ty;
                                existing.lastSnapshotZ = tz;

                                const distToTarget = Math.hypot(targetX - existing.x, targetY - existing.y, targetZ - existing.z);
                                if (distToTarget > 0.015) {
                                    existing.isMoving = true;
                                    const horizDist = Math.hypot(targetX - existing.x, targetZ - existing.z);
                                    if (horizDist > 0.025) {
                                        existing.desiredYaw = Math.atan2(targetX - existing.x, targetZ - existing.z);
                                    }
                                    transformsDirty = true;
                                }
                            }
                        } else {
                            const snapshotDelta = Math.hypot(
                                tx - existing.lastSnapshotX,
                                ty - existing.lastSnapshotY,
                                tz - existing.lastSnapshotZ
                            );

                            if (snapshotDelta > 1e-4) {
                                existing.lastSnapshotX = tx;
                                existing.lastSnapshotY = ty;
                                existing.lastSnapshotZ = tz;
                                existing.targetX = tx;
                                existing.targetY = ty;
                                existing.targetZ = tz;

                                const distToTarget = Math.hypot(tx - existing.x, ty - existing.y, tz - existing.z);
                                if (distToTarget > 0.015) {
                                    existing.isMoving = true;
                                    const horizDist = Math.hypot(tx - existing.x, tz - existing.z);
                                    if (horizDist > 0.025) {
                                        existing.desiredYaw = Math.atan2(tx - existing.x, tz - existing.z);
                                    }
                                    transformsDirty = true;
                                }
                            }
                        }

                        const isCavalry = archetype.startsWith('cavalry');
                        const canCombatAct = isInfantry || isCavalry;
                        if (canCombatAct) {
                            if (combatInfo.active) {
                                const isNewRequest = !existing.isCombatActing && !existing.combatFinished;
                                const isModeChange = existing.actionMode !== combatInfo.mode;
                                const isStateStringChange = existing.lastSnapshotState !== s.state;
                                if (isNewRequest || isModeChange || isStateStringChange) {
                                    existing.isCombatActing = true;
                                    existing.actionMode = combatInfo.mode;
                                    existing.combatFinished = false;
                                    existing.muzzleFired = false;
                                    existing.lastSnapshotState = s.state;
                                    transformsDirty = true;
                                }
                            } else if (existing.isCombatActing || existing.combatFinished) {
                                existing.isCombatActing = false;
                                existing.combatFinished = false;
                                existing.muzzleFired = false;
                                existing.lastSnapshotState = s.state;
                                transformsDirty = true;
                            }
                        } else {
                            existing.isCombatActing = false;
                            existing.actionBlend = 0;
                            existing.actionPhase = 0;
                            existing.muzzleFired = false;
                        }

                        if (existing.isMoving || existing.walkBlend > 0) {
                            movingCount++;
                        }
                        if (existing.isCombatActing || existing.actionBlend > 0) {
                            combatPosingCount++;
                        }

                        existing.soldierId = s.soldierId;
                        existing.groupId = s.groupId;
                        updated++;
                    } else {
                        const worldMat = FOC_THREE.Mat4.fromYawTranslation(FOC_THREE.Mat4.create(), restingYaw, tx, ty, tz);
                        const isCavalry = archetype.startsWith('cavalry');
                        const canCombatAct = isInfantry || isCavalry;
                        const initialCombatActive = canCombatAct && combatInfo.active;
                        const staggerPhase = initialCombatActive ? ((i * 0.13) % 1) : 0;
                        if (initialCombatActive) combatPosingCount++;

                        const isInitiallyMoving = hasTargetPos && Math.hypot(targetX - tx, targetZ - tz) > 0.015;
                        const initialDesiredYaw = isInitiallyMoving ? Math.atan2(targetX - tx, targetZ - tz) : restingYaw;

                        this.records.set(viewId, {
                            viewId,
                            soldierId: s.soldierId,
                            groupId: s.groupId,
                            side,
                            archetype,
                            templateKey,
                            x: tx,
                            y: ty,
                            z: tz,
                            targetX: targetX,
                            targetY: targetY,
                            targetZ: targetZ,
                            lastSnapshotX: tx,
                            lastSnapshotY: ty,
                            lastSnapshotZ: tz,
                            yaw: restingYaw,
                            desiredYaw: initialDesiredYaw,
                            restingYaw,
                            isMoving: isInitiallyMoving,
                            walkPhase: 0,
                            walkBlend: 0,
                            trotBlend: 0,
                            isCombatActing: initialCombatActive,
                            actionMode: combatInfo.mode,
                            actionPhase: staggerPhase,
                            actionBlend: 0,
                            combatFinished: false,
                            muzzleFired: false,
                            lastSnapshotState: s.state,
                            worldMat
                        });
                        created++;
                        structureDirty = true;
                    }
                }

                for (const [key] of this.records) {
                    if (!seenViewIds.has(key)) {
                        this.records.delete(key);
                        removed++;
                        structureDirty = true;
                    }
                }

                if (this.records.size === 0 && this.powderFxPool) {
                    this.powderFxPool.clear();
                }

                if (structureDirty) {
                    this._rebuildInstanceBatches();
                } else if (transformsDirty) {
                    this._updateBatchBuffersInPlace();
                }

                this.stats = {
                    activeCount: this.records.size,
                    infantryCount,
                    cavalryCount,
                    movingCount,
                    combatPosingCount,
                    cavalryWeapons,
                    batchCount: this.batchGroup.batches.length,
                    lastCreated: created,
                    lastUpdated: updated,
                    lastRemoved: removed
                };

                return this.stats;
            }

            update(dt) {
                if (this.records.size === 0) return 0;
                const safeDt = Math.min(0.05, Math.max(0.0001, dt || 0.016));

                let movingCount = 0;
                let combatPosingCount = 0;
                let anyChanged = false;

                for (const rec of this.records.values()) {
                    const dx = rec.targetX - rec.x;
                    const dy = rec.targetY - rec.y;
                    const dz = rec.targetZ - rec.z;
                    const horizDist = Math.hypot(dx, dz);
                    const totalDist = Math.hypot(dx, dy, dz);
                    const isCavalry = rec.archetype.startsWith('cavalry');

                    let recordChanged = false;

                    if (totalDist > 0.015) {
                        rec.isMoving = true;

                        if (horizDist > 0.025) {
                            rec.desiredYaw = Math.atan2(dx, dz);
                        }
                        const yawDiff = shortestAngleDelta(rec.yaw, rec.desiredYaw);
                        if (Math.abs(yawDiff) > 1e-4) {
                            const turnAlpha = 1 - Math.exp(-11 * safeDt);
                            rec.yaw += yawDiff * turnAlpha;
                        }

                        const baseSpeed = isCavalry ? 4.6 : 2.75;
                        const moveSpeed = Math.max(baseSpeed, Math.min(7.5, totalDist * 1.6));
                        const step = Math.min(totalDist, moveSpeed * safeDt);

                        rec.x += (dx / totalDist) * step;
                        rec.y += (dy / totalDist) * step;
                        rec.z += (dz / totalDist) * step;

                        if (isCavalry) {
                            const targetTrot = totalDist > 3.2 ? Math.min(1, (moveSpeed - 4.6) / 1.8) : 0;
                            const gaitAlpha = 1 - Math.exp(-6.5 * safeDt);
                            rec.trotBlend += (targetTrot - rec.trotBlend) * gaitAlpha;
                            const phaseRate = 2.65 + rec.trotBlend * 0.75;
                            rec.walkPhase += step * phaseRate;
                        } else {
                            rec.walkPhase += step * 3.85;
                        }

                        recordChanged = true;
                    } else if (rec.isMoving || totalDist > 0) {
                        rec.x = rec.targetX;
                        rec.y = rec.targetY;
                        rec.z = rec.targetZ;
                        rec.isMoving = false;
                        recordChanged = true;
                    }

                    if (rec.isMoving) {
                        if (rec.walkBlend < 1) {
                            rec.walkBlend = Math.min(1, rec.walkBlend + safeDt * 7.5);
                            recordChanged = true;
                        }
                        movingCount++;
                    } else if (rec.walkBlend > 0) {
                        rec.walkBlend = Math.max(0, rec.walkBlend - safeDt * 6.0);
                        rec.trotBlend = Math.max(0, rec.trotBlend - safeDt * 6.0);
                        if (rec.walkBlend === 0) {
                            rec.walkPhase = 0;
                            rec.trotBlend = 0;
                        }
                        recordChanged = true;
                        movingCount++;
                    }

                    // Visual combat action pose update (Infantry & Cavalry G3D-03D)
                    const canDoCombat = !isCavalry || rec.archetype.startsWith('cavalry');
                    if (canDoCombat) {
                        if (rec.isCombatActing) {
                            let cycleDuration = 1.55;
                            const isMusketeer = rec.archetype === 'infantry_musketeer';
                            if (isMusketeer) cycleDuration = 2.6;
                            else if (rec.archetype === 'infantry_pikeman') cycleDuration = 1.85;
                            else if (rec.archetype === 'cavalry_lance') cycleDuration = 1.85;
                            else if (rec.archetype === 'cavalry_sabre') cycleDuration = 1.50;
                            else if (rec.archetype === 'cavalry_carbine') cycleDuration = 2.00;
                            else if (rec.archetype === 'cavalry_pistol') cycleDuration = 1.75;

                            const nextPhase = rec.actionPhase + safeDt / cycleDuration;

                            // Trigger black powder muzzle flash & smoke cloud at discharge phase
                            const isFirearm = (rec.archetype === 'infantry_musketeer' || rec.archetype === 'cavalry_carbine' || rec.archetype === 'cavalry_pistol');
                            if (isFirearm && rec.actionMode === 'attack' && rec.actionBlend > 0.1) {
                                const fireStart = rec.archetype === 'infantry_musketeer' ? 0.28 : 0.34;
                                const fireEnd = rec.archetype === 'infantry_musketeer' ? 0.44 : 0.50;
                                const crossingFire = (rec.actionPhase < fireStart && nextPhase >= fireStart);
                                const insideFire = (rec.actionPhase >= fireStart && rec.actionPhase < fireEnd);
                                if ((crossingFire || insideFire) && !rec.muzzleFired) {
                                    rec.muzzleFired = true;
                                    const sinY = Math.sin(rec.yaw);
                                    const cosY = Math.cos(rec.yaw);
                                    const yOffset = isCavalry ? 1.75 : 1.25;
                                    const fwdOffset = isCavalry ? 0.65 : 0.45;
                                    const mx = rec.x + sinY * fwdOffset;
                                    const my = rec.y + yOffset;
                                    const mz = rec.z + cosY * fwdOffset;
                                    if (this.powderFxPool) {
                                        this.powderFxPool.spawnMuzzleFlashAndSmoke(mx, my, mz, sinY, cosY);
                                    }
                                }
                            }

                            if (rec.actionMode === 'attack' && nextPhase >= 1.0) {
                                rec.actionPhase = 1.0;
                                rec.isCombatActing = false;
                                rec.combatFinished = true;
                                rec.muzzleFired = false;
                            } else {
                                rec.actionPhase = nextPhase % 1.0;
                                if (rec.actionPhase < 0.25) {
                                    rec.muzzleFired = false;
                                }
                            }
                            if (rec.actionBlend < 1) {
                                rec.actionBlend = Math.min(1, rec.actionBlend + safeDt * 8.0);
                            }
                            recordChanged = true;
                            combatPosingCount++;
                        } else if (rec.actionBlend > 0) {
                            rec.actionBlend = Math.max(0, rec.actionBlend - safeDt * 6.5);
                            rec.muzzleFired = false;
                            if (rec.actionBlend === 0) {
                                rec.actionPhase = 0;
                                rec.actionMode = 'attack';
                                rec.combatFinished = false;
                            }
                            recordChanged = true;
                        }
                    }

                    if (recordChanged) {
                        FOC_THREE.Mat4.fromYawTranslation(rec.worldMat, rec.yaw, rec.x, rec.y, rec.z);
                        anyChanged = true;
                    }
                }

                this.stats.movingCount = movingCount;
                this.stats.combatPosingCount = combatPosingCount;

                if (this.powderFxPool) {
                    this.powderFxPool.update(safeDt);
                }

                if (anyChanged) {
                    this._updateBatchBuffersInPlace();
                }

                return movingCount + combatPosingCount;
            }

            _updateBatchBuffersInPlace() {
                const batches = this.batchGroup.batches;
                if (!batches || batches.length === 0) return;

                if (!this._batchWriteOffsets || this._batchWriteOffsets.length < batches.length) {
                    this._batchWriteOffsets = new Int32Array(Math.max(16, batches.length));
                } else {
                    this._batchWriteOffsets.fill(0);
                }
                const writeOffsets = this._batchWriteOffsets;

                for (const rec of this.records.values()) {
                    const parts = this.templates[rec.templateKey] || this.templates['player:infantry_pikeman'];
                    const isInfantry = rec.archetype.startsWith('infantry_');
                    const isCavalry = rec.archetype.startsWith('cavalry');

                    for (let p = 0; p < parts.length; p++) {
                        const part = parts[p];
                        const bIdx = part._batchIndex;
                        if (bIdx === undefined || bIdx < 0 || bIdx >= batches.length) continue;

                        const batch = batches[bIdx];
                        const slot = writeOffsets[bIdx]++;
                        const base = slot * INSTANCE_STRIDE_FLOATS;

                        if (isInfantry && (rec.walkBlend > 1e-4 || rec.actionBlend > 1e-4)) {
                            computeInfantryPartLocalMatrix(
                                this._tmpPartLocalMat,
                                part,
                                rec.archetype,
                                rec.walkPhase,
                                rec.walkBlend,
                                this._scratchA,
                                this._scratchB,
                                rec.actionPhase,
                                rec.actionBlend,
                                rec.actionMode
                            );
                            FOC_THREE.Mat4.multiply(this._tmpWorldPartMat, rec.worldMat, this._tmpPartLocalMat);
                        } else if (isCavalry && (rec.walkBlend > 1e-4 || rec.actionBlend > 1e-4)) {
                            computeCavalryPartLocalMatrix(
                                this._tmpPartLocalMat,
                                part,
                                rec.walkPhase,
                                rec.walkBlend,
                                rec.trotBlend,
                                this._scratchA,
                                this._scratchB,
                                rec.actionPhase,
                                rec.actionBlend,
                                rec.actionMode,
                                rec.archetype,
                                p,
                                parts.length
                            );
                            FOC_THREE.Mat4.multiply(this._tmpWorldPartMat, rec.worldMat, this._tmpPartLocalMat);
                        } else {
                            FOC_THREE.Mat4.multiply(this._tmpWorldPartMat, rec.worldMat, part.localMat);
                        }

                        batch.instanceData.set(this._tmpWorldPartMat, base);
                    }
                }

                for (let b = 0; b < batches.length; b++) {
                    batches[b]._needsUpload = true;
                }
            }

            _rebuildInstanceBatches() {
                if (this.records.size === 0) {
                    this.batchGroup.setBatches([]);
                    return;
                }

                const buckets = new Map();

                for (const rec of this.records.values()) {
                    const parts = this.templates[rec.templateKey] || this.templates['player:infantry_pikeman'];
                    const isInfantry = rec.archetype.startsWith('infantry_');
                    const isCavalry = rec.archetype.startsWith('cavalry');

                    for (let p = 0; p < parts.length; p++) {
                        const part = parts[p];
                        const matObj = this.materials[part.mat] || this.materials.steel;
                        const passKey = matObj.transparent ? 'transparent' : 'opaque';
                        const bucketKey = `${part.prim}:${passKey}`;

                        let bucket = buckets.get(bucketKey);
                        if (!bucket) {
                            bucket = {
                                prim: part.prim,
                                transparent: matObj.transparent,
                                entries: []
                            };
                            buckets.set(bucketKey, bucket);
                        }

                        let localMatToUse = part.localMat;
                        if (isInfantry && (rec.walkBlend > 1e-4 || rec.actionBlend > 1e-4)) {
                            localMatToUse = computeInfantryPartLocalMatrix(
                                FOC_THREE.Mat4.create(),
                                part,
                                rec.archetype,
                                rec.walkPhase,
                                rec.walkBlend,
                                this._scratchA,
                                this._scratchB,
                                rec.actionPhase,
                                rec.actionBlend,
                                rec.actionMode
                            );
                        } else if (isCavalry && (rec.walkBlend > 1e-4 || rec.actionBlend > 1e-4)) {
                            localMatToUse = computeCavalryPartLocalMatrix(
                                FOC_THREE.Mat4.create(),
                                part,
                                rec.walkPhase,
                                rec.walkBlend,
                                rec.trotBlend,
                                this._scratchA,
                                this._scratchB,
                                rec.actionPhase,
                                rec.actionBlend,
                                rec.actionMode,
                                rec.archetype,
                                p,
                                parts.length
                            );
                        }

                        bucket.entries.push({
                            partRef: part,
                            worldMat: rec.worldMat,
                            localMat: localMatToUse,
                            r: matObj.color.r,
                            g: matObj.color.g,
                            b: matObj.color.b,
                            a: matObj.opacity,
                            metalness: matObj.metalness || 0.0
                        });
                    }
                }

                const sortedBuckets = Array.from(buckets.values()).sort(
                    (a, b) => Number(a.transparent) - Number(b.transparent)
                );

                const batches = [];
                const tmpMat = FOC_THREE.Mat4.create();

                for (let bIdx = 0; bIdx < sortedBuckets.length; bIdx++) {
                    const bucket = sortedBuckets[bIdx];
                    const count = bucket.entries.length;
                    const instanceData = new Float32Array(count * INSTANCE_STRIDE_FLOATS);

                    for (let i = 0; i < count; i++) {
                        const entry = bucket.entries[i];
                        entry.partRef._batchIndex = bIdx;
                        const base = i * INSTANCE_STRIDE_FLOATS;
                        FOC_THREE.Mat4.multiply(tmpMat, entry.worldMat, entry.localMat);
                        instanceData.set(tmpMat, base);
                        instanceData[base + 16] = entry.r;
                        instanceData[base + 17] = entry.g;
                        instanceData[base + 18] = entry.b;
                        instanceData[base + 19] = entry.a;
                        instanceData[base + 20] = entry.metalness;
                    }

                    batches.push({
                        geometry: this.geometries[bucket.prim],
                        transparent: bucket.transparent,
                        instanceData,
                        count,
                        _gl: null,
                        _glInstanceBuffer: null,
                        _needsUpload: true
                    });
                }

                this.batchGroup.setBatches(batches);
            }

            clear() {
                this.records.clear();
                this.batchGroup.setBatches([]);
                if (this.powderFxPool) this.powderFxPool.clear();
                this.stats = {
                    activeCount: 0,
                    infantryCount: 0,
                    cavalryCount: 0,
                    movingCount: 0,
                    combatPosingCount: 0,
                    cavalryWeapons: { lance: 0, sabre: 0, carbine: 0, pistol: 0 },
                    batchCount: 0,
                    lastCreated: 0,
                    lastUpdated: 0,
                    lastRemoved: 0
                };
            }

            dispose() {
                this.clear();
                if (this.powderFxPool) {
                    this.powderFxPool.dispose();
                }
                Object.values(this.geometries).forEach((g) => g.dispose());
                Object.values(this.materials).forEach((m) => m.dispose());
                this.batchGroup.dispose();
            }
        }

        /* ============================================================================
         * 4. MODULE: RTSCamera3D (HIGH-ANGLED DAMPED RTS CAMERA CONTROLLER)
         * ============================================================================ */
        
        /* ============================================================================
         * G3D-03H RTS MATEMATİKSEL PROJEKSİYON VE RAYCAST FONKSİYONLARI
         * ============================================================================ */
        function screenToGroundPlane(screenX, screenY, width, height, cameraController) {
            if (!cameraController) return null;
            const safeW = Math.max(1, width);
            const safeH = Math.max(1, height);
            const ndcX = (screenX / safeW) * 2 - 1;
            const ndcY = 1 - (screenY / safeH) * 2;

            const cam = cameraController.current;
            const yaw = cam.yaw;
            const pitch = cam.pitch;
            const dist = cam.distance;

            const eyeX = cam.targetX + Math.sin(yaw) * Math.cos(pitch) * dist;
            const eyeY = Math.sin(pitch) * dist;
            const eyeZ = cam.targetZ + Math.cos(yaw) * Math.cos(pitch) * dist;

            const fwdX = -Math.sin(yaw) * Math.cos(pitch);
            const fwdY = -Math.sin(pitch);
            const fwdZ = -Math.cos(yaw) * Math.cos(pitch);

            const rightX = Math.cos(yaw);
            const rightY = 0;
            const rightZ = -Math.sin(yaw);

            const upX = rightY * fwdZ - rightZ * fwdY;
            const upY = rightZ * fwdX - rightX * fwdZ;
            const upZ = rightX * fwdY - rightY * fwdX;

            const aspect = safeW / safeH;
            const fovHalfTan = Math.tan(42 * 0.5 * Math.PI / 180);

            const rayDirX = fwdX + rightX * (ndcX * aspect * fovHalfTan) + upX * (ndcY * fovHalfTan);
            const rayDirY = fwdY + rightY * (ndcX * aspect * fovHalfTan) + upY * (ndcY * fovHalfTan);
            const rayDirZ = fwdZ + rightZ * (ndcX * aspect * fovHalfTan) + upZ * (ndcY * fovHalfTan);

            if (Math.abs(rayDirY) < 1e-5) return null;
            const t = -eyeY / rayDirY;
            if (t < 0) return null;

            return {
                x: eyeX + t * rayDirX,
                y: 0,
                z: eyeZ + t * rayDirZ
            };
        }

        function projectWorldToScreen(wx, wy, wz, cam, aspect, width, height) {
            const yaw = cam.yaw;
            const pitch = cam.pitch;
            const dist = cam.distance;

            const eyeX = cam.targetX + Math.sin(yaw) * Math.cos(pitch) * dist;
            const eyeY = Math.sin(pitch) * dist;
            const eyeZ = cam.targetZ + Math.cos(yaw) * Math.cos(pitch) * dist;

            const fwdX = -Math.sin(yaw) * Math.cos(pitch);
            const fwdY = -Math.sin(pitch);
            const fwdZ = -Math.cos(yaw) * Math.cos(pitch);

            const rightX = Math.cos(yaw);
            const rightY = 0;
            const rightZ = -Math.sin(yaw);

            const upX = rightY * fwdZ - rightZ * fwdY;
            const upY = rightZ * fwdX - rightX * fwdZ;
            const upZ = rightX * fwdY - rightY * fwdX;

            const dx = wx - eyeX;
            const dy = wy - eyeY;
            const dz = wz - eyeZ;

            const camZ = dx * fwdX + dy * fwdY + dz * fwdZ;
            if (camZ <= 0.1) return null;

            const camX = dx * rightX + dy * rightY + dz * rightZ;
            const camY = dx * upX + dy * upY + dz * upZ;

            const fovHalfTan = Math.tan(42 * 0.5 * Math.PI / 180);
            const ndcX = camX / (camZ * aspect * fovHalfTan);
            const ndcY = camY / (camZ * fovHalfTan);

            return {
                x: (ndcX + 1) * 0.5 * width,
                y: (1 - ndcY) * 0.5 * height,
                depth: camZ
            };
        }

        /* ============================================================================
         * MODULE: RTSSelectionManager (Agent 01 - Birlik Seçimi & Kontrol Grupları)
         * ============================================================================ */
        class RTSSelectionManager {
            constructor(renderer) {
                this.renderer = renderer;
                this.selectedSoldierIds = new Set();
                this.selectedGroupIds = new Set();
                this.controlGroups = new Map();
                this.lastSelectedArchetype = null;
                this.lastClickTime = 0;
                this.lastClickId = null;
            }

            clear() {
                this.selectedSoldierIds.clear();
                this.selectedGroupIds.clear();
                this.lastSelectedArchetype = null;
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            select(soldierId, isShift = false, selectEntireGroup = false) {
                if (!isShift) {
                    this.clear();
                }
                if (!soldierId) return;

                const rec = this.renderer.soldierRegistry?.records?.get(soldierId);
                if (!rec) return;

                if (selectEntireGroup && rec.groupId) {
                    this.selectGroup(rec.groupId, isShift);
                    return;
                }

                if (this.selectedSoldierIds.has(soldierId) && isShift) {
                    this.selectedSoldierIds.delete(soldierId);
                } else {
                    this.selectedSoldierIds.add(soldierId);
                    this.lastSelectedArchetype = rec.archetype;
                    if (rec.groupId) this.selectedGroupIds.add(rec.groupId);
                }
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            selectGroup(groupId, isShift = false) {
                if (!isShift) {
                    this.clear();
                }
                if (!groupId) return;
                this.selectedGroupIds.add(groupId);

                const records = this.renderer.soldierRegistry?.records;
                if (!records) return;

                for (const [id, rec] of records.entries()) {
                    if (rec.groupId === groupId) {
                        this.selectedSoldierIds.add(id);
                        this.lastSelectedArchetype = rec.archetype;
                    }
                }
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            selectInScreenRect(minX, minY, maxX, maxY, isShift = false, cameraController, width, height) {
                if (!isShift) {
                    this.clear();
                }
                const records = this.renderer.soldierRegistry?.records;
                if (!records || records.size === 0) return 0;

                let selectedCount = 0;
                const aspect = width / height;
                const cam = cameraController.current;

                for (const [id, rec] of records.entries()) {
                    const screen = projectWorldToScreen(rec.x, rec.y, rec.z, cam, aspect, width, height);
                    if (screen && screen.x >= minX && screen.x <= maxX && screen.y >= minY && screen.y <= maxY) {
                        this.selectedSoldierIds.add(id);
                        if (rec.groupId) this.selectedGroupIds.add(rec.groupId);
                        this.lastSelectedArchetype = rec.archetype;
                        selectedCount++;
                    }
                }
                if (this.renderer) this.renderer.selectionDirty = true;
                return selectedCount;
            }

            selectSameClass(archetype, isShift = false) {
                if (!isShift) {
                    this.clear();
                }
                const records = this.renderer.soldierRegistry?.records;
                if (!records) return;

                for (const [id, rec] of records.entries()) {
                    if (rec.archetype === archetype) {
                        this.selectedSoldierIds.add(id);
                        if (rec.groupId) this.selectedGroupIds.add(rec.groupId);
                    }
                }
                if (this.renderer) this.renderer.selectionDirty = true;
            }

            assignControlGroup(num) {
                if (num < 1 || num > 9) return;
                this.controlGroups.set(num, new Set(this.selectedSoldierIds));
            }

            recallControlGroup(num, isShift = false) {
                if (num < 1 || num > 9) return false;
                const group = this.controlGroups.get(num);
                if (!group || group.size === 0) return false;

                if (!isShift) {
                    this.clear();
                }
                for (const id of group) {
                    this.selectedSoldierIds.add(id);
                    const rec = this.renderer.soldierRegistry?.records?.get(id);
                    if (rec && rec.groupId) this.selectedGroupIds.add(rec.groupId);
                }
                if (this.renderer) this.renderer.selectionDirty = true;
                return true;
            }

            isSelected(soldierId) {
                return this.selectedSoldierIds.has(soldierId);
            }

            getSelectedList() {
                const records = this.renderer.soldierRegistry?.records;
                if (!records) return [];
                const list = [];
                for (const id of this.selectedSoldierIds) {
                    const r = records.get(id);
                    if (r) list.push(r);
                }
                return list;
            }
        }

        /* ============================================================================
         * MODULE: RTSFormationManager (Agent 03 - 6 Taktik Formasyon Sistemi)
         * ============================================================================ */
        class RTSFormationManager {
            constructor() {
                this.currentFormation = 'line';
            }

            setFormation(type) {
                const valid = ['line', 'column', 'wedge', 'loose', 'skirmish', 'circle'];
                if (valid.includes(type)) {
                    this.currentFormation = type;
                    return true;
                }
                return false;
            }

            computeSlots(count, isCavalry = false, facingYaw = 0.0, formationOverride = null) {
                const form = formationOverride || this.currentFormation;
                const spX = isCavalry ? 2.2 : 1.1;
                const spZ = isCavalry ? 2.5 : 1.3;
                const localSlots = [];

                if (form === 'line') {
                    const files = Math.ceil(count / 2);
                    for (let i = 0; i < count; i++) {
                        const rank = i % 2;
                        const col = Math.floor(i / 2);
                        const lx = (col - (files - 1) * 0.5) * spX;
                        const lz = -rank * spZ;
                        localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                    }
                } else if (form === 'column') {
                    const numCols = count <= 4 ? 2 : 3;
                    for (let i = 0; i < count; i++) {
                        const col = i % numCols;
                        const row = Math.floor(i / numCols);
                        const lx = (col - (numCols - 1) * 0.5) * spX;
                        const lz = -row * spZ;
                        localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                    }
                } else if (form === 'wedge') {
                    for (let i = 0; i < count; i++) {
                        if (i === 0) {
                            localSlots.push({ x: 0, z: 0, extraYaw: 0 });
                        } else {
                            const tier = Math.floor((i + 1) / 2);
                            const side = (i % 2 === 1) ? -1 : 1;
                            const lx = side * tier * spX * 0.9;
                            const lz = -tier * spZ * 1.1;
                            localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                        }
                    }
                } else if (form === 'loose') {
                    const cols = Math.ceil(Math.sqrt(count * 1.5));
                    for (let i = 0; i < count; i++) {
                        const row = Math.floor(i / cols);
                        const col = i % cols;
                        const stagger = (row % 2) * 0.5 * spX;
                        const lx = (col - (cols - 1) * 0.5) * (spX * 2.0) + stagger;
                        const lz = -row * (spZ * 1.8);
                        localSlots.push({ x: lx, z: lz, extraYaw: 0 });
                    }
                } else if (form === 'skirmish') {
                    const maxR = Math.sqrt(count) * spX * 1.2;
                    for (let i = 0; i < count; i++) {
                        const r = Math.sqrt((i + 0.5) / count) * maxR;
                        const ang = i * 2.3999632;
                        localSlots.push({
                            x: r * Math.cos(ang),
                            z: r * Math.sin(ang),
                            extraYaw: 0
                        });
                    }
                } else if (form === 'circle') {
                    const r = Math.max(3.0, (count * spX) / (2.0 * Math.PI));
                    for (let i = 0; i < count; i++) {
                        const ang = (i / count) * 2.0 * Math.PI;
                        localSlots.push({
                            x: r * Math.sin(ang),
                            z: r * Math.cos(ang),
                            extraYaw: ang
                        });
                    }
                }

                const cosY = Math.cos(facingYaw);
                const sinY = Math.sin(facingYaw);
                return localSlots.map(s => ({
                    dx: s.x * cosY - s.z * sinY,
                    dz: s.x * sinY + s.z * cosY,
                    yaw: facingYaw + s.extraYaw
                }));
            }
        }

        /* ============================================================================
         * MODULE: RTSMovementManager (Agent 02 - Birlik Hareketi & Rota Yönlendirme)
         * ============================================================================ */
        class RTSMovementManager {
            constructor(renderer) {
                this.renderer = renderer;
                this.waypointQueues = new Map();
                this.activeMovePings = [];
            }

            issueMoveOrder(targetX, targetZ, isShift = false, formationManager = null) {
                const selection = this.renderer.selectionManager?.getSelectedList() || [];
                if (selection.length === 0) return;

                this.triggerMovePing(targetX, targetZ);

                const groups = new Map();
                for (const sol of selection) {
                    const gKey = sol.groupId || 'independent';
                    if (!groups.has(gKey)) groups.set(gKey, []);
                    groups.get(gKey).push(sol);
                }

                for (const [gKey, soldiers] of groups.entries()) {
                    let cx = 0, cz = 0;
                    soldiers.forEach(s => { cx += s.x; cz += s.z; });
                    cx /= soldiers.length;
                    cz /= soldiers.length;

                    const facingYaw = Math.atan2(targetX - cx, targetZ - cz);
                    const isCavalry = soldiers[0]?.archetype?.startsWith('cavalry');
                    const slots = formationManager
                        ? formationManager.computeSlots(soldiers.length, isCavalry, facingYaw)
                        : soldiers.map(() => ({ dx: 0, dz: 0, yaw: facingYaw }));

                    for (let i = 0; i < soldiers.length; i++) {
                        const sol = soldiers[i];
                        const slot = slots[i];
                        const destX = targetX + slot.dx;
                        const destZ = targetZ + slot.dz;

                        if (!isShift) {
                            this.waypointQueues.delete(sol.viewId);
                            sol.targetX = destX;
                            sol.targetY = 0;
                            sol.targetZ = destZ;
                            sol.desiredYaw = slot.yaw;
                            sol.isMoving = true;
                            sol.currentOrder = 'move';
                            sol.isCombatActing = false;
                        } else {
                            if (!this.waypointQueues.has(sol.viewId)) {
                                this.waypointQueues.set(sol.viewId, []);
                            }
                            this.waypointQueues.get(sol.viewId).push({ x: destX, z: destZ, yaw: slot.yaw });
                        }
                    }
                }
            }

            updateWaypoints() {
                const records = this.renderer.soldierRegistry?.records;
                if (!records) return;

                for (const [id, queue] of this.waypointQueues.entries()) {
                    if (queue.length === 0) continue;
                    const sol = records.get(id);
                    if (!sol) continue;

                    const dist = Math.hypot(sol.targetX - sol.x, sol.targetZ - sol.z);
                    if (dist < 0.45 && !sol.isMoving) {
                        const nextWp = queue.shift();
                        sol.targetX = nextWp.x;
                        sol.targetY = 0;
                        sol.targetZ = nextWp.z;
                        sol.desiredYaw = nextWp.yaw;
                        sol.isMoving = true;
                    }
                }
            }

            triggerMovePing(x, z) {
                this.activeMovePings.push({ x, z, progress: 0 });
            }

            updatePings(dt) {
                for (let i = this.activeMovePings.length - 1; i >= 0; i--) {
                    this.activeMovePings[i].progress += dt * 1.5;
                    if (this.activeMovePings[i].progress >= 1.0) {
                        this.activeMovePings.splice(i, 1);
                    }
                }
            }
        }

        /* ============================================================================
         * MODULE: RTSCommandManager (Agent 05 - 8 Taktik RTS Emir Sistemi)
         * ============================================================================ */
        class RTSCommandManager {
            constructor(renderer) {
                this.renderer = renderer;
                this.currentOrder = 'move';
            }

            executeCommand(orderType) {
                const selection = this.renderer.selectionManager?.getSelectedList() || [];
                if (selection.length === 0) return false;

                this.currentOrder = orderType;

                for (const sol of selection) {
                    sol.currentOrder = orderType;

                    if (orderType === 'hold') {
                        sol.targetX = sol.x;
                        sol.targetY = sol.y;
                        sol.targetZ = sol.z;
                        sol.isMoving = false;
                        sol.isCombatActing = true;
                        sol.actionMode = 'guard';
                    } else if (orderType === 'attack') {
                        sol.isCombatActing = true;
                        sol.actionMode = 'attack';
                    } else if (orderType === 'attack_move') {
                        sol.actionMode = 'attack';
                    } else if (orderType === 'retreat') {
                        const retreatDir = sol.side === 'player' ? -1 : 1;
                        sol.targetX = sol.x;
                        sol.targetZ = sol.z + retreatDir * 20.0;
                        sol.desiredYaw = retreatDir < 0 ? Math.PI : 0;
                        sol.isMoving = true;
                        sol.isCombatActing = false;
                    } else if (orderType === 'fire_at_will') {
                        const isRanged = sol.archetype === 'infantry_musketeer' || sol.archetype.includes('carbine') || sol.archetype.includes('pistol');
                        if (isRanged) {
                            sol.isCombatActing = true;
                            sol.actionMode = 'attack';
                        }
                    } else if (orderType === 'hold_fire') {
                        sol.isCombatActing = false;
                        sol.muzzleFired = false;
                    } else if (orderType === 'regroup') {
                        const formManager = this.renderer.formationManager;
                        if (formManager) {
                            const selList = this.renderer.selectionManager.getSelectedList();
                            let cx = 0, cz = 0;
                            selList.forEach(s => { cx += s.x; cz += s.z; });
                            cx /= selList.length;
                            cz /= selList.length;
                            this.renderer.movementManager.issueMoveOrder(cx, cz, false, formManager);
                        }
                    }
                }
                return true;
            }
        }

        /* ============================================================================
         * MODULE: RTSMinimapController (Agent 06 - Sade Taktik Minimap & Radar)
         * ============================================================================ */
        class RTSMinimapController {
            constructor(canvas, renderer) {
                this.canvas = canvas;
                this.ctx = canvas ? canvas.getContext('2d') : null;
                this.renderer = renderer;
                this.isDragging = false;
                this.bounds = { minX: -60, maxX: 60, minZ: -60, maxZ: 60 };
                this._bindEvents();
            }

            _bindEvents() {
                if (!this.canvas) return;
                this.canvas.addEventListener('mousedown', (e) => {
                    if (e.button === 0) {
                        this.isDragging = true;
                        this._handleClick(e);
                    } else if (e.button === 2) {
                        e.preventDefault();
                        this._handleRightClick(e);
                    }
                });
                window.addEventListener('mousemove', (e) => {
                    if (this.isDragging) this._handleClick(e);
                });
                window.addEventListener('mouseup', () => {
                    this.isDragging = false;
                });
                this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
            }

            _handleClick(e) {
                const rect = this.canvas.getBoundingClientRect();
                const mx = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                const my = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));

                const wx = this.bounds.minX + mx * (this.bounds.maxX - this.bounds.minX);
                const wz = this.bounds.minZ + my * (this.bounds.maxZ - this.bounds.minZ);

                if (this.renderer.cameraController) {
                    this.renderer.cameraController.desired.targetX = wx;
                    this.renderer.cameraController.desired.targetZ = wz;
                }
            }

            _handleRightClick(e) {
                const rect = this.canvas.getBoundingClientRect();
                const mx = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
                const my = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));

                const wx = this.bounds.minX + mx * (this.bounds.maxX - this.bounds.minX);
                const wz = this.bounds.minZ + my * (this.bounds.maxZ - this.bounds.minZ);

                if (this.renderer.movementManager) {
                    this.renderer.movementManager.issueMoveOrder(wx, wz, e.shiftKey, this.renderer.formationManager);
                }
            }

            render() {
                if (!this.ctx || !this.renderer) return;
                const ctx = this.ctx;
                const w = this.canvas.width;
                const h = this.canvas.height;

                ctx.clearRect(0, 0, w, h);

                // Grid lines
                ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(w * 0.5, 0); ctx.lineTo(w * 0.5, h);
                ctx.moveTo(0, h * 0.5); ctx.lineTo(w, h * 0.5);
                ctx.stroke();

                // Render soldiers
                const records = this.renderer.soldierRegistry?.records;
                const selManager = this.renderer.selectionManager;

                if (records) {
                    for (const [id, sol] of records.entries()) {
                        const sx = ((sol.x - this.bounds.minX) / (this.bounds.maxX - this.bounds.minX)) * w;
                        const sy = ((sol.z - this.bounds.minZ) / (this.bounds.maxZ - this.bounds.minZ)) * h;

                        const isSelected = selManager && selManager.isSelected(id);

                        if (isSelected) {
                            ctx.fillStyle = '#facc15';
                            ctx.beginPath();
                            ctx.arc(sx, sy, 3.5, 0, Math.PI * 2);
                            ctx.fill();
                        }

                        ctx.fillStyle = sol.side === 'enemy' ? '#ef4444' : '#38bdf8';
                        ctx.beginPath();
                        ctx.arc(sx, sy, isSelected ? 2.2 : 1.6, 0, Math.PI * 2);
                        ctx.fill();
                    }
                }

                // Render camera viewport frustum rectangle
                const cam = this.renderer.cameraController?.current;
                if (cam) {
                    const cx = ((cam.targetX - this.bounds.minX) / (this.bounds.maxX - this.bounds.minX)) * w;
                    const cy = ((cam.targetZ - this.bounds.minZ) / (this.bounds.maxZ - this.bounds.minZ)) * h;
                    const viewRadius = (cam.distance / 95.0) * (w * 0.22);

                    ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
                    ctx.lineWidth = 1.5;
                    ctx.strokeRect(cx - viewRadius, cy - viewRadius * 0.7, viewRadius * 2, viewRadius * 1.4);

                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(cx - 1.5, cy - 1.5, 3, 3);
                }
            }
        }

        class RTSCamera3D {
            constructor(options = {}) {
                const aspect = Number.isFinite(options.aspect) && options.aspect > 0 ? options.aspect : 1;
                this.onUpdate = typeof options.onUpdate === 'function' ? options.onUpdate : null;

                this.camera = new FOC_THREE.PerspectiveCamera(42, aspect, 0.5, 340);

                this.bounds = {
                    minX: -55,
                    maxX: 55,
                    minZ: -55,
                    maxZ: 55
                };

                this.defaultTarget = { x: 0, z: 0 };

                this.limits = {
                    minDistance: 6,
                    maxDistance: 95,
                    minPitch: 0.34,
                    maxPitch: 1.24
                };

                this.current = {
                    targetX: 0,
                    targetZ: 0,
                    distance: 46,
                    yaw: 0.0,
                    pitch: 0.88
                };

                this.desired = { ...this.current };
                this.syncTransform(1);
            }

            setBoundsAndTarget(bounds, target = null, snap = false) {
                if (bounds) {
                    this.bounds = {
                        minX: Number.isFinite(bounds.minX) ? bounds.minX : -55,
                        maxX: Number.isFinite(bounds.maxX) ? bounds.maxX : 55,
                        minZ: Number.isFinite(bounds.minZ) ? bounds.minZ : -55,
                        maxZ: Number.isFinite(bounds.maxZ) ? bounds.maxZ : 55
                    };
                }

                if (target && Number.isFinite(target.x) && Number.isFinite(target.z)) {
                    this.defaultTarget = {
                        x: this._clamp(target.x, this.bounds.minX, this.bounds.maxX),
                        z: this._clamp(target.z, this.bounds.minZ, this.bounds.maxZ)
                    };
                    this.desired.targetX = this.defaultTarget.x;
                    this.desired.targetZ = this.defaultTarget.z;
                } else {
                    this.desired.targetX = this._clamp(this.desired.targetX, this.bounds.minX, this.bounds.maxX);
                    this.desired.targetZ = this._clamp(this.desired.targetZ, this.bounds.minZ, this.bounds.maxZ);
                }

                if (snap) {
                    this.current.targetX = this.desired.targetX;
                    this.current.targetZ = this.desired.targetZ;
                    this.syncTransform(1);
                }
            }

            
            focusOnSelection(selectionList) {
                if (!selectionList || selectionList.length === 0) {
                    this.focusOnDefaultTarget();
                    return;
                }
                let sumX = 0, sumZ = 0;
                selectionList.forEach(s => { sumX += s.x; sumZ += s.z; });
                this.desired.targetX = this._clamp(sumX / selectionList.length, this.bounds.minX, this.bounds.maxX);
                this.desired.targetZ = this._clamp(sumZ / selectionList.length, this.bounds.minZ, this.bounds.maxZ);
            }

            focusOnDefaultTarget() {
                this.desired.targetX = this._clamp(this.defaultTarget.x, this.bounds.minX, this.bounds.maxX);
                this.desired.targetZ = this._clamp(this.defaultTarget.z, this.bounds.minZ, this.bounds.maxZ);
                this.desired.distance = 46;
                this.desired.yaw = 0;
                this.desired.pitch = 0.88;
            }

            panRelative(forwardDelta, rightDelta) {
                const forwardX = -Math.sin(this.current.yaw);
                const forwardZ = -Math.cos(this.current.yaw);
                const rightX = Math.cos(this.current.yaw);
                const rightZ = -Math.sin(this.current.yaw);

                this.desired.targetX += forwardX * forwardDelta + rightX * rightDelta;
                this.desired.targetZ += forwardZ * forwardDelta + rightZ * rightDelta;
                this._clampDesired();
            }

            panByScreenDelta(dx, dy) {
                const scale = this.current.distance * 0.0019;
                const cosY = Math.cos(this.current.yaw);
                const sinY = Math.sin(this.current.yaw);
                this.desired.targetX -= (dx * cosY + dy * sinY) * scale;
                this.desired.targetZ -= (-dx * sinY + dy * cosY) * scale;
                this._clampDesired();
            }

            rotateBy(deltaYaw, deltaPitch = 0) {
                this.desired.yaw += deltaYaw;
                this.desired.pitch += deltaPitch;
                this._clampDesired();
            }

            zoomBy(deltaDistance) {
                this.desired.distance += deltaDistance;
                this._clampDesired();
            }

            resize(width, height) {
                const safeW = Math.max(1, width);
                const safeH = Math.max(1, height);
                this.camera.aspect = safeW / safeH;
                this.camera.updateProjectionMatrix();
            }

            syncTransform(dt) {
                this._clampDesired();
                const smooth = dt >= 1 ? 1 : (1 - Math.exp(-10 * Math.max(0.001, dt)));

                this.current.targetX += (this.desired.targetX - this.current.targetX) * smooth;
                this.current.targetZ += (this.desired.targetZ - this.current.targetZ) * smooth;
                this.current.distance += (this.desired.distance - this.current.distance) * smooth;
                this.current.yaw += (this.desired.yaw - this.current.yaw) * smooth;
                this.current.pitch += (this.desired.pitch - this.current.pitch) * smooth;

                const horizDist = Math.cos(this.current.pitch) * this.current.distance;
                const vertDist = Math.sin(this.current.pitch) * this.current.distance;

                this.camera.position.set(
                    this.current.targetX + Math.sin(this.current.yaw) * horizDist,
                    vertDist,
                    this.current.targetZ + Math.cos(this.current.yaw) * horizDist
                );
                this.camera.lookAt(this.current.targetX, 0, this.current.targetZ);

                if (this.onUpdate) {
                    this.onUpdate({
                        targetX: this.current.targetX,
                        targetZ: this.current.targetZ,
                        distance: this.current.distance,
                        yaw: this.current.yaw,
                        pitch: this.current.pitch
                    });
                }
            }

            _clampDesired() {
                this.desired.targetX = this._clamp(this.desired.targetX, this.bounds.minX, this.bounds.maxX);
                this.desired.targetZ = this._clamp(this.desired.targetZ, this.bounds.minZ, this.bounds.maxZ);
                this.desired.distance = this._clamp(this.desired.distance, this.limits.minDistance, this.limits.maxDistance);
                this.desired.pitch = this._clamp(this.desired.pitch, this.limits.minPitch, this.limits.maxPitch);
            }

            _clamp(val, min, max) {
                return Math.max(min, Math.min(max, val));
            }
        }

        /* ============================================================================
         * 5. MODULE: Battle3DRenderer (SYNCHRONIZED CONTEXT LOSS / RESTORE & CLEANUP)
         * ============================================================================ */
        const DEFAULT_SECTOR_BOUNDS = Object.freeze({
            minX: -55,
            maxX: 55,
            minZ: -55,
            maxZ: 55
        });

        function deriveSectorViewBounds(snapshot) {
            if (!snapshot || typeof snapshot !== 'object') {
                return {
                    isEmpty: true,
                    sectorId: 'BOS_SEKTOR',
                    bounds: { ...DEFAULT_SECTOR_BOUNDS },
                    cameraTarget: { x: 0, z: 0 },
                    uniqueGroupCount: 0,
                    playerCount: 0,
                    enemyCount: 0,
                    totalVisible: 0,
                    hiddenAlive: { player: 0, enemy: 0 },
                    limits: { player: 150, enemy: 150 },
                    dataAuthority: 'none'
                };
            }

            const soldiers = Array.isArray(snapshot.soldiers) ? snapshot.soldiers : [];
            const uniqueGroups = new Set();

            let minX = Infinity;
            let maxX = -Infinity;
            let minZ = Infinity;
            let maxZ = -Infinity;
            let sumX = 0;
            let sumZ = 0;
            let validPosCount = 0;
            let countedPlayer = 0;
            let countedEnemy = 0;

            for (let i = 0; i < soldiers.length; i++) {
                const s = soldiers[i];
                if (!s || typeof s !== 'object') continue;

                if (s.groupId !== null && s.groupId !== undefined && s.groupId !== '') {
                    uniqueGroups.add(s.groupId);
                }

                if (s.side === 'player') {
                    countedPlayer++;
                } else if (s.side === 'enemy') {
                    countedEnemy++;
                }

                const pos = s.position;
                if (pos && Number.isFinite(pos.x) && Number.isFinite(pos.z)) {
                    if (pos.x < minX) minX = pos.x;
                    if (pos.x > maxX) maxX = pos.x;
                    if (pos.z < minZ) minZ = pos.z;
                    if (pos.z > maxZ) maxZ = pos.z;
                    sumX += pos.x;
                    sumZ += pos.z;
                    validPosCount++;
                }
            }

            const playerCount = snapshot.visible && Number.isFinite(snapshot.visible.player)
                ? snapshot.visible.player
                : countedPlayer;
            const enemyCount = snapshot.visible && Number.isFinite(snapshot.visible.enemy)
                ? snapshot.visible.enemy
                : countedEnemy;

            const isEmpty = validPosCount === 0 && (playerCount + enemyCount) === 0;

            let bounds = { ...DEFAULT_SECTOR_BOUNDS };
            let cameraTarget = { x: 0, z: 0 };

            if (validPosCount > 0) {
                const centerX = sumX / validPosCount;
                const centerZ = sumZ / validPosCount;
                const padding = 24;
                const minHalfSpan = 45;

                const rawHalfX = Math.max(minHalfSpan, ((maxX - minX) * 0.5) + padding);
                const rawHalfZ = Math.max(minHalfSpan, ((maxZ - minZ) * 0.5) + padding);

                bounds = {
                    minX: Math.round((centerX - rawHalfX) * 10) / 10,
                    maxX: Math.round((centerX + rawHalfX) * 10) / 10,
                    minZ: Math.round((centerZ - rawHalfZ) * 10) / 10,
                    maxZ: Math.round((centerZ + rawHalfZ) * 10) / 10
                };
                cameraTarget = {
                    x: Math.round(centerX * 10) / 10,
                    z: Math.round(centerZ * 10) / 10
                };
            }

            return {
                isEmpty,
                sectorId: snapshot.sectorId ? String(snapshot.sectorId) : 'BOS_SEKTOR',
                bounds,
                cameraTarget,
                uniqueGroupCount: uniqueGroups.size,
                playerCount,
                enemyCount,
                totalVisible: playerCount + enemyCount,
                hiddenAlive: {
                    player: snapshot.hiddenAlive && Number.isFinite(snapshot.hiddenAlive.player) ? snapshot.hiddenAlive.player : 0,
                    enemy: snapshot.hiddenAlive && Number.isFinite(snapshot.hiddenAlive.enemy) ? snapshot.hiddenAlive.enemy : 0
                },
                limits: {
                    player: snapshot.limits && Number.isFinite(snapshot.limits.player) ? snapshot.limits.player : 150,
                    enemy: snapshot.limits && Number.isFinite(snapshot.limits.enemy) ? snapshot.limits.enemy : 150
                },
                dataAuthority: typeof snapshot.dataAuthority === 'string' ? snapshot.dataAuthority : 'existing_battle_simulation'
            };
        }

        class Battle3DRenderer {
            constructor(options = {}) {
                this.onCameraUpdate = typeof options.onCameraUpdate === 'function' ? options.onCameraUpdate : null;
                this.onError = typeof options.onError === 'function' ? options.onError : null;
                this.onContextRestored = typeof options.onContextRestored === 'function' ? options.onContextRestored : null;
                this.onFrameTick = typeof options.onFrameTick === 'function' ? options.onFrameTick : null;
                this.rendererFactory = typeof options.rendererFactory === 'function' ? options.rendererFactory : null;

                this.mount = null;
                this.isInitialized = false;
                this.isDisposed = false;
                this.isContextLost = false;
                this.contextLossType = 'none';
                this.rafId = null;
                this.lastTimestamp = 0;

                this.scene = null;
                this.cameraController = null;
                this.renderer = null;
                this.resizeObserver = null;
                this.sectorFrameNode = null;
                this.sectorCenterCrossNode = null;
                this.soldierRegistry = null;
                this.derivedSummary = deriveSectorViewBounds(null);

                this.disposables = {
                    geometries: [],
                    materials: [],
                    textures: []
                };

                
                this.selectionManager = new RTSSelectionManager(this);
                this.formationManager = new RTSFormationManager();
                this.movementManager = new RTSMovementManager(this);
                this.commandManager = new RTSCommandManager(this);
                this.minimapController = null;
                this.selectionDirty = true;
                this.selectionRingsNode = null;
                this.movePingNode = null;
                this.dragSelect = {
                    active: false,
                    startX: 0,
                    startY: 0,
                    currentX: 0,
                    currentY: 0
                };

                this.input = {
                    keys: {},
                    isPanning: false,
                    isOrbiting: false,
                    lastX: 0,
                    lastY: 0,
                    touchLastX: 0,
                    touchLastY: 0,
                    pinchDist: 0
                };

                this._boundAnimate = this._animate.bind(this);
                this._boundResize = this.resize.bind(this);
                this._boundKeyDown = this._onKeyDown.bind(this);
                this._boundKeyUp = this._onKeyUp.bind(this);
                this._boundMouseDown = this._onMouseDown.bind(this);
                this._boundMouseMove = this._onMouseMove.bind(this);
                this._boundMouseUp = this._onMouseUp.bind(this);
                this._boundWheel = this._onWheel.bind(this);
                this._boundTouchStart = this._onTouchStart.bind(this);
                this._boundTouchMove = this._onTouchMove.bind(this);
                this._boundTouchEnd = this._onTouchEnd.bind(this);
            }

            static isWebGLAvailable() {
                try {
                    if (typeof document === 'undefined') return false;
                    const testCanvas = document.createElement('canvas');
                    return Boolean(
                        typeof window !== 'undefined' &&
                        window.WebGLRenderingContext &&
                        (testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl'))
                    );
                } catch (err) {
                    return false;
                }
            }

            init(mountElement, initialSnapshot = null) {
                if (this.isInitialized && !this.isContextLost) return true;

                if (!mountElement) {
                    this._reportError('3D sahne bağlama öğesi (mount) bulunamadı.');
                    return false;
                }

                if (!this.rendererFactory && !Battle3DRenderer.isWebGLAvailable()) {
                    this._reportError('Tarayıcı veya cihaz WebGL desteği sağlamıyor.');
                    return false;
                }

                try {
                    this.mount = mountElement;
                    this.isDisposed = false;
                    this.isContextLost = false;
                    this.contextLossType = 'none';

                    const width = Math.max(1, this.mount.clientWidth || window.innerWidth || 800);
                    const height = Math.max(1, this.mount.clientHeight || window.innerHeight || 600);

                    this.scene = new FOC_THREE.Scene();
                    this.scene.background = new FOC_THREE.Color(BATTLEFIELD_VISUAL_CONFIG.atmosphere.skyColor);
                    this.scene.fog = new FOC_THREE.FogExp2(BATTLEFIELD_VISUAL_CONFIG.atmosphere.fogColor, BATTLEFIELD_VISUAL_CONFIG.atmosphere.fogDensity);

                    this.cameraController = new RTSCamera3D({
                        aspect: width / height,
                        onUpdate: this.onCameraUpdate
                    });

                    const handleContextLost = (reasonMsg, meta = {}) => {
                        this._onWebGLContextLost(reasonMsg, meta);
                    };

                    const handleContextRestored = () => {
                        this._onWebGLContextRestored();
                    };

                    if (this.rendererFactory) {
                        this.renderer = this.rendererFactory({
                            width,
                            height,
                            onContextLost: handleContextLost,
                            onContextRestored: handleContextRestored
                        });
                    } else {
                        this.renderer = new FOC_THREE.WebGLRenderer({
                            antialias: true,
                            powerPreference: 'high-performance',
                            onContextLost: handleContextLost,
                            onContextRestored: handleContextRestored
                        });
                        this.renderer.setSize(width, height);
                        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
                    }

                    if (!this.renderer) {
                        throw new Error('WebGL renderer örneği oluşturulamadı.');
                    }

                    if (!this.renderer.onContextLost) {
                        this.renderer.onContextLost = handleContextLost;
                    }
                    if (!this.renderer.onContextRestored) {
                        this.renderer.onContextRestored = handleContextRestored;
                    }

                    if (this.renderer.domElement) {
                        this.mount.innerHTML = '';
                        this.mount.appendChild(this.renderer.domElement);
                    }

                    this._buildTemporary1650Terrain();
                    this._buildSectorBoundaryMarkers();

                    this.soldierRegistry = new SoldierVisualRegistry();
                    this.scene.add(this.soldierRegistry.batchGroup);
                    this.scene.add(this.soldierRegistry.powderFxPool.batchGroup);

                    this.sync(initialSnapshot, { snapCamera: true });

                    this._bindEvents();

                    this.isInitialized = true;
                    this.lastTimestamp = performance.now();
                    
                this._buildSelectionAndPingVisuals();
                const minimapCanvas = document.getElementById('rtsMinimapCanvas');
                if (minimapCanvas) {
                    this.minimapController = new RTSMinimapController(minimapCanvas, this);
                }

                this._startAnimationLoop();
                    return true;
                } catch (err) {
                    this.dispose();
                    this._reportError(`WebGL sahnesi başlatılamadı: ${err.message}`);
                    return false;
                }
            }

            _startAnimationLoop() {
                if (this.rafId === null && this.isInitialized && !this.isDisposed && !this.isContextLost) {
                    this.lastTimestamp = performance.now();
                    this.rafId = requestAnimationFrame(this._boundAnimate);
                }
            }

            _stopAnimationLoop() {
                if (this.rafId !== null) {
                    cancelAnimationFrame(this.rafId);
                    this.rafId = null;
                }
            }

            _invalidateSceneGpuResources() {
                this.disposables.geometries.forEach((g) => {
                    if (g && typeof g.invalidateGpuHandle === 'function') g.invalidateGpuHandle();
                });
                this.disposables.textures.forEach((t) => {
                    if (t && typeof t.invalidateGpuHandle === 'function') t.invalidateGpuHandle();
                });
                if (this.soldierRegistry && typeof this.soldierRegistry.invalidateGpuHandles === 'function') {
                    this.soldierRegistry.invalidateGpuHandles();
                }
            }

            _onWebGLContextLost(reasonMsg, meta = {}) {
                if (this.isDisposed) return;

                const isSimulated = Boolean(meta && meta.simulated);
                this.isContextLost = true;
                this.contextLossType = isSimulated ? 'simulated' : 'hardware';

                if (this.renderer && this.renderer._contextLost !== true) {
                    this.renderer._contextLost = true;
                    this.renderer._contextLossSource = this.contextLossType;
                }

                this._stopAnimationLoop();
                this._invalidateSceneGpuResources();

                this._reportError(
                    reasonMsg || 'WebGL bağlamı (context) kayboldu. Geçersiz GPU kaynakları durduruldu; sahneyi yeniden başlatabilirsiniz.'
                );
            }

            _onWebGLContextRestored() {
                if (this.isDisposed || !this.isInitialized) return;
                if (this.renderer && this.renderer._contextLost) {
                    return;
                }

                this._invalidateSceneGpuResources();
                this.isContextLost = false;
                this.contextLossType = 'none';
                
                this._buildSelectionAndPingVisuals();
                const minimapCanvas = document.getElementById('rtsMinimapCanvas');
                if (minimapCanvas) {
                    this.minimapController = new RTSMinimapController(minimapCanvas, this);
                }

                this._startAnimationLoop();

                if (this.renderer && this.scene && this.cameraController) {
                    this.renderer.render(this.scene, this.cameraController.camera);
                }

                if (this.onContextRestored) {
                    this.onContextRestored();
                }
            }

            simulateContextLoss() {
                if (!this.isInitialized || this.isDisposed || this.isContextLost) return false;

                if (this.renderer && typeof this.renderer.simulateContextLoss === 'function') {
                    const result = this.renderer.simulateContextLoss();
                    if (!this.isContextLost) {
                        this._onWebGLContextLost(
                            'Simüle edilmiş WebGL context kaybı tetiklendi.',
                            { simulated: true }
                        );
                    }
                    return Boolean(result);
                }

                if (this.renderer && typeof this.renderer.forceContextLoss === 'function') {
                    const triggered = this.renderer.forceContextLoss();
                    if (!triggered) {
                        this._onWebGLContextLost('Simüle edilmiş WebGL context kaybı tetiklendi.', { simulated: true });
                    }
                    return true;
                }

                this._onWebGLContextLost('Simüle edilmiş WebGL context kaybı tetiklendi.', { simulated: true });
                return true;
            }

            restoreSimulatedContext() {
                if (!this.isInitialized || this.isDisposed || !this.isContextLost) return false;
                if (this.renderer && typeof this.renderer._handleContextRestored === 'function') {
                    return this.renderer._handleContextRestored();
                }
                return false;
            }

            sync(snapshot, options = {}) {
                const derived = deriveSectorViewBounds(snapshot);

                let soldierStats = {
                    activeCount: 0,
                    infantryCount: 0,
                    cavalryCount: 0,
                    movingCount: 0,
                    combatPosingCount: 0,
                    cavalryWeapons: { lance: 0, sabre: 0, carbine: 0, pistol: 0 },
                    batchCount: 0,
                    lastCreated: 0,
                    lastUpdated: 0,
                    lastRemoved: 0
                };

                if (this.soldierRegistry) {
                    soldierStats = this.soldierRegistry.sync(snapshot);
                }

                derived.soldierVisuals = soldierStats;
                this.derivedSummary = derived;

                const width = Math.max(20, derived.bounds.maxX - derived.bounds.minX);
                const depth = Math.max(20, derived.bounds.maxZ - derived.bounds.minZ);
                const centerX = (derived.bounds.minX + derived.bounds.maxX) * 0.5;
                const centerZ = (derived.bounds.minZ + derived.bounds.maxZ) * 0.5;

                if (this.sectorFrameNode) {
                    this.sectorFrameNode.position.set(centerX, 0, centerZ);
                    this.sectorFrameNode.scale.set(width, 1, depth);
                }

                if (this.sectorCenterCrossNode) {
                    this.sectorCenterCrossNode.position.set(derived.cameraTarget.x, 0, derived.cameraTarget.z);
                }

                if (this.cameraController && !options.preserveCamera) {
                    this.cameraController.setBoundsAndTarget(
                        derived.bounds,
                        derived.cameraTarget,
                        Boolean(options.snapCamera)
                    );
                } else if (this.cameraController && options.preserveCamera) {
                    this.cameraController.setBoundsAndTarget(
                        derived.bounds,
                        null,
                        false
                    );
                }

                return derived;
            }

            stepSimulation(dt) {
                if (this.soldierRegistry) {
                    return this.soldierRegistry.update(dt);
                }
                return 0;
            }

            focusOnSectorCenter() {
                if (this.cameraController) {
                    this.cameraController.focusOnDefaultTarget();
                }
            }

            rotateBy(deltaYaw) {
                if (this.cameraController) {
                    this.cameraController.rotateBy(deltaYaw, 0);
                }
            }

            zoomBy(deltaDistance) {
                if (this.cameraController) {
                    this.cameraController.zoomBy(deltaDistance);
                }
            }

            resize() {
                if (!this.isInitialized || this.isDisposed || this.isContextLost || !this.renderer || !this.cameraController || !this.mount) {
                    return;
                }
                const width = Math.max(1, this.mount.clientWidth || window.innerWidth || 800);
                const height = Math.max(1, this.mount.clientHeight || window.innerHeight || 600);
                this.cameraController.resize(width, height);
                this.renderer.setSize(width, height);
            }

            _createBattlefieldTexture() {
                const size = 1024;
                const canvas = document.createElement('canvas');
                canvas.width = size;
                canvas.height = size;
                const ctx = canvas.getContext('2d');
                if (!ctx) return null;

                const cfg = BATTLEFIELD_VISUAL_CONFIG.terrain;

                // Base temperate 1650 meadow gradient: darkens outward for natural depth & contrast
                const grad = ctx.createRadialGradient(size * 0.5, size * 0.5, 60, size * 0.5, size * 0.5, size * 0.72);
                grad.addColorStop(0, cfg.grassCenter);
                grad.addColorStop(0.58, cfg.grassMid);
                grad.addColorStop(1, cfg.grassEdge);
                ctx.fillStyle = grad;
                ctx.fillRect(0, 0, size, size);

                // Layer 1: Broad, soft trampled turf, damp loam & dried grass patches
                for (let i = 0; i < 480; i++) {
                    const x = (i * 211) % size;
                    const y = (i * 379) % size;
                    const r = 18 + (i % 38);
                    ctx.fillStyle = i % 3 === 0
                        ? 'rgba(102, 90, 64, 0.14)'
                        : (i % 3 === 1 ? 'rgba(48, 62, 34, 0.18)' : 'rgba(110, 122, 80, 0.11)');
                    ctx.beginPath();
                    ctx.arc(x, y, r, 0, Math.PI * 2);
                    ctx.fill();
                }

                // Layer 2: Main historical cart road & supply trail (curved diagonal road)
                ctx.strokeStyle = 'rgba(102, 86, 60, 0.42)';
                ctx.lineWidth = 44;
                ctx.lineCap = 'round';
                ctx.beginPath();
                ctx.moveTo(size * 0.08, size * 0.82);
                ctx.quadraticCurveTo(size * 0.5, size * 0.48, size * 0.92, size * 0.22);
                ctx.stroke();

                // Subtle wagon wheel ruts inside the road
                ctx.strokeStyle = 'rgba(74, 60, 42, 0.32)';
                ctx.lineWidth = 3.5;
                [-9, 9].forEach((offset) => {
                    ctx.beginPath();
                    ctx.moveTo(size * 0.08, size * 0.82 + offset);
                    ctx.quadraticCurveTo(size * 0.5, size * 0.48 + offset, size * 0.92, size * 0.22 + offset);
                    ctx.stroke();
                });

                // Layer 3: Secondary trampled infantry marching lanes across the center
                ctx.strokeStyle = 'rgba(88, 76, 52, 0.22)';
                ctx.lineWidth = 26;
                ctx.beginPath();
                ctx.moveTo(size * 0.15, size * 0.28);
                ctx.quadraticCurveTo(size * 0.45, size * 0.52, size * 0.85, size * 0.76);
                ctx.stroke();

                // Layer 4: Fine organic ground stipple (low-noise micro-variation, no pixel flicker)
                for (let i = 0; i < 2800; i++) {
                    const x = (i * 79) % size;
                    const y = (i * 151) % size;
                    ctx.fillStyle = i % 2 === 0 ? 'rgba(32, 40, 22, 0.16)' : 'rgba(128, 140, 94, 0.12)';
                    ctx.fillRect(x, y, 2, 2);
                }

                const tex = new FOC_THREE.CanvasTexture(canvas);
                this.disposables.textures.push(tex);
                return tex;
            }

            _buildTemporary1650Terrain() {
                const terrainSpan = BATTLEFIELD_VISUAL_CONFIG.terrain.span;
                const subdivisions = BATTLEFIELD_VISUAL_CONFIG.terrain.subdivisions;
                const geo = new FOC_THREE.TerrainPlaneGeometry(terrainSpan, terrainSpan, subdivisions, subdivisions, (vx, vz) => {
                    const dist = Math.hypot(vx, vz);
                    if (dist > 74) {
                        const t = Math.min(1, (dist - 74) / 48);
                        return (Math.sin(vx * 0.065) * Math.cos(vz * 0.065) + 1.05) * 2.5 * t * t;
                    }
                    return 0;
                });

                const albedo = this._createBattlefieldTexture();
                const mat = new FOC_THREE.Material({
                    map: albedo,
                    color: albedo ? 0xffffff : BATTLEFIELD_VISUAL_CONFIG.terrain.baseColor
                });

                this.disposables.geometries.push(geo);
                this.disposables.materials.push(mat);

                const groundMesh = new FOC_THREE.Mesh(geo, mat);
                this.scene.add(groundMesh);
                this.groundMeshNode = groundMesh;

                const gridPts = [];
                const half = 60;
                const step = 10;
                for (let p = -half; p <= half; p += step) {
                    gridPts.push({ x: p, y: 0.04, z: -half }, { x: p, y: 0.04, z: half });
                    gridPts.push({ x: -half, y: 0.04, z: p }, { x: half, y: 0.04, z: p });
                }
                const gridGeo = new FOC_THREE.BufferGeometry().setFromPoints(gridPts);
                gridGeo.drawMode = 'LINES';
                const gridMat = new FOC_THREE.Material({
                    color: BATTLEFIELD_VISUAL_CONFIG.terrain.gridColor,
                    transparent: true,
                    opacity: BATTLEFIELD_VISUAL_CONFIG.terrain.gridOpacity,
                    isLine: true
                });
                const gridMesh = new FOC_THREE.Line(gridGeo, gridMat);
                this.scene.add(gridMesh);
                this.gridMeshNode = gridMesh;
                this.disposables.geometries.push(gridGeo);
                this.disposables.materials.push(gridMat);
            }

            _buildSectorBoundaryMarkers() {
                const frameGeo = new FOC_THREE.BufferGeometry().setFromPoints([
                    { x: -0.5, y: 0.08, z: -0.5 },
                    { x: 0.5, y: 0.08, z: -0.5 },
                    { x: 0.5, y: 0.08, z: 0.5 },
                    { x: -0.5, y: 0.08, z: 0.5 },
                    { x: -0.5, y: 0.08, z: -0.5 }
                ]);
                const frameMat = new FOC_THREE.Material({
                    color: 0xe5c97b,
                    transparent: true,
                    opacity: 0.72,
                    isLine: true
                });
                this.sectorFrameNode = new FOC_THREE.Line(frameGeo, frameMat);
                this.scene.add(this.sectorFrameNode);
                this.disposables.geometries.push(frameGeo);
                this.disposables.materials.push(frameMat);

                const crossGeo = new FOC_THREE.BufferGeometry().setFromPoints([
                    { x: -2.2, y: 0.1, z: 0 },
                    { x: 2.2, y: 0.1, z: 0 },
                    { x: 0, y: 0.1, z: -2.2 },
                    { x: 0, y: 0.1, z: 2.2 }
                ]);
                crossGeo.drawMode = 'LINES';
                const crossMat = new FOC_THREE.Material({
                    color: 0x38bdf8,
                    transparent: true,
                    opacity: 0.85,
                    isLine: true
                });
                this.sectorCenterCrossNode = new FOC_THREE.Line(crossGeo, crossMat);
                this.scene.add(this.sectorCenterCrossNode);
                this.disposables.geometries.push(crossGeo);
                this.disposables.materials.push(crossMat);
            }

            
            _buildSelectionAndPingVisuals() {
                // Ground selection rings line node
                const ringGeo = new FOC_THREE.BufferGeometry().setFromPoints([]);
                ringGeo.drawMode = 'LINES';
                const ringMat = new FOC_THREE.Material({
                    color: 0x38bdf8,
                    transparent: true,
                    opacity: 0.9,
                    isLine: true
                });
                this.selectionRingsNode = new FOC_THREE.Line(ringGeo, ringMat);
                this.scene.add(this.selectionRingsNode);
                this.disposables.geometries.push(ringGeo);
                this.disposables.materials.push(ringMat);

                // Ground move ping line node
                const pingGeo = new FOC_THREE.BufferGeometry().setFromPoints([]);
                pingGeo.drawMode = 'LINES';
                const pingMat = new FOC_THREE.Material({
                    color: 0xfacc15,
                    transparent: true,
                    opacity: 0.9,
                    isLine: true
                });
                this.movePingNode = new FOC_THREE.Line(pingGeo, pingMat);
                this.scene.add(this.movePingNode);
                this.disposables.geometries.push(pingGeo);
                this.disposables.materials.push(pingMat);
            }

            _updateRTSVisuals(dt) {
                if (this.movementManager) {
                    this.movementManager.updateWaypoints();
                    this.movementManager.updatePings(dt);
                }

                // Update Selection Rings
                if (this.selectionRingsNode) {
                    const selList = this.selectionManager?.getSelectedList() || [];
                    if (selList.length > 0) {
                        const pts = [];
                        const segs = 16;
                        for (let i = 0; i < selList.length; i++) {
                            const s = selList[i];
                            const r = s.archetype?.startsWith('cavalry') ? 1.55 : 0.88;
                            for (let j = 0; j < segs; j++) {
                                const a1 = (j / segs) * Math.PI * 2;
                                const a2 = ((j + 1) / segs) * Math.PI * 2;
                                pts.push(
                                    { x: s.x + Math.cos(a1) * r, y: 0.06, z: s.z + Math.sin(a1) * r },
                                    { x: s.x + Math.cos(a2) * r, y: 0.06, z: s.z + Math.sin(a2) * r }
                                );
                            }
                        }
                        this.selectionRingsNode.geometry.setFromPoints(pts);
                        this.selectionRingsNode.geometry.invalidateGpuHandle();
                        this.selectionRingsNode.visible = true;
                    } else {
                        this.selectionRingsNode.visible = false;
                    }
                }

                // Update Move Pings
                if (this.movePingNode && this.movementManager) {
                    const pings = this.movementManager.activeMovePings;
                    if (pings.length > 0) {
                        const pts = [];
                        const segs = 16;
                        for (let i = 0; i < pings.length; i++) {
                            const p = pings[i];
                            const r = 0.5 + p.progress * 2.2;
                            for (let j = 0; j < segs; j++) {
                                const a1 = (j / segs) * Math.PI * 2;
                                const a2 = ((j + 1) / segs) * Math.PI * 2;
                                pts.push(
                                    { x: p.x + Math.cos(a1) * r, y: 0.08, z: p.z + Math.sin(a1) * r },
                                    { x: p.x + Math.cos(a2) * r, y: 0.08, z: p.z + Math.sin(a2) * r }
                                );
                            }
                        }
                        this.movePingNode.geometry.setFromPoints(pts);
                        this.movePingNode.geometry.invalidateGpuHandle();
                        this.movePingNode.visible = true;
                    } else {
                        this.movePingNode.visible = false;
                    }
                }

                if (this.minimapController) {
                    this.minimapController.render();
                }
            }

            _animate(now) {
                if (!this.isInitialized || this.isDisposed || this.isContextLost) {
                    this.rafId = null;
                    return;
                }
                this.rafId = requestAnimationFrame(this._boundAnimate);

                const dt = Math.min(0.05, Math.max(0.001, (now - this.lastTimestamp) / 1000));
                this.lastTimestamp = now;

                if (this.onFrameTick) {
                    this.onFrameTick(dt, now);
                }

                const activeCount = this.stepSimulation(dt);
                this._updateRTSVisuals(dt);
                this._updateKeyboardNavigation(dt);
                if (this.cameraController) {
                    this.cameraController.syncTransform(dt);
                }

                if (this.renderer && this.scene && this.cameraController) {
                    this.renderer.render(this.scene, this.cameraController.camera);
                }
                return activeCount;
            }

            _updateKeyboardNavigation(dt) {
                if (!this.cameraController) return;

                const panSpeed = (22 + this.cameraController.current.distance * 0.55) * dt;
                let forward = 0;
                let right = 0;

                if (this.input.keys['KeyW'] || this.input.keys['ArrowUp']) forward += panSpeed;
                if (this.input.keys['KeyS'] || this.input.keys['ArrowDown']) forward -= panSpeed;
                if (this.input.keys['KeyA'] || this.input.keys['ArrowLeft']) right -= panSpeed;
                if (this.input.keys['KeyD'] || this.input.keys['ArrowRight']) right += panSpeed;

                if (forward !== 0 || right !== 0) {
                    this.cameraController.panRelative(forward, right);
                }

                if (this.input.keys['KeyQ']) {
                    this.cameraController.rotateBy(-1.35 * dt, 0);
                }
                if (this.input.keys['KeyE']) {
                    this.cameraController.rotateBy(1.35 * dt, 0);
                }
            }

            _isFocusInUIControl() {
                if (!document.activeElement) return false;
                const tag = document.activeElement.tagName;
                return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || tag === 'BUTTON';
            }

            _bindEvents() {
                window.addEventListener('resize', this._boundResize);
                window.addEventListener('keydown', this._boundKeyDown);
                window.addEventListener('keyup', this._boundKeyUp);
                window.addEventListener('mousemove', this._boundMouseMove);
                window.addEventListener('mouseup', this._boundMouseUp);

                if (this.renderer && this.renderer.domElement && typeof this.renderer.domElement.addEventListener === 'function') {
                    const dom = this.renderer.domElement;
                    dom.addEventListener('mousedown', this._boundMouseDown);
                    dom.addEventListener('wheel', this._boundWheel, { passive: false });
                    dom.addEventListener('touchstart', this._boundTouchStart, { passive: true });
                    dom.addEventListener('touchmove', this._boundTouchMove, { passive: false });
                    dom.addEventListener('touchend', this._boundTouchEnd);
                }

                if (typeof ResizeObserver !== 'undefined' && this.mount) {
                    this.resizeObserver = new ResizeObserver(() => this.resize());
                    this.resizeObserver.observe(this.mount);
                }
            }

            _unbindEvents() {
                window.removeEventListener('resize', this._boundResize);
                window.removeEventListener('keydown', this._boundKeyDown);
                window.removeEventListener('keyup', this._boundKeyUp);
                window.removeEventListener('mousemove', this._boundMouseMove);
                window.removeEventListener('mouseup', this._boundMouseUp);

                if (this.renderer && this.renderer.domElement && typeof this.renderer.domElement.removeEventListener === 'function') {
                    const dom = this.renderer.domElement;
                    dom.removeEventListener('mousedown', this._boundMouseDown);
                    dom.removeEventListener('wheel', this._boundWheel);
                    dom.removeEventListener('touchstart', this._boundTouchStart);
                    dom.removeEventListener('touchmove', this._boundTouchMove);
                    dom.removeEventListener('touchend', this._boundTouchEnd);
                }

                if (this.resizeObserver) {
                    this.resizeObserver.disconnect();
                    this.resizeObserver = null;
                }
            }

            _onKeyDown(e) {
                if (this._isFocusInUIControl()) return;
                this.input.keys[e.code] = true;
                
                // G3D-03H RTS Hotkeys & Control Groups
                if (e.code.startsWith('Digit') && !e.ctrlKey) {
                    const num = parseInt(e.code.replace('Digit', ''), 10);
                    if (num >= 1 && num <= 9 && this.selectionManager) {
                        this.selectionManager.recallControlGroup(num, e.shiftKey);
                    }
                } else if (e.code.startsWith('Digit') && e.ctrlKey) {
                    const num = parseInt(e.code.replace('Digit', ''), 10);
                    if (num >= 1 && num <= 9 && this.selectionManager) {
                        this.selectionManager.assignControlGroup(num);
                    }
                }

                // Command hotkeys
                if (this.commandManager) {
                    if (e.code === 'KeyM') this.commandManager.executeCommand('move');
                    else if (e.code === 'KeyH') this.commandManager.executeCommand('hold');
                    else if (e.code === 'KeyA') this.commandManager.executeCommand('attack');
                    else if (e.code === 'KeyT') this.commandManager.executeCommand('attack_move');
                    else if (e.code === 'KeyR') this.commandManager.executeCommand('retreat');
                    else if (e.code === 'KeyF') this.commandManager.executeCommand('fire_at_will');
                    else if (e.code === 'KeyX') this.commandManager.executeCommand('hold_fire');
                    else if (e.code === 'KeyG') this.commandManager.executeCommand('regroup');
                }

                // Formation hotkeys F1-F6
                if (this.formationManager) {
                    if (e.code === 'F1') { e.preventDefault(); this.formationManager.setFormation('line'); }
                    else if (e.code === 'F2') { e.preventDefault(); this.formationManager.setFormation('column'); }
                    else if (e.code === 'F3') { e.preventDefault(); this.formationManager.setFormation('wedge'); }
                    else if (e.code === 'F4') { e.preventDefault(); this.formationManager.setFormation('loose'); }
                    else if (e.code === 'F5') { e.preventDefault(); this.formationManager.setFormation('skirmish'); }
                    else if (e.code === 'F6') { e.preventDefault(); this.formationManager.setFormation('circle'); }
                }

                if (e.code === 'Space') {
                    e.preventDefault();
                    this.focusOnSectorCenter();
                }
            }

            _onKeyUp(e) {
                this.input.keys[e.code] = false;
            }


            _onMouseDown(e) {
                if (document.activeElement && typeof document.activeElement.blur === 'function') {
                    document.activeElement.blur();
                }

                const rect = this.mount ? this.mount.getBoundingClientRect() : { left: 0, top: 0, width: 800, height: 600 };
                const clientX = e.clientX - rect.left;
                const clientY = e.clientY - rect.top;

                if (e.button === 0) {
                    // Left click: Selection start
                    if (e.altKey) {
                        this.input.isOrbiting = true;
                        this.input.lastX = e.clientX;
                        this.input.lastY = e.clientY;
                    } else {
                        this.dragSelect.active = true;
                        this.dragSelect.startX = clientX;
                        this.dragSelect.startY = clientY;
                        this.dragSelect.currentX = clientX;
                        this.dragSelect.currentY = clientY;
                        this.dragSelect.isShift = e.shiftKey;
                    }
                } else if (e.button === 1) {
                    // Middle click: Camera Orbit
                    this.input.isOrbiting = true;
                    this.input.lastX = e.clientX;
                    this.input.lastY = e.clientY;
                } else if (e.button === 2) {
                    // Right click: Issue Move / Attack command
                    e.preventDefault();
                    const w = this.mount ? this.mount.clientWidth : 800;
                    const h = this.mount ? this.mount.clientHeight : 600;
                    const hit = screenToGroundPlane(clientX, clientY, w, h, this.cameraController);
                    if (hit && this.movementManager) {
                        this.movementManager.issueMoveOrder(hit.x, hit.z, e.shiftKey, this.formationManager);
                    }
                }
            }

            _onMouseMove(e) {
                const rect = this.mount ? this.mount.getBoundingClientRect() : { left: 0, top: 0 };
                const clientX = e.clientX - rect.left;
                const clientY = e.clientY - rect.top;

                if (this.dragSelect.active) {
                    this.dragSelect.currentX = clientX;
                    this.dragSelect.currentY = clientY;

                    const dx = this.dragSelect.currentX - this.dragSelect.startX;
                    const dy = this.dragSelect.currentY - this.dragSelect.startY;
                    const marquee = document.getElementById('selectionMarquee');

                    if (Math.hypot(dx, dy) > 5 && marquee) {
                        const left = Math.min(this.dragSelect.startX, this.dragSelect.currentX);
                        const top = Math.min(this.dragSelect.startY, this.dragSelect.currentY);
                        const w = Math.abs(dx);
                        const h = Math.abs(dy);
                        marquee.style.left = `${left + rect.left}px`;
                        marquee.style.top = `${top + rect.top}px`;
                        marquee.style.width = `${w}px`;
                        marquee.style.height = `${h}px`;
                        marquee.style.display = 'block';
                    }
                }

                if (this.input.isOrbiting && this.cameraController) {
                    const dx = e.clientX - this.input.lastX;
                    const dy = e.clientY - this.input.lastY;
                    this.input.lastX = e.clientX;
                    this.input.lastY = e.clientY;
                    this.cameraController.rotateBy(dx * 0.005, -dy * 0.004);
                } else if (this.input.isPanning && this.cameraController) {
                    const dx = e.clientX - this.input.lastX;
                    const dy = e.clientY - this.input.lastY;
                    this.input.lastX = e.clientX;
                    this.input.lastY = e.clientY;
                    this.cameraController.panByScreenDelta(dx, dy);
                }
            }

            _onMouseUp(e) {
                if (this.dragSelect.active) {
                    const rect = this.mount ? this.mount.getBoundingClientRect() : { left: 0, top: 0, width: 800, height: 600 };
                    const marquee = document.getElementById('selectionMarquee');
                    if (marquee) marquee.style.display = 'none';

                    const dx = this.dragSelect.currentX - this.dragSelect.startX;
                    const dy = this.dragSelect.currentY - this.dragSelect.startY;
                    const w = this.mount ? this.mount.clientWidth : 800;
                    const h = this.mount ? this.mount.clientHeight : 600;

                    if (Math.hypot(dx, dy) > 6 && this.selectionManager) {
                        // Box Marquee Selection
                        const minX = Math.min(this.dragSelect.startX, this.dragSelect.currentX);
                        const maxX = Math.max(this.dragSelect.startX, this.dragSelect.currentX);
                        const minY = Math.min(this.dragSelect.startY, this.dragSelect.currentY);
                        const maxY = Math.max(this.dragSelect.startY, this.dragSelect.currentY);
                        this.selectionManager.selectInScreenRect(minX, minY, maxX, maxY, this.dragSelect.isShift, this.cameraController, w, h);
                    } else if (this.selectionManager) {
                        // Single Click Pick
                        const hit = screenToGroundPlane(this.dragSelect.startX, this.dragSelect.startY, w, h, this.cameraController);
                        if (hit) {
                            let closestId = null;
                            let minDist = 2.4;
                            const records = this.soldierRegistry?.records;
                            if (records) {
                                for (const [id, sol] of records.entries()) {
                                    const d = Math.hypot(sol.x - hit.x, sol.z - hit.z);
                                    if (d < minDist) {
                                        minDist = d;
                                        closestId = id;
                                    }
                                }
                            }
                            const now = performance.now();
                            if (closestId && (now - this.selectionManager.lastClickTime < 350) && this.selectionManager.lastClickId === closestId) {
                                // Double click: select same class
                                const rec = records?.get(closestId);
                                if (rec) this.selectionManager.selectSameClass(rec.archetype, this.dragSelect.isShift);
                            } else if (closestId) {
                                this.selectionManager.select(closestId, this.dragSelect.isShift, false);
                                this.selectionManager.lastClickTime = now;
                                this.selectionManager.lastClickId = closestId;
                            } else if (!this.dragSelect.isShift) {
                                this.selectionManager.clear();
                            }
                        }
                    }
                    this.dragSelect.active = false;
                }

                this.input.isPanning = false;
                this.input.isOrbiting = false;
            }

            _onWheel(e) {
                e.preventDefault();
                this.zoomBy(e.deltaY * 0.025);
            }

            _onTouchStart(e) {
                if (e.touches.length === 1) {
                    this.input.touchLastX = e.touches[0].clientX;
                    this.input.touchLastY = e.touches[0].clientY;
                } else if (e.touches.length === 2) {
                    this.input.pinchDist = Math.hypot(
                        e.touches[0].clientX - e.touches[1].clientX,
                        e.touches[0].clientY - e.touches[1].clientY
                    );
                }
            }

            _onTouchMove(e) {
                if (!this.cameraController) return;
                if (e.touches.length === 1) {
                    const dx = e.touches[0].clientX - this.input.touchLastX;
                    const dy = e.touches[0].clientY - this.input.touchLastY;
                    this.input.touchLastX = e.touches[0].clientX;
                    this.input.touchLastY = e.touches[0].clientY;
                    this.cameraController.panByScreenDelta(dx, dy);
                } else if (e.touches.length === 2) {
                    e.preventDefault();
                    const newDist = Math.hypot(
                        e.touches[0].clientX - e.touches[1].clientX,
                        e.touches[0].clientY - e.touches[1].clientY
                    );
                    const delta = this.input.pinchDist - newDist;
                    this.input.pinchDist = newDist;
                    this.zoomBy(delta * 0.08);
                }
            }

            _onTouchEnd() {
                this.input.pinchDist = 0;
            }

            _reportError(message) {
                if (this.onError) {
                    this.onError(message);
                }
            }

            dispose() {
                if (this.isDisposed && !this.isInitialized) return;

                this._stopAnimationLoop();
                this._unbindEvents();
                this.input.keys = {};
                this.input.isPanning = false;
                this.input.isOrbiting = false;

                if (this.soldierRegistry) {
                    this.soldierRegistry.dispose();
                    this.soldierRegistry = null;
                }

                this.disposables.geometries.forEach((g) => {
                    if (g && typeof g.dispose === 'function') g.dispose();
                });
                this.disposables.materials.forEach((m) => {
                    if (m && typeof m.dispose === 'function') m.dispose();
                });
                this.disposables.textures.forEach((t) => {
                    if (t && typeof t.dispose === 'function') t.dispose();
                });
                this.disposables = { geometries: [], materials: [], textures: [] };

                if (this.renderer) {
                    this.renderer._intentionalContextLoss = true;
                    if (typeof this.renderer.dispose === 'function') {
                        this.renderer.dispose();
                    }
                    if (typeof this.renderer.forceContextLoss === 'function') {
                        try {
                            this.renderer.forceContextLoss();
                        } catch (err) {
                            // Ignore if already lost
                        }
                    }
                    if (this.renderer.domElement && this.renderer.domElement.parentNode) {
                        this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
                    }
                    this.renderer = null;
                }

                this.scene = null;
                this.cameraController = null;
                this.sectorFrameNode = null;
                this.sectorCenterCrossNode = null;
                this.mount = null;
                this.derivedSummary = deriveSectorViewBounds(null);
                this.isContextLost = false;
                this.contextLossType = 'none';
                this.isInitialized = false;
                this.isDisposed = true;
            }
        }

        /* ============================================================================
         * 6. INTEGRATED G3D-03C-R1 VERIFICATION UNIT TEST SUITE (37/37 TESTS)
         * ============================================================================ */
        function deepFreeze(obj) {
            if (!obj || typeof obj !== 'object') return obj;
            Object.freeze(obj);
            Object.keys(obj).forEach((k) => deepFreeze(obj[k]));
            return obj;
        }

        function createMockWebGLContext(opts = {}) {
            let shaderSeq = 1;
            let progSeq = 1;
            let bufSeq = 1;
            let texSeq = 1;
            const deletedPrograms = [];
            const deletedShaders = [];
            const deletedBuffers = [];
            const drawCalls = [];
            const instancedCalls = [];
            const bufferSubDataCalls = [];

            const gl = {
                VERTEX_SHADER: 0x8B31,
                FRAGMENT_SHADER: 0x8B30,
                COMPILE_STATUS: 0x8B81,
                LINK_STATUS: 0x8B82,
                DEPTH_TEST: 0x0B71,
                LEQUAL: 0x0203,
                ARRAY_BUFFER: 0x8892,
                ELEMENT_ARRAY_BUFFER: 0x8893,
                STATIC_DRAW: 0x88E4,
                DYNAMIC_DRAW: 0x88E8,
                FLOAT: 0x1406,
                UNSIGNED_SHORT: 0x1403,
                TRIANGLES: 0x0004,
                LINES: 0x0001,
                LINE_STRIP: 0x0003,
                BLEND: 0x0BE2,
                SRC_ALPHA: 0x0302,
                ONE_MINUS_SRC_ALPHA: 0x0303,
                TEXTURE_2D: 0x0DE1,
                TEXTURE0: 0x84C0,
                RGBA: 0x1908,
                UNSIGNED_BYTE: 0x1401,
                TEXTURE_MIN_FILTER: 0x2801,
                TEXTURE_MAG_FILTER: 0x2800,
                TEXTURE_WRAP_S: 0x2802,
                TEXTURE_WRAP_T: 0x2803,
                LINEAR_MIPMAP_LINEAR: 0x2703,
                LINEAR: 0x2601,
                CLAMP_TO_EDGE: 0x812F,
                COLOR_BUFFER_BIT: 0x00004000,
                DEPTH_BUFFER_BIT: 0x00000100,

                isContextLost() {
                    return Boolean(opts.contextLost);
                },
                getExtension(name) {
                    if (name === 'ANGLE_instanced_arrays') {
                        if (opts.noInstancing) return null;
                        return {
                            vertexAttribDivisorANGLE() {},
                            drawElementsInstancedANGLE(mode, count, type, offset, primcount) {
                                instancedCalls.push({ mode, count, primcount });
                            }
                        };
                    }
                    return null;
                },
                createShader(type) {
                    return { id: shaderSeq++, type };
                },
                shaderSource() {},
                compileShader() {},
                getShaderParameter(sh, param) {
                    if (param === 0x8B81) {
                        return !opts.failCompile;
                    }
                    return true;
                },
                getShaderInfoLog() {
                    return opts.failCompile ? 'Mock shader compile error' : '';
                },
                deleteShader(sh) {
                    deletedShaders.push(sh);
                },
                createProgram() {
                    return { id: progSeq++ };
                },
                attachShader() {},
                linkProgram() {},
                getProgramParameter(prog, param) {
                    if (param === 0x8B82) {
                        if (typeof opts.failLinkAt === 'number') {
                            return prog.id !== opts.failLinkAt;
                        }
                        return !opts.failLink;
                    }
                    return true;
                },
                getProgramInfoLog() {
                    return 'Mock program LINK_STATUS failed';
                },
                deleteProgram(prog) {
                    deletedPrograms.push(prog);
                },
                useProgram() {},
                getAttribLocation() {
                    return 0;
                },
                getUniformLocation() {
                    return {};
                },
                uniformMatrix4fv() {},
                uniform1i() {},
                uniform1f() {},
                uniform3f() {},
                uniform3fv() {},
                createBuffer() {
                    return { id: bufSeq++ };
                },
                bindBuffer() {},
                bufferData() {},
                bufferSubData(target, offset, data) {
                    bufferSubDataCalls.push({ target, offset, byteLength: data ? data.byteLength : 0 });
                },
                deleteBuffer(buf) {
                    deletedBuffers.push(buf);
                },
                createTexture() {
                    return { id: texSeq++ };
                },
                bindTexture() {},
                texImage2D() {},
                generateMipmap() {},
                texParameteri() {},
                activeTexture() {},
                deleteTexture() {},
                enableVertexAttribArray() {},
                disableVertexAttribArray() {},
                vertexAttribPointer() {},
                enable() {},
                disable() {},
                blendFunc() {},
                depthFunc() {},
                depthMask() {},
                viewport() {},
                clearColor() {},
                clear() {},
                drawElements(mode, count, type, offset) {
                    drawCalls.push({ mode, count });
                },
                drawArrays(mode, first, count) {
                    drawCalls.push({ mode, count });
                }
            };

            return {
                gl,
                getBufferCount: () => bufSeq - 1,
                deletedPrograms,
                deletedShaders,
                deletedBuffers,
                drawCalls,
                instancedCalls,
                bufferSubDataCalls
            };
        }

        function runBattle3DUnitTests() {
            const results = [];
            function assert(cond, msg) {
                if (!cond) throw new Error(msg);
            }

            function runCase(name, fn) {
                try {
                    fn();
                    results.push({ name, passed: true, detail: 'Doğrulandı' });
                } catch (err) {
                    results.push({ name, passed: false, detail: err.message });
                }
            }

            // --- PRESERVED 30 TESTS FROM G3D-03B UNCHANGED ---
            runCase('1. Merkez Sektörde 300 Asker, 7 Batch (<= 10) & R2 Gruplarının Korunması', () => {
                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const snap = deepFreeze(projectActiveSector3D(sm));

                assert(snap.sectorId === 'SECTOR_1650_01', `Beklenen SECTOR_1650_01, gelen: ${snap.sectorId}`);
                assert(snap.visible.player === 150 && snap.visible.enemy === 150, '150/150 görünür limiti doğrulanmalı');
                assert(snap.hiddenAlive.player === 18 && snap.hiddenAlive.enemy === 12, 'Görünmeyen askerler veriden silinmemeli');

                const musketeersRight = snap.soldiers.filter((s) => s.groupId === 'grp_p_musketeers_right');
                const arquebusiersSouth = snap.soldiers.filter((s) => s.groupId === 'grp_e_arquebusiers_south');
                assert(musketeersRight.length === 40, `grp_p_musketeers_right 40 tüfekçi olmalı, gelen: ${musketeersRight.length}`);
                assert(arquebusiersSouth.length === 38, `grp_e_arquebusiers_south 38 arkebüzcü olmalı, gelen: ${arquebusiersSouth.length}`);

                const reg = new SoldierVisualRegistry();
                const stats = reg.sync(snap);
                assert(stats.activeCount === 300, `Sahnede 300 3D asker olmalı, gelen: ${stats.activeCount}`);
                assert(stats.batchCount === 7 && stats.batchCount <= 10, `Batch sayısı 7 (<= 10) olmalı, gelen: ${stats.batchCount}`);

                for (let i = 0; i < snap.soldiers.length; i++) {
                    const s = snap.soldiers[i];
                    const rec = reg.records.get(s.viewId);
                    assert(rec && rec.x === s.position.x && rec.y === s.position.y && rec.z === s.position.z, 'Asker konumları değişmemeli');
                }
                reg.dispose();
            });

            runCase('2. B2 Piyade Şablonlarının (44, 43, 41 Parça) & Anatomik At Modellerinin Doğrulanması', () => {
                const reg = new SoldierVisualRegistry();

                assert(reg.templates['player:infantry_pikeman'].length === 44, `Mızraklı piyade 44 parça olmalı, gelen: ${reg.templates['player:infantry_pikeman'].length}`);
                assert(reg.templates['enemy:infantry_pikeman'].length === 44, 'Düşman mızraklı piyade 44 parça olmalı');
                assert(reg.templates['player:infantry_musketeer'].length === 43, `Tüfekçi piyade 43 parça olmalı, gelen: ${reg.templates['player:infantry_musketeer'].length}`);
                assert(reg.templates['enemy:infantry_musketeer'].length === 43, 'Düşman arkebüzcü 43 parça olmalı');
                assert(reg.templates['player:infantry_swordsman'].length === 41, `Kılıçlı piyade 41 parça olmalı, gelen: ${reg.templates['player:infantry_swordsman'].length}`);
                assert(reg.templates['enemy:infantry_swordsman'].length === 41, 'Düşman kılıçlı piyade 41 parça olmalı');

                const mountTypes = ['warhorse', 'destrier', 'charger', 'courser', 'rouncey', 'steppe_horse'];
                mountTypes.forEach((mt) => {
                    const key = resolveCavalryVisualVariant({
                        side: 'player',
                        unitClass: 'cuirassier',
                        mountType: mt,
                        activeWeapon: 'cavalry_sabre',
                        armorLoadout: ['three_quarter_plate']
                    });
                    const tpl = reg.templates[key];
                    assert(Array.isArray(tpl) && tpl.length >= 60, `${mt} at ve binici şablonu eksiksiz olmalı (${key})`);
                });

                reg.dispose();
            });

            runCase('3. Süvari Aktif Silah Seçimi (activeWeapon: Mızrak, Kılıç, Karabina, Tabanca) Doğrulanması', () => {
                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const reg = new SoldierVisualRegistry();

                const countVisibleCavalryByArchetype = (soldiersList) => {
                    const counts = {
                        cavalry_sabre: 0,
                        cavalry_lance: 0,
                        cavalry_carbine: 0,
                        cavalry_pistol: 0
                    };
                    for (let i = 0; i < soldiersList.length; i++) {
                        const archetype = classifySoldierArchetype(soldiersList[i]);
                        if (Object.prototype.hasOwnProperty.call(counts, archetype)) {
                            counts[archetype]++;
                        }
                    }
                    return counts;
                };

                const s0Snap = projectActiveSector3D(sm);
                assert(s0Snap.visible.player === 150 && s0Snap.visible.enemy === 150, 'Merkez sektörde 150 dost ve 150 düşman asker görünür olmalı');
                assert(s0Snap.hiddenAlive.player === 18 && s0Snap.hiddenAlive.enemy === 12, 'Merkez sektörde 18 gizli dost ve 12 gizli düşman asker korunmalı');

                const s0Expected = countVisibleCavalryByArchetype(s0Snap.soldiers);
                assert(s0Expected.cavalry_sabre === 14, `Merkez görünür kılıçlı süvari beklentisi 14 olmalı, hesaplanan: ${s0Expected.cavalry_sabre}`);
                assert(s0Expected.cavalry_lance === 18, `Merkez görünür mızraklı süvari beklentisi 18 olmalı, hesaplanan: ${s0Expected.cavalry_lance}`);

                const s0Stats = reg.sync(s0Snap);
                assert(
                    s0Stats.cavalryWeapons.sabre === s0Expected.cavalry_sabre && s0Stats.cavalryWeapons.sabre === 14,
                    `Merkez görünür dost süvariler kılıçlı (14) olmalı, gelen: ${s0Stats.cavalryWeapons.sabre}`
                );
                assert(
                    s0Stats.cavalryWeapons.lance === s0Expected.cavalry_lance && s0Stats.cavalryWeapons.lance === 18,
                    `Merkez görünür düşman mızraklı süvariler (18) olmalı, gelen: ${s0Stats.cavalryWeapons.lance}`
                );

                sm.setActiveSector(1);
                const s1Snap = projectActiveSector3D(sm);
                const s1Expected = countVisibleCavalryByArchetype(s1Snap.soldiers);
                const s1Stats = reg.sync(s1Snap);
                assert(s1Stats.activeCount === 62 && s1Stats.lastRemoved === 300, 'Batı sektöründe 62 süvari olmalı ve önceki 300 temizlenmeli');
                assert(
                    s1Stats.cavalryWeapons.carbine === s1Expected.cavalry_carbine && s1Stats.cavalryWeapons.carbine === 28,
                    `grp_p_harquebusiers_west (28) karabinalı görünmeli, gelen: ${s1Stats.cavalryWeapons.carbine}`
                );
                assert(
                    s1Stats.cavalryWeapons.pistol === s1Expected.cavalry_pistol && s1Stats.cavalryWeapons.pistol === 34,
                    `grp_e_reiters_west (34) tabancalı görünmeli, gelen: ${s1Stats.cavalryWeapons.pistol}`
                );

                sm.setActiveSector(2);
                const s2Snap = projectActiveSector3D(sm);
                const s2Expected = countVisibleCavalryByArchetype(s2Snap.soldiers);
                const s2Stats = reg.sync(s2Snap);
                assert(s2Stats.activeCount === 50 && s2Stats.lastRemoved === 62, 'Doğu sektöründe 50 süvari olmalı ve önceki 62 temizlenmeli');
                assert(
                    s2Stats.cavalryWeapons.carbine === s2Expected.cavalry_carbine && s2Stats.cavalryWeapons.carbine === 24,
                    `grp_p_dragoon_east (24) karabinalı görünmeli, gelen: ${s2Stats.cavalryWeapons.carbine}`
                );
                assert(
                    s2Stats.cavalryWeapons.sabre === s2Expected.cavalry_sabre && s2Stats.cavalryWeapons.sabre === 26,
                    `grp_e_cossack_skirmishers_east (26) kılıçlı görünmeli, gelen: ${s2Stats.cavalryWeapons.sabre}`
                );

                reg.dispose();
            });

            runCase('4. Aynı Asker İçin Çift Oluşturma Önleme (viewId Güncelleme) & Boş Sektör Temizliği', () => {
                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const snap = projectActiveSector3D(sm);

                const reg = new SoldierVisualRegistry();
                const first = reg.sync(snap);
                const second = reg.sync(snap);

                assert(first.lastCreated === 300 && first.lastUpdated === 0, 'İlk senkronizasyonda 300 oluşturulmalı');
                assert(second.lastCreated === 0 && second.lastUpdated === 300, 'İkinci senkronizasyonda yeniden oluşturulmamalı');
                assert(reg.records.size === 300, 'Toplam kayıt 300 kalmalı');

                const emptyStats = reg.sync(null);
                assert(emptyStats.activeCount === 0 && reg.batchGroup.batches.length === 0, 'Boş veride sahnede 0 asker ve 0 batch kalmalı');
                reg.dispose();
            });

            runCase('5. RTSCamera3D Sınır Kelepçeleme ve Yaşam Döngüsü (Init -> Dispose -> Re-Init)', () => {
                const cam = new RTSCamera3D({ aspect: 16 / 9 });
                cam.setBoundsAndTarget({ minX: -40, maxX: 40, minZ: -30, maxZ: 30 }, { x: 0, z: 0 }, true);
                cam.panRelative(500, 500);
                cam.syncTransform(1);
                assert(cam.current.targetX === 40 && cam.current.targetZ === -30, 'Kamera sınırları korunmalı');

                let disposeCount = 0;
                const mockCanvas = document.createElement('canvas');
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const r = new Battle3DRenderer({
                    rendererFactory: () => ({
                        domElement: mockCanvas,
                        setSize() {},
                        setPixelRatio() {},
                        render() {},
                        dispose() { disposeCount++; },
                        forceContextLoss() {}
                    })
                });
                assert(r.init(mockMount, null) === true, 'init başarılı olmalı');
                r.dispose();
                r.dispose();
                assert(r.isDisposed === true && disposeCount === 1, 'dispose idempotent olmalı');
                assert(r.init(mockMount, null) === true, 'dispose sonrası yeniden açılabilmeli');
                r.dispose();
            });

            runCase('6. Shader Programı Link Hatasında Güvenli Başarısızlık & GPU Program Temizliği', () => {
                const mockCtx = createMockWebGLContext({ failLinkAt: 3 });
                let errorMsg = null;

                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 800, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 600, configurable: true });

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl }),
                    onError: (msg) => { errorMsg = msg; }
                });

                const ok = renderer.init(mockMount, null);
                assert(ok === false, 'Link hatasında init false dönmeli');
                assert(renderer.isInitialized === false, 'Hatalı sahne asla aktif olarak işaretlenmemeli');
                assert(renderer.isDisposed === true, 'Hatalı başlatma sonrası kaynaklar temizlenmeli');
                assert(typeof errorMsg === 'string' && errorMsg.includes('LINK_STATUS'), `Link hata mesajı raporlanmalı: ${errorMsg}`);
                assert(mockCtx.deletedPrograms.length === 3, `Başarısızlıkta 3 GPU programı temizlenmeli, temizlenen: ${mockCtx.deletedPrograms.length}`);
            });

            runCase('7. WebGL Context Oluşturulamadığında Düzgün Fallback & Sahnenin Aktif Olmaması', () => {
                let capturedErr = null;
                const mockMount = document.createElement('div');

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => {
                        throw new Error('WebGL bağlamı (context) oluşturulamadı.');
                    },
                    onError: (msg) => { capturedErr = msg; }
                });

                const ok = renderer.init(mockMount, null);
                assert(ok === false, 'WebGL context yoksa init false dönmeli');
                assert(renderer.isInitialized === false, 'WebGL yokken sahne aktif olmamalı');
                assert(renderer.renderer === null, 'Renderer referansı null olmalı');
                assert(capturedErr && capturedErr.includes('context'), 'Anlamlı hata mesajı döndürülmeli');
            });

            runCase('8. Kapatma, Çift Kapatma ve Yeniden Başlatmada Kaynak & Dinleyici Temizliği', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const snap = projectActiveSector3D(sm);

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });

                assert(renderer.init(mockMount, snap) === true, 'İlk başlatma başarılı olmalı');
                assert(renderer.soldierRegistry.records.size === 300, '300 asker havuzda olmalı');

                renderer.dispose();
                assert(renderer.isDisposed === true && renderer.isInitialized === false, 'Kapatma sonrası durum güncellenmeli');
                assert(renderer.rafId === null, 'Animasyon döngüsü iptal edilmeli');
                assert(mockMount.children.length === 0, 'Canvas DOM üzerinden kaldırılmalı');
                const programsAfterFirstDispose = mockCtx.deletedPrograms.length;
                assert(programsAfterFirstDispose === 3, '3 shader programı silinmeli');

                renderer.dispose();
                assert(mockCtx.deletedPrograms.length === programsAfterFirstDispose, 'İkinci kapatma ek işlem/hata üretmemeli');

                assert(renderer.init(mockMount, snap) === true, 'Kapatma sonrası yeniden başlatma başarılı olmalı');
                assert(renderer.soldierRegistry.records.size === 300, 'Yeniden başlatmada 300 asker yüklenmeli');
                renderer.dispose();
            });

            runCase('9. WebGL Yok Testi Sonrasında Tekrar Çalışma (Başlat -> WebGL Yok -> Yeniden Başlat)', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 800, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 600, configurable: true });

                let allowWebGL = true;
                let errorCount = 0;

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => {
                        if (!allowWebGL) {
                            throw new Error('Simüle edilmiş WebGL yok durumu');
                        }
                        return new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl });
                    },
                    onError: () => { errorCount++; }
                });

                assert(renderer.init(mockMount, null) === true, 'Başlangıç sahnesi aktif olmalı');
                renderer.dispose();
                allowWebGL = false;
                assert(renderer.init(mockMount, null) === false && errorCount === 1, 'WebGL yok durumunda güvenli hata verilmeli');
                assert(renderer.isInitialized === false, 'WebGL yokken sahne aktif olmamalı');
                allowWebGL = true;
                assert(renderer.init(mockMount, null) === true, 'WebGL tekrar sağlandığında sahne yeniden başlamalı');
                assert(renderer.isInitialized === true, 'Sahne tekrar aktif olmalı');
                renderer.dispose();
            });

            runCase('10. Boş Veri ve Normal Asker Verisi Arasında Geçiş (Normal -> Boş -> Yeniden Başlat / Normal)', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const fullSnap = projectActiveSector3D(sm);

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });

                assert(renderer.init(mockMount, fullSnap) === true, 'Normal veri ile başlatma');
                assert(renderer.soldierRegistry.records.size === 300, '300 asker yüklü olmalı');

                const emptyDerived = renderer.sync(null, { snapCamera: true });
                assert(emptyDerived.isEmpty === true && renderer.soldierRegistry.records.size === 0, 'Boş veride 0 asker kalmalı');
                assert(renderer.soldierRegistry.batchGroup.batches.length === 0, 'Boş veride 0 batch kalmalı');

                const restoredDerived = renderer.sync(fullSnap, { snapCamera: true });
                assert(restoredDerived.isEmpty === false && renderer.soldierRegistry.records.size === 300, 'Normal veriye dönüşte 300 asker geri gelmeli');

                renderer.dispose();
                assert(renderer.init(mockMount, fullSnap) === true, 'Boş veri sonrası yeniden başlatma sorunsuz olmalı');
                renderer.dispose();
            });

            runCase('11. Instancing Desteği Olmadığında Alternatif Çizim Yolu & Context Kaybı Geri Dönüşü', () => {
                const fallbackCtx = createMockWebGLContext({ noInstancing: true });
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 800, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 600, configurable: true });

                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                sm.setActiveSector(2);
                const eastSnap = projectActiveSector3D(sm);

                const callbackLog = [];
                const renderer = new Battle3DRenderer({
                    rendererFactory: (opts) => new FOC_THREE.WebGLRenderer({
                        gl: fallbackCtx.gl,
                        onContextLost: opts.onContextLost,
                        onContextRestored: opts.onContextRestored
                    }),
                    onError: () => { callbackLog.push('lost'); },
                    onContextRestored: () => { callbackLog.push('restored'); }
                });

                assert(renderer.init(mockMount, eastSnap) === true, 'Instancing olmadan başlatma başarılı olmalı');
                assert(renderer.renderer.isInstancedSupported() === false, 'Instancing desteği false raporlanmalı');
                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                assert(renderer.renderer.lastRenderMode === 'fallback_non_instanced', 'Alternatif çizim yolu kullanılmalı');
                assert(fallbackCtx.instancedCalls.length === 0 && fallbackCtx.drawCalls.length > 0, 'Standart drawElements çağrıları çalışmalı');

                renderer.simulateContextLoss();
                assert(renderer.isContextLost === true, 'Battle3DRenderer.isContextLost true olmalı');
                assert(renderer.renderer._contextLost === true, 'FOC_THREE.WebGLRenderer._contextLost senkronize true olmalı');
                assert(renderer.contextLossType === 'simulated' && renderer.renderer._contextLossSource === 'simulated', 'Simüle edilen context kaybı gerçek GPU kaybından ayrılmalı');
                assert(callbackLog.includes('lost'), 'Context kaybında hata durumu bildirilmeli');
                assert(renderer.rafId === null, 'Context kaybında animasyon döngüsü durdurulmalı');

                const restored = renderer.renderer._handleContextRestored();
                assert(restored === true, '_handleContextRestored true dönmeli');
                assert(renderer.isContextLost === false && renderer.renderer._contextLost === false, 'Context geri geldiğinde her iki katman da aktif olmalı');
                assert(renderer.rafId !== null, 'Context geri geldiğinde kaynaklar ve döngü güvenli biçimde yenilenmeli');
                assert(renderer.renderer.meshProg !== null && renderer.renderer.instancedProg !== null && renderer.renderer.lineProg !== null, 'Shader programları yeniden derlenip bağlanmalı');
                assert(callbackLog[0] === 'lost' && callbackLog[1] === 'restored', 'Callback sırası (lost -> restored) doğru olmalı');

                renderer.dispose();
            });

            runCase('12. Hareket Sırasında Aynı Asker Kimliğinin (viewId) Korunması', () => {
                const reg = new SoldierVisualRegistry();
                const snap1 = {
                    sectorId: 'SEC_MOVE',
                    soldiers: [{
                        viewId: 'SEC_MOVE:p1',
                        sectorId: 'SEC_MOVE',
                        side: 'player',
                        groupId: 'grp_1',
                        soldierId: 'p1',
                        unitClass: 'pikeman',
                        activeWeapon: 'pike',
                        position: { x: -10, y: 0, z: 0 }
                    }]
                };
                const snap2 = {
                    sectorId: 'SEC_MOVE',
                    soldiers: [{
                        viewId: 'SEC_MOVE:p1',
                        sectorId: 'SEC_MOVE',
                        side: 'player',
                        groupId: 'grp_1',
                        soldierId: 'p1',
                        unitClass: 'pikeman',
                        activeWeapon: 'pike',
                        position: { x: -4, y: 0, z: 3 }
                    }]
                };

                const s1 = reg.sync(snap1);
                const s2 = reg.sync(snap2);
                assert(s1.lastCreated === 1 && s2.lastCreated === 0, 'Konum değişiminde asker yeniden oluşturulmamalı');
                assert(s2.lastUpdated === 1 && reg.records.size === 1, 'Aynı viewId kaydı yerinde güncellenmeli');
                const rec = reg.getSoldierVisualState('SEC_MOVE:p1');
                assert(rec && rec.soldierId === 'p1' && rec.groupId === 'grp_1', 'Asker kimliği ve grup bilgisi korunmalı');
                reg.dispose();
            });

            runCase('13. Konum Değişiminde Yumuşak İnterpolasyon, Yön Dönüşü & Tekrarlayan Snapshot Koruması', () => {
                const reg = new SoldierVisualRegistry();
                const baseSnap = {
                    sectorId: 'SEC_INTERP',
                    soldiers: [{
                        viewId: 'SEC_INTERP:m1',
                        sectorId: 'SEC_INTERP',
                        side: 'player',
                        groupId: 'grp_m',
                        soldierId: 'm1',
                        unitClass: 'musketeer',
                        activeWeapon: 'matchlock_musket',
                        position: { x: 0, y: 0, z: 0 }
                    }]
                };
                reg.sync(baseSnap);

                reg.sync(baseSnap);
                const rec = reg.getSoldierVisualState('SEC_INTERP:m1');
                assert(rec.isMoving === false && rec.walkPhase === 0, 'Aynı snapshot tekrar geldiğinde animasyon başlamamalı');

                const movedSnap = {
                    sectorId: 'SEC_INTERP',
                    soldiers: [{
                        ...baseSnap.soldiers[0],
                        position: { x: 6, y: 0, z: 6 }
                    }]
                };
                reg.sync(movedSnap);
                assert(rec.isMoving === true, 'Yeni hedef konum verildiğinde yürüyüş başlamalı');

                reg.update(0.04);
                assert(rec.x > 0 && rec.x < 6 && rec.z > 0 && rec.z < 6, `Konum yumuşak interpolasyonla ilerlemeli (x=${rec.x.toFixed(2)}, z=${rec.z.toFixed(2)})`);
                const expectedYaw = Math.atan2(6, 6);
                assert(Math.abs(rec.desiredYaw - expectedYaw) < 1e-4, 'Hedef yön hareket vektörüne hizalanmalı');

                const phaseBeforeResync = rec.walkPhase;
                assert(phaseBeforeResync > 0, 'Yürüyüş fazı ilerlemiş olmalı');
                reg.sync(movedSnap);
                assert(rec.walkPhase === phaseBeforeResync, 'Aynı hedef snapshot tekrar geldiğinde yürüyüş fazı sıfırlanmamalı');
                reg.dispose();
            });

            runCase('14. Yürüyüş Başlangıcı ve Sonunda Hazır Duruşuna Dönüş (Kendi Kendine Yürümeme)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_STOP',
                    soldiers: [{
                        viewId: 'SEC_STOP:s1',
                        sectorId: 'SEC_STOP',
                        side: 'player',
                        groupId: 'grp_s',
                        soldierId: 's1',
                        unitClass: 'swordsman',
                        activeWeapon: 'broadsword',
                        position: { x: 0, y: 0, z: 0 }
                    }]
                });

                const rec = reg.getSoldierVisualState('SEC_STOP:s1');
                const restMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_STOP:s1', 1));

                reg.sync({
                    sectorId: 'SEC_STOP',
                    soldiers: [{
                        viewId: 'SEC_STOP:s1',
                        sectorId: 'SEC_STOP',
                        side: 'player',
                        groupId: 'grp_s',
                        soldierId: 's1',
                        unitClass: 'swordsman',
                        activeWeapon: 'broadsword',
                        position: { x: 2.0, y: 0, z: 0 }
                    }]
                });

                for (let f = 0; f < 60; f++) {
                    reg.update(0.05);
                }

                assert(Math.abs(rec.x - 2.0) < 1e-4 && Math.abs(rec.z) < 1e-4, 'Asker hedef konuma tam ulaşmalı');
                assert(rec.isMoving === false && rec.walkBlend === 0 && rec.walkPhase === 0, 'Hedefe ulaşınca asker durmalı ve hazır duruşuna dönmeli');

                const postStopMat = reg.evaluateSoldierPartMatrix('SEC_STOP:s1', 1);
                for (let k = 0; k < 16; k++) {
                    assert(Math.abs(postStopMat[k] - restMat[k]) < 1e-5, 'Durduktan sonra bacak/gövde matrisi ilk hazır duruşuna eşit olmalı');
                }

                reg.update(0.05);
                assert(rec.isMoving === false && Math.abs(rec.x - 2.0) < 1e-4, 'Yeni hedef verilmezse asker kendi kendine yürümemeli');
                reg.dispose();
            });

            runCase('15. Sağ ve Sol Bacak Hareketlerinin Farklı Fazlarda Olması (Mızraklı, Tüfekçi, Kılıçlı)', () => {
                const reg = new SoldierVisualRegistry();
                const classes = [
                    { id: 'pk', unitClass: 'pikeman', activeWeapon: 'pike' },
                    { id: 'mk', unitClass: 'musketeer', activeWeapon: 'matchlock_musket' },
                    { id: 'sw', unitClass: 'swordsman', activeWeapon: 'broadsword' }
                ];

                reg.sync({
                    sectorId: 'SEC_GAIT',
                    soldiers: classes.map((c, i) => ({
                        viewId: `SEC_GAIT:${c.id}`,
                        sectorId: 'SEC_GAIT',
                        side: 'player',
                        groupId: 'grp_gait',
                        soldierId: c.id,
                        unitClass: c.unitClass,
                        activeWeapon: c.activeWeapon,
                        position: { x: 0, y: 0, z: i * 3 }
                    }))
                });

                reg.sync({
                    sectorId: 'SEC_GAIT',
                    soldiers: classes.map((c, i) => ({
                        viewId: `SEC_GAIT:${c.id}`,
                        sectorId: 'SEC_GAIT',
                        side: 'player',
                        groupId: 'grp_gait',
                        soldierId: c.id,
                        unitClass: c.unitClass,
                        activeWeapon: c.activeWeapon,
                        position: { x: 8, y: 0, z: i * 3 }
                    }))
                });

                for (let f = 0; f < 6; f++) {
                    reg.update(0.04);
                }

                classes.forEach((c) => {
                    const vid = `SEC_GAIT:${c.id}`;
                    const rec = reg.getSoldierVisualState(vid);
                    assert(rec.isMoving && rec.walkBlend > 0.5, `${c.unitClass} aktif yürüyüş durumunda olmalı`);

                    const leftFootMat = reg.evaluateSoldierPartMatrix(vid, 1);
                    const rightFootMat = reg.evaluateSoldierPartMatrix(vid, 2);
                    const leftZ = leftFootMat[14];
                    const rightZ = rightFootMat[14];
                    const leftY = leftFootMat[13];
                    const rightY = rightFootMat[13];

                    assert(
                        (leftZ - 0.03) * (rightZ - 0.03) < 0,
                        `${c.unitClass} sağ ve sol bacaklar zıt fazda hareket etmeli (leftZ=${leftZ.toFixed(3)}, rightZ=${rightZ.toFixed(3)})`
                    );
                    assert(leftY >= 0 && rightY >= 0, `${c.unitClass} ayaklar zeminin altına inmemeli (leftY=${leftY.toFixed(3)}, rightY=${rightY.toFixed(3)})`);
                });

                reg.dispose();
            });

            runCase('16. Silah ve Zırh Modellerinin Korunması (44, 43, 41 Parça & El-Silah Hizası)', () => {
                const reg = new SoldierVisualRegistry();
                assert(reg.templates['player:infantry_pikeman'].length === 44, 'Mızraklı 44 parça korunmalı');
                assert(reg.templates['player:infantry_musketeer'].length === 43, 'Tüfekçi 43 parça korunmalı');
                assert(reg.templates['player:infantry_swordsman'].length === 41, 'Kılıçlı 41 parça korunmalı');

                reg.sync({
                    sectorId: 'SEC_WEP',
                    soldiers: [{
                        viewId: 'SEC_WEP:sw',
                        sectorId: 'SEC_WEP',
                        side: 'player',
                        groupId: 'g',
                        soldierId: 'sw',
                        unitClass: 'swordsman',
                        activeWeapon: 'broadsword',
                        position: { x: 0, y: 0, z: 0 }
                    }]
                });
                const handRest = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_WEP:sw', 35));
                const bladeRest = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_WEP:sw', 40));
                const restDist = Math.hypot(
                    bladeRest[12] - handRest[12],
                    bladeRest[13] - handRest[13],
                    bladeRest[14] - handRest[14]
                );

                reg.sync({
                    sectorId: 'SEC_WEP',
                    soldiers: [{
                        viewId: 'SEC_WEP:sw',
                        sectorId: 'SEC_WEP',
                        side: 'player',
                        groupId: 'g',
                        soldierId: 'sw',
                        unitClass: 'swordsman',
                        activeWeapon: 'broadsword',
                        position: { x: 6, y: 0, z: 0 }
                    }]
                });
                for (let f = 0; f < 6; f++) reg.update(0.04);

                const handWalk = reg.evaluateSoldierPartMatrix('SEC_WEP:sw', 35);
                const bladeWalk = reg.evaluateSoldierPartMatrix('SEC_WEP:sw', 40);
                const walkDist = Math.hypot(
                    bladeWalk[12] - handWalk[12],
                    bladeWalk[13] - handWalk[13],
                    bladeWalk[14] - handWalk[14]
                );
                assert(Math.abs(walkDist - restDist) < 1e-4, 'Yürüyüş sırasında kılıç elden ayrılmamalı');
                reg.dispose();
            });

            runCase('17. Sektör Değişiminde Eski Asker ve Animasyon Kayıtlarının Temizlenmesi', () => {
                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const reg = new SoldierVisualRegistry();

                const s0 = projectActiveSector3D(sm);
                reg.sync(s0);
                const movedS0 = {
                    ...s0,
                    soldiers: s0.soldiers.map((sol, idx) => idx === 0
                        ? { ...sol, position: { x: sol.position.x + 4, y: 0, z: sol.position.z } }
                        : sol)
                };
                reg.sync(movedS0);
                reg.update(0.04);
                assert(reg.stats.movingCount === 1, 'Sektör 0 askeri yürüyüşte olmalı');

                sm.setActiveSector(1);
                const s1Stats = reg.sync(projectActiveSector3D(sm));
                assert(s1Stats.activeCount === 62 && s1Stats.lastRemoved === 300, 'Sektör değişiminde eski 300 asker kaydı silinmeli');
                assert(s1Stats.movingCount === 0, 'Eski sektörün animasyon kayıtları temizlenmeli');
                reg.dispose();
            });

            runCase('18. Boş Veri ve Yeniden Başlatmada Animasyon Kayıtlarının Temizlenmesi', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });

                const snap = {
                    sectorId: 'SEC_CLR',
                    soldiers: [{
                        viewId: 'SEC_CLR:p1',
                        sectorId: 'SEC_CLR',
                        side: 'player',
                        groupId: 'g1',
                        soldierId: 'p1',
                        unitClass: 'pikeman',
                        activeWeapon: 'pike',
                        position: { x: 0, y: 0, z: 0 }
                    }]
                };
                renderer.init(mockMount, snap);
                renderer.sync({
                    ...snap,
                    soldiers: [{ ...snap.soldiers[0], position: { x: 5, y: 0, z: 0 } }]
                });
                renderer.stepSimulation(0.04);
                assert(renderer.soldierRegistry.stats.movingCount === 1, 'Asker yürüyüşte olmalı');

                renderer.sync(null);
                assert(renderer.soldierRegistry.records.size === 0 && renderer.soldierRegistry.stats.movingCount === 0, 'Boş veride animasyon kayıtları sıfırlanmalı');

                renderer.sync(snap);
                renderer.sync({
                    ...snap,
                    soldiers: [{ ...snap.soldiers[0], position: { x: 5, y: 0, z: 0 } }]
                });
                renderer.stepSimulation(0.04);
                renderer.dispose();
                assert(renderer.soldierRegistry === null, 'Dispose sonrası kayıt defteri temizlenmeli');

                renderer.init(mockMount, snap);
                assert(renderer.soldierRegistry.stats.movingCount === 0, 'Yeniden başlatmada eski hareket durumu taşınmamalı');
                renderer.dispose();
            });

            runCase('19. GPU Çizim Gruplarının (7 Batch) & Mevcut Buffer Havuzunun Frame Başına Yeniden Oluşturulmaması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const snap = projectActiveSector3D(sm);

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                renderer.init(mockMount, snap);

                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                const buffersAfterFirstRender = mockCtx.getBufferCount();
                assert(renderer.soldierRegistry.batchGroup.batches.length === 7, '7 instanced çizim grubu korunmalı');

                const movedSnap = {
                    ...snap,
                    soldiers: snap.soldiers.map((s, idx) => idx < 20
                        ? { ...s, position: { x: s.position.x + 4, y: 0, z: s.position.z } }
                        : s)
                };
                renderer.sync(movedSnap);

                for (let f = 0; f < 10; f++) {
                    renderer.stepSimulation(0.03);
                    renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                }

                assert(mockCtx.getBufferCount() === buffersAfterFirstRender, 'Animasyon karelerinde yeni GPU buffer oluşturulmamalı');
                assert(mockCtx.bufferSubDataCalls.length >= 10, 'Mevcut GPU buffer bufferSubData ile yerinde güncellenmeli');
                assert(renderer.soldierRegistry.batchGroup.batches.length === 7, 'Animasyon sırasında batch sayısı 7 kalmalı');
                renderer.dispose();
            });

            runCase('20. WebGL Context Kaybı ve Geri Yükleme Sisteminin Yürüyüş Sırasında Korunması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 800, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 600, configurable: true });

                const renderer = new Battle3DRenderer({
                    rendererFactory: (opts) => new FOC_THREE.WebGLRenderer({
                        gl: mockCtx.gl,
                        onContextLost: opts.onContextLost,
                        onContextRestored: opts.onContextRestored
                    })
                });

                const snap = {
                    sectorId: 'SEC_CTX',
                    soldiers: [{
                        viewId: 'SEC_CTX:p1',
                        sectorId: 'SEC_CTX',
                        side: 'player',
                        groupId: 'g',
                        soldierId: 'p1',
                        unitClass: 'pikeman',
                        activeWeapon: 'pike',
                        position: { x: 0, y: 0, z: 0 }
                    }]
                };
                renderer.init(mockMount, snap);
                renderer.sync({
                    ...snap,
                    soldiers: [{ ...snap.soldiers[0], position: { x: 5, y: 0, z: 0 } }]
                });
                renderer.stepSimulation(0.04);
                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);

                renderer.simulateContextLoss();
                assert(renderer.isContextLost === true && renderer.rafId === null, 'Context kaybında RAF döngüsü güvenle durmalı');

                const restored = renderer.renderer._handleContextRestored();
                assert(restored === true && renderer.isContextLost === false && renderer.rafId !== null, 'Context geri yüklendiğinde sahne ve animasyon döngüsü devam etmeli');
                renderer.dispose();
            });

            runCase('21. Üst Menü ve Test Panelinin Çakışmasız Yerleşimi & Gerçek Fare Tıklaması', () => {
                const header = document.getElementById('focHeader');
                const sidebar = document.getElementById('focSidebar');
                const btnRunTests = document.getElementById('btnRunTests');
                const btnModeTest = document.getElementById('btnModeTest');

                assert(header && sidebar && btnRunTests && btnModeTest, 'Üst menü ve yan panel DOM öğeleri mevcut olmalı');

                const hRect = header.getBoundingClientRect();
                const sRect = sidebar.getBoundingClientRect();
                const btnRect = btnRunTests.getBoundingClientRect();

                assert(sRect.top >= hRect.bottom - 1, `Sol yan panel üst menüyü kapatmamalı (sidebar.top=${sRect.top}, header.bottom=${hRect.bottom})`);
                assert(btnRect.width > 0 && btnRect.height > 0, 'Birim Testleri düğmesi görünür ve tıklanabilir boyutta olmalı');

                if (typeof document.elementFromPoint === 'function') {
                    const cx = btnRect.left + btnRect.width * 0.5;
                    const cy = btnRect.top + btnRect.height * 0.5;
                    const hitEl = document.elementFromPoint(cx, cy);
                    assert(
                        hitEl === btnRunTests || (hitEl && btnRunTests.contains(hitEl)),
                        'Birim Testleri düğmesinin merkezi başka bir panel tarafından kapatılmamalı'
                    );
                }

                let clicked = false;
                const probe = () => { clicked = true; };
                btnModeTest.addEventListener('click', probe, { once: true });
                btnModeTest.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
                assert(clicked === true, 'Üst menü düğmesi gerçek fare tıklamasına yanıt vermeli');
            });

            runCase('22. Yürüyüş Önizlemesi Kimlik, Sınıf, Silah, Ekipman Korunumu ve Kapanış Regresyon Testi', () => {
                const probeController = new Battle3DPreviewController();
                probeController._buildSectorManager('test');

                const sm = probeController.sectorManager;
                const origSnap = projectActiveSector3D(sm);
                const previewResult = probeController._buildWalkPreviewSnapshot(0);
                const prevSnap = previewResult.snapshot;

                assert(origSnap.soldiers.length === 300 && prevSnap.soldiers.length === 300, 'Önizleme snapshot 300 askeri eksiksiz içermeli');

                let movedInfantryCount = 0;
                const origByViewId = new Map();

                for (let i = 0; i < origSnap.soldiers.length; i++) {
                    const orig = origSnap.soldiers[i];
                    const prev = prevSnap.soldiers[i];
                    origByViewId.set(orig.viewId, orig);

                    assert(orig.viewId === prev.viewId, `viewId değişmemeli: ${orig.viewId}`);
                    assert(orig.sectorId === prev.sectorId, `sectorId değişmemeli: ${orig.viewId}`);
                    assert(orig.side === prev.side, `side değişmemeli: ${orig.viewId}`);
                    assert(orig.groupId === prev.groupId, `groupId değişmemeli: ${orig.viewId}`);
                    assert(orig.soldierId === prev.soldierId, `soldierId değişmemeli: ${orig.viewId}`);
                    assert(orig.unitClass === prev.unitClass, `unitClass değişmemeli (${orig.viewId}: ${orig.unitClass} !== ${prev.unitClass})`);
                    assert(orig.combatRole === prev.combatRole, `combatRole değişmemeli: ${orig.viewId}`);
                    assert(orig.bodyType === prev.bodyType, `bodyType değişmemeli: ${orig.viewId}`);
                    assert(orig.mountType === prev.mountType, `mountType değişmemeli: ${orig.viewId}`);
                    assert(orig.activeWeapon === prev.activeWeapon, `activeWeapon değişmemeli (${orig.viewId}: ${orig.activeWeapon} !== ${prev.activeWeapon})`);
                    assert(JSON.stringify(orig.weaponLoadout) === JSON.stringify(prev.weaponLoadout), `weaponLoadout değişmemeli: ${orig.viewId}`);
                    assert(JSON.stringify(orig.armorLoadout) === JSON.stringify(prev.armorLoadout), `armorLoadout değişmemeli: ${orig.viewId}`);
                    assert(orig.state === prev.state, `state değişmemeli: ${orig.viewId}`);
                    assert(orig.hp === prev.hp, `hp değişmemeli: ${orig.viewId}`);

                    const posChanged = Math.hypot(
                        prev.position.x - orig.position.x,
                        prev.position.y - orig.position.y,
                        prev.position.z - orig.position.z
                    ) > 1e-4;

                    if (posChanged) {
                        movedInfantryCount++;
                        assert(
                            orig.bodyType === 'human' && (orig.mountType === 'foot' || !orig.mountType),
                            `Yalnızca seçilen piyadelerin kopya konumları değişebilmeli (${orig.viewId})`
                        );
                        assert(
                            orig.unitClass !== 'swordsman' && prev.unitClass !== 'swordsman',
                            `Mevcut piyadeler kılıçlıya dönüştürülmemeli (${orig.viewId})`
                        );
                    }
                }

                assert(movedInfantryCount === 16, `16 örnek piyade hareket etmeli, gelen: ${movedInfantryCount}`);

                const rawSoldiers = sm.getActiveSector().getAllSoldiers();
                assert(rawSoldiers.length === 330, 'Asıl SectorManager asker sayısı değişmemeli');
                for (let j = 0; j < origSnap.soldiers.length; j++) {
                    const snapSol = origSnap.soldiers[j];
                    const rawSol = rawSoldiers.find((r) => r.id === snapSol.soldierId);
                    assert(
                        rawSol &&
                        rawSol.position.x === snapSol.position.x &&
                        rawSol.position.z === snapSol.position.z &&
                        rawSol.unitClass === snapSol.unitClass &&
                        rawSol.activeWeapon === snapSol.activeWeapon,
                        `Asıl SectorManager verileri değişmemeli (${snapSol.soldierId})`
                    );
                }

                const reg = new SoldierVisualRegistry();
                reg.sync(origSnap);
                const initialTemplates = new Map();
                for (const [vid, rec] of reg.records.entries()) {
                    initialTemplates.set(vid, rec.templateKey);
                }

                reg.sync(prevSnap);
                for (let f = 0; f < 6; f++) {
                    reg.update(0.04);
                }

                assert(reg.stats.movingCount === 16, `16 piyade aktif yürüyüş durumunda olmalı, gelen: ${reg.stats.movingCount}`);
                for (const [vid, rec] of reg.records.entries()) {
                    assert(
                        rec.templateKey === initialTemplates.get(vid),
                        `Önizleme açıldığında hiçbir askerin templateKey değeri farklı sınıfa geçmemeli (${vid}: ${initialTemplates.get(vid)} -> ${rec.templateKey})`
                    );
                }

                reg.sync(origSnap);
                for (let f = 0; f < 80; f++) {
                    reg.update(0.05);
                }

                assert(reg.stats.movingCount === 0, 'Önizleme kapatıldığında yürüyen asker kalmamalı');
                for (const [vid, rec] of reg.records.entries()) {
                    const orig = origByViewId.get(vid);
                    assert(
                        Math.abs(rec.x - orig.position.x) < 1e-4 &&
                        Math.abs(rec.y - orig.position.y) < 1e-4 &&
                        Math.abs(rec.z - orig.position.z) < 1e-4,
                        `Önizleme kapatıldığında asker eski konumuna dönmeli (${vid})`
                    );
                    assert(
                        rec.isMoving === false && rec.walkBlend === 0 && rec.walkPhase === 0,
                        `Önizleme kapatıldığında asker hazır duruşuna dönmeli (${vid})`
                    );
                }

                reg.dispose();
            });

            runCase('23. Yürüyüş Önizlemesi Kamera Kadrajı Regresyon Testi (Yürüyen Piyade Kümesi & Panel Arası Görünürlük)', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 4.5;
                cam.desired.targetZ = -6.0;
                cam.desired.distance = 52;
                cam.desired.yaw = 0.25;
                cam.desired.pitch = 0.92;
                cam.syncTransform(1);

                const preWalkState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance,
                    yaw: cam.current.yaw,
                    pitch: cam.current.pitch
                };

                const previewInfo = probe._buildWalkPreviewSnapshot(0);
                assert(
                    previewInfo.focusCenter.x < -12 && previewInfo.focusCenter.z < -12,
                    `focusCenter boş orta nokta (0,0) yerine dost yürüyen piyade kümesine odaklanmalı (x=${previewInfo.focusCenter.x.toFixed(2)}, z=${previewInfo.focusCenter.z.toFixed(2)})`
                );

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true, 'Yürüyüş önizlemesi aktif olmalı');
                cam.syncTransform(1);

                assert(
                    cam.current.targetX < -12 && cam.current.targetZ < -12,
                    `Kamera hedefi yürüyen dost piyadelere odaklanmalı (targetX=${cam.current.targetX.toFixed(2)}, targetZ=${cam.current.targetZ.toFixed(2)})`
                );

                for (let f = 0; f < 6; f++) {
                    testRenderer.stepSimulation(0.04);
                }

                const vw = 1440;
                const vh = 900;
                const openLeft = 364;
                const openRight = 1004;
                const openTop = 84;
                const openBottom = 834;

                let visibleUnoccludedWalkingInfantry = 0;
                const reg = testRenderer.soldierRegistry;

                for (const rec of reg.records.values()) {
                    if (!rec.isMoving && rec.walkBlend <= 0) continue;
                    const scr = cam.camera.projectWorldToScreen(rec.x, 1.0, rec.z, vw, vh);
                    if (
                        scr.inFront &&
                        scr.x >= openLeft &&
                        scr.x <= openRight &&
                        scr.y >= openTop &&
                        scr.y <= openBottom
                    ) {
                        visibleUnoccludedWalkingInfantry++;
                    }
                }

                assert(
                    visibleUnoccludedWalkingInfantry >= 6,
                    `1440x900 çözünürlükte sol ve sağ paneller açıkken en az 6 yürüyen piyade paneller arasındaki açık alanda görülebilmeli, görülen: ${visibleUnoccludedWalkingInfantry}`
                );

                const beforeUserPanX = cam.desired.targetX;
                cam.panRelative(0, 3.0);
                assert(cam.desired.targetX !== beforeUserPanX, 'Yürüyüş önizlemesi sırasında kullanıcı kamera kontrolleri kilitlenmemeli');

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === false, 'Yürüyüş önizlemesi kapatılabilmeli');
                cam.syncTransform(1);

                assert(
                    Math.abs(cam.current.targetX - preWalkState.targetX) < 1e-4 &&
                    Math.abs(cam.current.targetZ - preWalkState.targetZ) < 1e-4 &&
                    Math.abs(cam.current.distance - preWalkState.distance) < 1e-4 &&
                    Math.abs(cam.current.yaw - preWalkState.yaw) < 1e-4 &&
                    Math.abs(cam.current.pitch - preWalkState.pitch) < 1e-4,
                    'Önizleme kapandığında kullanıcının eski kamera konumu, açısı ve yakınlığı geri yüklenmeli'
                );

                testRenderer.dispose();
            });

            runCase('24. Çok Aşamalı Yürüyüş (walkPreviewLeg 0 -> 1 -> 2 -> 3) Kamera Odağı & Kullanıcı Kontrolü Koruması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 5.0;
                cam.desired.targetZ = -4.0;
                cam.desired.distance = 50;
                cam.desired.yaw = 0.2;
                cam.desired.pitch = 0.9;
                cam.syncTransform(1);

                const preWalkState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance,
                    yaw: cam.current.yaw,
                    pitch: cam.current.pitch
                };

                const vw = 1440;
                const vh = 900;
                const openLeft = 364;
                const openRight = 1004;
                const openTop = 84;
                const openBottom = 834;

                const countOpenAreaPlayerWalking = () => {
                    let count = 0;
                    for (const rec of testRenderer.soldierRegistry.records.values()) {
                        if (rec.side !== 'player') continue;
                        if (!rec.isMoving && rec.walkBlend <= 0) continue;
                        const scr = cam.camera.projectWorldToScreen(rec.x, 1.0, rec.z, vw, vh);
                        if (
                            scr.inFront &&
                            scr.x >= openLeft &&
                            scr.x <= openRight &&
                            scr.y >= openTop &&
                            scr.y <= openBottom
                        ) {
                            count++;
                        }
                    }
                    return count;
                };

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true && probe.walkPreviewLeg === 0, 'Önizleme Leg 0 ile başlamalı');
                cam.syncTransform(1);

                const walkFocusTargetX = cam.current.targetX;
                const walkFocusTargetZ = cam.current.targetZ;
                assert(
                    Math.abs(walkFocusTargetX - (-17.0)) < 0.5 && Math.abs(walkFocusTargetZ - (-19.88)) < 0.5,
                    `Başlangıç kamera odağı dost piyade kümesinde (-17.0, -19.88) olmalı, gelen: (${walkFocusTargetX.toFixed(2)}, ${walkFocusTargetZ.toFixed(2)})`
                );

                const visitedLegs = [probe.walkPreviewLeg];
                for (let stepIdx = 0; stepIdx < 4; stepIdx++) {
                    for (let f = 0; f < 8; f++) {
                        testRenderer.stepSimulation(0.04);
                    }
                    cam.syncTransform(1);

                    const distFromSectorCenter = Math.hypot(cam.current.targetX - 0.1, cam.current.targetZ - (-3.4));
                    assert(
                        distFromSectorCenter > 15.0 &&
                        Math.abs(cam.current.targetX - walkFocusTargetX) < 1e-4 &&
                        Math.abs(cam.current.targetZ - walkFocusTargetZ) < 1e-4,
                        `Leg ${probe.walkPreviewLeg} aşamasında kamera sektör merkezine dönmemeli (targetX=${cam.current.targetX.toFixed(2)}, targetZ=${cam.current.targetZ.toFixed(2)})`
                    );

                    const visibleCount = countOpenAreaPlayerWalking();
                    assert(
                        visibleCount >= 6,
                        `Leg ${probe.walkPreviewLeg} aşamasında paneller arasındaki açık alanda en az 6 dost yürüyen piyade görülebilmeli, görülen: ${visibleCount}`
                    );

                    if (stepIdx < 3) {
                        probe._onFrameTick(2.45);
                        visitedLegs.push(probe.walkPreviewLeg);
                    }
                }

                assert(
                    JSON.stringify(visitedLegs) === JSON.stringify([0, 1, 2, 3]),
                    `walkPreviewLeg 0 -> 1 -> 2 -> 3 geçişlerinin tamamı çalıştırılmalı, gerçekleşen: ${visitedLegs.join(' -> ')}`
                );

                cam.panRelative(0, 2.5);
                cam.zoomBy(-3.0);
                cam.syncTransform(1);
                const userCustomX = cam.current.targetX;
                const userCustomZ = cam.current.targetZ;
                const userCustomDist = cam.current.distance;

                probe._onFrameTick(2.45);
                cam.syncTransform(1);
                assert(
                    Math.abs(cam.current.targetX - userCustomX) < 1e-4 &&
                    Math.abs(cam.current.targetZ - userCustomZ) < 1e-4 &&
                    Math.abs(cam.current.distance - userCustomDist) < 1e-4,
                    'Kullanıcının elle değiştirdiği kamera konumu ve yakınlığı sonraki snapshot senkronizasyonunda korunmalı'
                );

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === false, 'Yürüyüş önizlemesi kapatılabilmeli');
                cam.syncTransform(1);
                assert(
                    Math.abs(cam.current.targetX - preWalkState.targetX) < 1e-4 &&
                    Math.abs(cam.current.targetZ - preWalkState.targetZ) < 1e-4 &&
                    Math.abs(cam.current.distance - preWalkState.distance) < 1e-4 &&
                    Math.abs(cam.current.yaw - preWalkState.yaw) < 1e-4 &&
                    Math.abs(cam.current.pitch - preWalkState.pitch) < 1e-4,
                    'Önizleme kapatıldığında başlangıçtaki kamera durumu geri gelmeli'
                );

                testRenderer.dispose();
            });

            runCase('25. Süvari Modellerinin, 206 Görsel Şablonun ve Aktif Silahların (Mızrak, Kılıç, Karabina, Tabanca) Korunması', () => {
                const reg = new SoldierVisualRegistry();
                const allTemplateKeys = Object.keys(reg.templates);
                assert(allTemplateKeys.length === 206, `Toplam 206 görsel model şablonu korunmalı, gelen: ${allTemplateKeys.length}`);
                assert(reg.templates['player:infantry_pikeman'].length === 44, 'Mızraklı piyade 44 parça korunmalı');
                assert(reg.templates['player:infantry_musketeer'].length === 43, 'Tüfekçi 43 parça korunmalı');
                assert(reg.templates['player:infantry_swordsman'].length === 41, 'Kılıçlı 41 parça korunmalı');

                const weaponChecks = [
                    { side: 'enemy', unitClass: 'demi_lancer', mountType: 'destrier', activeWeapon: 'war_lance', armorLoadout: ['close_helm'], expectedArch: 'cavalry_lance' },
                    { side: 'player', unitClass: 'cuirassier', mountType: 'warhorse', activeWeapon: 'cavalry_sabre', armorLoadout: ['three_quarter_plate'], expectedArch: 'cavalry_sabre' },
                    { side: 'player', unitClass: 'harquebusier', mountType: 'courser', activeWeapon: 'carbine', armorLoadout: ['burgonet'], expectedArch: 'cavalry_carbine' },
                    { side: 'enemy', unitClass: 'reiter', mountType: 'charger', activeWeapon: 'wheellock_pistol', armorLoadout: ['blackened_cuirass'], expectedArch: 'cavalry_pistol' }
                ];

                weaponChecks.forEach((wc) => {
                    assert(classifySoldierArchetype(wc) === wc.expectedArch, `${wc.activeWeapon} -> ${wc.expectedArch} sınıflandırılmalı`);
                    const vKey = resolveCavalryVisualVariant(wc);
                    const tpl = reg.templates[vKey];
                    assert(Array.isArray(tpl) && tpl.length >= 60, `${vKey} şablonu eksiksiz olmalı`);
                    tpl.forEach((p, idx) => {
                        assert(typeof p.rigGroup === 'string' && p.localMat && p.localMat.length === 16, `${vKey}[${idx}] rigGroup ve localMat[16] korunmalı`);
                    });
                });

                reg.dispose();
            });

            runCase('26. Süvari Snapshot Konum Değişimi, Asker Kimliği Sürekliliği & Hareket Hızı Değişmezliği', () => {
                const reg = new SoldierVisualRegistry();
                const cavSnap1 = {
                    sectorId: 'SEC_CAV_ID',
                    soldiers: [{
                        viewId: 'SEC_CAV_ID:c1',
                        sectorId: 'SEC_CAV_ID',
                        side: 'player',
                        groupId: 'grp_cav',
                        soldierId: 'c1',
                        unitClass: 'cuirassier',
                        bodyType: 'mounted',
                        mountType: 'warhorse',
                        activeWeapon: 'cavalry_sabre',
                        armorLoadout: ['three_quarter_plate'],
                        position: { x: -30, y: 0, z: 4 }
                    }]
                };
                const cavSnap2 = {
                    sectorId: 'SEC_CAV_ID',
                    soldiers: [{
                        ...cavSnap1.soldiers[0],
                        position: { x: -24, y: 0, z: 4 }
                    }]
                };

                const s1 = reg.sync(cavSnap1);
                const s2 = reg.sync(cavSnap2);
                assert(s1.lastCreated === 1 && s2.lastCreated === 0, 'Konum değişiminde süvari yeniden oluşturulmamalı');
                assert(s2.lastUpdated === 1 && reg.records.size === 1, 'Aynı viewId kaydı korunmalı');

                const rec = reg.getSoldierVisualState('SEC_CAV_ID:c1');
                const initialTpl = rec.templateKey;
                assert(rec.isMoving === true, 'Yeni hedef verildiğinde süvari hareket etmeli');

                for (let f = 0; f < 80; f++) {
                    reg.update(0.05);
                }
                assert(Math.abs(rec.x - (-24)) < 1e-4 && Math.abs(rec.z - 4) < 1e-4, 'Süvari hedef konuma ulaşmalı');
                assert(rec.isMoving === false && rec.walkBlend === 0 && rec.trotBlend === 0 && rec.walkPhase === 0, 'Hareket sona erince at ve binici tam olarak eski duruşuna dönmeli');
                assert(rec.templateKey === initialTpl, 'Hareket boyunca süvari model varyantı ve silahı değişmemeli');

                reg.update(0.05);
                assert(rec.isMoving === false && Math.abs(rec.x - (-24)) < 1e-4, 'Yeni hedef verilmezse at kendi kendine hareket etmemeli');
                reg.dispose();
            });

            runCase('27. At Yürüyüşünde (4-Beat Walk) Dört Bacağın Ayrı Fazlarda Hareketi & Diz/Toynak Bağlantısı', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_WALK_HORSE',
                    soldiers: [{
                        viewId: 'SEC_WALK_HORSE:h1',
                        sectorId: 'SEC_WALK_HORSE',
                        side: 'player',
                        groupId: 'grp_h',
                        soldierId: 'h1',
                        unitClass: 'cuirassier',
                        bodyType: 'mounted',
                        mountType: 'warhorse',
                        activeWeapon: 'cavalry_sabre',
                        armorLoadout: ['three_quarter_plate'],
                        position: { x: 0, y: 0, z: 0 }
                    }]
                });

                reg.sync({
                    sectorId: 'SEC_WALK_HORSE',
                    soldiers: [{
                        viewId: 'SEC_WALK_HORSE:h1',
                        sectorId: 'SEC_WALK_HORSE',
                        side: 'player',
                        groupId: 'grp_h',
                        soldierId: 'h1',
                        unitClass: 'cuirassier',
                        bodyType: 'mounted',
                        mountType: 'warhorse',
                        activeWeapon: 'cavalry_sabre',
                        armorLoadout: ['three_quarter_plate'],
                        position: { x: 2.5, y: 0, z: 0 }
                    }]
                });

                for (let f = 0; f < 5; f++) {
                    reg.update(0.04);
                }

                const rec = reg.getSoldierVisualState('SEC_WALK_HORSE:h1');
                assert(rec.isMoving && rec.walkBlend > 0.5 && rec.trotBlend < 0.05, `Kısa mesafede 4 zamanlı yürüyüş aktif olmalı (trotBlend=${rec.trotBlend.toFixed(3)})`);

                const flHoof = reg.evaluateSoldierPartMatrix('SEC_WALK_HORSE:h1', 14);
                const frHoof = reg.evaluateSoldierPartMatrix('SEC_WALK_HORSE:h1', 15);
                const hlHoof = reg.evaluateSoldierPartMatrix('SEC_WALK_HORSE:h1', 24);
                const hrHoof = reg.evaluateSoldierPartMatrix('SEC_WALK_HORSE:h1', 25);

                const flDz = flHoof[14] - 0.58;
                const frDz = frHoof[14] - 0.58;
                const hlDz = hlHoof[14] - (-0.59);
                const hrDz = hrHoof[14] - (-0.59);

                assert(flDz * frDz < 0, `Ön sağ ve sol bacaklar zıt fazda olmalı (flDz=${flDz.toFixed(3)}, frDz=${frDz.toFixed(3)})`);
                assert(hlDz * hrDz < 0, `Arka sağ ve sol bacaklar zıt fazda olmalı (hlDz=${hlDz.toFixed(3)}, hrDz=${hrDz.toFixed(3)})`);
                assert(Math.abs(flDz - hlDz) > 0.02, `4 zamanlı yürüyüşte ön-sol ve arka-sol bacaklar farklı fazlarda olmalı (flDz=${flDz.toFixed(3)}, hlDz=${hlDz.toFixed(3)})`);

                [flHoof, frHoof, hlHoof, hrHoof].forEach((hm, idx) => {
                    assert(hm[13] >= 0.02, `Toynak ${idx} zeminin altına gömülmemeli (y=${hm[13].toFixed(3)})`);
                });

                reg.dispose();
            });

            runCase('28. Tırıs Hareketi (2-Beat Diagonal Trot) & Binici-Eyer-Üzengi-Silah Bütünlüğü', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TROT',
                    soldiers: [{
                        viewId: 'SEC_TROT:h1',
                        sectorId: 'SEC_TROT',
                        side: 'enemy',
                        groupId: 'grp_lancers',
                        soldierId: 'h1',
                        unitClass: 'demi_lancer',
                        bodyType: 'mounted',
                        mountType: 'destrier',
                        activeWeapon: 'war_lance',
                        armorLoadout: ['close_helm', 'half_plate'],
                        position: { x: 35, y: 0, z: 2 }
                    }]
                });

                const restStirrup = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 49));
                const restBoot = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 59));
                const restFootStirrupDist = Math.hypot(
                    restBoot[12] - restStirrup[12],
                    restBoot[13] - restStirrup[13],
                    restBoot[14] - restStirrup[14]
                );

                reg.sync({
                    sectorId: 'SEC_TROT',
                    soldiers: [{
                        viewId: 'SEC_TROT:h1',
                        sectorId: 'SEC_TROT',
                        side: 'enemy',
                        groupId: 'grp_lancers',
                        soldierId: 'h1',
                        unitClass: 'demi_lancer',
                        bodyType: 'mounted',
                        mountType: 'destrier',
                        activeWeapon: 'war_lance',
                        armorLoadout: ['close_helm', 'half_plate'],
                        position: { x: 25, y: 0, z: 2 }
                    }]
                });

                for (let f = 0; f < 10; f++) {
                    reg.update(0.04);
                }

                const rec = reg.getSoldierVisualState('SEC_TROT:h1');
                assert(rec.isMoving && rec.trotBlend > 0.75, `Uzun süvari hareketinde tırıs modu aktif olmalı (trotBlend=${rec.trotBlend.toFixed(3)})`);

                const flHoof = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 14);
                const frHoof = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 15);
                const hlHoof = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 24);
                const hrHoof = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 25);

                const flDz = flHoof[14] - 0.58;
                const hrDz = hrHoof[14] - (-0.59);
                const frDz = frHoof[14] - 0.58;
                const hlDz = hlHoof[14] - (-0.59);

                assert(flDz * hrDz > 0, `Tırısta ön-sol ve arka-sağ çapraz çifti birlikte hareket etmeli (flDz=${flDz.toFixed(3)}, hrDz=${hrDz.toFixed(3)})`);
                assert(frDz * hlDz > 0, `Tırısta ön-sağ ve arka-sol çapraz çifti birlikte hareket etmeli (frDz=${frDz.toFixed(3)}, hlDz=${hlDz.toFixed(3)})`);
                assert(flDz * frDz < 0, 'İki çapraz bacak çifti birbirine zıt fazda salınmalı');

                const trotStirrup = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 49);
                const trotBoot = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', 59);
                const trotFootStirrupDist = Math.hypot(
                    trotBoot[12] - trotStirrup[12],
                    trotBoot[13] - trotStirrup[13],
                    trotBoot[14] - trotStirrup[14]
                );
                assert(Math.abs(trotFootStirrupDist - restFootStirrupDist) < 1e-4, 'Binici ayağı üzengiden kopmamalı');

                const tplLen = reg.templates[rec.templateKey].length;
                const handMat = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', tplLen - 6);
                const tipMat = reg.evaluateSoldierPartMatrix('SEC_TROT:h1', tplLen - 3);
                const handTipDist = Math.hypot(tipMat[12] - handMat[12], tipMat[13] - handMat[13], tipMat[14] - handMat[14]);
                assert(handTipDist > 2.0, 'Mızrak binicinin elinde bütünlüğünü korumalı');

                reg.dispose();
            });

            runCase('29. Süvari Hareket Önizlemesi, Piyade Önizlemesi ile Karşılıklı Dışlama & Kamera Koruması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 2.0;
                cam.desired.targetZ = -2.0;
                cam.desired.distance = 48;
                cam.desired.yaw = 0.1;
                cam.desired.pitch = 0.88;
                cam.syncTransform(1);

                const preState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance,
                    yaw: cam.current.yaw,
                    pitch: cam.current.pitch
                };

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true && probe.cavalryPreviewActive === false, 'Piyade önizlemesi aktif olmalı');

                probe.toggleCavalryPreview();
                assert(probe.cavalryPreviewActive === true && probe.walkPreviewActive === false, 'Piyade ve süvari önizlemeleri aynı anda açık olmamalı');
                cam.syncTransform(1);

                const cavFocusX = cam.current.targetX;
                const cavFocusZ = cam.current.targetZ;

                for (let f = 0; f < 6; f++) testRenderer.stepSimulation(0.04);
                cam.syncTransform(1);
                assert(Math.abs(cam.current.targetX - cavFocusX) < 1e-4, 'Süvari önizlemesinde kamera odağı korunmalı');

                probe._onFrameTick(2.65);
                assert(probe.cavalryPreviewLeg === 1, 'Süvari önizlemesi 2. aşamaya (tırıs) geçebilmeli');
                for (let f = 0; f < 8; f++) testRenderer.stepSimulation(0.04);
                cam.syncTransform(1);
                assert(Math.abs(cam.current.targetX - cavFocusX) < 1e-4 && Math.abs(cam.current.targetZ - cavFocusZ) < 1e-4, 'Tırıs geçişinde kamera odağı sektör merkezine dönmemeli');

                const beforePan = cam.desired.targetX;
                cam.panRelative(0, 2.0);
                assert(cam.desired.targetX !== beforePan, 'Süvari önizlemesinde kullanıcı kamera kontrolü kilitlenmemeli');

                probe.toggleCavalryPreview();
                assert(probe.cavalryPreviewActive === false, 'Süvari önizlemesi kapatılabilmeli');
                for (let f = 0; f < 80; f++) testRenderer.stepSimulation(0.05);
                cam.syncTransform(1);

                assert(testRenderer.soldierRegistry.stats.movingCount === 0, 'Önizleme kapandığında hareketli süvari kalmamalı');
                assert(
                    Math.abs(cam.current.targetX - preState.targetX) < 1e-4 &&
                    Math.abs(cam.current.targetZ - preState.targetZ) < 1e-4 &&
                    Math.abs(cam.current.distance - preState.distance) < 1e-4,
                    'Süvari önizlemesi kapandığında kamera başlangıç durumuna dönmeli'
                );

                testRenderer.dispose();
            });

            runCase('30. Sektör Geçişleri, GPU Kaynak Havuzu, Context Kurtarma & 12 Grup / 442 Askerlik Ordu Koruması', () => {
                const battleData = createTestBattleData();
                const allGroups = [...battleData.playerGroups, ...battleData.enemyGroups];
                assert(allGroups.length === 12, `12 birlik grubu korunmalı, gelen: ${allGroups.length}`);
                const totalSoldiers = allGroups.reduce((acc, g) => acc + g.soldiers.length, 0);
                assert(totalSoldiers === 442, `442 asker korunmalı, gelen: ${totalSoldiers}`);

                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);

                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const renderer = new Battle3DRenderer({
                    rendererFactory: (opts) => new FOC_THREE.WebGLRenderer({
                        gl: mockCtx.gl,
                        onContextLost: opts.onContextLost,
                        onContextRestored: opts.onContextRestored
                    })
                });

                renderer.init(mockMount, projectActiveSector3D(sm));
                assert(renderer.soldierRegistry.records.size === 300 && renderer.soldierRegistry.batchGroup.batches.length === 7, 'Merkez 300 asker & 7 batch');

                sm.setActiveSector(1);
                renderer.sync(projectActiveSector3D(sm), { snapCamera: true });
                assert(renderer.soldierRegistry.records.size === 62, 'Batı sektörü 62 asker');

                sm.setActiveSector(2);
                renderer.sync(projectActiveSector3D(sm), { snapCamera: true });
                assert(renderer.soldierRegistry.records.size === 50, 'Doğu sektörü 50 asker');

                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                const bufCountBeforeAnim = mockCtx.getBufferCount();
                const eastSnap = projectActiveSector3D(sm);
                renderer.sync({
                    ...eastSnap,
                    soldiers: eastSnap.soldiers.map((s, idx) => idx < 10
                        ? { ...s, position: { x: s.position.x - 6, y: 0, z: s.position.z } }
                        : s)
                }, { preserveCamera: true });
                for (let f = 0; f < 6; f++) {
                    renderer.stepSimulation(0.04);
                    renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                }
                assert(mockCtx.getBufferCount() === bufCountBeforeAnim, 'Süvari animasyonunda yeni GPU buffer oluşturulmamalı');

                renderer.simulateContextLoss();
                assert(renderer.isContextLost === true, 'Context kaybı algılanmalı');
                assert(renderer.renderer._handleContextRestored() === true && renderer.isContextLost === false, 'Context geri yüklenebilmeli');

                renderer.dispose();
            });

            // --- NEW 7 TESTS FOR G3D-03C-R1 (31 TO 37) ---
            runCase('31. Mızraklı Piyade Savaş Eylemi (Hazırlanma, İleri Hamle, Bekleme, Geri Çekilme & El-Mızrak Bütünlüğü)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_PIKE_ATK',
                    soldiers: [{
                        viewId: 'SEC_PIKE_ATK:pk1',
                        sectorId: 'SEC_PIKE_ATK',
                        side: 'player',
                        groupId: 'grp_pikemen',
                        soldierId: 'pk1',
                        unitClass: 'pikeman',
                        activeWeapon: 'pike',
                        state: 'ready',
                        position: { x: -16, y: 0, z: -8 }
                    }]
                });

                const rec = reg.getSoldierVisualState('SEC_PIKE_ATK:pk1');
                // Part 36 = Right Hand, Part 39 = Left Hand, Part 43 = Pike Spearhead
                const restHandMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 36));
                const restLeftHandMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 39));
                const restTipMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 43));

                const restHandToTipDist = Math.hypot(
                    restTipMat[12] - restHandMat[12],
                    restTipMat[13] - restHandMat[13],
                    restTipMat[14] - restHandMat[14]
                );
                const restHandsSpan = Math.hypot(
                    restLeftHandMat[12] - restHandMat[12],
                    restLeftHandMat[13] - restHandMat[13],
                    restLeftHandMat[14] - restHandMat[14]
                );

                // Trigger visual combat action ('attack') via snapshot without altering position/weapon
                reg.sync({
                    sectorId: 'SEC_PIKE_ATK',
                    soldiers: [{
                        viewId: 'SEC_PIKE_ATK:pk1',
                        sectorId: 'SEC_PIKE_ATK',
                        side: 'player',
                        groupId: 'grp_pikemen',
                        soldierId: 'pk1',
                        unitClass: 'pikeman',
                        activeWeapon: 'pike',
                        state: 'attack',
                        position: { x: -16, y: 0, z: -8 }
                    }]
                });

                // Bring actionBlend to full 1.0
                for (let f = 0; f < 6; f++) reg.update(0.03);
                assert(rec.isCombatActing === true && rec.actionBlend > 0.9, 'Mızraklı piyade savaş eylemi aktif olmalı');

                // Phase 1: Wind-up / chambering (u = 0.14 -> spearhead retracts backward in Z relative to ready stance)
                rec.actionPhase = 0.14;
                const windupTipMat = reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 43);
                assert(
                    windupTipMat[14] < restTipMat[14] - 0.15,
                    `Hazırlanma fazında mızrak geri çekilmeli (windupZ=${windupTipMat[14].toFixed(3)}, restZ=${restTipMat[14].toFixed(3)})`
                );

                // Phase 2 & 3: Forward pike thrust & brief hold (u = 0.56 -> spearhead drives strongly forward in +Z)
                rec.actionPhase = 0.56;
                const thrustHandMat = reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 36);
                const thrustLeftHandMat = reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 39);
                const thrustTipMat = reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 43);

                assert(
                    thrustTipMat[14] > restTipMat[14] + 0.55,
                    `İleri hamle ve bekleme fazında mızrak ucu öne uzanmalı (thrustZ=${thrustTipMat[14].toFixed(3)}, restZ=${restTipMat[14].toFixed(3)})`
                );

                // Verify pike never detaches from either gripping hand during full thrust
                const thrustHandToTipDist = Math.hypot(
                    thrustTipMat[12] - thrustHandMat[12],
                    thrustTipMat[13] - thrustHandMat[13],
                    thrustTipMat[14] - thrustHandMat[14]
                );
                const thrustHandsSpan = Math.hypot(
                    thrustLeftHandMat[12] - thrustHandMat[12],
                    thrustLeftHandMat[13] - thrustHandMat[13],
                    thrustLeftHandMat[14] - thrustHandMat[14]
                );
                assert(Math.abs(thrustHandToTipDist - restHandToTipDist) < 1e-4, 'Mızrak hamle sırasında sağ elden kopmamalı');
                assert(Math.abs(thrustHandsSpan - restHandsSpan) < 1e-4, 'İki elin mızrak üzerindeki tutuş mesafesi korunmalı');

                // Return to ready stance when combat state ends
                reg.sync({
                    sectorId: 'SEC_PIKE_ATK',
                    soldiers: [{
                        viewId: 'SEC_PIKE_ATK:pk1',
                        sectorId: 'SEC_PIKE_ATK',
                        side: 'player',
                        groupId: 'grp_pikemen',
                        soldierId: 'pk1',
                        unitClass: 'pikeman',
                        activeWeapon: 'pike',
                        state: 'ready',
                        position: { x: -16, y: 0, z: -8 }
                    }]
                });
                for (let f = 0; f < 40; f++) reg.update(0.04);

                assert(rec.isCombatActing === false && rec.actionBlend === 0 && rec.actionPhase === 0, 'Eylem bitince hazır duruşuna dönmeli');
                const recoveredTipMat = reg.evaluateSoldierPartMatrix('SEC_PIKE_ATK:pk1', 43);
                for (let k = 0; k < 16; k++) {
                    assert(Math.abs(recoveredTipMat[k] - restTipMat[k]) < 1e-5, 'Hazır duruşuna dönüşte mızrak matrisi ilk duruşuna eşit olmalı');
                }

                reg.dispose();
            });

            runCase('32. Tüfekçi ve Arkebüzcü Nişan Alma, Ateşleme/Geri Tepme, İndirme & Yeniden Doldurma Pozları', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_MUSK_ATK',
                    soldiers: [
                        {
                            viewId: 'SEC_MUSK_ATK:mk1',
                            sectorId: 'SEC_MUSK_ATK',
                            side: 'player',
                            groupId: 'grp_musketeers',
                            soldierId: 'mk1',
                            unitClass: 'musketeer',
                            activeWeapon: 'matchlock_musket',
                            state: 'ready',
                            position: { x: -24, y: 0, z: -22 }
                        },
                        {
                            viewId: 'SEC_MUSK_ATK:arq1',
                            sectorId: 'SEC_MUSK_ATK',
                            side: 'enemy',
                            groupId: 'grp_arquebusiers',
                            soldierId: 'arq1',
                            unitClass: 'arquebusier',
                            activeWeapon: 'arquebus',
                            state: 'ready',
                            position: { x: 24, y: 0, z: -20 }
                        }
                    ]
                });

                const mkRec = reg.getSoldierVisualState('SEC_MUSK_ATK:mk1');
                const arqRec = reg.getSoldierVisualState('SEC_MUSK_ATK:arq1');
                assert(mkRec.templateKey === 'player:infantry_musketeer' && arqRec.templateKey === 'enemy:infantry_musketeer', 'Tüfekçi ve arkebüzcü modelleri korunmalı');

                // Part 31 = Right Hand, Part 39 = Brass Muzzle Band
                const restHandMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_MUSK_ATK:mk1', 31));
                const restMuzzleMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_MUSK_ATK:mk1', 39));
                const restHandMuzzleDist = Math.hypot(
                    restMuzzleMat[12] - restHandMat[12],
                    restMuzzleMat[13] - restHandMat[13],
                    restMuzzleMat[14] - restHandMat[14]
                );

                // Activate combat poses for both musketeer and enemy arquebusier
                reg.sync({
                    sectorId: 'SEC_MUSK_ATK',
                    soldiers: [
                        {
                            viewId: 'SEC_MUSK_ATK:mk1',
                            sectorId: 'SEC_MUSK_ATK',
                            side: 'player',
                            groupId: 'grp_musketeers',
                            soldierId: 'mk1',
                            unitClass: 'musketeer',
                            activeWeapon: 'matchlock_musket',
                            state: 'attack',
                            position: { x: -24, y: 0, z: -22 }
                        },
                        {
                            viewId: 'SEC_MUSK_ATK:arq1',
                            sectorId: 'SEC_MUSK_ATK',
                            side: 'enemy',
                            groupId: 'grp_arquebusiers',
                            soldierId: 'arq1',
                            unitClass: 'arquebusier',
                            activeWeapon: 'arquebus',
                            state: 'attack',
                            position: { x: 24, y: 0, z: -20 }
                        }
                    ]
                });

                for (let f = 0; f < 6; f++) reg.update(0.03);
                assert(mkRec.isCombatActing && arqRec.isCombatActing, 'Her iki tüfekçi/arkebüzcü savaş eylemi modunda olmalı');

                // 1) Aiming pose (u = 0.22): barrel raises toward shoulder/eye level
                mkRec.actionPhase = 0.22;
                const aimMuzzle = reg.evaluateSoldierPartMatrix('SEC_MUSK_ATK:mk1', 39);
                assert(
                    aimMuzzle[13] > restMuzzleMat[13] + 0.12,
                    `Nişan alma fazında namlu omuz hizasına yükselmeli (aimY=${aimMuzzle[13].toFixed(3)}, restY=${restMuzzleMat[13].toFixed(3)})`
                );

                // 2) Fire & Recoil kick (u = 0.36): weapon kicks backward (-Z) relative to aim pose
                mkRec.actionPhase = 0.36;
                const recoilMuzzle = reg.evaluateSoldierPartMatrix('SEC_MUSK_ATK:mk1', 39);
                assert(
                    recoilMuzzle[14] < aimMuzzle[14] - 0.12,
                    `Ateşleme/geri tepme fazında tüfek geri tepmeli (recoilZ=${recoilMuzzle[14].toFixed(3)}, aimZ=${aimMuzzle[14].toFixed(3)})`
                );

                // 3) Lowering & Reloading motion (u = 0.72): weapon lowers & tilts upright for reloading
                mkRec.actionPhase = 0.72;
                const reloadHand = reg.evaluateSoldierPartMatrix('SEC_MUSK_ATK:mk1', 31);
                const reloadMuzzle = reg.evaluateSoldierPartMatrix('SEC_MUSK_ATK:mk1', 39);
                assert(
                    reloadHand[13] < restHandMat[13] - 0.05 && reloadMuzzle[13] > aimMuzzle[13] + 0.10,
                    `Yeniden doldurma fazında silah indirilip dikey doldurma açısına getirilmeli (reloadHandY=${reloadHand[13].toFixed(3)}, reloadMuzzleY=${reloadMuzzle[13].toFixed(3)})`
                );

                // Verify weapon remains locked to hands across all phases
                const reloadHandMuzzleDist = Math.hypot(
                    reloadMuzzle[12] - reloadHand[12],
                    reloadMuzzle[13] - reloadHand[13],
                    reloadMuzzle[14] - reloadHand[14]
                );
                assert(Math.abs(reloadHandMuzzleDist - restHandMuzzleDist) < 1e-4, 'Nişan, ateş ve doldurma sırasında tüfek ellerden kopmamalı');

                // 4) Return to ready stance
                reg.sync({
                    sectorId: 'SEC_MUSK_ATK',
                    soldiers: [
                        {
                            viewId: 'SEC_MUSK_ATK:mk1',
                            sectorId: 'SEC_MUSK_ATK',
                            side: 'player',
                            groupId: 'grp_musketeers',
                            soldierId: 'mk1',
                            unitClass: 'musketeer',
                            activeWeapon: 'matchlock_musket',
                            state: 'ready',
                            position: { x: -24, y: 0, z: -22 }
                        },
                        {
                            viewId: 'SEC_MUSK_ATK:arq1',
                            sectorId: 'SEC_MUSK_ATK',
                            side: 'enemy',
                            groupId: 'grp_arquebusiers',
                            soldierId: 'arq1',
                            unitClass: 'arquebusier',
                            activeWeapon: 'arquebus',
                            state: 'ready',
                            position: { x: 24, y: 0, z: -20 }
                        }
                    ]
                });
                for (let f = 0; f < 40; f++) reg.update(0.04);
                assert(mkRec.actionBlend === 0 && arqRec.actionBlend === 0, 'Doldurma sonrası tüfekçi ve arkebüzcü hazır duruşuna dönmeli');

                reg.dispose();
            });

            runCase('33. Kılıç-Kalkanlı Piyade Kontrollü Kılıç Savuruşu & Bağımsız Kalkan Koruma Pozu (Sentetik Test Karakteri)', () => {
                // Separate synthetic test character (does NOT alter any real pikeman or musketeer)
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_SYNTH_SWORD',
                    soldiers: [{
                        viewId: 'SYNTHETIC_TEST:swordsman_1',
                        sectorId: 'SEC_SYNTH_SWORD',
                        side: 'player',
                        groupId: 'grp_synth_swordsmen',
                        soldierId: 'synth_sw_1',
                        unitClass: 'swordsman',
                        activeWeapon: 'broadsword',
                        state: 'ready',
                        position: { x: 0, y: 0, z: 0 }
                    }]
                });

                const rec = reg.getSoldierVisualState('SYNTHETIC_TEST:swordsman_1');
                assert(rec && rec.templateKey === 'player:infantry_swordsman', 'Sentetik test karakteri 41 parçalı kılıç-kalkanlı piyade şablonunu kullanmalı');

                // Part 30 = Convex Steel Buckler Shield (leftArmWeapon)
                // Part 35 = Right Hand, Part 40 = Broadsword Blade (rightArmWeapon)
                const restShieldMat = new Float32Array(reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 30));
                const restHandMat = new Float32Array(reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 35));
                const restBladeMat = new Float32Array(reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 40));
                const restHandBladeDist = Math.hypot(
                    restBladeMat[12] - restHandMat[12],
                    restBladeMat[13] - restHandMat[13],
                    restBladeMat[14] - restHandMat[14]
                );

                // Activate controlled sword slash + independent shield guard pose
                reg.setSoldierVisualCombatAction('SYNTHETIC_TEST:swordsman_1', true, 'attack', 0.18);
                for (let f = 0; f < 6; f++) reg.update(0.03);
                assert(rec.isCombatActing === true && rec.actionBlend > 0.9, 'Sentetik kılıçlı piyade savaş eylemi aktif olmalı');

                // Wind-up phase (u = 0.18): sword cocks high/upward while buckler shield raises inward across chest
                rec.actionPhase = 0.18;
                const windupShield = reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 30);
                const windupBlade = reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 40);

                // Shield moves inward toward chest centerline (x decreases from +0.39 toward 0) & raises in Y
                assert(
                    windupShield[12] < restShieldMat[12] - 0.08 && windupShield[13] > restShieldMat[13] + 0.05,
                    `Kalkan koruma pozunda göğüs önüne ve yukarı kalkmalı (shieldX=${windupShield[12].toFixed(3)}, restX=${restShieldMat[12].toFixed(3)})`
                );
                // Sword blade raises high in wind-up (y increases while z cocks back)
                assert(
                    windupBlade[13] > restBladeMat[13] + 0.25 && windupBlade[14] < restBladeMat[14] - 0.15,
                    `Kılıç hazırlanma fazında yukarı ve geriye kalkmalı (bladeY=${windupBlade[13].toFixed(3)}, bladeZ=${windupBlade[14].toFixed(3)})`
                );

                // Slash phase (u = 0.44): sword sweeps forward/downward while shield maintains independent guard
                rec.actionPhase = 0.44;
                const slashShield = reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 30);
                const slashHand = reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 35);
                const slashBlade = reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 40);

                assert(
                    slashBlade[13] < windupBlade[13] - 0.45 && slashBlade[14] > windupBlade[14] + 0.20,
                    `Kılıç savuruş fazında öne ve aşağı inmeli (slashBladeY=${slashBlade[13].toFixed(3)}, windupBladeY=${windupBlade[13].toFixed(3)})`
                );

                // Verify shield arm moves independently from sword arm (blade drops -0.45m in Y while shield stays raised near guard height)
                assert(
                    Math.abs(slashShield[13] - windupShield[13]) < 0.16,
                    'Kalkan kolu kılıç savuruşundan bağımsız koruma yüksekliğini korumalı'
                );

                // Verify broadsword stays welded to right hand
                const slashHandBladeDist = Math.hypot(
                    slashBlade[12] - slashHand[12],
                    slashBlade[13] - slashHand[13],
                    slashBlade[14] - slashHand[14]
                );
                assert(Math.abs(slashHandBladeDist - restHandBladeDist) < 1e-4, 'Kılıç savuruş sırasında sağ elden ayrılmamalı');

                // Dedicated guard stance verification
                reg.setSoldierVisualCombatAction('SYNTHETIC_TEST:swordsman_1', true, 'guard', 0);
                const guardShield = reg.evaluateSoldierPartMatrix('SYNTHETIC_TEST:swordsman_1', 30);
                assert(guardShield[12] < restShieldMat[12] - 0.10, 'Bağımsız kalkan koruma duruşu aktif olmalı');

                // Return to ready stance
                reg.setSoldierVisualCombatAction('SYNTHETIC_TEST:swordsman_1', false);
                for (let f = 0; f < 40; f++) reg.update(0.04);
                assert(rec.actionBlend === 0 && rec.actionPhase === 0, 'Kılıç-kalkanlı piyade eylem bitince hazır duruşuna dönmeli');

                reg.dispose();
            });

            runCase('34. Savaş Pozları Sırasında Model Kimliği, Sınıf, Silah, Konum & Kaynak Veri Değişmezliği', () => {
                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const sm = probe.sectorManager;
                const origSnap = projectActiveSector3D(sm);
                const combatPreview = probe._buildCombatPreviewSnapshot();
                const combatSnap = combatPreview.snapshot;

                assert(origSnap.soldiers.length === 300 && combatSnap.soldiers.length === 300, 'Savaş pozları snapshot 300 askeri korumalı');

                let combatPosingSoldiers = 0;
                for (let i = 0; i < origSnap.soldiers.length; i++) {
                    const orig = origSnap.soldiers[i];
                    const comb = combatSnap.soldiers[i];

                    assert(orig.viewId === comb.viewId, `viewId değişmemeli: ${orig.viewId}`);
                    assert(orig.sectorId === comb.sectorId, `sectorId değişmemeli: ${orig.viewId}`);
                    assert(orig.side === comb.side, `side değişmemeli: ${orig.viewId}`);
                    assert(orig.groupId === comb.groupId, `groupId değişmemeli: ${orig.viewId}`);
                    assert(orig.soldierId === comb.soldierId, `soldierId değişmemeli: ${orig.viewId}`);
                    assert(orig.unitClass === comb.unitClass, `unitClass değişmemeli: ${orig.viewId}`);
                    assert(orig.activeWeapon === comb.activeWeapon, `activeWeapon değişmemeli: ${orig.viewId}`);
                    assert(JSON.stringify(orig.weaponLoadout) === JSON.stringify(comb.weaponLoadout), `weaponLoadout değişmemeli: ${orig.viewId}`);
                    assert(JSON.stringify(orig.armorLoadout) === JSON.stringify(comb.armorLoadout), `armorLoadout değişmemeli: ${orig.viewId}`);
                    assert(orig.hp === comb.hp, `hp değişmemeli: ${orig.viewId}`);
                    assert(
                        orig.position.x === comb.position.x &&
                        orig.position.y === comb.position.y &&
                        orig.position.z === comb.position.z,
                        `Savaş pozları sırasında asker konumu değişmemeli: ${orig.viewId}`
                    );
                    assert(
                        orig.unitClass !== 'swordsman' && comb.unitClass !== 'swordsman',
                        `Gerçek mızraklı veya tüfekçiler kılıçlıya dönüştürülmemeli: ${orig.viewId}`
                    );

                    if (comb.state === 'attack') {
                        combatPosingSoldiers++;
                        assert(
                            orig.bodyType === 'human' && (orig.mountType === 'foot' || !orig.mountType),
                            `Yalnızca piyadeler piyade savaş pozuna girmeli: ${orig.viewId}`
                        );
                    }
                }

                assert(combatPosingSoldiers === 16, `16 piyade savaş pozuna girmeli, gelen: ${combatPosingSoldiers}`);

                // Verify underlying SectorManager soldiers still have state === 'ready' and original data
                const rawAll = sm.getActiveSector().getAllSoldiers();
                assert(rawAll.length === 330, 'Kaynak SectorManager 330 askeri korumalı');
                rawAll.forEach((s) => {
                    assert(s.state === 'ready', `Kaynak SectorManager asker durumu 'ready' kalmalı (${s.id}: ${s.state})`);
                });

                // Verify SoldierVisualRegistry keeps identical templateKeys
                const reg = new SoldierVisualRegistry();
                reg.sync(origSnap);
                const tplBefore = new Map();
                for (const [vid, rec] of reg.records.entries()) tplBefore.set(vid, rec.templateKey);

                reg.sync(combatSnap);
                for (let f = 0; f < 6; f++) reg.update(0.03);
                assert(reg.stats.combatPosingCount === 16, `16 piyade görsel savaş pozunda olmalı, gelen: ${reg.stats.combatPosingCount}`);

                for (const [vid, rec] of reg.records.entries()) {
                    assert(rec.templateKey === tplBefore.get(vid), `Görsel model şablonu değişmemeli (${vid})`);
                }

                reg.dispose();
            });

            runCase('35. Piyade Savaş Pozları Önizlemesi, Diğer Önizlemelerle Karşılıklı Dışlama & Kamera Koruması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 3.0;
                cam.desired.targetZ = -5.0;
                cam.desired.distance = 49;
                cam.desired.yaw = 0.15;
                cam.desired.pitch = 0.90;
                cam.syncTransform(1);

                const preState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance,
                    yaw: cam.current.yaw,
                    pitch: cam.current.pitch
                };

                // 1) Mutual exclusion across all 3 previews: Walk -> Cavalry -> Combat -> Walk
                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive && !probe.cavalryPreviewActive && !probe.combatPreviewActive, 'Yalnız yürüyüş önizlemesi açık olmalı');

                probe.toggleCavalryPreview();
                assert(!probe.walkPreviewActive && probe.cavalryPreviewActive && !probe.combatPreviewActive, 'Yalnız süvari önizlemesi açık olmalı');

                probe.toggleCombatPreview();
                assert(!probe.walkPreviewActive && !probe.cavalryPreviewActive && probe.combatPreviewActive, 'Yalnız piyade savaş pozları önizlemesi açık olmalı');
                cam.syncTransform(1);

                const combatFocusX = cam.current.targetX;
                const combatFocusZ = cam.current.targetZ;

                // Step combat pose animation frames and verify camera focus & user controls remain intact
                for (let f = 0; f < 10; f++) testRenderer.stepSimulation(0.04);
                cam.syncTransform(1);
                assert(
                    Math.abs(cam.current.targetX - combatFocusX) < 1e-4 &&
                    Math.abs(cam.current.targetZ - combatFocusZ) < 1e-4,
                    'Savaş pozları önizlemesinde kamera odağı korunmalı'
                );

                const beforeUserPan = cam.desired.targetX;
                cam.panRelative(0, 2.5);
                assert(cam.desired.targetX !== beforeUserPan, 'Savaş pozları önizlemesinde kullanıcı kamera kontrolü kilitlenmemeli');

                // 2) Turn off Combat Preview -> soldiers return to ready stance & user's original camera is restored
                probe.toggleCombatPreview();
                assert(!probe.combatPreviewActive, 'Savaş pozları önizlemesi kapatılabilmeli');
                for (let f = 0; f < 50; f++) testRenderer.stepSimulation(0.04);
                cam.syncTransform(1);

                assert(testRenderer.soldierRegistry.stats.combatPosingCount === 0, 'Önizleme kapandığında savaş pozunda asker kalmamalı');
                assert(
                    Math.abs(cam.current.targetX - preState.targetX) < 1e-4 &&
                    Math.abs(cam.current.targetZ - preState.targetZ) < 1e-4 &&
                    Math.abs(cam.current.distance - preState.distance) < 1e-4 &&
                    Math.abs(cam.current.yaw - preState.yaw) < 1e-4 &&
                    Math.abs(cam.current.pitch - preState.pitch) < 1e-4,
                    'Önizleme kapandığında başlangıçtaki kamera konumu ve açısı geri yüklenmeli'
                );

                testRenderer.dispose();
            });

            runCase('36. Savaş Pozlarında 7 Batch, GPU Buffer Yeniden Kullanımı, Sektör Geçişi & WebGL Kurtarma', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const snap = projectActiveSector3D(sm);

                const renderer = new Battle3DRenderer({
                    rendererFactory: (opts) => new FOC_THREE.WebGLRenderer({
                        gl: mockCtx.gl,
                        onContextLost: opts.onContextLost,
                        onContextRestored: opts.onContextRestored
                    })
                });
                renderer.init(mockMount, snap);
                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);

                const initialBufferCount = mockCtx.getBufferCount();
                assert(renderer.soldierRegistry.batchGroup.batches.length === 7, '7 instanced batch korunmalı');

                // Put first 24 infantry into combat poses and run 12 animation + render frames
                const combatSnap = {
                    ...snap,
                    soldiers: snap.soldiers.map((s, idx) => idx < 24 ? { ...s, state: 'attack' } : s)
                };
                renderer.sync(combatSnap, { preserveCamera: true });

                for (let f = 0; f < 12; f++) {
                    renderer.stepSimulation(0.03);
                    renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                }

                assert(mockCtx.getBufferCount() === initialBufferCount, 'Savaş pozları animasyonunda yeni GPU buffer oluşturulmamalı');
                assert(mockCtx.bufferSubDataCalls.length >= 12, 'Mevcut GPU buffer bufferSubData ile yerinde güncellenmeli');
                assert(renderer.soldierRegistry.batchGroup.batches.length === 7, 'Batch sayısı 7 kalmalı');

                // Sector switch clears active combat poses cleanly
                sm.setActiveSector(1);
                const s1Derived = renderer.sync(projectActiveSector3D(sm), { snapCamera: true });
                assert(s1Derived.soldierVisuals.activeCount === 62 && s1Derived.soldierVisuals.combatPosingCount === 0, 'Sektör geçişinde savaş pozları temizlenmeli');

                // Context loss & restore recovery
                renderer.simulateContextLoss();
                assert(renderer.isContextLost === true, 'Context kaybı yakalanmalı');
                assert(renderer.renderer._handleContextRestored() === true && renderer.isContextLost === false, 'Context geri yüklenebilmeli');

                renderer.dispose();
            });

            runCase('37. Tek Seferlik Saldırı Eylemi Döngüsü (Tek Saldırı Talebinde Animasyonun Bir Kez Oynayıp Hazır Duruşuna Dönmesi)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_ONESHOT_ATK',
                    soldiers: [
                        {
                            viewId: 'SEC_ONESHOT:pk1',
                            sectorId: 'SEC_ONESHOT_ATK',
                            side: 'player',
                            groupId: 'grp_pikemen',
                            soldierId: 'pk1',
                            unitClass: 'pikeman',
                            activeWeapon: 'pike',
                            state: 'ready',
                            position: { x: -10, y: 0, z: -5 }
                        },
                        {
                            viewId: 'SEC_ONESHOT:mk1',
                            sectorId: 'SEC_ONESHOT_ATK',
                            side: 'player',
                            groupId: 'grp_musketeers',
                            soldierId: 'mk1',
                            unitClass: 'musketeer',
                            activeWeapon: 'matchlock_musket',
                            state: 'ready',
                            position: { x: -15, y: 0, z: -5 }
                        },
                        {
                            viewId: 'SEC_ONESHOT:sw1',
                            sectorId: 'SEC_ONESHOT_ATK',
                            side: 'player',
                            groupId: 'grp_swordsmen',
                            soldierId: 'sw1',
                            unitClass: 'swordsman',
                            activeWeapon: 'broadsword',
                            state: 'ready',
                            position: { x: -20, y: 0, z: -5 }
                        }
                    ]
                });

                const pkRec = reg.getSoldierVisualState('SEC_ONESHOT:pk1');
                const mkRec = reg.getSoldierVisualState('SEC_ONESHOT:mk1');
                const swRec = reg.getSoldierVisualState('SEC_ONESHOT:sw1');

                assert(!pkRec.isCombatActing && pkRec.actionBlend === 0, 'Başlangıçta mızraklı hazır duruşunda olmalı');
                assert(!mkRec.isCombatActing && mkRec.actionBlend === 0, 'Başlangıçta tüfekçi hazır duruşunda olmalı');
                assert(!swRec.isCombatActing && swRec.actionBlend === 0, 'Başlangıçta kılıçlı hazır duruşunda olmalı');

                // 1) Tek bir saldırı isteği tetikle (Musketeer & Swordsman: snapshot state: 'attack', Pikeman: setSoldierVisualCombatAction)
                reg.sync({
                    sectorId: 'SEC_ONESHOT_ATK',
                    soldiers: [
                        {
                            viewId: 'SEC_ONESHOT:pk1',
                            sectorId: 'SEC_ONESHOT_ATK',
                            side: 'player',
                            groupId: 'grp_pikemen',
                            soldierId: 'pk1',
                            unitClass: 'pikeman',
                            activeWeapon: 'pike',
                            state: 'ready',
                            position: { x: -10, y: 0, z: -5 }
                        },
                        {
                            viewId: 'SEC_ONESHOT:mk1',
                            sectorId: 'SEC_ONESHOT_ATK',
                            side: 'player',
                            groupId: 'grp_musketeers',
                            soldierId: 'mk1',
                            unitClass: 'musketeer',
                            activeWeapon: 'matchlock_musket',
                            state: 'attack',
                            position: { x: -15, y: 0, z: -5 }
                        },
                        {
                            viewId: 'SEC_ONESHOT:sw1',
                            sectorId: 'SEC_ONESHOT_ATK',
                            side: 'player',
                            groupId: 'grp_swordsmen',
                            soldierId: 'sw1',
                            unitClass: 'swordsman',
                            activeWeapon: 'broadsword',
                            state: 'attack',
                            position: { x: -20, y: 0, z: -5 }
                        }
                    ]
                });
                reg.setSoldierVisualCombatAction('SEC_ONESHOT:pk1', true, 'attack', 0);

                // İlk birkaç frame: Saldırı aktifleşmeli ve blend yükselmeli
                for (let f = 0; f < 8; f++) reg.update(0.03);
                assert(pkRec.isCombatActing && pkRec.actionBlend > 0.8, 'Mızraklı saldırı eylemi başlamalı');
                assert(mkRec.isCombatActing && mkRec.actionBlend > 0.8, 'Tüfekçi saldırı eylemi başlamalı');
                assert(swRec.isCombatActing && swRec.actionBlend > 0.8, 'Kılıçlı saldırı eylemi başlamalı');
                assert(pkRec.actionPhase > 0 && pkRec.actionPhase < 1.0, 'Saldırı fazı ilerlemeli');

                // 2) Saldırı döngüsü boyunca simülasyonu ilerlet (Kılıçlı: ~1.55s, Mızraklı: ~1.85s, Tüfekçi: ~2.6s)
                // Kılıçlı için ~1.55s sonra (toplam ~55 frame * 0.03s = 1.65s) saldırı bitmiş olmalı
                for (let f = 0; f < 50; f++) reg.update(0.03);
                assert(swRec.isCombatActing === false, 'Kılıçlı tek saldırı tamamlandığında saldırı eylemi sonlanmalı (sonsuz döngüye girmemeli)');

                // Mızraklı için ~1.85s sonra saldırı bitmiş olmalı
                for (let f = 0; f < 20; f++) reg.update(0.03);
                assert(pkRec.isCombatActing === false, 'Mızraklı tek saldırı tamamlandığında saldırı eylemi sonlanmalı (sonsuz döngüye girmemeli)');

                // Tüfekçi için ~2.6s sonra saldırı bitmiş olmalı
                for (let f = 0; f < 30; f++) reg.update(0.03);
                assert(mkRec.isCombatActing === false, 'Tüfekçi tek saldırı tamamlandığında saldırı eylemi sonlanmalı (sonsuz döngüye girmemeli)');

                // 3) Geri dönüş sönümlemesi (blend-out) sonrasında tüm askerler hazır duruşuna dönmeli
                for (let f = 0; f < 40; f++) reg.update(0.04);
                assert(pkRec.actionBlend === 0 && pkRec.actionPhase === 0, 'Mızraklı hazır duruşuna (blend=0, phase=0) dönmeli');
                assert(mkRec.actionBlend === 0 && mkRec.actionPhase === 0, 'Tüfekçi hazır duruşuna (blend=0, phase=0) dönmeli');
                assert(swRec.actionBlend === 0 && swRec.actionPhase === 0, 'Kılıçlı hazır duruşuna (blend=0, phase=0) dönmeli');
                assert(reg.stats.combatPosingCount === 0, 'Saldırılar bittikten sonra savaş pozunda asker kalmamalı');

                // 4) Ekstra framelerde kendi kendine tekrar başlamamalı (sonsuz döngü engeli)
                for (let f = 0; f < 30; f++) reg.update(0.04);
                assert(pkRec.isCombatActing === false && pkRec.actionBlend === 0, 'Mızraklı tek saldırı sonrası hazır duruşunda kalmalı');
                assert(mkRec.isCombatActing === false && mkRec.actionBlend === 0, 'Tüfekçi tek saldırı sonrası hazır duruşunda kalmalı');
                assert(swRec.isCombatActing === false && swRec.actionBlend === 0, 'Kılıçlı tek saldırı sonrası hazır duruşunda kalmalı');
                assert(reg.stats.combatPosingCount === 0, 'Kendi kendine yeniden saldırı başlamamalı');

                // 5) Savunma (guard) modu ise tek seferlik değil, kapatılana kadar aktif kalmalı
                reg.setSoldierVisualCombatAction('SEC_ONESHOT:sw1', true, 'guard', 0);
                for (let f = 0; f < 80; f++) reg.update(0.04); // 3.2 saniye sürer (> 1.55s)
                assert(swRec.isCombatActing === true && swRec.actionMode === 'guard', 'Savunma (guard) modu kapatılana kadar aktif kalmalı');
                reg.setSoldierVisualCombatAction('SEC_ONESHOT:sw1', false);
                for (let f = 0; f < 30; f++) reg.update(0.04);
                assert(swRec.isCombatActing === false && swRec.actionBlend === 0, 'Savunma modu kapatılınca hazır duruşuna dönmeli');

                reg.dispose();
            });

            
            // --- G3D-03D ENTEGRE EDİLMİŞ 6 YENİ BİRİM TESTİ (38 - 43) ---
            runCase('38. Atlı Mızrak Savaş Eylemi (Hazırlanma, İleri Hamle, Toparlanma, Hazır Duruşuna Dönüş & At-Eyer-Üzengi-Mızrak Bütünlüğü)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_LANCE_ATK',
                    soldiers: [{
                        viewId: 'SEC_LANCE_ATK:l1',
                        sectorId: 'SEC_LANCE_ATK',
                        side: 'enemy',
                        groupId: 'grp_lancers',
                        soldierId: 'l1',
                        unitClass: 'demi_lancer',
                        bodyType: 'mounted',
                        mountType: 'destrier',
                        activeWeapon: 'war_lance',
                        armorLoadout: ['close_helm', 'half_plate'],
                        state: 'ready',
                        position: { x: 20, y: 0, z: 10 }
                    }]
                });

                const rec = reg.getSoldierVisualState('SEC_LANCE_ATK:l1');
                assert(rec.archetype === 'cavalry_lance', 'Süvari sınıflandırması cavalry_lance olmalı');

                const tplLen = reg.templates[rec.templateKey].length;
                // Part 49 = Stirrup, Part 59 = Boot, tplLen - 6 = Right Hand, tplLen - 3 = Lance Tip
                const restStirrup = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 49));
                const restBoot = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 59));
                const restHandMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 6));
                const restTipMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 3));

                const restFootStirrupDist = Math.hypot(
                    restBoot[12] - restStirrup[12],
                    restBoot[13] - restStirrup[13],
                    restBoot[14] - restStirrup[14]
                );
                const restHandToTipDist = Math.hypot(
                    restTipMat[12] - restHandMat[12],
                    restTipMat[13] - restHandMat[13],
                    restTipMat[14] - restHandMat[14]
                );
                assert(restHandToTipDist > 2.0, 'Mızrak boyu 2.0m üzerinde olmalı');

                // 1) Trigger visual combat action ('attack') via snapshot without mutating position, weapon, armor or mount
                reg.sync({
                    sectorId: 'SEC_LANCE_ATK',
                    soldiers: [{
                        viewId: 'SEC_LANCE_ATK:l1',
                        sectorId: 'SEC_LANCE_ATK',
                        side: 'enemy',
                        groupId: 'grp_lancers',
                        soldierId: 'l1',
                        unitClass: 'demi_lancer',
                        bodyType: 'mounted',
                        mountType: 'destrier',
                        activeWeapon: 'war_lance',
                        armorLoadout: ['close_helm', 'half_plate'],
                        state: 'attack',
                        position: { x: 20, y: 0, z: 10 }
                    }]
                });

                // Blend in to full actionBlend
                for (let f = 0; f < 6; f++) reg.update(0.03);
                assert(rec.isCombatActing === true && rec.actionBlend > 0.9, 'Atlı mızrak savaş eylemi aktifleşmeli');

                // 2) Phase 1: Preparation / Couching (Hazırlanma) [u = 0.14 -> lance retracts slightly backward]
                rec.actionPhase = 0.14;
                const windupHandMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 6);
                const windupTipMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 3);
                const windupStirrup = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 49);
                const windupBoot = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 59);

                assert(
                    windupTipMat[14] < restTipMat[14] - 0.08,
                    `Hazırlanma fazında mızrak geri çekilip kurulmalı (windupZ=${windupTipMat[14].toFixed(3)}, restZ=${restTipMat[14].toFixed(3)})`
                );
                const windupHandToTipDist = Math.hypot(
                    windupTipMat[12] - windupHandMat[12],
                    windupTipMat[13] - windupHandMat[13],
                    windupTipMat[14] - windupHandMat[14]
                );
                const windupFootStirrupDist = Math.hypot(
                    windupBoot[12] - windupStirrup[12],
                    windupBoot[13] - windupStirrup[13],
                    windupBoot[14] - windupStirrup[14]
                );
                assert(Math.abs(windupHandToTipDist - restHandToTipDist) < 1e-4, 'Hazırlanma fazında mızrak sağ elden kopmamalı');
                assert(Math.abs(windupFootStirrupDist - restFootStirrupDist) < 1e-4, 'Hazırlanma fazında binici ayağı üzengiden ayrılmamalı');

                // 3) Phase 2 & 3: Forward Lance Thrust & Hold (İleri Hamle) [u = 0.56 -> lance drives strongly forward in +Z]
                rec.actionPhase = 0.56;
                const thrustHandMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 6);
                const thrustTipMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 3);
                const thrustStirrup = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 49);
                const thrustBoot = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 59);

                assert(
                    thrustTipMat[14] > restTipMat[14] + 0.50,
                    `İleri hamle fazında mızrak ucu güçlü biçimde ileri uzanmalı (thrustZ=${thrustTipMat[14].toFixed(3)}, restZ=${restTipMat[14].toFixed(3)})`
                );
                const thrustHandToTipDist = Math.hypot(
                    thrustTipMat[12] - thrustHandMat[12],
                    thrustTipMat[13] - thrustHandMat[13],
                    thrustTipMat[14] - thrustHandMat[14]
                );
                const thrustFootStirrupDist = Math.hypot(
                    thrustBoot[12] - thrustStirrup[12],
                    thrustBoot[13] - thrustStirrup[13],
                    thrustBoot[14] - thrustStirrup[14]
                );
                assert(Math.abs(thrustHandToTipDist - restHandToTipDist) < 1e-4, 'Hamle sırasında mızrak elden kopmamalı ve boyu sabit kalmalı');
                assert(Math.abs(thrustFootStirrupDist - restFootStirrupDist) < 1e-4, 'Hamle sırasında binici ayağı üzengide sabit kalmalı');

                // 4) Gait (yürüyüş/tırıs) ile eylem çakışmama doğrulaması
                rec.walkBlend = 0.85;
                rec.trotBlend = 0.80;
                rec.walkPhase = Math.PI * 0.35;
                const gaitThrustHandMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 6);
                const gaitThrustTipMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 3);
                const gaitThrustStirrup = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 49);
                const gaitThrustBoot = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', 59);
                const gaitHandToTipDist = Math.hypot(
                    gaitThrustTipMat[12] - gaitThrustHandMat[12],
                    gaitThrustTipMat[13] - gaitThrustHandMat[13],
                    gaitThrustTipMat[14] - gaitThrustHandMat[14]
                );
                const gaitFootStirrupDist = Math.hypot(
                    gaitThrustBoot[12] - gaitThrustStirrup[12],
                    gaitThrustBoot[13] - gaitThrustStirrup[13],
                    gaitThrustBoot[14] - gaitThrustStirrup[14]
                );
                assert(Math.abs(gaitHandToTipDist - restHandToTipDist) < 1e-4, 'Tırıs hareketi sırasında mızrak-el bağlantısı ve mızrak boyu korunmalı');
                assert(Math.abs(gaitFootStirrupDist - restFootStirrupDist) < 1e-4, 'Tırıs hareketi sırasında ayak üzengiden kopmamalı');
                assert(gaitThrustTipMat[14] > gaitThrustHandMat[14] + 1.8, 'Tırısta mızrak öne doğru uzanışını korumalı');

                // 5) Tek niyet tek hareket & Hazır Duruşuna (Idle) Dönüş Doğrulaması
                reg.sync({
                    sectorId: 'SEC_LANCE_ATK',
                    soldiers: [{
                        viewId: 'SEC_LANCE_ATK:l1',
                        sectorId: 'SEC_LANCE_ATK',
                        side: 'enemy',
                        groupId: 'grp_lancers',
                        soldierId: 'l1',
                        unitClass: 'demi_lancer',
                        bodyType: 'mounted',
                        mountType: 'destrier',
                        activeWeapon: 'war_lance',
                        armorLoadout: ['close_helm', 'half_plate'],
                        state: 'ready',
                        position: { x: 20, y: 0, z: 10 }
                    }]
                });

                // Blend out over ~1.85s cycle + blendout frames
                for (let f = 0; f < 50; f++) reg.update(0.04);
                assert(rec.isCombatActing === false && rec.actionBlend === 0 && rec.actionPhase === 0, 'Eylem tamamlandığında hazır duruşuna dönmeli');

                const recoveredTipMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 3);
                const recoveredHandMat = reg.evaluateSoldierPartMatrix('SEC_LANCE_ATK:l1', tplLen - 6);
                for (let k = 0; k < 16; k++) {
                    assert(Math.abs(recoveredTipMat[k] - restTipMat[k]) < 1e-5, `Hazır duruşuna dönüşte mızrak ucu matrisi[${k}] ilk duruşuna eşit olmalı`);
                    assert(Math.abs(recoveredHandMat[k] - restHandMat[k]) < 1e-5, `Hazır duruşuna dönüşte mızrak el matrisi[${k}] ilk duruşuna eşit olmalı`);
                }
                assert(reg.stats.combatPosingCount === 0, 'Hazır duruşuna dönüş sonrasında aktif savaş pozunda asker kalmamalı');

                reg.dispose();
            });

            runCase('39. Atlı Kılıç Savuruşu (Kılıç Kaldırma, Çapraz Savuruş, Duruşa Dönüş, Binici-At Bütünlüğü & Hareketli At Çakışmasızlığı)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_CAV_SWORD',
                    soldiers: [{
                        viewId: 'SEC_CAV_SWORD:cs1',
                        sectorId: 'SEC_CAV_SWORD',
                        side: 'player',
                        groupId: 'grp_cuirassiers',
                        soldierId: 'cs1',
                        unitClass: 'cuirassier',
                        bodyType: 'mounted',
                        mountType: 'warhorse',
                        activeWeapon: 'cavalry_sabre',
                        armorLoadout: ['three_quarter_plate'],
                        state: 'ready',
                        position: { x: -25, y: 0, z: 0 }
                    }]
                });

                const rec = reg.getSoldierVisualState('SEC_CAV_SWORD:cs1');
                assert(rec !== null, 'Atlı kılıçlı süvari kaydı mevcut olmalı');
                assert(rec.archetype === 'cavalry_sabre', 'Süvari sınıfı cavalry_sabre olmalı');

                const parts = reg.templates[rec.templateKey];
                const totalParts = parts.length;
                const handIdx = totalParts - 6; // Right hand (leather glove)
                const bladeIdx = totalParts - 1; // Sabre blade (steel frustum)
                const horseNeckIdx = 26; // Horse neck/head
                const breechesIdx = 56; // Rider breeches (seated contact with saddle)

                // 1. Initial ready stance verification
                const restHandMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', handIdx));
                const restBladeMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', bladeIdx));
                const restNeckMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', horseNeckIdx));
                const restBreechesMat = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', breechesIdx));

                const restHandBladeDist = Math.hypot(
                    restBladeMat[12] - restHandMat[12],
                    restBladeMat[13] - restHandMat[13],
                    restBladeMat[14] - restHandMat[14]
                );
                assert(Math.abs(restHandBladeDist - 0.60) < 1e-4, 'Başlangıçta kılıç namlusu el hizasında (0.60m) olmalı');
                assert(!rec.isCombatActing && rec.actionBlend === 0, 'Başlangıçta süvari hazır duruşunda olmalı');

                // 2. Trigger combat attack action via snapshot state
                reg.sync({
                    sectorId: 'SEC_CAV_SWORD',
                    soldiers: [{
                        viewId: 'SEC_CAV_SWORD:cs1',
                        sectorId: 'SEC_CAV_SWORD',
                        side: 'player',
                        groupId: 'grp_cuirassiers',
                        soldierId: 'cs1',
                        unitClass: 'cuirassier',
                        bodyType: 'mounted',
                        mountType: 'warhorse',
                        activeWeapon: 'cavalry_sabre',
                        armorLoadout: ['three_quarter_plate'],
                        state: 'attack',
                        position: { x: -25, y: 0, z: 0 }
                    }]
                });

                // Blend up to full attack action
                for (let f = 0; f < 8; f++) reg.update(0.03);
                assert(rec.isCombatActing === true && rec.actionBlend > 0.85, 'Atlı kılıç savuruşu eylemi aktifleşmeli');

                // 3. Wind-up phase (Kılıç Kaldırma, u = 0.20)
                rec.actionPhase = 0.20;
                const windupHandMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', handIdx);
                const windupBladeMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', bladeIdx);
                const windupBreechesMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', breechesIdx);

                // Blade raises high in Y and cocks back in -Z
                assert(
                    windupBladeMat[13] > restBladeMat[13] + 0.35,
                    `Kılıç kaldırma fazında namlu yukarı kalkmalı (windupY=${windupBladeMat[13].toFixed(3)}, restY=${restBladeMat[13].toFixed(3)})`
                );
                assert(
                    windupBladeMat[14] < restBladeMat[14] - 0.20,
                    `Kılıç kaldırma fazında namlu geriye kurulmalı (windupZ=${windupBladeMat[14].toFixed(3)}, restZ=${restBladeMat[14].toFixed(3)})`
                );
                // Rider stays firmly in saddle
                assert(
                    Math.abs(windupBreechesMat[13] - restBreechesMat[13]) < 0.05,
                    'Kılıç kaldırma sırasında binici eyerden fırlamamalı, at üstünde kalmalı'
                );
                // Sabre stays welded to hand
                const windupHandBladeDist = Math.hypot(
                    windupBladeMat[12] - windupHandMat[12],
                    windupBladeMat[13] - windupHandMat[13],
                    windupBladeMat[14] - windupHandMat[14]
                );
                assert(Math.abs(windupHandBladeDist - restHandBladeDist) < 1e-4, 'Kılıç kaldırma sırasında kılıç elden ayrılmamalı');

                // 4. Controlled diagonal slash phase (Kontrollü Çapraz Savuruş, u = 0.60)
                rec.actionPhase = 0.60;
                const slashHandMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', handIdx);
                const slashBladeMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', bladeIdx);
                const slashBreechesMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', breechesIdx);

                // Blade sweeps downward in Y and forward in +Z
                assert(
                    slashBladeMat[13] < windupBladeMat[13] - 0.60,
                    `Çapraz savuruşta kılıç aşağı inmeli (slashY=${slashBladeMat[13].toFixed(3)}, windupY=${windupBladeMat[13].toFixed(3)})`
                );
                assert(
                    slashBladeMat[14] > windupBladeMat[14] + 0.35,
                    `Çapraz savuruşta kılıç öne uzanmalı (slashZ=${slashBladeMat[14].toFixed(3)}, windupZ=${windupBladeMat[14].toFixed(3)})`
                );
                // Blade remains on rider's right flank (clear of horse centerline)
                assert(
                    slashBladeMat[12] < -0.25,
                    `Kılıç savuruşu atın sağ böğrü hizasında kalmalı, orta hatta girmemeli (slashX=${slashBladeMat[12].toFixed(3)})`
                );
                // Sabre remains welded to hand
                const slashHandBladeDist = Math.hypot(
                    slashBladeMat[12] - slashHandMat[12],
                    slashBladeMat[13] - slashHandMat[13],
                    slashBladeMat[14] - slashHandMat[14]
                );
                assert(Math.abs(slashHandBladeDist - restHandBladeDist) < 1e-4, 'Çapraz savuruş sırasında kılıç elden ayrılmamalı');
                // Rider remains firmly in saddle
                assert(
                    Math.abs(slashBreechesMat[13] - restBreechesMat[13]) < 0.05,
                    'Çapraz savuruş sırasında binici eyerde oturmaya devam etmeli'
                );

                // 5. Visual collision / clearance check on a MOVING horse (walk & trot)
                rec.isMoving = true;
                rec.walkBlend = 1.0;
                rec.trotBlend = 1.0;
                rec.walkPhase = Math.PI * 0.35;
                const movingNeckMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', horseNeckIdx);
                const movingBladeMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', bladeIdx);
                const movingBreechesMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', breechesIdx);

                // Lateral clearance between blade and horse neck (> 20cm)
                const lateralClearance = Math.abs(movingBladeMat[12] - movingNeckMat[12]);
                assert(
                    lateralClearance > 0.20,
                    `Hareketli atta kılıç ile at boynu arasında güvenli mesafe korunmalı (lateralClearance=${lateralClearance.toFixed(3)}m > 0.20m)`
                );
                // Rider stays in saddle during moving attack
                assert(
                    Math.abs(movingBreechesMat[13] - restBreechesMat[13]) < 0.12,
                    'Tırıs giden hareketli atta binici eyer-üzengi hattını korumalı'
                );

                // 6. Attack action completes and returns smoothly to ready stance (one-shot cycle)
                rec.isMoving = false;
                rec.walkBlend = 0;
                rec.trotBlend = 0;
                // Run remaining attack duration (~1.50s total cycle)
                for (let f = 0; f < 55; f++) reg.update(0.03);
                assert(rec.isCombatActing === false, 'Tek seferlik atlı kılıç saldırısı tamamlanınca eylem sonlanmalı');

                // Blend-out back to ready stance
                for (let f = 0; f < 35; f++) reg.update(0.04);
                assert(rec.actionBlend === 0 && rec.actionPhase === 0, 'Saldırı sonrası süvari hazır duruşuna (blend=0, phase=0) dönmeli');

                const finalBladeMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', bladeIdx);
                assert(
                    Math.abs(finalBladeMat[13] - restBladeMat[13]) < 1e-3,
                    'Kılıç hazır duruşuna geri dönmeli'
                );

                // 7. Dedicated defensive guard pose test
                reg.setSoldierVisualCombatAction('SEC_CAV_SWORD:cs1', true, 'guard', 0);
                for (let f = 0; f < 6; f++) reg.update(0.03);
                assert(rec.isCombatActing === true && rec.actionMode === 'guard', 'Süvari kılıç koruma/siper duruşu aktifleşmeli');
                const guardBladeMat = reg.evaluateSoldierPartMatrix('SEC_CAV_SWORD:cs1', bladeIdx);
                assert(
                    guardBladeMat[13] > restBladeMat[13] + 0.10,
                    'Koruma duruşunda kılıç siper pozisyonuna kalkmalı'
                );

                reg.setSoldierVisualCombatAction('SEC_CAV_SWORD:cs1', false);
                for (let f = 0; f < 30; f++) reg.update(0.04);
                assert(rec.actionBlend === 0, 'Koruma modu kapatılınca hazır duruşuna dönmeli');

                reg.dispose();
            });

            runCase('40. Süvari Karabina ve Tabanca Görsel Nişan Alma, Hafif Geri Tepme ve Toparlanma Pozları (Tek Niyet)', () => {
                const reg = new SoldierVisualRegistry();

                // 1) Karabinalı ve tabancalı süvarileri hazır durumunda sahneye ekle
                reg.sync({
                    sectorId: 'SEC_CAV_FIREARM',
                    soldiers: [
                        {
                            viewId: 'SEC_CAV_GUN:carbine_1',
                            sectorId: 'SEC_CAV_FIREARM',
                            side: 'player',
                            groupId: 'grp_p_dragoons',
                            soldierId: 'drag_1',
                            unitClass: 'harquebusier',
                            mountType: 'courser',
                            activeWeapon: 'carbine',
                            weaponLoadout: ['carbine', 'cavalry_sabre'],
                            armorLoadout: ['burgonet', 'leather_jerkin'],
                            state: 'ready',
                            position: { x: -14, y: 0, z: -10 }
                        },
                        {
                            viewId: 'SEC_CAV_GUN:pistol_1',
                            sectorId: 'SEC_CAV_FIREARM',
                            side: 'enemy',
                            groupId: 'grp_e_reiters',
                            soldierId: 'reit_1',
                            unitClass: 'reiter',
                            mountType: 'charger',
                            activeWeapon: 'wheellock_pistol',
                            weaponLoadout: ['wheellock_pistol', 'reitschwert'],
                            armorLoadout: ['blackened_cuirass'],
                            state: 'ready',
                            position: { x: 14, y: 0, z: -10 }
                        }
                    ]
                });

                const cRec = reg.getSoldierVisualState('SEC_CAV_GUN:carbine_1');
                const pRec = reg.getSoldierVisualState('SEC_CAV_GUN:pistol_1');
                assert(cRec && pRec, 'Her iki süvari görsel kaydı oluşturulmalı');
                assert(cRec.archetype === 'cavalry_carbine', 'Karabinalı süvari cavalry_carbine olarak sınıflandırılmalı');
                assert(pRec.archetype === 'cavalry_pistol', 'Tabancalı süvari cavalry_pistol olarak sınıflandırılmalı');

                const cTpl = reg.templates[cRec.templateKey];
                const pTpl = reg.templates[pRec.templateKey];
                assert(Array.isArray(cTpl) && cTpl.length >= 85, 'Karabinalı süvari şablonu tam parça sayısını korumalı');
                assert(Array.isArray(pTpl) && pTpl.length >= 85, 'Tabancalı süvari şablonu tam parça sayısını korumalı');

                // Karabina: tplLen - 9: Sağ Tetik Eli, tplLen - 6: Sol Kundak Eli, tplLen - 2: Altın Namlu Ağzı Bileziği
                const cTplLen = cTpl.length;
                const cHandIdx = cTplLen - 9;
                const cLeftHandIdx = cTplLen - 6;
                const cMuzzleIdx = cTplLen - 2;

                // Tabanca: tplLen - 5: Sağ Atış Eli, tplLen - 2: Çelik Namlu, tplLen - 1: Wheellock Mekanizması
                const pTplLen = pTpl.length;
                const pHandIdx = pTplLen - 5;
                const pBarrelIdx = pTplLen - 2;

                const restCHand = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cHandIdx));
                const restCLeftHand = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cLeftHandIdx));
                const restCMuzzle = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cMuzzleIdx));
                const restCHandMuzzleDist = Math.hypot(
                    restCMuzzle[12] - restCHand[12],
                    restCMuzzle[13] - restCHand[13],
                    restCMuzzle[14] - restCHand[14]
                );
                const restCHandsSpan = Math.hypot(
                    restCLeftHand[12] - restCHand[12],
                    restCLeftHand[13] - restCHand[13],
                    restCLeftHand[14] - restCHand[14]
                );

                const restPHand = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:pistol_1', pHandIdx));
                const restPBarrel = new Float32Array(reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:pistol_1', pBarrelIdx));
                const restPHandBarrelDist = Math.hypot(
                    restPBarrel[12] - restPHand[12],
                    restPBarrel[13] - restPHand[13],
                    restPBarrel[14] - restPHand[14]
                );

                assert(!cRec.isCombatActing && cRec.actionBlend === 0, 'Karabinalı süvari başlangıçta hazır duruşunda olmalı');
                assert(!pRec.isCombatActing && pRec.actionBlend === 0, 'Tabancalı süvari başlangıçta hazır duruşunda olmalı');

                // 2) Tek görsel saldırı niyeti tetikle (Karabina: snapshot attack state, Tabanca: setSoldierVisualCombatAction)
                reg.sync({
                    sectorId: 'SEC_CAV_FIREARM',
                    soldiers: [
                        {
                            viewId: 'SEC_CAV_GUN:carbine_1',
                            sectorId: 'SEC_CAV_FIREARM',
                            side: 'player',
                            groupId: 'grp_p_dragoons',
                            soldierId: 'drag_1',
                            unitClass: 'harquebusier',
                            mountType: 'courser',
                            activeWeapon: 'carbine',
                            weaponLoadout: ['carbine', 'cavalry_sabre'],
                            armorLoadout: ['burgonet', 'leather_jerkin'],
                            state: 'attack',
                            position: { x: -14, y: 0, z: -10 }
                        },
                        {
                            viewId: 'SEC_CAV_GUN:pistol_1',
                            sectorId: 'SEC_CAV_FIREARM',
                            side: 'enemy',
                            groupId: 'grp_e_reiters',
                            soldierId: 'reit_1',
                            unitClass: 'reiter',
                            mountType: 'charger',
                            activeWeapon: 'wheellock_pistol',
                            weaponLoadout: ['wheellock_pistol', 'reitschwert'],
                            armorLoadout: ['blackened_cuirass'],
                            state: 'ready',
                            position: { x: 14, y: 0, z: -10 }
                        }
                    ]
                });
                reg.setSoldierVisualCombatAction('SEC_CAV_GUN:pistol_1', true, 'attack', 0);

                for (let f = 0; f < 6; f++) reg.update(0.03);
                assert(cRec.isCombatActing && cRec.actionBlend > 0.8, 'Karabinalı süvari görsel saldırı eylemine başlamalı');
                assert(pRec.isCombatActing && pRec.actionBlend > 0.8, 'Tabancalı süvari görsel saldırı eylemine başlamalı');

                // 3) Faz 1: Nişan Alma Pozu (u = 0.24) - Silahlar göğüs/omuz doğrultusunda hedefe yükselmeli
                cRec.actionPhase = 0.24;
                pRec.actionPhase = 0.24;
                const aimCMuzzle = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cMuzzleIdx);
                const aimCHand = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cHandIdx);
                const aimCLeftHand = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cLeftHandIdx);

                const aimPBarrel = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:pistol_1', pBarrelIdx);
                const aimPHand = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:pistol_1', pHandIdx);

                assert(
                    aimCMuzzle[13] > restCMuzzle[13] + 0.06,
                    `Karabina nişan alma fazında namlu yükselmeli (aimMuzzleY=${aimCMuzzle[13].toFixed(3)}, restMuzzleY=${restCMuzzle[13].toFixed(3)})`
                );
                assert(
                    aimPBarrel[13] > restPBarrel[13] + 0.04,
                    `Tabanca nişan alma fazında namlu hedefe yükselmeli (aimBarrelY=${aimPBarrel[13].toFixed(3)}, restBarrelY=${restPBarrel[13].toFixed(3)})`
                );

                // Elde silah teması korunumu doğrulaması (Nişan alma fazı)
                const aimCHandMuzzleDist = Math.hypot(
                    aimCMuzzle[12] - aimCHand[12],
                    aimCMuzzle[13] - aimCHand[13],
                    aimCMuzzle[14] - aimCHand[14]
                );
                const aimCHandsSpan = Math.hypot(
                    aimCLeftHand[12] - aimCHand[12],
                    aimCLeftHand[13] - aimCHand[13],
                    aimCLeftHand[14] - aimCHand[14]
                );
                const aimPHandBarrelDist = Math.hypot(
                    aimPBarrel[12] - aimPHand[12],
                    aimPBarrel[13] - aimPHand[13],
                    aimPBarrel[14] - aimPHand[14]
                );
                assert(Math.abs(aimCHandMuzzleDist - restCHandMuzzleDist) < 1e-4, 'Karabina nişan alma sırasında elden kopmamalı');
                assert(Math.abs(aimCHandsSpan - restCHandsSpan) < 1e-4, 'Karabinayı tutan iki el arası mesafe nişanda korunmalı');
                assert(Math.abs(aimPHandBarrelDist - restPHandBarrelDist) < 1e-4, 'Tabanca nişan alma sırasında elden kopmamalı');

                // 4) Faz 2: Hafif Geri Tepme Pozu (u = 0.40) - Namlu hafif yukarı kalkmalı ve silah -Z yönünde tepmeli
                cRec.actionPhase = 0.40;
                pRec.actionPhase = 0.40;
                const recoilCMuzzle = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cMuzzleIdx);
                const recoilCHand = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cHandIdx);
                const recoilPBarrel = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:pistol_1', pBarrelIdx);
                const recoilPHand = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:pistol_1', pHandIdx);

                assert(
                    recoilCMuzzle[14] < aimCMuzzle[14] - 0.06,
                    `Karabina hafif geri tepme fazında -Z yönünde tepmeli (recoilZ=${recoilCMuzzle[14].toFixed(3)}, aimZ=${aimCMuzzle[14].toFixed(3)})`
                );
                assert(
                    recoilPBarrel[14] < aimPBarrel[14] - 0.05,
                    `Tabanca hafif geri tepme fazında -Z yönünde tepmeli (recoilZ=${recoilPBarrel[14].toFixed(3)}, aimZ=${aimPBarrel[14].toFixed(3)})`
                );

                // Elde silah teması korunumu doğrulaması (Geri tepme fazı)
                const recoilCHandMuzzleDist = Math.hypot(
                    recoilCMuzzle[12] - recoilCHand[12],
                    recoilCMuzzle[13] - recoilCHand[13],
                    recoilCMuzzle[14] - recoilCHand[14]
                );
                const recoilPHandBarrelDist = Math.hypot(
                    recoilPBarrel[12] - recoilPHand[12],
                    recoilPBarrel[13] - recoilPHand[13],
                    recoilPBarrel[14] - recoilPHand[14]
                );
                assert(Math.abs(recoilCHandMuzzleDist - restCHandMuzzleDist) < 1e-4, 'Karabina geri tepme sırasında elden kopmamalı');
                assert(Math.abs(recoilPHandBarrelDist - restPHandBarrelDist) < 1e-4, 'Tabanca geri tepme sırasında elden kopmamalı');

                // 5) Faz 3: Toparlanma & Tek Niyet Tamamlanması (Tek seferlik döngü sonu)
                // Tabanca döngüsü (~1.75s): ~55 frame * 0.03s sonra tamamlanmalı
                for (let f = 0; f < 55; f++) reg.update(0.03);
                assert(pRec.isCombatActing === false, 'Tabanca tek atış eylemi tamamlandığında eylem sonlanmalı (tek niyet)');

                // Karabina döngüsü (~2.0s): sonraki ~15 frame * 0.03s sonra tamamlanmalı
                for (let f = 0; f < 15; f++) reg.update(0.03);
                assert(cRec.isCombatActing === false, 'Karabina tek atış eylemi tamamlandığında eylem sonlanmalı (tek niyet)');

                // Toparlanma sönümlemesi (blend-out): Askerler hazır duruşuna dönmeli
                for (let f = 0; f < 40; f++) reg.update(0.04);
                assert(cRec.actionBlend === 0 && cRec.actionPhase === 0, 'Karabinalı süvari toparlanıp hazır duruşuna (blend=0) dönmeli');
                assert(pRec.actionBlend === 0 && pRec.actionPhase === 0, 'Tabancalı süvari toparlanıp hazır duruşuna (blend=0) dönmeli');
                assert(reg.stats.combatPosingCount === 0, 'Toparlanma sonrası savaş pozunda süvari kalmamalı');

                // Toparlanma sonrası parça matrisleri başlangıçtaki hazır duruşu matrislerine tam eşit olmalı
                const recoveredCMuzzle = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:carbine_1', cMuzzleIdx);
                const recoveredPBarrel = reg.evaluateSoldierPartMatrix('SEC_CAV_GUN:pistol_1', pBarrelIdx);
                for (let k = 0; k < 16; k++) {
                    assert(Math.abs(recoveredCMuzzle[k] - restCMuzzle[k]) < 1e-5, 'Toparlanma sonrası karabina hazır duruşu matrisine eşit olmalı');
                    assert(Math.abs(recoveredPBarrel[k] - restPBarrel[k]) < 1e-5, 'Toparlanma sonrası tabanca hazır duruşu matrisine eşit olmalı');
                }

                // Ekstra framelerde yeni niyet olmadan kendi kendine tekrar başlamamalı (sonsuz döngü engeli)
                for (let f = 0; f < 30; f++) reg.update(0.04);
                assert(cRec.isCombatActing === false && cRec.actionBlend === 0, 'Karabina tek saldırı sonrası hazır duruşunda kalmalı');
                assert(pRec.isCombatActing === false && pRec.actionBlend === 0, 'Tabanca tek saldırı sonrası hazır duruşunda kalmalı');

                reg.dispose();
            });

            runCase('41. 5 At Tipinde (Warhorse, Charger, Courser, Rouncey, Steppe) 4 Zamanlı Yürüyüş, Çapraz Tırıs, Toynak Zemin Teması & Durunca Tam Önceki Poza Dönüş', () => {
                const reg = new SoldierVisualRegistry();
                const horseTypes = [
                    { id: 'h_warhorse', mountType: 'warhorse', expectedMountVariant: 'heavy_warhorse', unitClass: 'cuirassier', activeWeapon: 'cavalry_sabre', side: 'player' },
                    { id: 'h_charger',  mountType: 'charger',  expectedMountVariant: 'charger_horse',  unitClass: 'reiter',     activeWeapon: 'cavalry_pistol', side: 'enemy' },
                    { id: 'h_courser',  mountType: 'courser',  expectedMountVariant: 'courser_horse',  unitClass: 'harquebusier', activeWeapon: 'cavalry_carbine', side: 'player' },
                    { id: 'h_rouncey',  mountType: 'rouncey',  expectedMountVariant: 'rouncey_horse',  unitClass: 'dragoon',    activeWeapon: 'cavalry_carbine', side: 'player' },
                    { id: 'h_steppe',   mountType: 'steppe_horse', expectedMountVariant: 'steppe_horse', unitClass: 'light_cavalry', activeWeapon: 'cavalry_lance', side: 'enemy' }
                ];

                // 1) 5 Farklı at tipi ve süvari varyantının kaydedilmesi
                const initialSoldiers = horseTypes.map((ht, idx) => ({
                    viewId: `SEC_HORSE_5:${ht.id}`,
                    sectorId: 'SEC_HORSE_5',
                    side: ht.side,
                    groupId: `grp_${ht.id}`,
                    soldierId: ht.id,
                    unitClass: ht.unitClass,
                    bodyType: 'mounted',
                    mountType: ht.mountType,
                    activeWeapon: ht.activeWeapon,
                    armorLoadout: ['three_quarter_plate'],
                    position: { x: (idx - 2) * 5.0, y: 0, z: 0 }
                }));

                reg.sync({ sectorId: 'SEC_HORSE_5', soldiers: initialSoldiers });

                // 2) Her bir at tipinin duruş (rest) matrislerinin tüm parçalar için önbelleğe alınması
                const restMatrices = new Map();
                for (const ht of horseTypes) {
                    const vid = `SEC_HORSE_5:${ht.id}`;
                    const rec = reg.getSoldierVisualState(vid);
                    assert(rec, `At tipi ${ht.mountType} kaydı bulunmalı`);
                    assert(
                        rec.templateKey.includes(ht.expectedMountVariant),
                        `${ht.mountType} beklenen ${ht.expectedMountVariant} varyantıyla eşleşmeli (gelen: ${rec.templateKey})`
                    );

                    const tpl = reg.templates[rec.templateKey];
                    assert(tpl && tpl.length > 30, `${ht.mountType} için geçerli parça şablonu bulunmalı`);
                    const partMats = [];
                    for (let pIdx = 0; pIdx < tpl.length; pIdx++) {
                        partMats.push(new Float32Array(reg.evaluateSoldierPartMatrix(vid, pIdx)));
                    }
                    restMatrices.set(vid, partMats);
                }

                // 3) 4 ZAMANLI YÜRÜYÜŞ FAZI: Kısa hareket (dz=2.5m) -> 4-beat walk aktif (walkBlend > 0.5, trotBlend < 0.05)
                const walkSoldiers = initialSoldiers.map((s) => ({
                    ...s,
                    position: { x: s.position.x, y: 0, z: s.position.z + 2.5 }
                }));
                reg.sync({ sectorId: 'SEC_HORSE_5', soldiers: walkSoldiers });

                for (let f = 0; f < 5; f++) {
                    reg.update(0.04);
                }

                for (const ht of horseTypes) {
                    const vid = `SEC_HORSE_5:${ht.id}`;
                    const rec = reg.getSoldierVisualState(vid);
                    assert(
                        rec.isMoving && rec.walkBlend > 0.5 && rec.trotBlend < 0.05,
                        `${ht.mountType} yürüyüş modunda olmalı (walkBlend=${rec.walkBlend.toFixed(3)}, trotBlend=${rec.trotBlend.toFixed(3)})`
                    );

                    const flHoof = reg.evaluateSoldierPartMatrix(vid, 14);
                    const frHoof = reg.evaluateSoldierPartMatrix(vid, 15);
                    const hlHoof = reg.evaluateSoldierPartMatrix(vid, 24);
                    const hrHoof = reg.evaluateSoldierPartMatrix(vid, 25);

                    // Toynak zemin teması hissi: Hiçbir toynak zemin altına inmemeli
                    [flHoof, frHoof, hlHoof, hrHoof].forEach((hm, idx) => {
                        assert(hm[13] >= 0.02, `${ht.mountType} toynak ${idx} zeminin altına inmemeli (y=${hm[13].toFixed(3)})`);
                    });

                    // 4 ayrı adım fazı (4-beat walk): Ön bacaklar zıt, arka bacaklar zıt, ön-arka faz farkı belirgin
                    const flDz = flHoof[14] - 0.58;
                    const frDz = frHoof[14] - 0.58;
                    const hlDz = hlHoof[14] - (-0.59);
                    const hrDz = hrHoof[14] - (-0.59);

                    assert(flDz * frDz < 0, `${ht.mountType} yürüyüşte ön sağ ve sol bacaklar zıt fazda olmalı`);
                    assert(hlDz * hrDz < 0, `${ht.mountType} yürüyüşte arka sağ ve sol bacaklar zıt fazda olmalı`);
                    assert(Math.abs(flDz - hlDz) > 0.02, `${ht.mountType} 4 zamanlı yürüyüşte ön-sol ve arka-sol bacaklar farklı fazlarda olmalı`);
                }

                // 4) TIRIS FAZI: Uzun hareket (dz=12m) -> 2-beat diagonal trot aktif (trotBlend > 0.75)
                const trotSoldiers = initialSoldiers.map((s) => ({
                    ...s,
                    position: { x: s.position.x, y: 0, z: s.position.z + 12.0 }
                }));
                reg.sync({ sectorId: 'SEC_HORSE_5', soldiers: trotSoldiers });

                for (let f = 0; f < 10; f++) {
                    reg.update(0.04);
                }

                for (const ht of horseTypes) {
                    const vid = `SEC_HORSE_5:${ht.id}`;
                    const rec = reg.getSoldierVisualState(vid);
                    assert(
                        rec.isMoving && rec.trotBlend > 0.75,
                        `${ht.mountType} tırıs modunda olmalı (trotBlend=${rec.trotBlend.toFixed(3)})`
                    );

                    const flHoof = reg.evaluateSoldierPartMatrix(vid, 14);
                    const frHoof = reg.evaluateSoldierPartMatrix(vid, 15);
                    const hlHoof = reg.evaluateSoldierPartMatrix(vid, 24);
                    const hrHoof = reg.evaluateSoldierPartMatrix(vid, 25);

                    const flDz = flHoof[14] - 0.58;
                    const hrDz = hrHoof[14] - (-0.59);
                    const frDz = frHoof[14] - 0.58;
                    const hlDz = hlHoof[14] - (-0.59);

                    // Tırıs çapraz eşleşmesi (2-beat diagonal trot)
                    assert(flDz * hrDz > 0, `${ht.mountType} tırısta ön-sol ve arka-sağ çapraz çifti birlikte hareket etmeli`);
                    assert(frDz * hlDz > 0, `${ht.mountType} tırısta ön-sağ ve arka-sol çapraz çifti birlikte hareket etmeli`);
                    assert(flDz * frDz < 0, `${ht.mountType} iki çapraz bacak çifti birbirine zıt fazda salınmalı`);

                    // Baş ve binici salınımı matris geçerliliği
                    const headMat = reg.evaluateSoldierPartMatrix(vid, 26);
                    const riderUpperMat = reg.evaluateSoldierPartMatrix(vid, reg.templates[rec.templateKey].length - 8);
                    assert(headMat && Number.isFinite(headMat[13]), `${ht.mountType} baş salınım matrisi geçerli olmalı`);
                    assert(riderUpperMat && Number.isFinite(riderUpperMat[13]), `${ht.mountType} binici üst gövde matrisi geçerli olmalı`);
                }

                // 5) DURMA VE SÖNÜMLEME FAZI: Hedef konuma varış
                for (const ht of horseTypes) {
                    const rec = reg.records.get(`SEC_HORSE_5:${ht.id}`);
                    rec.targetX = rec.x;
                    rec.targetY = rec.y;
                    rec.targetZ = rec.z;
                }
                for (let f = 0; f < 60; f++) {
                    reg.update(0.05);
                }

                // 6) DURUNCA TAM ÖNCEKİ POZA DÖNÜŞ TESTİ:
                // Tüm 5 at tipinde bütün parçaların matrislerinin duruş (rest) matrisiyle birebir aynı olduğu doğrulanır
                for (const ht of horseTypes) {
                    const vid = `SEC_HORSE_5:${ht.id}`;
                    const rec = reg.getSoldierVisualState(vid);
                    assert(rec.isMoving === false, `${ht.mountType} durmuş olmalı`);
                    assert(
                        rec.walkBlend === 0 && rec.trotBlend === 0 && rec.walkPhase === 0,
                        `${ht.mountType} durunca walkBlend=0, trotBlend=0, walkPhase=0 olmalı`
                    );

                    const tpl = reg.templates[rec.templateKey];
                    const savedRestMats = restMatrices.get(vid);
                    for (let pIdx = 0; pIdx < tpl.length; pIdx++) {
                        const currentPartMat = reg.evaluateSoldierPartMatrix(vid, pIdx);
                        const restPartMat = savedRestMats[pIdx];
                        for (let k = 0; k < 16; k++) {
                            const diff = Math.abs(currentPartMat[k] - restPartMat[k]);
                            assert(
                                diff < 1e-5,
                                `${ht.mountType} durunca parça #${pIdx} (${tpl[pIdx].rigGroup}) matris elemanı [${k}] tam dinlenme pozuna dönmeli (fark: ${diff.toFixed(7)})`
                            );
                        }
                    }
                }

                reg.dispose();
            });

            runCase('42. Kara Barut Dumanı & Namlu Parlaması Havuzu GPU Buffer Sızıntısı Yok Doğrulaması (G3D-03D Ajan 5)', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const battleData = createTestBattleData();
                const sm = new SectorManager();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const snap = projectActiveSector3D(sm);

                const renderer = new Battle3DRenderer({
                    rendererFactory: (opts) => new FOC_THREE.WebGLRenderer({
                        gl: mockCtx.gl,
                        onContextLost: opts.onContextLost,
                        onContextRestored: opts.onContextRestored
                    })
                });

                assert(renderer.init(mockMount, snap) === true, 'Renderer başarıyla başlatılmalı');
                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);

                // 1) Başlangıç GPU buffer sayısı ve 7 asker batch kontrolü
                const initialBufferCount = mockCtx.getBufferCount();
                assert(renderer.soldierRegistry.batchGroup.batches.length === 7, '7 asker instanced batch değişmemeli');
                assert(renderer.soldierRegistry.powderFxPool !== null, 'Kara barut FX havuzu mevcut olmalı');
                assert(renderer.soldierRegistry.powderFxPool.capacity === 64, 'FX havuzu sabit kapasiteye (64 slot) sahip olmalı');
                assert(renderer.soldierRegistry.powderFxPool.activeCount === 0, 'Başlangıçta FX havuzunda aktif parçacık olmamalı');

                // 2) Tüfekçileri (musketeers) tespit et
                const musketeerSoldiers = snap.soldiers.filter((s) => classifySoldierArchetype(s) === 'infantry_musketeer');
                assert(musketeerSoldiers.length > 0, 'Sektörde en az 1 tüfekçi/arkebüzcü bulunmalı');

                // 3) Tüfekçileri ateş fazı öncesine (0.27) hazırla ve tek seferlik ateşlemeyi test et
                musketeerSoldiers.forEach((ms) => {
                    renderer.soldierRegistry.setSoldierVisualCombatAction(ms.viewId, true, 'attack', 0.27);
                });

                // 1 simülasyon adımı: 0.27'den 0.28+'e geçiş ve tetiklenme
                renderer.stepSimulation(0.03);
                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);

                const activeFxAfterFire = renderer.soldierRegistry.powderFxPool.activeCount;
                assert(activeFxAfterFire > 0, `Ateş anında namlu parlaması ve duman üretilmeli, aktif: ${activeFxAfterFire}`);
                assert(activeFxAfterFire <= renderer.soldierRegistry.powderFxPool.capacity, 'Aktif parçacık sayısı havuz kapasitesini aşmamalı');

                // 4) Ateş fazı devam ederken parçacıkların tekrar tekrar (sürekli) tetiklenmediğini doğrula
                const initialActiveAfterFire = activeFxAfterFire;
                renderer.stepSimulation(0.03);
                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                assert(renderer.soldierRegistry.powderFxPool.activeCount <= initialActiveAfterFire, 'Aynı ateş fazında mükerrer/sürekli duman tetiklenmemeli (bir kez tetiklenmeli)');

                // 5) Ateşleme ve duman animasyonu boyunca GPU buffer sızıntısı olmadığını doğrula
                for (let f = 0; f < 25; f++) {
                    renderer.stepSimulation(0.03);
                    renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                }

                assert(mockCtx.getBufferCount() === initialBufferCount, 'Ateş ve duman animasyonu sırasında yeni GPU buffer oluşturulmamalı (GPU buffer sızıntısı yok)');
                assert(mockCtx.bufferSubDataCalls.length >= 25, 'Havuzlanmış GPU instance buffer bufferSubData ile yerinde güncellenmeli');
                assert(renderer.soldierRegistry.batchGroup.batches.length === 7, '7 asker instanced batch sayısı sabit kalmalı');

                // 6) Ömrü kısa (short-lived) parçacıkların kendiliğinden sönümlenip havuza dönmesi
                for (let f = 0; f < 30; f++) {
                    renderer.stepSimulation(0.03);
                    renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                }
                assert(renderer.soldierRegistry.powderFxPool.activeCount === 0, 'Kısa ömürlü namlu parlaması ve duman sönümlenmeli, havuz temizlenmeli');

                // 7) Kapatma ve GPU buffer temizliği doğrulaması
                const buffersBeforeDispose = mockCtx.deletedBuffers.length;
                renderer.dispose();
                assert(mockCtx.deletedBuffers.length > buffersBeforeDispose, 'Kapatma sırasında havuzlanmış GPU buffer gl.deleteBuffer ile serbest bırakılmalı');
            });

            runCase('43. 1650 Savaş Alanı Zemin Renk Parametreleri, Sis Yapılandırması, Işık Dengesi & Uzak Siluet Okunurluğu Doğrulaması', () => {
                // 1) BATTLEFIELD_VISUAL_CONFIG sabitlerinin bütünlüğü ve 1650 zemin/sis değerleri
                assert(typeof BATTLEFIELD_VISUAL_CONFIG === 'object' && BATTLEFIELD_VISUAL_CONFIG !== null, 'BATTLEFIELD_VISUAL_CONFIG tanımlı olmalı');
                const { terrain, atmosphere, lighting } = BATTLEFIELD_VISUAL_CONFIG;

                assert(terrain.span === 260 && terrain.subdivisions === 72, 'Arazi boyutu 260m ve 72x72 altbölüm korunmalı');
                assert(terrain.baseColor === 0x3d492c, 'Zemin temel albedo rengi 1650 toprak-çimen tonunda (0x3d492c) olmalı');
                assert(terrain.grassCenter === '#485533' && terrain.grassMid === '#3e4a2b' && terrain.grassEdge === '#2e381f', 'Zemin çimen gradyan tonları düşük gürültülü ve yüksek kontrastlı olmalı');
                assert(terrain.gridColor === 0x766f5e && terrain.gridOpacity <= 0.20, 'Taktik ızgara düşük görsel gürültü için mat ve düşük opaklıkta olmalı');

                assert(atmosphere.skyColor === 0x94a9be, 'Gökyüzü arka plan rengi 1650 atmosferik tonunda (0x94a9be) olmalı');
                assert(atmosphere.fogColor === 0x9cb1c3, 'Mesafe sis rengi ufukla uyumlu (0x9cb1c3) olmalı');
                assert(atmosphere.fogDensity === 0.0048, 'Sis yoğunluğu uzak asker siluetlerini korumak için 0.0048 olmalı');

                assert(lighting.sunColor === 0xfff2dc, 'Güneş ışığı rengi sıcak sabah ışığı (0xfff2dc) olmalı');
                assert(Array.isArray(lighting.sunDirection) && lighting.sunDirection.length === 3, 'Güneş yönü 3 bileşenli vektör olmalı');
                assert(lighting.sunDirection[1] > 0.55 && lighting.sunDirection[1] < 0.75, 'Güneş açısı siluetleri ve silahları vurgulayacak yataylıkta olmalı');
                assert(lighting.hemiGroundColor === 0x3a422a && lighting.hemiSkyColor === 0xd6e5f7, 'Hemisferik ortam ışığı zemin yansıması ve gök aydınlatmasını sağlamalı');

                // 2) Scene sınıfı varsayılanlarının BATTLEFIELD_VISUAL_CONFIG ile uyumu
                const testScene = new FOC_THREE.Scene();
                assert(testScene.fog instanceof FOC_THREE.FogExp2, 'Scene.fog FogExp2 tipinde olmalı');
                assert(testScene.fog.density === atmosphere.fogDensity, 'Scene.fog.density BATTLEFIELD_VISUAL_CONFIG ile eşleşmeli');
                assert(testScene.fog.color.getHex() === atmosphere.fogColor, 'Scene.fog.color BATTLEFIELD_VISUAL_CONFIG ile eşleşmeli');
                assert(testScene.background.getHex() === atmosphere.skyColor, 'Scene.background BATTLEFIELD_VISUAL_CONFIG ile eşleşmeli');
                assert(testScene.hemiGroundColor.getHex() === lighting.hemiGroundColor, 'Scene.hemiGroundColor doğru atanmalı');
                assert(testScene.hemiSkyColor.getHex() === lighting.hemiSkyColor, 'Scene.hemiSkyColor doğru atanmalı');
                assert(testScene.sunColor.getHex() === lighting.sunColor, 'Scene.sunColor doğru atanmalı');

                // 3) Battle3DRenderer entegrasyonu ve zemin nesnesi doğrulaması
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1024, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 768, configurable: true });

                const sm = new SectorManager();
                const battleData = createTestBattleData();
                sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                const snap = projectActiveSector3D(sm);

                const renderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });

                const initOk = renderer.init(mockMount, snap);
                assert(initOk === true, 'Renderer başlatılabilmeli');
                assert(renderer.scene.fog.density === atmosphere.fogDensity, 'Renderer sahne sis yoğunluğu korunmalı');
                assert(renderer.scene.fog.color.getHex() === atmosphere.fogColor, 'Renderer sahne sis rengi korunmalı');
                assert(renderer.scene.background.getHex() === atmosphere.skyColor, 'Renderer sahne arka plan rengi korunmalı');

                // Zemin geometrisi, materyali ve dokusu
                assert(renderer.groundMeshNode instanceof FOC_THREE.Mesh, 'Zemin mesh nesnesi sahnede bulunmalı');
                assert(renderer.groundMeshNode.geometry instanceof FOC_THREE.TerrainPlaneGeometry, 'Zemin geometrisi TerrainPlaneGeometry olmalı');
                assert(renderer.groundMeshNode.material.map instanceof FOC_THREE.CanvasTexture, 'Zemin materyalinde CanvasTexture dokusu bulunmalı');
                assert(renderer.gridMeshNode instanceof FOC_THREE.Line, 'Taktik ızgara çizgileri bulunmalı');
                assert(renderer.gridMeshNode.material.color.getHex() === terrain.gridColor, 'Izgara rengi zeminle uyumlu olmalı');

                // 4) Prosedürel 1024x1024 zemin dokusu üretimi ve piksel kontrastı
                const tex = renderer._createBattlefieldTexture();
                assert(tex instanceof FOC_THREE.CanvasTexture, 'Zemin dokusu üretilebilmeli');
                assert(tex.image && tex.image.width === 1024 && tex.image.height === 1024, 'Zemin dokusu 1024x1024 çözünürlükte olmalı');
                if (typeof tex.image.getContext === 'function') {
                    const ctx2d = tex.image.getContext('2d');
                    if (ctx2d) {
                        const pixel = ctx2d.getImageData(512, 512, 1, 1).data;
                        assert(pixel[3] === 255, 'Zemin dokusu tam opak olmalı');
                        assert(pixel[1] > pixel[2], 'Zemin rengi çimen/toprak tonu olmalı (yeşil > mavi)');
                    }
                }

                // 5) Sektör geçişinde ve render döngüsünde zemin ve sis bütünlüğü
                sm.setActiveSector(1);
                renderer.sync(projectActiveSector3D(sm), { snapCamera: true });
                assert(renderer.scene.fog.density === atmosphere.fogDensity, 'Sektör 1 geçişinde sis parametresi bozulmamalı');
                assert(renderer.groundMeshNode !== null, 'Sektör geçişinde zemin nesnesi korunmalı');

                sm.setActiveSector(2);
                renderer.sync(projectActiveSector3D(sm), { snapCamera: true });
                assert(renderer.scene.fog.density === atmosphere.fogDensity, 'Sektör 2 geçişinde sis parametresi bozulmamalı');

                // Render çağrısı ve temizleme
                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                assert(mockCtx.drawCalls.length > 0, 'Render çağrıları gerçekleşmeli');

                renderer.dispose();
                assert(renderer.isDisposed === true, 'Renderer düzgün dispose edilmeli');
            });

            
            // --- G3D-03D QA DÜZELTME & REGRESYON TESTİ (44) ---
            runCase('44. 5 At Tipi Önizlemesi (_buildHorseTypesPreviewSnapshot), Buton Tıklama, Karşılıklı Dışlama & Sahneye Dönüş Doğrulaması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 4.0;
                cam.desired.targetZ = -4.0;
                cam.desired.distance = 50;
                cam.desired.yaw = 0.2;
                cam.desired.pitch = 0.85;
                cam.syncTransform(1);

                const preState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance,
                    yaw: cam.current.yaw,
                    pitch: cam.current.pitch
                };

                // 1) Fonksiyon varlığı ve snapshot içeriğini doğrula
                assert(typeof probe._buildHorseTypesPreviewSnapshot === 'function', '_buildHorseTypesPreviewSnapshot fonksiyonu tanımlı olmalı');
                const legData = probe._buildHorseTypesPreviewSnapshot(0);
                assert(legData && legData.snapshot && Array.isArray(legData.snapshot.soldiers), '5 at tipi snapshot verisi üretilebilmeli');
                assert(legData.snapshot.soldiers.length === 5, 'Tam 5 at tipi bulunmalı, tespit edilen: ' + legData.snapshot.soldiers.length);
                
                const expectedMounts = ['warhorse', 'charger', 'courser', 'rouncey', 'steppe_horse'];
                expectedMounts.forEach(mType => {
                    assert(legData.snapshot.soldiers.some(s => s.mountType === mType), mType + ' at tipi mevcut olmalı');
                });

                // 2) Diğer önizleme açıkken 5 at tipine geçiş ve karşılıklı dışlama
                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true, 'Yürüyüş önizlemesi açılabilmeli');
                
                probe.toggleHorseTypesPreview();
                assert(probe.horseTypesPreviewActive === true, '5 at tipi önizlemesi açılabilmeli');
                assert(probe.walkPreviewActive === false, 'Yürüyüş önizlemesi kapatılmalı (karşılıklı dışlama)');
                assert(probe.cavalryPreviewActive === false, 'Süvari önizlemesi kapalı kalmalı');
                assert(probe.combatPreviewActive === false, 'Savaş pozları kapalı kalmalı');
                assert(testRenderer.soldierRegistry.records.size === 5, 'Sahneye 5 at tipi kaydı yüklenmeli');

                // 3) Önizlemeyi kapat ve ana sahneye (300 asker) geri dönüşü doğrula
                probe.toggleHorseTypesPreview();
                assert(probe.horseTypesPreviewActive === false, '5 at tipi önizlemesi kapatılabilmeli');
                assert(testRenderer.soldierRegistry.records.size === 300, 'Merkez sektördeki 300 asker geri gelmeli, bulunan: ' + testRenderer.soldierRegistry.records.size);

                cam.syncTransform(1);
                assert(Math.abs(cam.desired.targetX - preState.targetX) < 1e-4, 'Kamera hedef X korunmalı');
                assert(Math.abs(cam.desired.targetZ - preState.targetZ) < 1e-4, 'Kamera hedef Z korunmalı');
                assert(Math.abs(cam.desired.distance - preState.distance) < 1e-4, 'Kamera mesafesi korunmalı');

                testRenderer.dispose();
            });

            // --- G3D-03E TESTLERİ (45 - 50) ---
            // 45. Ajan 01: Süvari Savaş Animasyonları
            runCase('45. Süvari Savaş Animasyonları (Mızrak, Kılıç, Karabina, Tabanca) Geçiş Yumuşaklığı, Toparlanma, Olay Akışı & Kesinti Toleransı', () => {
                const archetypes = ['cavalry_lance', 'cavalry_sabre', 'cavalry_carbine', 'cavalry_pistol'];
                for (const arch of archetypes) {
                    const startPose = evaluateCavalryCombatPose(arch, 0.0);
                    const midPose = evaluateCavalryCombatPose(arch, 0.50);
                    const endPose = evaluateCavalryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || endPose.pitch || 0) - (startPose.torsoPitch || startPose.pitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'cavalry_lance') {
                        const thrustPose = evaluateCavalryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.5, 'Mızrak hücum anında ileri uzanmalı (>0.5), bulunan: ' + thrustPose.weaponDz);
                    }

                    if (arch === 'cavalry_sabre') {
                        assert(midPose.weaponDx <= -0.10, 'Kılıç savurmasında at boynundan güvenli yan açıklık korunmalı (dx <= -0.10)');
                    }

                    if (arch === 'cavalry_carbine' || arch === 'cavalry_pistol') {
                        const recoilPose = evaluateCavalryCombatPose(arch, 0.40);
                        assert(recoilPose.dz < 0, arch + ' geri tepme tepkisi geriye doğru (-dz) olmalı: ' + recoilPose.dz);
                    }
                }

                // Kesinti toleransı (saldırı esnasında hareket geçişi simülasyonu)
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();
                const dummyPart = { rigGroup: 'riderRightArm', localMat: FOC_THREE.Mat4.create() };
                computeCavalryPartLocalMatrix(outMat, dummyPart, 0.5, 0.6, 0.5, scratchA, scratchB, 0.45, 0.8, 'attack', 'cavalry_sabre');
                assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Kesinti anında süvari kol matrisi geçerli olmalı');
            });

            // 46. Ajan 02: Piyade Savaş Animasyonları
            runCase('46. Piyade Savaş Animasyonları (Mızrak, Tüfek, Kılıç-Kalkan) Geçiş Yumuşaklığı, Ayak Kaymama, Doldurma & Hareketli Saldırı Doğrulaması', () => {
                const archetypes = ['infantry_pikeman', 'infantry_musketeer', 'infantry_swordsman'];
                for (const arch of archetypes) {
                    const startPose = evaluateInfantryCombatPose(arch, 0.0);
                    const midPose = evaluateInfantryCombatPose(arch, 0.50);
                    const endPose = evaluateInfantryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || 0) - (startPose.torsoPitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'infantry_pikeman') {
                        const thrustPose = evaluateInfantryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.6, 'Piyade mızrak uzanımı dz > 0.6 olmalı, bulunan: ' + thrustPose.weaponDz);
                        assert(thrustPose.leftKneePitch > 0.2, 'Mızrak hücumunda ön diz bükülerek hamle dengelenmeli');
                    }

                    if (arch === 'infantry_musketeer') {
                        const recoilPose = evaluateInfantryCombatPose(arch, 0.36);
                        assert(recoilPose.weaponDz < -0.15, 'Tüfek ateş anında geri tepmeli (dz < -0.15), bulunan: ' + recoilPose.weaponDz);
                        const reloadPose = evaluateInfantryCombatPose(arch, 0.70);
                        assert(reloadPose.weaponPitch < -0.4, 'Tüfek doldurma fazında namlu yukarı/göğse dik eğilmeli (pitch < -0.4)');
                    }

                    if (arch === 'infantry_swordsman') {
                        assert(Math.abs(midPose.shieldDx) <= 0.16, 'Kılıç savurmasında kalkan göğüs merkezini siper almalı (|shieldDx| <= 0.16)');
                    }
                }

                // Hareket halinde saldırı ve ayak kaymama matris doğrulama
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();
                const legPart = { rigGroup: 'leftLegUpper', localMat: FOC_THREE.Mat4.create() };
                computeInfantryPartLocalMatrix(outMat, legPart, 'infantry_pikeman', 0.8, 0.7, scratchA, scratchB, 0.55, 0.8, 'attack');
                assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Hareketli mızrak hamlesinde bacak matrisi sayısal olarak geçerli olmalı');
            });

            // 47. Ajan 03: Birleşik Animasyon Önizlemesi
            runCase('47. Birleşik Animasyon Önizlemesi (300 Asker Savaş & İntikal Döngüsü, 4 Bacaklı İlerleme, HUD & Kamera Koruma Doğrulaması)', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 2.0;
                cam.desired.targetZ = -3.0;
                cam.desired.distance = 55;
                cam.syncTransform(1);

                const preState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance
                };

                assert(typeof probe._buildCombinedPreviewSnapshot === 'function', '_buildCombinedPreviewSnapshot tanımlı olmalı');

                // 4 Bacak döngü testi (Advance, Clash, Push of Pike, Re-formation)
                for (let leg = 0; leg < 4; leg++) {
                    const combData = probe._buildCombinedPreviewSnapshot(leg);
                    assert(combData && combData.snapshot && Array.isArray(combData.snapshot.soldiers), 'Bacak ' + leg + ' snapshot verisi üretilebilmeli');
                    const soldiers = combData.snapshot.soldiers;
                    assert(soldiers.length === 300, 'Tüm 300 asker korunmalı (bacak ' + leg + '), bulunan: ' + soldiers.length);
                    const attackCount = soldiers.filter(s => s.state === 'attack').length;
                    const readyCount = soldiers.filter(s => s.state === 'ready').length;
                    assert(attackCount > 0, 'Savaş pozunda askerler bulunmalı (bacak ' + leg + '): ' + attackCount);
                    assert(readyCount > 0, 'Hazır pozunda askerler bulunmalı (bacak ' + leg + '): ' + readyCount);
                }

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true, 'Yürüyüş önizlemesi açılabilmeli');

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === true, 'Birleşik önizleme açılabilmeli');
                assert(probe.walkPreviewActive === false, 'Yürüyüş önizlemesi kapatılmalı (karşılıklı dışlama)');
                assert(probe.cavalryPreviewActive === false, 'Süvari önizlemesi kapalı kalmalı');
                assert(probe.horseTypesPreviewActive === false, '5 at tipi önizlemesi kapalı kalmalı');
                assert(probe.combinedPreviewLeg === 0, 'Başlangıçta birleşik önizleme 0. bacakta başlamalı');

                // Zaman ilerlemesi ile döngüsel bacak geçişi doğrulama (_onFrameTick)
                probe._onFrameTick(3.0);
                assert(probe.combinedPreviewLeg === 1, '_onFrameTick(3.0) sonrası 1. bacağa geçilmeli, bulunan: ' + probe.combinedPreviewLeg);

                // G3D-03G Hardening: Askerlerin targetPosition'a doğru gerçekten adım attığını doğrula
                const movingRec = Array.from(testRenderer.soldierRegistry.records.values()).find(r => r.isMoving && Math.abs(r.targetZ - r.z) > 0.1);
                assert(movingRec !== undefined, 'Önizleme snapshot senkronizasyonunda hareket eden en az bir asker kaydı bulunmalı');
                const initMovingZ = movingRec.z;
                for (let step = 0; step < 30; step++) {
                    testRenderer.soldierRegistry.update(0.016);
                }
                const deltaMovingZ = Math.abs(movingRec.z - initMovingZ);
                assert(deltaMovingZ > 0.05, 'Asker simülasyon adımlarıyla hedef Z konumuna doğru gerçekten ilerlemeli (deltaMovingZ > 0.05), bulunan: ' + deltaMovingZ);

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === false, 'Birleşik önizleme kapatılabilmeli');
                assert(testRenderer.soldierRegistry.records.size === 300, 'Merkez sektördeki 300 asker geri gelmeli');

                cam.syncTransform(1);
                assert(Math.abs(cam.desired.targetX - preState.targetX) < 1e-4, 'Kamera hedef X korunmalı');
                assert(Math.abs(cam.desired.targetZ - preState.targetZ) < 1e-4, 'Kamera hedef Z korunmalı');
                assert(Math.abs(cam.desired.distance - preState.distance) < 1e-4, 'Kamera mesafesi korunmalı');

                testRenderer.dispose();
            });

            // 48. Ajan 04: At Hareketi ve Binici Uyumu
            runCase('48. At Yürüyüş-Tırıs Geçiş Yumuşaklığı, Toynak Dünya Koordinat Zemin Teması ve Binici-Eyer Uyum Doğrulaması', () => {
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();
                const worldPartMat = FOC_THREE.Mat4.create();

                const templates = createSoldierPartTemplates();
                const cavKey = Object.keys(templates).find(k => k.includes('cavalry_lance')) || Object.keys(templates)[0];
                const cavParts = templates[cavKey];
                assert(Array.isArray(cavParts), 'Süvari şablonu parça listesi mevcut olmalı');

                const hoofPart = cavParts.find(p => p.rigGroup === 'horseLegFLLower' && p.prim === 'frustum');
                assert(hoofPart, 'Gerçek at modeli şablonunda toynak parçası (horseLegFLLower frustum) bulunmalı');

                const riderPart = cavParts.find(p => p.rigGroup === 'riderLower');
                assert(riderPart, 'Gerçek süvari modeli şablonunda binici alt gövdesi (riderLower) bulunmalı');

                const soldierWorldMat = FOC_THREE.Mat4.fromEulerTranslationScale(
                    FOC_THREE.Mat4.create(),
                    0, 0, 0,
                    10.0, 0.0, -5.0,
                    1, 1, 1
                );

                const trotBlends = [0.0, 0.5, 1.0];
                for (const tb of trotBlends) {
                    for (let step = 0; step < 16; step++) {
                        const phase = step * (Math.PI * 2) / 16;
                        computeCavalryPartLocalMatrix(outMat, hoofPart, phase, 1.0, tb, scratchA, scratchB);
                        assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Bacak matrisi tb=' + tb + ', step=' + step + ' için geçerli olmalı');

                        FOC_THREE.Mat4.multiply(worldPartMat, soldierWorldMat, outMat);
                        // Toynak birim frustum tabanı (y = -0.5) dünya koordinatına dönüştürülür
                        const bottomY = worldPartMat[1] * 0 + worldPartMat[5] * (-0.5) + worldPartMat[9] * 0 + worldPartMat[13];
                        assert(!isNaN(bottomY), 'Dünya koordinatlarında toynak tabanı Y hesaplanabilmeli');
                        assert(bottomY >= -0.05, 'Toynak zemin içine aşırı batmamalı (bottomY >= -0.05), bulunan: ' + bottomY);
                    }

                    computeCavalryPartLocalMatrix(outMat, riderPart, 0.5, 1.0, tb, scratchA, scratchB);
                    const riderDy = outMat[13] - riderPart.localMat[13];
                    assert(!isNaN(riderDy), 'Binici dikey yer değiştirmesi tb=' + tb + ' için geçerli olmalı');
                    assert(riderDy >= -0.05 && riderDy <= 0.15, 'Binici eyerle dikey teması korumalı (-0.05 <= riderDy <= 0.15), bulunan: ' + riderDy);
                }

                computeCavalryPartLocalMatrix(outMat, hoofPart, 0.5, 0.0, 0.0, scratchA, scratchB);
                for (let i = 0; i < 16; i++) {
                    const expected = hoofPart.localMat[i];
                    assert(Math.abs(outMat[i] - expected) < 1e-5, 'Durma anında toynak tam referans pozuna dönmeli');
                }
            });

            // 49. Ajan 05: Kara Barut ve WebGL Kaynakları
            runCase('49. Kara Barut Efekt Havuzu (64 Slot), GPU Handle Yaşam Döngüsü, Sıfır GC Tahsisi ve Context Kaybı Doğrulaması', () => {
                const pool = new BlackPowderFxPool(64);
                assert(pool.capacity === 64, 'Efekt havuz kapasitesi 64 olmalı');
                assert(pool.particles.length === 64, 'Önceden ayrılmış 64 parçacık slotu bulunmalı');
                assert(pool.activeCount === 0, 'Başlangıçta aktif parçacık olmamalı');

                pool.spawnMuzzleFlashAndSmoke(10.0, 1.5, -5.0, 1.0, 0.0);
                assert(pool.activeCount > 0, 'Ateşleme sonrası aktif parçacık bulunmalı');
                const flash = pool.particles.find(p => p.active && p.isFlash);
                assert(flash !== undefined, 'Namlu parlaması parçacığı oluşturulabilmeli');
                assert(Math.abs(flash.x - 10.05) < 1e-4, 'Parlamanın namlu çıkışına X kilidi doğru olmalı: ' + flash.x);
                assert(flash.maxLife <= 0.10, 'Namlu parlaması çok kısa ömürlü olmalı (<= 0.10s)');

                for (let i = 0; i < 30; i++) {
                    pool.spawnMuzzleFlashAndSmoke(i, 1.5, 0, 1, 0);
                }
                assert(pool.activeCount <= 64, 'Aktif parçacık sayısı havuz kapasitesini (64) asla aşmamalı, bulunan: ' + pool.activeCount);

                const initialBufferRef = pool.instanceData;
                for (let frame = 0; frame < 100; frame++) {
                    pool.update(0.016);
                }
                assert(pool.instanceData === initialBufferRef, 'instanceData Float32Array referansı değişmemeli (sıfır GC)');

                // BULGU B Doğrulaması: SoldierVisualRegistry.invalidateGpuHandles -> powderFxPool handle sıfırlama
                const registry = new SoldierVisualRegistry();
                registry.powderFxPool.spawnMuzzleFlashAndSmoke(5, 1.5, 0, 1, 0);
                assert(registry.powderFxPool.activeCount > 0, 'Registry havuzunda parçacık oluşturulabilmeli');

                // Mock GL handle ataması simülasyonu
                registry.powderFxPool.batch._gl = { dummy: true };
                registry.powderFxPool.batch._glInstanceBuffer = { dummyBuffer: true };
                registry.powderFxPool.batch._needsUpload = false;

                registry.invalidateGpuHandles();
                assert(registry.powderFxPool.batch._gl === null, 'BlackPowderFxPool batch GL handle sıfırlanmalı (BULGU B)');
                assert(registry.powderFxPool.batch._glInstanceBuffer === null, 'BlackPowderFxPool instance buffer GL handle sıfırlanmalı (BULGU B)');
                assert(registry.powderFxPool.batch._needsUpload === true, 'BlackPowderFxPool context geri dönüşünde yeniden yüklemeye hazır olmalı');

                // BULGU D / G3D-03G Doğrulaması: Registry döngüsünde scratch matris ve batchWriteOffsets referanslarının korunması (sıfır heap tahsisi)
                const scratchARef = registry._scratchA;
                const scratchBRef = registry._scratchB;
                const tmpPartLocalMatRef = registry._tmpPartLocalMat;
                const tmpWorldPartMatRef = registry._tmpWorldPartMat;
                const batchWriteOffsetsRef = registry._batchWriteOffsets;

                assert(batchWriteOffsetsRef instanceof Int32Array, '_batchWriteOffsets Int32Array olarak önceden ayrılmış olmalı');

                for (let frame = 0; frame < 100; frame++) {
                    registry.update(0.016);
                    registry._updateBatchBuffersInPlace();
                }
                assert(registry._scratchA === scratchARef && registry._scratchB === scratchBRef, 'Scratch matrisleri döngüde yeniden oluşturulmamalı (BULGU D)');
                assert(registry._tmpPartLocalMat === tmpPartLocalMatRef && registry._tmpWorldPartMat === tmpWorldPartMatRef, 'Geçici dönüşüm matrisleri referansları değişmemeli (BULGU D)');
                assert(registry._batchWriteOffsets === batchWriteOffsetsRef, '_batchWriteOffsets referansı kareler boyunca korunmalı (sıfır GC)');

                assert(typeof pool.reset === 'function', 'pool.reset fonksiyonu mevcut olmalı');
                pool.reset();
                assert(pool.activeCount === 0, 'reset sonrası aktif parçacık kalmamalı');
                assert(pool.particles.every(p => p.active === false), 'Tüm slotlar inaktif duruma getirilmeli');
            });

            // 50. Ajan 06: Saha Görselliği ve WebGL Performans Profilleme
            runCase('50. Saha Görselliği (Uzak Silüet & Rim Light) ve 300 Askerli Sahne WebGL Performans Profilleme Doğrulaması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });

            // ============================================================================
            // G3D-03H RTS KOMUTA, SEÇİM, FORMASYON VE MİNİMAP DOĞRULAMA TESTLERİ (51 - 58)
            // ============================================================================

            // 51. Ajan 01: RTS Birlik Seçimi ve Kontrol Grupları
            runCase('51. RTS Birlik Seçimi (Tekil & Grup Seçimi, Shift Ekleme/Çıkarma, Kontrol Grupları 1-9)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_SEL',
                    soldiers: [
                        { viewId: 's1', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 0, y: 0, z: 0 } },
                        { viewId: 's2', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 2, y: 0, z: 0 } },
                        { viewId: 's3', side: 'enemy', groupId: 'g2', archetype: 'infantry_musketeer', position: { x: 10, y: 0, z: 10 } }
                    ]
                });

                const mockRenderer = { soldierRegistry: reg, selectionDirty: false };
                const sel = new RTSSelectionManager(mockRenderer);

                // Tekil seçim
                sel.select('s1', false);
                assert(sel.selectedSoldierIds.size === 1 && sel.isSelected('s1'), 's1 tekil seçilmeli');

                // Shift ile ekleme
                sel.select('s3', true);
                assert(sel.selectedSoldierIds.size === 2 && sel.isSelected('s3'), 'Shift ile s3 seçime eklenmeli');

                // Grup seçimi
                sel.selectGroup('g1', false);
                assert(sel.selectedSoldierIds.size === 2 && sel.isSelected('s1') && sel.isSelected('s2'), 'g1 grubunun tüm askerleri seçilmeli');

                // Kontrol Grubu 1 atama ve geri çağırma
                sel.assignControlGroup(1);
                sel.clear();
                assert(sel.selectedSoldierIds.size === 0, 'Seçim temizlenmeli');

                const recalled = sel.recallControlGroup(1);
                assert(recalled && sel.selectedSoldierIds.size === 2 && sel.isSelected('s1'), 'Kontrol grubu 1 geri çağrılabilmeli');
                reg.dispose();
            });

            // 52. Ajan 01: Dikdörtgen Marquee Alan Seçimi
            runCase('52. Dikdörtgen Marquee Alan Seçimi (2D Ekran -> 3D Dünya Birim Kapsama Doğrulaması)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_BOX',
                    soldiers: [
                        { viewId: 'b1', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 0, y: 0, z: 0 } },
                        { viewId: 'b2', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 50, y: 0, z: 50 } }
                    ]
                });

                const mockCam = {
                    current: { targetX: 0, targetZ: 0, distance: 46, yaw: 0, pitch: 0.88 }
                };
                const mockRenderer = { soldierRegistry: reg, selectionDirty: false };
                const sel = new RTSSelectionManager(mockRenderer);

                // Ekran merkezini kapsayan bir dikdörtgen alan seçimi (400x300 piksel)
                const count = sel.selectInScreenRect(300, 200, 500, 400, false, mockCam, 800, 600);
                assert(count >= 1 && sel.isSelected('b1'), 'Merkezdeki b1 askeri dikdörtgen seçim kutusuna girmeli');
                assert(!sel.isSelected('b2'), 'Uzak köşedeki b2 askeri seçim kutusu dışında kalmalı');
                reg.dispose();
            });

            // 53. Ajan 02: Sağ Tık Hareket Emri & Shift Sıralı Emir Kuyruğu
            runCase('53. Sağ Tık Hareket Emri, Hedef Konum İnterpolasyonu & Shift Sıralı Emir Kuyruğu', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_MOVE',
                    soldiers: [
                        { viewId: 'm1', side: 'player', groupId: 'g1', archetype: 'infantry_pikeman', position: { x: 0, y: 0, z: 0 } }
                    ]
                });

                const mockRenderer = { soldierRegistry: reg };
                const sel = new RTSSelectionManager(mockRenderer);
                const mov = new RTSMovementManager(mockRenderer);
                mockRenderer.selectionManager = sel;

                sel.select('m1', false);

                // 1. Hareket emri
                mov.issueMoveOrder(10, 20, false);
                const sol = reg.records.get('m1');
                assert(sol.isMoving && sol.targetX === 10 && sol.targetZ === 20, 'Asker hedef konuma yönlendirilmeli');

                // 2. Shift ile sıralı hareket kuyruğu ekleme
                mov.issueMoveOrder(30, 40, true);
                assert(mov.waypointQueues.has('m1') && mov.waypointQueues.get('m1').length === 1, 'Shift ile ikinci hedef kuyruğa eklenmeli');
                reg.dispose();
            });

            // 54. Ajan 03: 6 Taktik Formasyon Matrisi
            runCase('54. 6 Taktik Formasyon Matrisi (Hat, Kol, Kama, Gevşek, Dağınık, Çember) & Slot Dağılımı', () => {
                const formManager = new RTSFormationManager();
                const formations = ['line', 'column', 'wedge', 'loose', 'skirmish', 'circle'];

                for (const f of formations) {
                    const slots = formManager.computeSlots(20, false, 0.0, f);
                    assert(slots.length === 20, `Formasyon ${f} 20 askere tam 20 slot üretmeli`);

                    // Slotlar arasında çakışma olmamalı
                    for (let i = 0; i < slots.length; i++) {
                        for (let j = i + 1; j < slots.length; j++) {
                            const d = Math.hypot(slots[i].dx - slots[j].dx, slots[i].dz - slots[j].dz);
                            assert(d > 0.35, `Formasyon ${f} slotları aşırı çakışmamalı (d > 0.35m)`);
                        }
                    }
                }
            });

            // 55. Ajan 03: Formasyon Dönüşü & Süvari/Piyade Aralık Uyumu
            runCase('55. Formasyon Dönüşü (Pivot/Wheel) & Süvari/Piyade Aralık Uyumu (Işınlanma Yok)', () => {
                const formManager = new RTSFormationManager();

                const infSlots = formManager.computeSlots(10, false, 0.0, 'line');
                const cavSlots = formManager.computeSlots(10, true, 0.0, 'line');

                const infWidth = Math.abs(infSlots[infSlots.length - 1].dx - infSlots[0].dx);
                const cavWidth = Math.abs(cavSlots[cavSlots.length - 1].dx - cavSlots[0].dx);

                assert(cavWidth > infWidth * 1.5, 'Süvari formasyonu piyadeden en az 1.5 kat daha geniş aralıklı olmalı');

                // 90 derece dönüş testi
                const rotSlots = formManager.computeSlots(10, false, Math.PI * 0.5, 'line');
                assert(Math.abs(rotSlots[0].dz) > 0.1, 'Açı değiştiğinde formasyon yönü dünya koordinatlarında dönmeli');
            });

            // 56. Ajan 04: RTS Kamera Panning, Zoom & Seçili Birliğe Odaklanma
            runCase('56. RTS Kamera Panning (WASD/Sınırlar), Zoom, Eğim & Seçili Birliğe Odaklanma (Space)', () => {
                const cam = new RTSCamera3D();
                cam.setBoundsAndTarget({ minX: -60, maxX: 60, minZ: -60, maxZ: 60 }, { x: 0, z: 0 }, true);

                cam.panRelative(20, 10);
                assert(cam.desired.targetX !== 0 || cam.desired.targetZ !== 0, 'Kamera pan hareketi uygulanmalı');

                cam.zoomBy(-15);
                assert(cam.desired.distance === 31, 'Kamera yakınlaşabilmeli');

                // Seçime odaklanma
                cam.focusOnSelection([{ x: 25, z: -30 }]);
                assert(Math.abs(cam.desired.targetX - 25) < 1e-4 && Math.abs(cam.desired.targetZ - (-30)) < 1e-4, 'Kamera seçili birliğe odaklanabilmeli');
            });

            // 57. Ajan 05: 8 Taktik RTS Emri
            runCase('57. 8 Taktik RTS Emri (Move, Hold, Attack, Attack-Move, Retreat, Fire-at-Will, Hold-Fire, Regroup)', () => {
                const reg = new SoldierVisualRegistry();
                reg.sync({
                    sectorId: 'SEC_TEST_CMD',
                    soldiers: [
                        { viewId: 'c1', side: 'player', groupId: 'g1', archetype: 'infantry_musketeer', position: { x: 0, y: 0, z: 0 } }
                    ]
                });

                const mockRenderer = { soldierRegistry: reg };
                const sel = new RTSSelectionManager(mockRenderer);
                const cmd = new RTSCommandManager(mockRenderer);
                mockRenderer.selectionManager = sel;

                sel.select('c1', false);
                const sol = reg.records.get('c1');

                // Hold Ground
                cmd.executeCommand('hold');
                assert(sol.currentOrder === 'hold' && sol.isCombatActing && sol.actionMode === 'guard', 'Hold emri askeri guard pozuna almalı');

                // Attack Move
                cmd.executeCommand('attack_move');
                assert(sol.currentOrder === 'attack_move' && sol.actionMode === 'attack', 'Attack move hücum hazırlığı yapmalı');

                // Retreat
                cmd.executeCommand('retreat');
                assert(sol.currentOrder === 'retreat' && sol.isMoving, 'Geri çekilme intikali tetiklemeli');
                reg.dispose();
            });

            // 58. Ajan 06: İnteraktif Minimap
            runCase('58. İnteraktif Minimap (3D->2D Koordinat Dönüşümü, Kamera Frustum Göstergesi & Tıklama ile Yönlendirme)', () => {
                const mockCanvas = {
                    width: 180,
                    height: 180,
                    getContext: () => ({
                        clearRect: () => {},
                        beginPath: () => {},
                        moveTo: () => {},
                        lineTo: () => {},
                        stroke: () => {},
                        arc: () => {},
                        fill: () => {},
                        strokeRect: () => {},
                        fillRect: () => {}
                    }),
                    addEventListener: () => {},
                    getBoundingClientRect: () => ({ left: 0, top: 0, width: 180, height: 180 })
                };

                const mockCam = new RTSCamera3D();
                const mockRenderer = { cameraController: mockCam };
                const minimap = new RTSMinimapController(mockCanvas, mockRenderer);

                // Minimap tıklama simülasyonu: tam merkeze tıklama (90, 90) -> (0, 0) koordinatına taşımalı
                minimap._handleClick({ clientX: 90, clientY: 90 });

            // ============================================================================
            // G3D-03J ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & MODEL ÇEŞİTLİLİĞİ TESTLERİ (59 - 64)
            // ============================================================================

            // 59. Ajan 01: Osmanlı Piyade Sınıfları ve Model Şablonları (Yeniçeri, Azap, Humbaracı, Bostancı, Levend)
            runCase('59. Osmanlı Piyade Sınıfları ve Model Şablonları (Yeniçeri, Azap, Humbaracı, Bostancı, Levend)', () => {
                const reg = new SoldierVisualRegistry();
                const expectedOttomanInf = [
                    'ottoman:janissary:v1', 'ottoman:janissary:v2',
                    'ottoman:azap:v1', 'ottoman:azap:v2',
                    'ottoman:humbaraci:v1', 'ottoman:humbaraci:v2',
                    'ottoman:bostanci:v1', 'ottoman:bostanci:v2',
                    'ottoman:levend:v1', 'ottoman:levend:v2'
                ];

                for (const key of expectedOttomanInf) {
                    const parts = reg.templates[key];
                    assert(Array.isArray(parts) && parts.length >= 18, `${key} şablonu mevcut ve en az 18 parça içermeli, gelen: ${parts ? parts.length : 0}`);
                    const hasTorso = parts.some(p => p.rigGroup === 'torso');
                    assert(hasTorso, `${key} gövde (torso) rig grubuna sahip olmalı`);
                }

                // Yeniçeri Börk doğrulaması
                const janissaryParts = reg.templates['ottoman:janissary:v1'];
                const hasBork = janissaryParts.some(p => p.mat === 'ottomanWhite');
                assert(hasBork, 'Yeniçeri beyaz keçe börk parçasına sahip olmalı');
            });

            // 60. Ajan 02: Osmanlı Süvari Sınıfları (Sipahi, Kapıkulu Sipahisi, Deli, Ciritçi, Akıncı)
            runCase('60. Osmanlı Süvari Sınıfları (Sipahi, Kapıkulu Sipahisi, Deli, Ciritçi, Akıncı)', () => {
                const reg = new SoldierVisualRegistry();
                const expectedOttomanCav = [
                    'ottoman:sipahi:v1', 'ottoman:sipahi:v2',
                    'ottoman:kapikulu_sipahi:v1', 'ottoman:kapikulu_sipahi:v2',
                    'ottoman:deli:v1', 'ottoman:deli:v2',
                    'ottoman:ciritci:v1', 'ottoman:ciritci:v2',
                    'ottoman:akinci:v1', 'ottoman:akinci:v2'
                ];

                for (const key of expectedOttomanCav) {
                    const parts = reg.templates[key];
                    assert(Array.isArray(parts) && parts.length >= 60, `${key} süvari şablonu en az 60 parça içermeli, gelen: ${parts ? parts.length : 0}`);
                    const hasRider = parts.some(p => p.rigGroup && p.rigGroup.startsWith('rider'));
                    const hasHorse = parts.some(p => p.rigGroup && p.rigGroup.startsWith('horse'));
                    assert(hasRider && hasHorse, `${key} hem binici hem at parçalarına sahip olmalı`);
                }

                // Deli pars postu doğrulaması
                const deliParts = reg.templates['ottoman:deli:v1'];
                const hasLeopard = deliParts.some(p => p.mat === 'leopardPelt');
                assert(hasLeopard, 'Deli süvarisi leopar/pars postu materyaline sahip olmalı');
            });

            // 61. Ajan 03: Avrupa / HRE Asker Sınıfları (Musketier, Pikeniere, Hellebardier, Kürassier, Reiter)
            runCase('61. Avrupa / HRE Asker Sınıfları (Musketier, Pikeniere, Hellebardier, Kürassier, Reiter)', () => {
                const reg = new SoldierVisualRegistry();
                const expectedHRE = [
                    'european:musketier:v1', 'european:musketier:v2',
                    'european:pikeniere:v1', 'european:pikeniere:v2',
                    'european:hellebardier:v1', 'european:hellebardier:v2',
                    'european:curassier:v1', 'european:curassier:v2',
                    'european:reiter:v1', 'european:reiter:v2'
                ];

                for (const key of expectedHRE) {
                    const parts = reg.templates[key];
                    assert(Array.isArray(parts) && parts.length >= 40, `${key} şablonu mevcut ve geçerli parça sayısına sahip olmalı`);
                }

                // Hellebardier balta parçası doğrulaması
                const halberdParts = reg.templates['european:hellebardier:v1'];
                assert(halberdParts.length > 41, 'Hellebardier balta başlığı parçasına sahip olmalı');
            });

            // 62. Ajan 04: Modüler Ekipman Havuzları (RTS_EQUIPMENT_POOLS) ve Deterministik Donanım Çözümü
            runCase('62. Modüler Ekipman Havuzları (RTS_EQUIPMENT_POOLS) ve Deterministik Donanım Çözümü', () => {
                assert(typeof RTS_EQUIPMENT_POOLS === 'object', 'RTS_EQUIPMENT_POOLS tanımlı olmalı');
                assert(RTS_EQUIPMENT_POOLS.ottoman && RTS_EQUIPMENT_POOLS.european, 'Osmanlı ve Avrupa havuzları ayrılmış olmalı');
                assert(RTS_EQUIPMENT_POOLS.ottoman.weapons.length >= 6, 'Osmanlı silah havuzu zengin olmalı');
                assert(RTS_EQUIPMENT_POOLS.european.weapons.length >= 5, 'Avrupa silah havuzu zengin olmalı');

                const loadout1 = resolveUnitEquipment('ottoman', 'janissary', 42);
                const loadout2 = resolveUnitEquipment('ottoman', 'janissary', 42);
                assert(loadout1.weapon.id === loadout2.weapon.id, 'Aynı seed ile deterministik donanım çözümü üretilmeli');

                const loadoutEuro = resolveUnitEquipment('european', 'musketier', 7);
                assert(loadoutEuro.culture === 'european', 'Avrupa donanımı Avrupa kültürüne ait olmalı');
                const hasOttomanWeapon = RTS_EQUIPMENT_POOLS.european.weapons.some(w => w.id === 'yatagan_sword');
                assert(!hasOttomanWeapon, 'Avrupa silah havuzunda yatağan bulunmamalı (kültür izolasyonu)');
            });

            // 63. Ajan 05: 1650 Tarihsel Malzeme Kütüphanesi & Siluet / LOD / Çizim Kararlılığı
            runCase('63. 1650 Tarihsel Malzeme Kütüphanesi & Siluet / LOD / Çizim Kararlılığı', () => {
                const reg = new SoldierVisualRegistry();
                const expectedMats = ['ottomanCrimson', 'ottomanEmerald', 'ottomanSaffron', 'ottomanNavy', 'ottomanWhite', 'leopardPelt', 'bronze', 'damascusSteel'];
                for (const m of expectedMats) {
                    assert(reg.materials[m], `${m} materyali SoldierVisualRegistry kütüphanesinde tanımlı olmalı`);
                    assert(reg.materials[m].color && typeof reg.materials[m].color.r === 'number', `${m} geçerli bir Color nesnesine sahip olmalı`);
                }

                // 206 temel şablonun tam korunduğu doğrulaması
                const baseKeys = Object.keys(reg.templates);
                assert(baseKeys.length === 206, `206 temel şablon korunmalı, enumerable anahtar sayısı: ${baseKeys.length}`);
            });

            // 64. Ajan 06: Asker Vitrini (RTSUnitShowcaseController) ve 3D Model Önizleme / Karşılaştırma
            runCase('64. Asker Vitrini (RTSUnitShowcaseController) ve 3D Model Önizleme / Karşılaştırma', () => {
                const mockRenderer = { cameraController: new RTSCamera3D() };
                const showcase = new RTSUnitShowcaseController(mockRenderer);
                assert(showcase.unitCatalog.ottoman.length >= 8, 'Osmanlı vitrin kataloğu zengin olmalı');
                assert(showcase.unitCatalog.european.length >= 5, 'Avrupa vitrin kataloğu tam olmalı');

                showcase.setCulture('ottoman');
                assert(showcase.currentCulture === 'ottoman', 'Kültür Osmanlı olarak ayarlanmalı');

                showcase.setVariant(2);
                assert(showcase.selectedVariant === 2, 'Varyant 2 seçilebilmeli');

                showcase.setAnim('attack');
                assert(showcase.selectedAnim === 'attack', 'Saldırı animasyonu seçilebilmeli');

                showcase.toggleCompare();
                assert(showcase.compareMode === true, 'Karşılaştırma modu açılabilmeli');
            });

            // ============================================================================
            // G3D-03K ASKER MODEL KALİTESİ, ANATOMİ, ZIRH & KIYAFET TESTLERİ (65 - 70)
            // ============================================================================

            // 65. Ajan 01: İnsan Anatomisi ve 3 Temel Vücut Profili (Slim, Average, Heavy)
            runCase('65. İnsan Anatomisi ve 3 Temel Vücut Profili (Slim, Average, Heavy)', () => {
                assert(typeof BODY_PROFILES === 'object', 'BODY_PROFILES nesnesi mevcut olmalı');
                assert(BODY_PROFILES.slim && BODY_PROFILES.average && BODY_PROFILES.heavy, '3 temel vücut profili (slim, average, heavy) tanımlı olmalı');
                assert(BODY_PROFILES.heavy.shoulderWidth > BODY_PROFILES.average.shoulderWidth, 'Ağır profil daha geniş omuz genişliğine sahip olmalı');
                assert(BODY_PROFILES.average.shoulderWidth > BODY_PROFILES.slim.shoulderWidth, 'Ortalama profil ince profilden daha geniş omuz genişliğine sahip olmalı');

                const slimModel = buildAnatomicalHumanBase('player', 'slim');
                const heavyModel = buildAnatomicalHumanBase('player', 'heavy');
                assert(slimModel.length >= 22, 'Anatomik insan modeli en az 22 parçadan oluşmalı');
                assert(heavyModel.length >= 22, 'Ağır anatomik insan modeli en az 22 parçadan oluşmalı');

                // Mafsal ve eklem parçaları doğrulaması (baldır, diz ve el)
                const hasKnee = slimModel.some(p => p.rigGroup === 'leftLegLower' && p.prim === 'dome');
                assert(hasKnee, 'Diz kapağı mafsal kubbesi (dome) tanımlı olmalı');
            });

            // 66. Ajan 02: Osmanlı Çok Katmanlı Kıyafet ve Zırh Geometrisi (Kaftan, Kuşak, Çevşen, Börk)
            runCase('66. Osmanlı Çok Katmanlı Kıyafet ve Zırh Geometrisi (Kaftan, Kuşak, Çevşen, Börk)', () => {
                const reg = new SoldierVisualRegistry();
                const ottomanHigh = buildOttomanHighDefHumanBase('player', 'average');
                assert(Array.isArray(ottomanHigh) && ottomanHigh.length >= 24, 'Osmanlı yüksek detaylı gövdesi katmanlı kıyafet parçalarına sahip olmalı');

                // Kaftan kloş alt etek ve altın sırma kenar doğrulaması
                const hasFlaredSkirt = ottomanHigh.some(p => p.mat === 'ottomanCrimson' && p.prim === 'frustum' && p.rigGroup === 'torso');
                const hasGoldBorder = ottomanHigh.some(p => p.mat === 'gold' && p.prim === 'frustum' && p.rigGroup === 'torso');
                assert(hasFlaredSkirt && hasGoldBorder, 'Hacimli kaftan alt eteği ve altın sırma kenarlığı bulunmalı');

                // Börk ve Çevşen doğrulaması
                const borkParts = buildHighDefBork();
                assert(borkParts.length >= 5, 'Yüksek detaylı Börk en az 5 parçaya (zarf, taç, arka sarkan kumaş) sahip olmalı');
                const cevsenParts = buildHighDefCevsen();
                assert(cevsenParts.length >= 5, 'Yüksek detaylı Çevşen çelik disk ve bazuband kolçaklarına sahip olmalı');
            });

            // 67. Ajan 03: Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları (Doublet, Morion, Tapul)
            runCase('67. Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları (Doublet, Morion, Tapul)', () => {
                const euroHigh = buildEuropeanHighDefHumanBase('enemy', 'average');
                assert(Array.isArray(euroHigh) && euroHigh.length >= 24, 'Avrupa yüksek detaylı gövdesi peascod ceket ve yaka detaylarına sahip olmalı');

                // Kolalı keten yaka ve kılıç baldriği doğrulaması
                const hasCollar = euroHigh.some(p => p.mat === 'linen' && p.prim === 'frustum' && p.rigGroup === 'torso');
                const hasBaldric = euroHigh.some(p => p.mat === 'buffLeather' && p.rigGroup === 'torso');
                assert(hasCollar && hasBaldric, 'Düşen keten yaka ve deri süvari baldriği mevcut olmalı');

                // Morion miğfer ibiği ve Tapul zırh omurgası doğrulaması
                const morionParts = buildHighDefMorion();
                const hasComb = morionParts.some(p => p.mat === 'steel' && p.prim === 'box');
                assert(hasComb, 'Morion miğferi yüksek çelik ibiğe sahip olmalı');

                const tapulParts = buildHighDefTapulArmor();
                const hasSpine = tapulParts.some(p => p.mat === 'steel' && p.prim === 'box');
                assert(hasSpine, 'Tapul zırhı mermi saptırıcı çelik omurgaya ve tasset plakalarına sahip olmalı');
            });

            // 68. Ajan 04: Baş, Yüz Anatomisi, Yüz Kılları ve Miğfer Oturumu
            runCase('68. Baş, Yüz Anatomisi, Yüz Kılları ve Miğfer Oturumu', () => {
                const headMustache = buildAnatomicalHead('skin', 'wood', 'ottoman_pala');
                const headVandyke = buildAnatomicalHead('skin', 'wood', 'vandyke');
                const headBeard = buildAnatomicalHead('skin', 'wood', 'full_beard');

                assert(headMustache.length >= 9, 'Pala bıyıklı baş modeli anatomik yüz detaylarını içermeli');
                assert(headVandyke.length >= 9, 'Van Dyke sakallı Avrupa baş modeli anatomik yüz detaylarını içermeli');
                assert(headBeard.length >= 8, 'Tam sakallı gazi/veteran baş modeli tanımlı olmalı');

                // Burun köprüsü ve kulak kubbeleri doğrulaması
                const hasNose = headMustache.some(p => p.prim === 'cone' && p.mat === 'skin');
                const hasEars = headMustache.filter(p => p.prim === 'dome' && p.mat === 'skin').length === 2;
                assert(hasNose && hasEars, 'Belirgin burun köprüsü ve iki kulak kubbesi bulunmalı');
            });

            // 69. Ajan 05: 1650 İleri Malzeme Kütüphanesi ve PBR Yüzey Özellikleri
            runCase('69. 1650 İleri Malzeme Kütüphanesi ve PBR Yüzey Özellikleri', () => {
                const reg = new SoldierVisualRegistry();
                const expectedPBR = ['blackenedSteel', 'burnishedBronze', 'buffLeather', 'fineSilk', 'roughWool'];
                for (const matKey of expectedPBR) {
                    assert(reg.materials[matKey], `${matKey} PBR materyali kayıtlı olmalı`);
                    assert(reg.materials[matKey].color && typeof reg.materials[matKey].color.r === 'number', `${matKey} geçerli Color nesnesi içermeli`);
                }

                // Metalness kontrast doğrulaması: Karartılmış çelik yüksek metalness, manda derisi sıfıra yakın metalness içermeli
                assert(reg.materials.blackenedSteel.metalness > 0.75, 'blackenedSteel yüksek metalness içermeli');
                assert(reg.materials.buffLeather.metalness < 0.10, 'buffLeather mat deri olarak düşük metalness içermeli');

                // 206 temel model şablonunun kesin korunması
                assert(Object.keys(reg.templates).length === 206, '206 temel model şablonu tam olarak korunmalı');
            });

            // 70. Ajan 06: Modüler Asker Birleştirme Motoru ve Vitrin Model Kalitesi Kıyaslaması
            runCase('70. Modüler Asker Birleştirme Motoru ve Vitrin Model Kalitesi Kıyaslaması', () => {
                assert(typeof RTSModularUnitBuilder === 'function', 'RTSModularUnitBuilder sınıfı tanımlı olmalı');

                const soldier1 = RTSModularUnitBuilder.assembleSoldier('ottoman_janissary', 'player', 10);
                const soldier2 = RTSModularUnitBuilder.assembleSoldier('european_pikeniere', 'enemy', 11);
                assert(Array.isArray(soldier1) && soldier1.length >= 30, 'Modüler Yeniçeri en az 30 yüksek detaylı parçadan oluşmalı');
                assert(Array.isArray(soldier2) && soldier2.length >= 30, 'Modüler Pikeniere en az 30 yüksek detaylı parçadan oluşmalı');

                // Vitrin Kalite Modu Doğrulaması
                const mockRenderer = { cameraController: new RTSCamera3D() };
                const showcase = new RTSUnitShowcaseController(mockRenderer);
                assert(showcase.qualityMode === 'high', 'Asker vitrini varsayılan olarak G3D-03K yüksek kalite modunda başlamalı');

                const btnQuality = document.getElementById('btnShowcaseQualityToggle');
                assert(btnQuality, 'Model kalitesi geçiş butonu arayüzde mevcut olmalı');
            });




                assert(Math.abs(mockCam.desired.targetX) < 1e-4 && Math.abs(mockCam.desired.targetZ) < 1e-4, 'Minimap tıklaması dünya hedef koordinatını güncellemeli');
            });


                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const batches = testRenderer.soldierRegistry.batchGroup ? testRenderer.soldierRegistry.batchGroup.batches : [];
                assert(Array.isArray(batches) && batches.length === 7, 'Tam 7 asker çizim grubu (batch) bulunmalı, bulunan: ' + batches.length);
                const totalInstances = batches.reduce((acc, b) => acc + b.count, 0);
                assert(totalInstances > 0, 'Asker parçaları başarıyla batch tamponlarına işlenmeli: ' + totalInstances);

                const rimTangent = Math.pow(1.0, 3.2) * 0.32;
                const rimDirect = Math.pow(0.0, 3.2) * 0.32;
                assert(rimTangent >= 0.30, 'Kenar teğet rim faktörü silüet okunurluğu için >= 0.30 olmalı: ' + rimTangent);
                assert(rimDirect === 0.0, 'Doğrudan yüzeyde rim faktörü 0 olmalı');

                const startBench = performance.now();
                const frameCount = 60;
                for (let f = 0; f < frameCount; f++) {
                    testRenderer.stepSimulation(0.016);
                    if (testRenderer.renderer && testRenderer.scene && testRenderer.cameraController) {
                        testRenderer.renderer.render(testRenderer.scene, testRenderer.cameraController.camera);
                    }
                }
                const totalBenchTime = performance.now() - startBench;
                const avgFrameTime = totalBenchTime / frameCount;

                assert(!isNaN(avgFrameTime) && avgFrameTime >= 0, 'Frame süresi geçerli bir sayı olmalı');
                assert(avgFrameTime < 16.6, 'Simüle edilen frame süresi 60 FPS eşiğinde (< 16.6ms) kalmalı, bulunan: ' + avgFrameTime.toFixed(2) + 'ms');

                testRenderer.dispose();
            });

            return results;
        }

        /* ============================================================================
         * 7. DEVELOPER PREVIEW CONTROLLER + INFANTRY WALK, CAVALRY & COMBAT PREVIEWS
         * ============================================================================ */
        
        /* ============================================================================
         * MODULE: RTS_EQUIPMENT_POOLS & resolveUnitEquipment (Agent 04)
         * ============================================================================ */
        const RTS_EQUIPMENT_POOLS = {
            ottoman: {
                headwear: [
                    { id: 'bork_serpus', name: 'Beyaz Keçe Börk', type: 'infantry_elite', mat: 'ottomanWhite' },
                    { id: 'sarik_turban', name: 'Sarıklı Başlık', type: 'infantry_light', mat: 'ottomanWhite' },
                    { id: 'bostanci_kulah', name: 'Bostancı Külahı', type: 'guard', mat: 'ottomanCrimson' },
                    { id: 'sisak_tolga', name: 'Burunluklu Şişak / Tolga', type: 'cavalry', mat: 'damascusSteel' },
                    { id: 'deli_winged_hat', name: 'Kartal Kanatlı Deli Kalpağı', type: 'shock_cavalry', mat: 'ottomanCrimson' }
                ],
                armor: [
                    { id: 'kaftan_dolaman', name: 'İpek Kuşaklı Kaftan & Dolaman', type: 'cloth', mat: 'ottomanCrimson' },
                    { id: 'cevsen_plate_mail', name: 'Çelik Çevşen (Disk Plaka & Zırh Örme)', type: 'heavy', mat: 'damascusSteel' },
                    { id: 'char_aina_mirror', name: 'Çar-Ayna Dört Ayna Göğüslüğü', type: 'elite_heavy', mat: 'damascusSteel' },
                    { id: 'leather_yelek', name: 'Deri Yelek & Önlük', type: 'light', mat: 'leather' },
                    { id: 'leopard_pelt', name: 'Deli Pars / Kurt Postu', type: 'shock', mat: 'leopardPelt' }
                ],
                weapons: [
                    { id: 'ottoman_tufenk', name: 'Fitilli Osmanlı Tüfengi', range: 'ranged', mat: 'damascusSteel' },
                    { id: 'yatagan_sword', name: 'Fildişi Kabzalı Yatağan', range: 'melee', mat: 'damascusSteel' },
                    { id: 'kilic_shamshir', name: 'Eğri Türk Kılıcı (Şemşir)', range: 'melee', mat: 'damascusSteel' },
                    { id: 'sipahi_kargi', name: '4 Metrelik Bayraklı Sipahi Kargısı', range: 'polearm', mat: 'wood' },
                    { id: 'humbara_grenade', name: 'Demir Döküm Humbara', range: 'explosive', mat: 'darkSteel' },
                    { id: 'crescent_teber', name: 'Hilal Ağızlı Muhafız Teberi', range: 'polearm', mat: 'damascusSteel' },
                    { id: 'cirit_spears', name: 'Süvari Cirit Sadakı (3 Cirit)', range: 'thrown', mat: 'wood' },
                    { id: 'recurve_bow', name: 'Kompozit Akıncı Yayı & Tirkeş', range: 'ranged', mat: 'wood' }
                ],
                shields: [
                    { id: 'wicker_kalkan', name: 'Örme Hasır & Çelik Kalkan', mat: 'gold' },
                    { id: 'steel_kalkan', name: 'Çelik Sipahi Kalkanı', mat: 'damascusSteel' }
                ],
                mounts: [
                    { id: 'ottoman_courser', name: 'Arap / Anadolu Savaş Atı (İşlemeli Çaprak)', mat: 'courser_horse' },
                    { id: 'ottoman_barded', name: 'Zırhlı Alınlıklı Kapıkulu Atı (Alınlık & Boyunluk)', mat: 'heavy_warhorse' },
                    { id: 'steppe_pony', name: 'Hızlı Step Akıncı Atı', mat: 'steppe_horse' }
                ]
            },
            european: {
                headwear: [
                    { id: 'morion_comb', name: 'İspanyol / Alman İbikli Morion Miğfer', type: 'infantry', mat: 'steel' },
                    { id: 'burgonet_peak', name: 'Siperlikli Burgonet Miğfer', type: 'cavalry', mat: 'steel' },
                    { id: 'zischagge_bars', name: 'Üç Çubuklu Zischägge (Demir Başlık)', type: 'cavalry', mat: 'darkSteel' },
                    { id: 'cavalier_plume', name: 'Devekuşu Tüylü Geniş Süvari Şapkası', type: 'ranged', mat: 'darkCloth' }
                ],
                armor: [
                    { id: 'tapul_breastplate', name: 'Sivri Omurgalı Tapul Göğüs Zırhı & Tasset', type: 'heavy', mat: 'steel' },
                    { id: 'cuirassier_three_quarter', name: 'Üç Çeyrek Karartılmış Çelik Plaka', type: 'super_heavy', mat: 'darkSteel' },
                    { id: 'buff_coat', name: 'Kalın Süvari Manda Derisi Kolsuz Yelek (Buff Coat)', type: 'medium', mat: 'leather' },
                    { id: 'apostles_bandolier', name: 'On İki Havari Fişeklik Bandolye', type: 'ranged', mat: 'leather' }
                ],
                weapons: [
                    { id: 'european_matchlock', name: 'Fitilli Ağır Tüfek ve Çatal Ayak', range: 'ranged', mat: 'steel' },
                    { id: 'pike_long', name: '4.5 Metrelik Kül Dişbudak Piyade Kargısı', range: 'polearm', mat: 'wood' },
                    { id: 'halberd_hook', name: 'Gaga Kancalı ve Sivri Uçlu Hellebarda', range: 'polearm', mat: 'steel' },
                    { id: 'broadsword_rapier', name: 'Geniş Ağızlı Çift Oluklu Süvari Kılıcı', range: 'melee', mat: 'steel' },
                    { id: 'wheellock_pair', name: 'Çift Çarklı Piştov & Eyer Kılıfı', range: 'ranged', mat: 'steel' },
                    { id: 'wheellock_carbine', name: 'Çarklı Süvari Karabinası', range: 'ranged', mat: 'steel' }
                ],
                shields: [
                    { id: 'target_buckler', name: 'Yuvarlak Çelik Buckler', mat: 'steel' }
                ],
                mounts: [
                    { id: 'german_warmblood', name: 'Ağır Alman Savaş Atı', mat: 'heavy_warhorse' },
                    { id: 'reiter_charger', name: 'Hızlı Karabinier Atı', mat: 'charger_horse' }
                ]
            }
        };

        function resolveUnitEquipment(culture, unitClass, seed = 0) {
            const pool = RTS_EQUIPMENT_POOLS[culture] || RTS_EQUIPMENT_POOLS.ottoman;
            const s = Math.abs(seed);
            const headwear = pool.headwear[s % pool.headwear.length];
            const armor = pool.armor[(s + 1) % pool.armor.length];
            const weapon = pool.weapons[(s + 2) % pool.weapons.length];
            const shield = pool.shields[(s + 3) % pool.shields.length];
            const mount = pool.mounts[(s + 4) % pool.mounts.length];

            return {
                culture,
                unitClass,
                headwear,
                armor,
                weapon,
                shield,
                mount,
                seed
            };
        }

        /* ============================================================================
         * MODULE: RTSUnitShowcaseController (Agent 06 - Asker Vitrini & Karşılaştırma)
         * ============================================================================ */
        class RTSUnitShowcaseController {
            constructor(renderer) {
                this.renderer = renderer;
                this.overlay = document.getElementById('rtsShowcaseOverlay');
                this.unitListEl = document.getElementById('showcaseUnitList');
                this.currentCulture = 'ottoman';
                this.selectedUnitKey = 'janissary';
                this.selectedVariant = 1;
                this.selectedAnim = 'idle';
                this.compareMode = false;
                this.qualityMode = "high"; // "high" (G3D-03K) vs "classic" (G3D-03J)

                this.unitCatalog = {
                    ottoman: [
                        { key: 'janissary', name: 'Yeniçeri', role: 'Seçkin Tüfekli/Yatağanlı Kapıkulu Piyadesi', template: 'ottoman:janissary', weapon1: 'Fitilli Osmanlı Tüfengi', weapon2: 'Fildişi Yatağan & Çevşen', headwear: 'Börk (Serpuş)', armor: 'Kaftan & Kuşak' },
                        { key: 'azap', name: 'Azap', role: 'Hafif Sefer Piyadesi & Tırpanlı/Kılıçlı Hat Askeri', template: 'ottoman:azap', weapon1: '3.85m Tırpan Kargı', weapon2: 'Eğri Kılıç & Kalkan', headwear: 'Sarıklı Başlık', armor: 'Keten Yelek & Şalvar' },
                        { key: 'humbaraci', name: 'Humbaracı', role: 'Kuşatma ve Alan Hasarlı Patlayıcı Birliği', template: 'ottoman:humbaraci', weapon1: 'Demir Döküm Humbara Bombası', weapon2: 'Kısa Piştov & Yatağan', headwear: 'Yeşil Sarık', armor: 'Deri Bomba Önlüğü' },
                        { key: 'bostanci', name: 'Bostancı', role: 'Saray Muhafızı Ağır Teberli Şok Piyadesi', template: 'ottoman:bostanci', weapon1: 'Hilal Muhafız Teberi', weapon2: 'Ağır Saray Tüfengi', headwear: 'Bostancı Külahı', armor: 'Çelik Çevşen Plaka' },
                        { key: 'levend', name: 'Levend', role: 'Sahil ve Düzensiz Tüfekçi/Piştovcu', template: 'ottoman:levend', weapon1: 'Çift Piştov & Tırpan', weapon2: 'Fitilli Balkan Tüfengi', headwear: 'Çizgili Sarık', armor: 'Açık Göğüs Yelek' },
                        { key: 'sipahi', name: 'Sipahi', role: 'Tımarlı Süvari (Kargı & Kalkan)', template: 'ottoman:sipahi', weapon1: '4m Bayraklı Kargı & Kalkan', weapon2: 'Türk Kılıcı (Şemşir)', headwear: 'Şişak / Tolga Miğfer', armor: 'Çelik Çevşen & Kolçak' },
                        { key: 'kapikulu_sipahi', name: 'Kapıkulu Sipahisi', role: 'Hassa Ağır Süvarisi (Zırhlı At & Çar-Ayna)', template: 'ottoman:kapikulu_sipahi', weapon1: 'Ağır Süvari Kargısı', weapon2: 'Şeşper Ağır Gürz', headwear: 'Zırh Peçeli Tolga', armor: 'Çar-Ayna Dört Ayna Plaka' },
                        { key: 'deli', name: 'Deli Süvarisi', role: 'Korkusuz Şok ve Hücum Öncü Süvarisi', template: 'ottoman:deli', weapon1: 'Hafif Şok Kargısı', weapon2: 'Eğri Kılıç', headwear: 'Kartal Kanatlı Kalpak', armor: 'Pars / Kurt Postu' },
                        { key: 'ciritci', name: 'Ciritçi', role: 'Cirit Atan Çevik Taciz Süvarisi', template: 'ottoman:ciritci', weapon1: 'Süvari Cirit Sadakı (3 Cirit)', weapon2: 'Hafif Süvari Kılıcı', headwear: 'Deri Başlık', armor: 'Hafif Deri Zırh' },
                        { key: 'akinci', name: 'Akıncı', role: 'Menzilli Step ve Yay Süvarisi', template: 'ottoman:akinci', weapon1: 'Kompozit Yay & Ok Sadakı', weapon2: 'Kargı & Süvari Kılıcı', headwear: 'Keçe Külah', armor: 'Deri Yelek' }
                    ],
                    european: [
                        { key: 'musketier', name: 'Musketier (Tüfekçi)', role: '17. Yüzyıl Fitilli Ağır Tüfekçi', template: 'european:musketier', weapon1: 'Fitilli Musket & Çatal Ayak', weapon2: 'Kısa Süvari Kılıcı', headwear: 'Geniş Şapka & Tüy', armor: '12 Havariler Bandolyesi' },
                        { key: 'pikeniere', name: 'Pikeniere (Mızrakçı)', role: '4.5m Ağır Piyade Kargıcısı', template: 'european:pikeniere', weapon1: '4.5m Kül Dişbudak Pikesi', weapon2: 'Kısa Kılıç', headwear: 'İbikli Morion Miğfer', armor: 'Tapul Göğüslük & Tasset' },
                        { key: 'hellebardier', name: 'Hellebardier', role: 'Kancalı ve Baltalı Çok Amaçlı Piyade', template: 'european:hellebardier', weapon1: 'Gaga Kancalı Hellebarda', weapon2: 'Buckler & Kılıç', headwear: 'Burgonet Miğfer', armor: 'Karartılmış Plaka Zırh' },
                        { key: 'curassier', name: 'Kürassier', role: 'Üç Çeyrek Zırhlı Tabancalı Ağır Süvari', template: 'european:curassier', weapon1: 'Çift Çarklı Piştov', weapon2: 'Geniş Süvari Kılıcı', headwear: 'Zischägge Miğfer', armor: 'Üç Çeyrek Karartılmış Plaka' },
                        { key: 'reiter', name: 'Reiter (Karabinier)', role: 'Zırhlı Çarklı Karabinalı Süvari', template: 'european:reiter', weapon1: 'Çarklı Karabina', weapon2: 'Çift Tabanca', headwear: 'Süvari Şapkası', armor: 'Demir Göğüslük & Buff Coat' }
                    ]
                };

                this._initEvents();
            }

            _initEvents() {
                const btnOpen = document.getElementById('btnOpenShowcase');
                const btnClose = document.getElementById('btnCloseShowcase');
                const btnOttoman = document.getElementById('btnShowcaseOttoman');
                const btnEuropean = document.getElementById('btnShowcaseEuropean');
                const btnV1 = document.getElementById('btnShowcaseVariant1');
                const btnV2 = document.getElementById('btnShowcaseVariant2');
                const btnIdle = document.getElementById('btnShowcaseAnimIdle');
                const btnWalk = document.getElementById('btnShowcaseAnimWalk');
                const btnAttack = document.getElementById('btnShowcaseAnimAttack');
                const btnGuard = document.getElementById('btnShowcaseAnimGuard');
                const btnCompare = document.getElementById('btnShowcaseCompareToggle');
                const btnQuality = document.getElementById('btnShowcaseQualityToggle');
                if (btnQuality) {
                    btnQuality.addEventListener('click', () => {
                        this.qualityMode = this.qualityMode === 'high' ? 'classic' : 'high';
                        btnQuality.textContent = this.qualityMode === 'high' ? '✨ Model Kalitesi: G3D-03K (Detaylı)' : '📦 Model Kalitesi: G3D-03J (Klasik)';
                        btnQuality.classList.toggle('active', this.qualityMode === 'high');
                        this.updateInfoCard();
                    });
                }

                if (btnOpen) btnOpen.addEventListener('click', () => this.open());
                if (btnClose) btnClose.addEventListener('click', () => this.close());

                if (btnOttoman) btnOttoman.addEventListener('click', () => {
                    this.setCulture('ottoman');
                    btnOttoman.classList.add('active');
                    if (btnEuropean) btnEuropean.classList.remove('active');
                });

                if (btnEuropean) btnEuropean.addEventListener('click', () => {
                    this.setCulture('european');
                    btnEuropean.classList.add('active');
                    if (btnOttoman) btnOttoman.classList.remove('active');
                });

                if (btnV1) btnV1.addEventListener('click', () => {
                    this.setVariant(1);
                    btnV1.classList.add('active');
                    if (btnV2) btnV2.classList.remove('active');
                });

                if (btnV2) btnV2.addEventListener('click', () => {
                    this.setVariant(2);
                    btnV2.classList.add('active');
                    if (btnV1) btnV1.classList.remove('active');
                });

                const animBtns = [
                    { el: btnIdle, anim: 'idle' },
                    { el: btnWalk, anim: 'walk' },
                    { el: btnAttack, anim: 'attack' },
                    { el: btnGuard, anim: 'guard' }
                ];
                animBtns.forEach(item => {
                    if (item.el) {
                        item.el.addEventListener('click', () => {
                            animBtns.forEach(b => b.el && b.el.classList.remove('active'));
                            item.el.classList.add('active');
                            this.setAnim(item.anim);
                        });
                    }
                });

                if (btnCompare) {
                    btnCompare.addEventListener('click', () => {
                        this.toggleCompare();
                        btnCompare.classList.toggle('active', this.compareMode);
                    });
                }
            }

            open() {
                if (this.overlay) {
                    this.overlay.style.display = 'flex';
                }
                this.renderUnitList();
                this.updateInfoCard();
            }

            close() {
                if (this.overlay) {
                    this.overlay.style.display = 'none';
                }
            }

            setCulture(cult) {
                this.currentCulture = cult;
                const units = this.unitCatalog[cult] || [];
                if (units.length > 0) {
                    this.selectedUnitKey = units[0].key;
                }
                this.renderUnitList();
                this.updateInfoCard();
            }

            setVariant(v) {
                this.selectedVariant = v;
                this.updateInfoCard();
            }

            setAnim(a) {
                this.selectedAnim = a;
                this.updateInfoCard();
            }

            toggleCompare() {
                this.compareMode = !this.compareMode;
                this.updateInfoCard();
            }

            renderUnitList() {
                if (!this.unitListEl) return;
                this.unitListEl.innerHTML = '';
                const units = this.unitCatalog[this.currentCulture] || [];
                units.forEach(u => {
                    const item = document.createElement('div');
                    item.className = 'showcase-unit-item' + (u.key === this.selectedUnitKey ? ' active' : '');
                    item.innerHTML = `<span>${u.name}</span> <span style="font-size:10px; opacity:0.6;">${u.key.includes('sipahi') || u.key.includes('deli') || u.key.includes('ciritci') || u.key.includes('akinci') || u.key.includes('curassier') || u.key.includes('reiter') ? 'Süvari' : 'Piyade'}</span>`;
                    item.addEventListener('click', () => {
                        this.selectedUnitKey = u.key;
                        this.renderUnitList();
                        this.updateInfoCard();
                    });
                    this.unitListEl.appendChild(item);
                });
            }

            updateInfoCard() {
                const titleEl = document.getElementById('showcaseInfoTitle');
                const descEl = document.getElementById('showcaseInfoDesc');
                const specsEl = document.getElementById('showcaseInfoSpecs');
                if (!titleEl || !descEl || !specsEl) return;

                const units = this.unitCatalog[this.currentCulture] || [];
                const currentUnit = units.find(u => u.key === this.selectedUnitKey) || units[0];
                if (!currentUnit) return;

                const isCav = currentUnit.key.includes('sipahi') || currentUnit.key.includes('deli') || currentUnit.key.includes('ciritci') || currentUnit.key.includes('akinci') || currentUnit.key.includes('curassier') || currentUnit.key.includes('reiter');
                const cultTitle = this.currentCulture === 'ottoman' ? 'Osmanlı Ordusu' : 'Avrupa / Kutsal Roma';

                titleEl.textContent = `${currentUnit.name} — ${cultTitle} (Varyant ${this.selectedVariant})`;
                const qText = this.qualityMode === 'high' ? 'G3D-03K Yüksek Kalite (Anatomik Gövde, Katmanlı Kıyafet, Etek Fırfırı, Gerçekçi Başlık & Çevşen/Tapul)' : 'G3D-03J Klasik Düzey (Temel Geometrik Gövde)';
                descEl.textContent = `${currentUnit.role}. 1648–1650 dönemine uygun otantik malzeme ve anatomik parçalarla modellenmiştir. Kalite Düzeyi: ${qText}. Seçili Animasyon: ${this.selectedAnim.toUpperCase()}.`;

                const activeWeapon = this.selectedVariant === 1 ? currentUnit.weapon1 : currentUnit.weapon2;

                if (!this.compareMode) {
                    specsEl.innerHTML = `
                        <div>Sınıf: <strong>${isCav ? 'Süvari' : 'Piyade'}</strong></div>
                        <div>Kültür: <strong>${cultTitle}</strong></div>
                        <div>Aktif Silah: <strong>${activeWeapon}</strong></div>
                        <div>Başlık: <strong>${currentUnit.headwear}</strong></div>
                        <div>Zırh: <strong>${currentUnit.armor}</strong></div>
                        <div>Şablon Anahtarı: <strong>${currentUnit.template}:v${this.selectedVariant}</strong></div>
                        <div>Anatomi & Profil: <strong>${this.qualityMode === 'high' ? '3 Beden Profili (Slim/Avg/Heavy)' : 'Standart'}</strong></div>
                        <div>Model Standardı: <strong>${this.qualityMode === 'high' ? 'Age of Empires III DE Seviyesi' : 'G3D-03J'}</strong></div>
                    `;
                } else {
                    // Compare mode: compare current unit with parallel foreign unit
                    const otherCulture = this.currentCulture === 'ottoman' ? 'european' : 'ottoman';
                    const foreignUnits = this.unitCatalog[otherCulture] || [];
                    const foreignUnit = foreignUnits.find(u => {
                        const foreignCav = u.key.includes('sipahi') || u.key.includes('deli') || u.key.includes('ciritci') || u.key.includes('akinci') || u.key.includes('curassier') || u.key.includes('reiter');
                        return foreignCav === isCav;
                    }) || foreignUnits[0];

                    specsEl.innerHTML = `
                        <div>[${currentUnit.name}]: <strong>${activeWeapon}</strong></div>
                        <div>[${foreignUnit.name}]: <strong>${foreignUnit.weapon1}</strong></div>
                        <div>Başlık Karşılaştırma: <strong>${currentUnit.headwear} vs ${foreignUnit.headwear}</strong></div>
                        <div>Zırh Tipi: <strong>${currentUnit.armor} vs ${foreignUnit.armor}</strong></div>
                        <div>Karşılaştırma Modu: <strong>Aktif (Yan Yana)</strong></div>
                        <div>Durum: <strong>Dengeli RTS Eşleşmesi</strong></div>
                    `;
                }
            }
        }

class Battle3DPreviewController {
            constructor() {
                this.renderer = null;
                this.sectorManager = null;
                this.currentMode = 'test';
                this.activeSectorIdx = 0;

                this.walkPreviewActive = false;
                this.walkPreviewElapsed = 0;
                this.walkPreviewNextLegAt = 0;
                this.walkPreviewLeg = 0;

                this.cavalryPreviewActive = false;
                this.cavalryPreviewElapsed = 0;
                this.cavalryPreviewNextLegAt = 0;
                this.cavalryPreviewLeg = 0;

                this.horseTypesPreviewActive = false;
                this.horseTypesPreviewElapsed = 0;
                this.horseTypesPreviewNextLegAt = 0;
                this.horseTypesPreviewLeg = 0;

                this.combatPreviewActive = false;
                this.combinedPreviewActive = false;
                this.combinedPreviewElapsed = 0;
                this.combinedPreviewNextLegAt = 0;
                this.combinedPreviewLeg = 0;

                this._savedCameraStateBeforeWalk = null;
                this._headerResizeObserver = null;
                this._boundSyncLayout = this._syncResponsiveLayout.bind(this);

                this.dom = {
                    header: document.getElementById('focHeader'),
                    footer: document.getElementById('focFooter'),
                    sidebar: document.getElementById('focSidebar'),
                    btnToggleSidebar: document.getElementById('btnToggleSidebar'),
                    mount: document.getElementById('battle3dMount'),
                    fallbackScreen: document.getElementById('fallbackScreen'),
                    fallbackIcon: document.getElementById('fallbackIcon'),
                    fallbackTitle: document.getElementById('fallbackTitle'),
                    fallbackMessage: document.getElementById('fallbackMessage'),
                    btnModeTest: document.getElementById('btnModeTest'),
                    btnModeEmpty: document.getElementById('btnModeEmpty'),
                    btnModeNoWebGL: document.getElementById('btnModeNoWebGL'),
                    btnSimContextLoss: document.getElementById('btnSimContextLoss'),
                    btnDispose: document.getElementById('btnDispose'),
                    btnReinit: document.getElementById('btnReinit'),
                    btnRunTests: document.getElementById('btnRunTests'),
                    btnCloseTests: document.getElementById('btnCloseTests'),
                    btnToggleWalkPreview: document.getElementById('btnToggleWalkPreview'),
                    btnToggleCavalryPreview: document.getElementById('btnToggleCavalryPreview'),
                    btnToggleHorseTypesPreview: document.getElementById('btnToggleHorseTypesPreview'),
                    btnToggleCombatPreview: document.getElementById('btnToggleCombatPreview'),
                    btnToggleCombinedPreview: document.getElementById('btnToggleCombinedPreview'),
                    unitTestPanel: document.getElementById('unitTestPanel'),
                    unitTestSummary: document.getElementById('unitTestSummary'),
                    unitTestList: document.getElementById('unitTestList'),
                    btnSector0: document.getElementById('btnSector0'),
                    btnSector1: document.getElementById('btnSector1'),
                    btnSector2: document.getElementById('btnSector2'),
                    btnRotLeft: document.getElementById('btnRotLeft'),
                    btnRotRight: document.getElementById('btnRotRight'),
                    btnZoomIn: document.getElementById('btnZoomIn'),
                    btnZoomOut: document.getElementById('btnZoomOut'),
                    btnFocus: document.getElementById('btnFocus'),
                    dataSourceBadge: document.getElementById('dataSourceBadge'),
                    vmSectorId: document.getElementById('vmSectorId'),
                    vmSectorBounds: document.getElementById('vmSectorBounds'),
                    vmGroupCount: document.getElementById('vmGroupCount'),
                    vmSoldierCount: document.getElementById('vmSoldierCount'),
                    vmRendered3D: document.getElementById('vmRendered3D'),
                    vmClassBreakdown: document.getElementById('vmClassBreakdown'),
                    vmCavalryWeapons: document.getElementById('vmCavalryWeapons'),
                    vmLimits: document.getElementById('vmLimits'),
                    lifecycleStatus: document.getElementById('lifecycleStatus'),
                    renderPathStatus: document.getElementById('renderPathStatus'),
                    cameraTelemetry: document.getElementById('cameraTelemetry')
                };
            }

            init() {
                this._buildSectorManager('test');
                this._bindUIEvents();
                this._bindRTSUIEvents();

                this.showcaseController = new RTSUnitShowcaseController(this.renderer);
                window.focShowcase = this.showcaseController;

                this._syncResponsiveLayout();
                this.startScene();
                requestAnimationFrame(() => this._syncResponsiveLayout());
            }

            _syncResponsiveLayout() {
                if (typeof document === 'undefined' || !document.documentElement) return;
                const rootStyle = document.documentElement.style;
                const viewportH = window.innerHeight || 900;

                if (this.dom.header) {
                    const hRect = this.dom.header.getBoundingClientRect();
                    if (hRect.height > 0) {
                        rootStyle.setProperty('--header-bottom', `${Math.ceil(hRect.bottom + 10)}px`);
                    }
                }

                if (this.dom.footer) {
                    const fRect = this.dom.footer.getBoundingClientRect();
                    if (fRect.height > 0) {
                        const bottomOffset = Math.max(54, Math.ceil(viewportH - fRect.top + 8));
                        rootStyle.setProperty('--footer-top', `${bottomOffset}px`);
                    }
                }
            }

            _buildSectorManager(mode) {
                const sm = new SectorManager();
                if (mode === 'test') {
                    const battleData = createTestBattleData();
                    sm.initSectors(battleData.sectorCount, battleData.playerGroups, battleData.enemyGroups);
                    sm.setActiveSector(this.activeSectorIdx);
                } else {
                    sm.initSectors(1, [], []);
                }
                this.sectorManager = sm;
            }

            _getSnapshot() {
                return projectActiveSector3D(this.sectorManager);
            }

            _buildWalkPreviewSnapshot(legIndex) {
                const baseSnapshot = this._getSnapshot();
                if (!baseSnapshot || !Array.isArray(baseSnapshot.soldiers) || baseSnapshot.soldiers.length === 0) {
                    return {
                        snapshot: baseSnapshot,
                        focusCenter: { x: 0, z: 0 }
                    };
                }

                const offsets = [
                    { dx: 6.0, dz: 0.0 },
                    { dx: 6.0, dz: 3.6 },
                    { dx: 0.0, dz: 3.6 },
                    { dx: 0.0, dz: 0.0 }
                ];
                const step = offsets[legIndex % offsets.length];

                const quotas = {
                    player_pikeman: 4,
                    player_musketeer: 4,
                    enemy_pikeman: 4,
                    enemy_musketeer: 4
                };

                let sumPlayerFocusX = 0;
                let sumPlayerFocusZ = 0;
                let playerFocusCount = 0;

                const clonedSoldiers = baseSnapshot.soldiers.map((s) => {
                    const isInfantry = s.bodyType === 'human' && (s.mountType === 'foot' || !s.mountType);
                    const archetype = classifySoldierArchetype(s);
                    let selectedForWalk = false;

                    if (isInfantry) {
                        if (s.side === 'player' && archetype === 'infantry_pikeman' && quotas.player_pikeman > 0) {
                            quotas.player_pikeman--;
                            selectedForWalk = true;
                        } else if (s.side === 'player' && archetype === 'infantry_musketeer' && quotas.player_musketeer > 0) {
                            quotas.player_musketeer--;
                            selectedForWalk = true;
                        } else if (s.side === 'enemy' && archetype === 'infantry_pikeman' && quotas.enemy_pikeman > 0) {
                            quotas.enemy_pikeman--;
                            selectedForWalk = true;
                        } else if (s.side === 'enemy' && archetype === 'infantry_musketeer' && quotas.enemy_musketeer > 0) {
                            quotas.enemy_musketeer--;
                            selectedForWalk = true;
                        }
                    }

                    if (selectedForWalk) {
                        const dir = s.side === 'enemy' ? -1 : 1;
                        const nextX = Math.round((s.position.x + dir * step.dx) * 100) / 100;
                        const nextZ = Math.round((s.position.z + dir * step.dz) * 100) / 100;

                        if (s.side === 'player') {
                            sumPlayerFocusX += (s.position.x + nextX) * 0.5;
                            sumPlayerFocusZ += (s.position.z + nextZ) * 0.5;
                            playerFocusCount++;
                        }

                        return {
                            ...s,
                            weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                            armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                            position: {
                                x: nextX,
                                y: s.position.y,
                                z: nextZ
                            }
                        };
                    }

                    return {
                        ...s,
                        weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                        armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                        position: { ...s.position }
                    };
                });

                return {
                    snapshot: {
                        ...baseSnapshot,
                        soldiers: clonedSoldiers
                    },
                    focusCenter: playerFocusCount > 0
                        ? { x: sumPlayerFocusX / playerFocusCount, z: sumPlayerFocusZ / playerFocusCount }
                        : { x: -17.0, z: -19.88 }
                };
            }

            _buildCavalryPreviewSnapshot(legIndex) {
                const baseSnapshot = this._getSnapshot();
                if (!baseSnapshot || !Array.isArray(baseSnapshot.soldiers) || baseSnapshot.soldiers.length === 0) {
                    return {
                        snapshot: baseSnapshot,
                        focusCenter: { x: -31.0, z: 4.0 }
                    };
                }

                const offsets = [
                    { dx: 2.8, dz: 0.0 },
                    { dx: 9.2, dz: 3.4 },
                    { dx: 9.2, dz: -3.4 },
                    { dx: 0.0, dz: 0.0 }
                ];
                const step = offsets[legIndex % offsets.length];

                let playerCavQuota = 6;
                let enemyCavQuota = 6;
                let sumPlayerCavX = 0;
                let sumPlayerCavZ = 0;
                let playerCavCount = 0;

                const clonedSoldiers = baseSnapshot.soldiers.map((s) => {
                    const isMounted = s.bodyType === 'mounted' || (s.mountType && s.mountType !== 'foot');
                    let selectedForCavPreview = false;

                    if (isMounted) {
                        if (s.side === 'player' && playerCavQuota > 0) {
                            playerCavQuota--;
                            selectedForCavPreview = true;
                        } else if (s.side === 'enemy' && enemyCavQuota > 0) {
                            enemyCavQuota--;
                            selectedForCavPreview = true;
                        }
                    }

                    if (selectedForCavPreview) {
                        const dir = s.side === 'enemy' ? -1 : 1;
                        const nextX = Math.round((s.position.x + dir * step.dx) * 100) / 100;
                        const nextZ = Math.round((s.position.z + dir * step.dz) * 100) / 100;

                        if (s.side === 'player') {
                            sumPlayerCavX += (s.position.x + nextX) * 0.5;
                            sumPlayerCavZ += (s.position.z + nextZ) * 0.5;
                            playerCavCount++;
                        }

                        return {
                            ...s,
                            weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                            armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                            position: {
                                x: nextX,
                                y: s.position.y,
                                z: nextZ
                            }
                        };
                    }

                    return {
                        ...s,
                        weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                        armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                        position: { ...s.position }
                    };
                });

                return {
                    snapshot: {
                        ...baseSnapshot,
                        soldiers: clonedSoldiers
                    },
                    focusCenter: playerCavCount > 0
                        ? { x: sumPlayerCavX / playerCavCount, z: sumPlayerCavZ / playerCavCount }
                        : { x: -31.0, z: 4.0 }
                };
            }

            /**
             * Builds a cloned, temporary snapshot for the Infantry Combat Poses Preview toggle
             * without mutating SectorManager or changing any soldier's viewId, unitClass,
             * activeWeapon, weaponLoadout, armorLoadout, mountType, position, or hp.
             * Selects 16 existing front-line pikemen & musketeers/arquebusiers (4 player
             * pikemen, 4 player musketeers, 4 enemy tercio pikemen, 4 enemy arquebusiers)
             * and sets `state: 'attack'` on their cloned visual entries only.
             */
            _buildCombatPreviewSnapshot() {
                const baseSnapshot = this._getSnapshot();
                if (!baseSnapshot || !Array.isArray(baseSnapshot.soldiers) || baseSnapshot.soldiers.length === 0) {
                    return {
                        snapshot: baseSnapshot,
                        focusCenter: { x: -18.5, z: -15.0 }
                    };
                }

                const quotas = {
                    player_pikeman: 4,
                    player_musketeer: 4,
                    enemy_pikeman: 4,
                    enemy_musketeer: 4
                };

                let sumFocusX = 0;
                let sumFocusZ = 0;
                let focusCount = 0;

                const clonedSoldiers = baseSnapshot.soldiers.map((s) => {
                    const isInfantry = s.bodyType === 'human' && (s.mountType === 'foot' || !s.mountType);
                    const archetype = classifySoldierArchetype(s);
                    let selectedForCombat = false;

                    if (isInfantry) {
                        if (s.side === 'player' && archetype === 'infantry_pikeman' && quotas.player_pikeman > 0) {
                            quotas.player_pikeman--;
                            selectedForCombat = true;
                        } else if (s.side === 'player' && archetype === 'infantry_musketeer' && quotas.player_musketeer > 0) {
                            quotas.player_musketeer--;
                            selectedForCombat = true;
                        } else if (s.side === 'enemy' && archetype === 'infantry_pikeman' && quotas.enemy_pikeman > 0) {
                            quotas.enemy_pikeman--;
                            selectedForCombat = true;
                        } else if (s.side === 'enemy' && archetype === 'infantry_musketeer' && quotas.enemy_musketeer > 0) {
                            quotas.enemy_musketeer--;
                            selectedForCombat = true;
                        }
                    }

                    if (selectedForCombat && s.side === 'player') {
                        sumFocusX += s.position.x;
                        sumFocusZ += s.position.z;
                        focusCount++;
                    }

                    return {
                        ...s,
                        state: selectedForCombat ? 'attack' : s.state,
                        weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                        armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                        position: { ...s.position }
                    };
                });

                return {
                    snapshot: {
                        ...baseSnapshot,
                        soldiers: clonedSoldiers
                    },
                    focusCenter: focusCount > 0
                        ? { x: sumFocusX / focusCount, z: sumFocusZ / focusCount }
                        : { x: -20.0, z: -16.0 }
                };
            }

            /**
             * Displays exemplars of all 5 canonical 1650 mounts (heavy_warhorse, charger_horse,
             * courser_horse, rouncey_horse, steppe_horse) side-by-side with appropriate riders,
             * barding and arms, cycling through 4-beat walk, 2-beat diagonal trot, and halt.
             */
            _buildHorseTypesPreviewSnapshot(legIndex = 0) {
                const offsets = [
                    { dx: 2.8, dz: 0.0 },   // leg 0: 4-beat walk
                    { dx: 9.6, dz: 3.2 },   // leg 1: 2-beat diagonal trot
                    { dx: 9.6, dz: -3.2 },  // leg 2: trot return
                    { dx: 0.0, dz: 0.0 }    // leg 3: halt / exact rest pose
                ];
                const step = offsets[legIndex % offsets.length];

                const horseDefs = [
                    { id: 'show_warhorse', mountType: 'warhorse', unitClass: 'cuirassier', weapon: 'cavalry_sabre', armor: ['three_quarter_plate'], side: 'player', x: -8.0, z: -4.0 },
                    { id: 'show_charger',  mountType: 'charger',  unitClass: 'reiter',     weapon: 'cavalry_pistol', armor: ['blackened_cuirass'], side: 'enemy',  x: -4.0, z: -4.0 },
                    { id: 'show_courser',  mountType: 'courser',  unitClass: 'harquebusier', weapon: 'cavalry_carbine', armor: ['burgonet'], side: 'player', x: 0.0, z: -4.0 },
                    { id: 'show_rouncey',  mountType: 'rouncey',  unitClass: 'dragoon',    weapon: 'cavalry_carbine', armor: ['leather_jerkin'], side: 'player', x: 4.0, z: -4.0 },
                    { id: 'show_steppe',   mountType: 'steppe_horse', unitClass: 'light_cavalry', weapon: 'cavalry_lance', armor: ['mail_shirt'], side: 'enemy',  x: 8.0, z: -4.0 }
                ];

                const soldiers = horseDefs.map((hd) => {
                    const dir = hd.side === 'enemy' ? -1 : 1;
                    const nextX = Math.round((hd.x + dir * step.dx) * 100) / 100;
                    const nextZ = Math.round((hd.z + dir * step.dz) * 100) / 100;

                    return {
                        viewId: `SEC_SHOWCASE:${hd.id}`,
                        sectorId: 'SEC_SHOWCASE',
                        side: hd.side,
                        groupId: `grp_${hd.id}`,
                        soldierId: hd.id,
                        unitClass: hd.unitClass,
                        bodyType: 'mounted',
                        mountType: hd.mountType,
                        activeWeapon: hd.weapon,
                        weaponLoadout: [hd.weapon],
                        armorLoadout: hd.armor,
                        position: { x: nextX, y: 0, z: nextZ },
                        state: 'ready',
                        hp: 100
                    };
                });

                return {
                    snapshot: {
                        sectorId: 'SEC_SHOWCASE',
                        bounds: { minX: -40, maxX: 40, minZ: -40, maxZ: 40 },
                        soldiers,
                        visible: { player: 3, enemy: 2 },
                        hiddenAlive: { player: 0, enemy: 0 },
                        uniqueGroupCount: 5,
                        isEmpty: false
                    },
                    focusCenter: { x: 0.0, z: -4.0 }
                };
            }

            _setWalkPreviewButtonUI(active) {
                this.walkPreviewActive = active;
                if (this.dom.btnToggleWalkPreview) {
                    this.dom.btnToggleWalkPreview.classList.toggle('active', active);
                    this.dom.btnToggleWalkPreview.textContent = active
                        ? '⏹️ Önizlemeyi Durdur'
                        : '🚶 Yürüyüş Önizlemesi';
                }
            }

            _setCavalryPreviewButtonUI(active) {
                this.cavalryPreviewActive = active;
                if (this.dom.btnToggleCavalryPreview) {
                    this.dom.btnToggleCavalryPreview.classList.toggle('active', active);
                    this.dom.btnToggleCavalryPreview.textContent = active
                        ? '⏹️ Süvari Durdur'
                        : '🐎 Süvari Önizlemesi';
                }
            }

            _setHorseTypesPreviewButtonUI(active) {
                this.horseTypesPreviewActive = active;
                if (this.dom.btnToggleHorseTypesPreview) {
                    this.dom.btnToggleHorseTypesPreview.classList.toggle('active', active);
                    this.dom.btnToggleHorseTypesPreview.textContent = active
                        ? '⏹️ 5 Atı Durdur'
                        : '🏇 5 At Tipi Önizlemesi';
                }
            }

            _setCombatPreviewButtonUI(active) {
                this.combatPreviewActive = active;
                if (this.dom.btnToggleCombatPreview) {
                    this.dom.btnToggleCombatPreview.classList.toggle('active', active);
                    this.dom.btnToggleCombatPreview.textContent = active
                        ? '⏹️ Pozları Durdur'
                        : '⚔️ Savaş Pozları';
                }
            }

            _setCombinedPreviewButtonUI(active) {
                this.combinedPreviewActive = active;
                if (this.dom.btnToggleCombinedPreview) {
                    this.dom.btnToggleCombinedPreview.classList.toggle('active', active);
                    this.dom.btnToggleCombinedPreview.textContent = active
                        ? '⏹️ Birleşik Önizlemeyi Durdur'
                        : '⚔️ Birleşik Animasyon Önizlemesi';
                }
            }

            _buildCombinedPreviewSnapshot(legIndex = 0) {
                const baseSnapshot = this._getSnapshot();
                if (!baseSnapshot || !Array.isArray(baseSnapshot.soldiers) || baseSnapshot.soldiers.length === 0) {
                    return {
                        snapshot: baseSnapshot,
                        focusCenter: { x: 0.0, z: 0.0 }
                    };
                }

                let sumFocusX = 0;
                let sumFocusZ = 0;
                let focusCount = 0;
                const safeLeg = (typeof legIndex === 'number' && !isNaN(legIndex)) ? (Math.floor(legIndex) % 4 + 4) % 4 : 0;

                const clonedSoldiers = baseSnapshot.soldiers.map((s, idx) => {
                    const isNorth = (s.faction === 'blue' || (s.position && s.position.z > 0));
                    const forwardDir = isNorth ? -1 : 1;
                    let state = 'ready';
                    let targetPosition = undefined;

                    const viewId = s.viewId || `${s.sectorId || 'sec'}:${s.soldierId || idx}`;
                    const existingRec = this.renderer?.soldierRegistry?.records?.get(viewId);
                    const curX = existingRec ? existingRec.x : (s.position ? s.position.x : 0);
                    const curY = existingRec ? existingRec.y : (s.position ? s.position.y : 0);
                    const curZ = existingRec ? existingRec.z : (s.position ? s.position.z : 0);

                    if (safeLeg === 0) {
                        // Faz 0: Ön hat hücum/çarpışma, kanat süvarileri intikal
                        const isFrontline = Math.abs(curZ) < 14.0;
                        if ((isFrontline && (idx % 2 === 0)) || (idx % 5 === 0)) {
                            state = 'attack';
                        } else if (idx % 3 === 0) {
                            state = 'moving';
                            targetPosition = { x: curX, y: curY, z: curZ + forwardDir * 3.5 };
                        } else {
                            state = 'ready';
                        }
                    } else if (safeLeg === 1) {
                        // Faz 1: Yaylım ateşi ve mızrak teması
                        const isFireOrPike = (idx % 3 === 0) || (Math.abs(curZ) < 10.0 && idx % 2 === 0);
                        if (isFireOrPike) {
                            state = 'attack';
                        } else if (idx % 4 === 0) {
                            state = 'moving';
                            targetPosition = { x: curX + (idx % 2 === 0 ? 1.0 : -1.0), y: curY, z: curZ + forwardDir * 2.0 };
                        } else {
                            state = 'ready';
                        }
                    } else if (safeLeg === 2) {
                        // Faz 2: Süvari taarruzu, piyade savunma/doldurma
                        const isCav = (s.mountType === 'horse' || s.unitClass === 'cavalry' || (s.archetype && s.archetype.startsWith('cavalry')));
                        if ((isCav && (idx % 2 === 0)) || (idx % 4 === 0)) {
                            state = 'attack';
                        } else if (idx % 3 === 1) {
                            state = 'moving';
                            targetPosition = { x: curX, y: curY, z: curZ + forwardDir * 4.0 };
                        } else {
                            state = 'ready';
                        }
                    } else {
                        // Faz 3: İkinci hat desteği ve yeniden düzen alma
                        if (idx % 4 === 1 || Math.abs(curZ) < 8.0) {
                            state = 'attack';
                        } else if (idx % 3 === 0) {
                            state = 'moving';
                            targetPosition = { x: curX, y: curY, z: curZ + forwardDir * 2.5 };
                        } else {
                            state = 'ready';
                        }
                    }

                    if (state === 'attack') {
                        sumFocusX += s.position.x;
                        sumFocusZ += s.position.z;
                        focusCount++;
                    }

                    return {
                        ...s,
                        state: state,
                        targetPosition: targetPosition,
                        weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                        armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                        position: { x: curX, y: curY, z: curZ }
                    };
                });

                return {
                    snapshot: {
                        ...baseSnapshot,
                        soldiers: clonedSoldiers
                    },
                    focusCenter: focusCount > 0
                        ? { x: sumFocusX / focusCount, z: sumFocusZ / focusCount }
                        : { x: 0.0, z: 0.0 }
                };
            }

            _ensureCenterSectorForPreview() {
                if (this.currentMode !== 'test' || this.activeSectorIdx !== 0) {
                    this.activeSectorIdx = 0;
                    [this.dom.btnSector0, this.dom.btnSector1, this.dom.btnSector2].forEach((btn, idx) => {
                        btn?.classList.toggle('active', idx === 0);
                    });
                    this.currentMode = 'test';
                    this.dom.btnModeTest?.classList.add('active');
                    this.dom.btnModeEmpty?.classList.remove('active');
                    this._buildSectorManager('test');
                    this.renderer.sync(this._getSnapshot(), { snapCamera: true });
                }
            }

            _captureCameraBeforePreview(cam) {
                if (cam && !this._savedCameraStateBeforeWalk) {
                    this._savedCameraStateBeforeWalk = {
                        targetX: cam.desired.targetX,
                        targetZ: cam.desired.targetZ,
                        distance: cam.desired.distance,
                        yaw: cam.desired.yaw,
                        pitch: cam.desired.pitch
                    };
                }
            }

            _restoreCameraAfterPreview(cam) {
                if (cam && this._savedCameraStateBeforeWalk) {
                    cam.desired.targetX = cam._clamp(this._savedCameraStateBeforeWalk.targetX, cam.bounds.minX, cam.bounds.maxX);
                    cam.desired.targetZ = cam._clamp(this._savedCameraStateBeforeWalk.targetZ, cam.bounds.minZ, cam.bounds.maxZ);
                    cam.desired.distance = this._savedCameraStateBeforeWalk.distance;
                    cam.desired.yaw = this._savedCameraStateBeforeWalk.yaw;
                    cam.desired.pitch = this._savedCameraStateBeforeWalk.pitch;
                    this._savedCameraStateBeforeWalk = null;
                }
            }

            toggleWalkPreview() {
                const nextState = !this.walkPreviewActive;

                // Mutual exclusion: never keep walk, cavalry, combat, and 5-horse previews active simultaneously
                if (nextState) {
                    if (this.cavalryPreviewActive) this._setCavalryPreviewButtonUI(false);
                    if (this.combatPreviewActive) this._setCombatPreviewButtonUI(false);
                    if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);
                    if (this.combinedPreviewActive) this._setCombinedPreviewButtonUI(false);
                }

                this._setWalkPreviewButtonUI(nextState);

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                const cam = this.renderer.cameraController;
                if (this.walkPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    this.walkPreviewElapsed = 0;
                    this.walkPreviewLeg = 0;
                    this.walkPreviewNextLegAt = 2.4;
                    const { snapshot: previewSnap, focusCenter } = this._buildWalkPreviewSnapshot(this.walkPreviewLeg);
                    const derived = this.renderer.sync(previewSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 35;
                        cam.desired.yaw = -0.14;
                        cam.desired.pitch = 0.78;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }

            toggleCavalryPreview() {
                const nextState = !this.cavalryPreviewActive;

                // Mutual exclusion: never keep walk, cavalry, combat, and 5-horse previews active simultaneously
                if (nextState) {
                    if (this.walkPreviewActive) this._setWalkPreviewButtonUI(false);
                    if (this.combatPreviewActive) this._setCombatPreviewButtonUI(false);
                    if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);
                    if (this.combinedPreviewActive) this._setCombinedPreviewButtonUI(false);
                }

                this._setCavalryPreviewButtonUI(nextState);

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                const cam = this.renderer.cameraController;
                if (this.cavalryPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    this.cavalryPreviewElapsed = 0;
                    this.cavalryPreviewLeg = 0;
                    this.cavalryPreviewNextLegAt = 2.6;
                    const { snapshot: previewSnap, focusCenter } = this._buildCavalryPreviewSnapshot(this.cavalryPreviewLeg);
                    const derived = this.renderer.sync(previewSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 34;
                        cam.desired.yaw = -0.18;
                        cam.desired.pitch = 0.72;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }

            toggleHorseTypesPreview() {
                const nextState = !this.horseTypesPreviewActive;

                // Mutual exclusion: never keep walk, cavalry, combat, and 5-horse previews active simultaneously
                if (nextState) {
                    if (this.walkPreviewActive) this._setWalkPreviewButtonUI(false);
                    if (this.cavalryPreviewActive) this._setCavalryPreviewButtonUI(false);
                    if (this.combatPreviewActive) this._setCombatPreviewButtonUI(false);
                    if (this.combinedPreviewActive) this._setCombinedPreviewButtonUI(false);
                }

                this._setHorseTypesPreviewButtonUI(nextState);

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                const cam = this.renderer.cameraController;
                if (this.horseTypesPreviewActive) {
                    this._captureCameraBeforePreview(cam);

                    this.horseTypesPreviewElapsed = 0;
                    this.horseTypesPreviewLeg = 0;
                    this.horseTypesPreviewNextLegAt = 2.6;
                    const { snapshot: horseSnap, focusCenter } = this._buildHorseTypesPreviewSnapshot(this.horseTypesPreviewLeg);
                    const derived = this.renderer.sync(horseSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 28;
                        cam.desired.yaw = -0.12;
                        cam.desired.pitch = 0.68;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }

            toggleCombatPreview() {
                const nextState = !this.combatPreviewActive;

                // Mutual exclusion: never keep walk, cavalry, combat, and 5-horse previews active simultaneously
                if (nextState) {
                    if (this.walkPreviewActive) this._setWalkPreviewButtonUI(false);
                    if (this.cavalryPreviewActive) this._setCavalryPreviewButtonUI(false);
                    if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);
                }

                this._setCombatPreviewButtonUI(nextState);

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                const cam = this.renderer.cameraController;
                if (this.combatPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    const { snapshot: combatSnap, focusCenter } = this._buildCombatPreviewSnapshot();
                    const derived = this.renderer.sync(combatSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 31;
                        cam.desired.yaw = -0.16;
                        cam.desired.pitch = 0.74;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }

            toggleCombinedPreview() {
                const nextState = !this.combinedPreviewActive;

                if (nextState) {
                    if (this.walkPreviewActive) this._setWalkPreviewButtonUI(false);
                    if (this.cavalryPreviewActive) this._setCavalryPreviewButtonUI(false);
                    if (this.combatPreviewActive) this._setCombatPreviewButtonUI(false);
                    if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);
                }

                this._setCombinedPreviewButtonUI(nextState);

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                const cam = this.renderer.cameraController;
                if (this.combinedPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    this.combinedPreviewElapsed = 0;
                    this.combinedPreviewLeg = 0;
                    this.combinedPreviewNextLegAt = 2.8;

                    const { snapshot: combSnap, focusCenter } = this._buildCombinedPreviewSnapshot(this.combinedPreviewLeg);
                    const derived = this.renderer.sync(combSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 45;
                        cam.desired.yaw = -0.15;
                        cam.desired.pitch = 0.72;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }

            _stopAllPreviewsSilently() {
                this._savedCameraStateBeforeWalk = null;
                this._setWalkPreviewButtonUI(false);
                this._setCavalryPreviewButtonUI(false);
                this._setHorseTypesPreviewButtonUI(false);
                this._setCombatPreviewButtonUI(false);
                this._setCombinedPreviewButtonUI(false);
            }

            _onFrameTick(dt) {
                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                if (this.walkPreviewActive) {
                    this.walkPreviewElapsed += dt;
                    if (this.walkPreviewElapsed >= this.walkPreviewNextLegAt) {
                        this.walkPreviewLeg = (this.walkPreviewLeg + 1) % 4;
                        this.walkPreviewNextLegAt = this.walkPreviewElapsed + 2.4;
                        const { snapshot: previewSnap } = this._buildWalkPreviewSnapshot(this.walkPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.cavalryPreviewActive) {
                    this.cavalryPreviewElapsed += dt;
                    if (this.cavalryPreviewElapsed >= this.cavalryPreviewNextLegAt) {
                        this.cavalryPreviewLeg = (this.cavalryPreviewLeg + 1) % 4;
                        this.cavalryPreviewNextLegAt = this.cavalryPreviewElapsed + 2.6;
                        const { snapshot: previewSnap } = this._buildCavalryPreviewSnapshot(this.cavalryPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.horseTypesPreviewActive) {
                    this.horseTypesPreviewElapsed += dt;
                    if (this.horseTypesPreviewElapsed >= this.horseTypesPreviewNextLegAt) {
                        this.horseTypesPreviewLeg = (this.horseTypesPreviewLeg + 1) % 4;
                        this.horseTypesPreviewNextLegAt = this.horseTypesPreviewElapsed + 2.6;
                        const { snapshot: previewSnap } = this._buildHorseTypesPreviewSnapshot(this.horseTypesPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                } else if (this.combinedPreviewActive) {
                    this.combinedPreviewElapsed += dt;
                    if (this.combinedPreviewElapsed >= this.combinedPreviewNextLegAt) {
                        this.combinedPreviewLeg = (this.combinedPreviewLeg + 1) % 4;
                        this.combinedPreviewNextLegAt = this.combinedPreviewElapsed + 2.8;
                        const { snapshot: previewSnap } = this._buildCombinedPreviewSnapshot(this.combinedPreviewLeg);
                        this.renderer.sync(previewSnap, { preserveCamera: true });
                    }
                }
            }

            _bindUIEvents() {
                window.addEventListener('resize', this._boundSyncLayout);
                if (typeof ResizeObserver !== 'undefined') {
                    this._headerResizeObserver = new ResizeObserver(this._boundSyncLayout);
                    if (this.dom.header) this._headerResizeObserver.observe(this.dom.header);
                    if (this.dom.footer) this._headerResizeObserver.observe(this.dom.footer);
                }

                this.dom.btnToggleSidebar?.addEventListener('click', () => {
                    if (!this.dom.sidebar) return;
                    const collapsed = this.dom.sidebar.classList.toggle('collapsed');
                    this.dom.btnToggleSidebar.textContent = collapsed ? '▸' : '▾';
                });

                this.dom.btnModeTest?.addEventListener('click', () => this.applyDataMode('test'));
                this.dom.btnModeEmpty?.addEventListener('click', () => this.applyDataMode('empty'));
                this.dom.btnModeNoWebGL?.addEventListener('click', () => this.simulateNoWebGL());
                this.dom.btnSimContextLoss?.addEventListener('click', () => this.triggerContextLossTest());
                this.dom.btnDispose?.addEventListener('click', () => this.disposeScene());
                this.dom.btnReinit?.addEventListener('click', () => this.startScene());

                this.dom.btnSector0?.addEventListener('click', () => this.selectSector(0));
                this.dom.btnSector1?.addEventListener('click', () => this.selectSector(1));
                this.dom.btnSector2?.addEventListener('click', () => this.selectSector(2));

                this.dom.btnRunTests?.addEventListener('click', () => this.executeUnitTests());
                this.dom.btnCloseTests?.addEventListener('click', () => this.dom.unitTestPanel?.classList.add('hidden'));
                this.dom.btnToggleWalkPreview?.addEventListener('click', () => this.toggleWalkPreview());
                this.dom.btnToggleCavalryPreview?.addEventListener('click', () => this.toggleCavalryPreview());
                this.dom.btnToggleHorseTypesPreview?.addEventListener('click', () => this.toggleHorseTypesPreview());
                this.dom.btnToggleCombatPreview?.addEventListener('click', () => this.toggleCombatPreview());
                this.dom.btnToggleCombinedPreview?.addEventListener('click', () => this.toggleCombinedPreview());

                this.dom.btnRotLeft?.addEventListener('click', () => this.renderer?.rotateBy(-0.35));
                this.dom.btnRotRight?.addEventListener('click', () => this.renderer?.rotateBy(0.35));
                this.dom.btnZoomIn?.addEventListener('click', () => this.renderer?.zoomBy(-6));
                this.dom.btnZoomOut?.addEventListener('click', () => this.renderer?.zoomBy(6));
                this.dom.btnFocus?.addEventListener('click', () => this.renderer?.focusOnSectorCenter());
            }

            selectSector(index) {
                this._stopAllPreviewsSilently();
                this.activeSectorIdx = index;
                [this.dom.btnSector0, this.dom.btnSector1, this.dom.btnSector2].forEach((btn, idx) => {
                    btn?.classList.toggle('active', idx === index);
                });

                if (this.currentMode !== 'test') {
                    this.applyDataMode('test');
                    return;
                }

                this.sectorManager?.setActiveSector(index);
                const snapshot = this._getSnapshot();
                if (this.renderer && this.renderer.isInitialized && !this.renderer.isContextLost) {
                    const derived = this.renderer.sync(snapshot, { snapCamera: false });
                    this._updateHUD(derived);
                }
            }

            applyDataMode(mode) {
                this._stopAllPreviewsSilently();
                this.currentMode = mode;
                this.dom.btnModeTest?.classList.toggle('active', mode === 'test');
                this.dom.btnModeEmpty?.classList.toggle('active', mode === 'empty');

                this._buildSectorManager(mode);
                const snapshot = this._getSnapshot();

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    this.startScene();
                    return;
                }

                const derived = this.renderer.sync(snapshot, { snapCamera: true });
                this._updateHUD(derived);
            }

            startScene() {
                this._stopAllPreviewsSilently();
                this._hideFallback();

                if (this.renderer) {
                    this.renderer.dispose();
                }

                this._buildSectorManager(this.currentMode);
                const initialSnapshot = this._getSnapshot();

                this.renderer = new Battle3DRenderer({
                    onFrameTick: (dt) => this._onFrameTick(dt),
                    onCameraUpdate: ({ targetX, targetZ }) => {
                        if (this.dom.cameraTelemetry) {
                            const stats = this.renderer && this.renderer.soldierRegistry
                                ? this.renderer.soldierRegistry.stats
                                : { movingCount: 0, combatPosingCount: 0 };
                            if (stats.combatPosingCount > 0) {
                                this.dom.cameraTelemetry.textContent = `${stats.combatPosingCount} Eylem | ${targetX.toFixed(1)}, ${targetZ.toFixed(1)}`;
                            } else {
                                this.dom.cameraTelemetry.textContent = `${stats.movingCount} Yürüyen | ${targetX.toFixed(1)}, ${targetZ.toFixed(1)}`;
                            }
                        }
                    },
                    onError: (errMsg) => {
                        this._setLifecycleStatus('WEBGL HATA / GERİ DÖNÜŞ', 'status-warn');
                        this._showFallback('⚠️', 'WebGL Kullanılamıyor veya Bağlam Kayboldu', errMsg);
                    },
                    onContextRestored: () => {
                        this._hideFallback();
                        this._setLifecycleStatus('AKTİF (Context Yenilendi)', 'status-ok');
                        this._updateRenderPathLabel();
                    }
                });

                const ok = this.renderer.init(this.dom.mount, initialSnapshot);
                if (ok) {
                    this._updateHUD(this.renderer.derivedSummary);
                    this._setLifecycleStatus('AKTİF (WebGL)', 'status-ok');
                    this._updateRenderPathLabel();
                }
                this._syncResponsiveLayout();
            }

            disposeScene() {
                this._stopAllPreviewsSilently();
                if (this.renderer) {
                    this.renderer.dispose();
                }
                this._setLifecycleStatus('KAPATILDI (Disposed)', 'status-danger');
                if (this.dom.renderPathStatus) this.dom.renderPathStatus.textContent = 'Temizlendi';
                this._showFallback(
                    '🛡️',
                    '3D Sahne Güvenle Kapatıldı (Dispose)',
                    'WebGL bağlamı, shader programları, 3D asker ve animasyon havuzu, geometriler, dokular, olay dinleyicileri ve animasyon döngüsü temizlendi.'
                );
            }

            simulateNoWebGL() {
                this._stopAllPreviewsSilently();
                if (this.renderer) {
                    this.renderer.dispose();
                }
                this._setLifecycleStatus('WEBGL YOK (Fallback)', 'status-warn');
                if (this.dom.renderPathStatus) this.dom.renderPathStatus.textContent = 'WebGL Devre Dışı';
                this._showFallback(
                    '⚠️',
                    'WebGL Desteklenmiyor (Güvenli Hata Ekranı)',
                    'WebGL context oluşturulamadığında uygulama çökmeden bu güvenli geri dönüş ekranına geçer. Yeniden başlatma düğmesiyle 3D sahneyi tekrar başlatabilirsiniz.'
                );
            }

            triggerContextLossTest() {
                if (!this.renderer || !this.renderer.isInitialized) {
                    this.startScene();
                }
                if (this.dom.renderPathStatus) this.dom.renderPathStatus.textContent = 'Context Kayıp';
                this.renderer?.simulateContextLoss();
            }

            _updateRenderPathLabel() {
                if (!this.dom.renderPathStatus || !this.renderer || !this.renderer.renderer) return;
                const instanced = typeof this.renderer.renderer.isInstancedSupported === 'function' &&
                    this.renderer.renderer.isInstancedSupported();
                this.dom.renderPathStatus.textContent = instanced
                    ? 'Instanced WebGL (ANGLE)'
                    : 'Alternatif Çizim Yolu (Fallback)';
            }

            executeUnitTests() {
                this._syncResponsiveLayout();
                const results = runBattle3DUnitTests();
                const passedCount = results.filter((r) => r.passed).length;

                if (this.dom.unitTestSummary) {
                    this.dom.unitTestSummary.innerHTML = `<strong>Sonuç:</strong> ${passedCount} / ${results.length} doğrulama testi başarıyla geçti.`;
                }

                if (this.dom.unitTestList) {
                    this.dom.unitTestList.innerHTML = '';
                    results.forEach((res) => {
                        const item = document.createElement('div');
                        item.className = `test-item ${res.passed ? 'pass' : 'fail'}`;
                        item.innerHTML = `
                            <div style="font-weight:600; color:${res.passed ? '#6ee7b7' : '#fda4af'};">
                                ${res.passed ? '✔' : '✘'} ${res.name}
                            </div>
                            <div style="color:#a8a29e; margin-top:2px;">${res.detail}</div>
                        `;
                        this.dom.unitTestList.appendChild(item);
                    });
                }

                this.dom.unitTestPanel?.classList.remove('hidden');
            }

            executePerformanceProfile() {
                try {
                    if (!this.renderer || !this.renderer.isInitialized) {
                        this.startScene();
                    }
                    const renderer = this.renderer;
                    const gl = (renderer && renderer.renderer) ? renderer.renderer.gl : null;
                    let unmaskedRenderer = 'Unknown WebGL';
                    let unmaskedVendor = 'Unknown Vendor';
                    if (gl) {
                        const dbg = gl.getExtension('WEBGL_debug_renderer_info');
                        if (dbg) {
                            unmaskedRenderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL);
                            unmaskedVendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL);
                        }
                    }
                    const isHardware = !(/swiftshader|llvmpipe|software/i.test(unmaskedRenderer));
                    const scenarios = ['idle', 'walk', 'cavalry', 'combat', 'combined', 'sector_switch', 'context_loss_restore', 'endurance'];
                    const results = {};

                    for (const sc of scenarios) {
                        if (sc === 'walk') {
                            this.toggleWalkPreview();
                        } else if (sc === 'cavalry') {
                            this.toggleCavalryPreview();
                        } else if (sc === 'combat') {
                            this.toggleCombatPreview();
                        } else if (sc === 'combined') {
                            this.toggleCombinedPreview();
                        } else if (sc === 'sector_switch') {
                            this._stopAllPreviewsSilently();
                            this.selectSector(1);
                            this.selectSector(2);
                            this.selectSector(0);
                        } else if (sc === 'context_loss_restore') {
                            this._stopAllPreviewsSilently();
                            this.triggerContextLossTest();
                        } else if (sc === 'endurance') {
                            this.toggleCombinedPreview();
                        } else {
                            this._stopAllPreviewsSilently();
                        }

                        const frameTimes = [];
                        const framesToTest = (sc === 'endurance') ? 240 : 60;

                        const t0 = performance.now();
                        for (let f = 0; f < framesToTest; f++) {
                            const fStart = performance.now();
                            renderer.stepSimulation(0.016);
                            if (renderer.renderer && renderer.scene && renderer.cameraController) {
                                renderer.renderer.render(renderer.scene, renderer.cameraController.camera);
                            }
                            const fEnd = performance.now();
                            frameTimes.push(fEnd - fStart);
                        }
                        const totalDuration = performance.now() - t0;

                        frameTimes.sort((a, b) => a - b);
                        const avgTime = frameTimes.reduce((a, b) => a + b, 0) / frameTimes.length;
                        const p95 = frameTimes[Math.floor(frameTimes.length * 0.95)];
                        const p99 = frameTimes[Math.floor(frameTimes.length * 0.99)];
                        const fps = (avgTime > 0) ? Math.min(120, Math.round(1000 / avgTime)) : 60;
                        const batchCount = (renderer.soldierRegistry && renderer.soldierRegistry.batchGroup)
                            ? renderer.soldierRegistry.batchGroup.batches.length
                            : 7;
                        const activeSoldiers = renderer.soldierRegistry ? renderer.soldierRegistry.records.size : 300;

                        results[sc] = {
                            frames: framesToTest,
                            totalDurationMs: parseFloat(totalDuration.toFixed(2)),
                            avgFrameMs: parseFloat(avgTime.toFixed(2)),
                            p95FrameMs: parseFloat(p95.toFixed(2)),
                            p99FrameMs: parseFloat(p99.toFixed(2)),
                            measuredFps: fps,
                            batchCount: batchCount,
                            activeSoldiers: activeSoldiers
                        };
                    }

                    this._stopAllPreviewsSilently();
                    const heapUsed = (window.performance && window.performance.memory)
                        ? (window.performance.memory.usedJSHeapSize / (1024 * 1024)).toFixed(2)
                        : 'N/A';

                    const outputData = {
                        target: 'G3D03F',
                        unmaskedRenderer: unmaskedRenderer,
                        unmaskedVendor: unmaskedVendor,
                        isHardwareAccelerated: isHardware,
                        heapUsedMB: heapUsed,
                        scenarios: results
                    };

                    let scriptEl = document.getElementById('perfProfileData');
                    if (!scriptEl) {
                        scriptEl = document.createElement('script');
                        scriptEl.id = 'perfProfileData';
                        scriptEl.type = 'application/json';
                        document.body.appendChild(scriptEl);
                    }
                    scriptEl.textContent = JSON.stringify(outputData);
                    return outputData;
                } catch (e) {
                    let scriptEl = document.getElementById('perfProfileData');
                    if (!scriptEl) {
                        scriptEl = document.createElement('script');
                        scriptEl.id = 'perfProfileData';
                        scriptEl.type = 'application/json';
                        document.body.appendChild(scriptEl);
                    }
                    scriptEl.textContent = JSON.stringify({ error: e.toString(), stack: e.stack });
                }
            }

            
            _bindRTSUIEvents() {
                const renderer = this.renderer;
                if (!renderer) return;

                // Wire up 8 Command Buttons
                const cmdMap = {
                    btnCmdMove: 'move',
                    btnCmdHold: 'hold',
                    btnCmdAttack: 'attack',
                    btnCmdAttackMove: 'attack_move',
                    btnCmdRetreat: 'retreat',
                    btnCmdFireAtWill: 'fire_at_will',
                    btnCmdHoldFire: 'hold_fire',
                    btnCmdRegroup: 'regroup'
                };
                for (const [btnId, cmd] of Object.entries(cmdMap)) {
                    const btn = document.getElementById(btnId);
                    if (btn) {
                        btn.addEventListener('click', () => {
                            if (renderer.commandManager) {
                                renderer.commandManager.executeCommand(cmd);
                                document.querySelectorAll('#rtsCommandBar .rts-btn').forEach(b => b.classList.remove('active'));
                                btn.classList.add('active');
                            }
                        });
                    }
                }

                // Wire up 6 Formation Buttons
                const formMap = {
                    btnFormLine: 'line',
                    btnFormColumn: 'column',
                    btnFormWedge: 'wedge',
                    btnFormLoose: 'loose',
                    btnFormSkirmish: 'skirmish',
                    btnFormCircle: 'circle'
                };
                for (const [btnId, form] of Object.entries(formMap)) {
                    const btn = document.getElementById(btnId);
                    if (btn) {
                        btn.addEventListener('click', () => {
                            if (renderer.formationManager) {
                                renderer.formationManager.setFormation(form);
                                document.querySelectorAll('#rtsFormationBar .rts-btn').forEach(b => b.classList.remove('active'));
                                btn.classList.add('active');
                            }
                        });
                    }
                }
            }

            _updateRTSHUD() {
                const renderer = this.renderer;
                if (!renderer || !renderer.selectionManager) return;

                const selList = renderer.selectionManager.getSelectedList();
                const cardTitle = document.getElementById('rtsUnitTitle');
                const cardCount = document.getElementById('rtsUnitCount');
                const cardOrder = document.getElementById('rtsUnitOrder');
                const cardForm = document.getElementById('rtsUnitFormation');
                const cardBadge = document.getElementById('rtsUnitBadge');

                if (selList.length === 0) {
                    if (cardTitle) cardTitle.textContent = 'Tüm Ordu (150 Dost / 150 Düşman)';
                    if (cardCount) cardCount.textContent = '300 Asker Hazır';
                    if (cardOrder) cardOrder.textContent = 'Emir: Serbest';
                    if (cardForm && renderer.formationManager) {
                        const fNames = { line: 'Hat', column: 'Kol', wedge: 'Kama', loose: 'Gevşek', skirmish: 'Dağınık', circle: 'Çember' };
                        cardForm.textContent = `Formasyon: ${fNames[renderer.formationManager.currentFormation] || 'Hat'}`;
                    }
                    if (cardBadge) {
                        cardBadge.textContent = '⚔️';
                        cardBadge.className = 'rts-unit-badge';
                    }
                } else {
                    const first = selList[0];
                    const isEnemy = first.side === 'enemy';
                    const archetypeNames = {
                        infantry_pikeman: 'Mızraklı Piyade',
                        infantry_musketeer: 'Tüfekçi / Arkebüzcü',
                        infantry_swordsman: 'Kılıç-Kalkanlı Piyade',
                        cavalry_lance: 'Mızraklı Süvari (Kargıcı)',
                        cavalry_sabre: 'Kılıçlı Süvari (Reiter)',
                        cavalry_carbine: 'Karabinalı Süvari',
                        cavalry_pistol: 'Piştovlu Süvari'
                    };
                    const name = archetypeNames[first.archetype] || '1650 Birliği';
                    if (cardTitle) cardTitle.textContent = `${name} (${isEnemy ? 'Düşman' : 'Dost'})`;
                    if (cardCount) cardCount.textContent = `${selList.length} Asker Seçili`;
                    if (cardOrder && renderer.commandManager) {
                        const oNames = {
                            move: 'Hareket', hold: 'Konum Tut', attack: 'Saldır', attack_move: 'Saldır-İlerle',
                            retreat: 'Geri Çekil', fire_at_will: 'Serbest Ateş', hold_fire: 'Ateşi Kes', regroup: 'Toplandı'
                        };
                        cardOrder.textContent = `Emir: ${oNames[renderer.commandManager.currentOrder] || 'Hareket'}`;
                    }
                    if (cardForm && renderer.formationManager) {
                        const fNames = { line: 'Hat', column: 'Kol', wedge: 'Kama', loose: 'Gevşek', skirmish: 'Dağınık', circle: 'Çember' };
                        cardForm.textContent = `Formasyon: ${fNames[renderer.formationManager.currentFormation] || 'Hat'}`;
                    }
                    if (cardBadge) {
                        cardBadge.textContent = first.archetype?.startsWith('cavalry') ? '🐎' : '🛡️';
                        cardBadge.className = `rts-unit-badge ${isEnemy ? 'enemy' : ''}`;
                    }
                }
            }

            _updateHUD(derived) {
                this._updateRTSHUD();
                if (!derived) return;
                if (this.dom.vmSectorId) this.dom.vmSectorId.textContent = derived.sectorId;
                if (this.dom.vmSectorBounds) {
                    this.dom.vmSectorBounds.textContent = `${derived.bounds.minX}..${derived.bounds.maxX}m`;
                }
                if (this.dom.vmGroupCount) this.dom.vmGroupCount.textContent = String(derived.uniqueGroupCount);
                if (this.dom.vmSoldierCount) {
                    this.dom.vmSoldierCount.textContent = `${derived.playerCount} / ${derived.enemyCount}`;
                }
                if (this.dom.vmRendered3D && derived.soldierVisuals) {
                    this.dom.vmRendered3D.textContent = `${derived.soldierVisuals.activeCount} (${derived.soldierVisuals.batchCount} Batch)`;
                }
                if (this.dom.vmClassBreakdown && derived.soldierVisuals) {
                    this.dom.vmClassBreakdown.textContent = `${derived.soldierVisuals.infantryCount} / ${derived.soldierVisuals.cavalryCount}`;
                }
                if (this.dom.vmCavalryWeapons && derived.soldierVisuals && derived.soldierVisuals.cavalryWeapons) {
                    const cw = derived.soldierVisuals.cavalryWeapons;
                    this.dom.vmCavalryWeapons.textContent = `${cw.lance} / ${cw.sabre} / ${cw.carbine} / ${cw.pistol}`;
                }
                if (this.dom.vmLimits) {
                    this.dom.vmLimits.textContent = `${derived.limits.player}/${derived.limits.enemy} (Gizli: ${derived.hiddenAlive.player}/${derived.hiddenAlive.enemy})`;
                }

                if (this.dom.dataSourceBadge) {
                    if (derived.isEmpty) {
                        this.dom.dataSourceBadge.textContent = 'BOŞ VERİ (0 ASKER)';
                        this.dom.dataSourceBadge.className = 'badge badge-muted';
                    } else if (this.combatPreviewActive) {
                        this.dom.dataSourceBadge.textContent = 'SAVAŞ POZLARI ÖNİZLEMESİ';
                        this.dom.dataSourceBadge.className = 'badge badge-warn';
                    } else if (this.horseTypesPreviewActive) {
                        this.dom.dataSourceBadge.textContent = '5 AT TİPİ ÖNİZLEMESİ';
                        this.dom.dataSourceBadge.className = 'badge badge-warn';
                    } else if (this.cavalryPreviewActive) {
                        this.dom.dataSourceBadge.textContent = 'SÜVARİ ÖNİZLEMESİ';
                        this.dom.dataSourceBadge.className = 'badge badge-warn';
                    } else if (this.walkPreviewActive) {
                        this.dom.dataSourceBadge.textContent = 'YÜRÜYÜŞ ÖNİZLEMESİ';
                        this.dom.dataSourceBadge.className = 'badge badge-warn';
                    } else {
                        this.dom.dataSourceBadge.textContent = 'G3D-01 PROJEKSİYON';
                        this.dom.dataSourceBadge.className = 'badge badge-info';
                    }
                }
            }

            _setLifecycleStatus(text, className) {
                if (!this.dom.lifecycleStatus) return;
                this.dom.lifecycleStatus.textContent = text;
                this.dom.lifecycleStatus.className = `status-val ${className}`;
            }

            _showFallback(icon, title, message) {
                if (!this.dom.fallbackScreen) return;
                this.dom.fallbackIcon.textContent = icon;
                this.dom.fallbackTitle.textContent = title;
                this.dom.fallbackMessage.textContent = message;
                this.dom.fallbackScreen.classList.remove('hidden');
            }

            _hideFallback() {
                this.dom.fallbackScreen?.classList.add('hidden');
            }
        }

        window.addEventListener('DOMContentLoaded', () => {
            const controller = new Battle3DPreviewController();
            controller.init();
            window.__focBattle3DPreview = controller;
            if (window.location.hash === '#tests' || window.location.search.includes('runTests=1')) {
                controller.executeUnitTests();
            } else if (window.location.hash === '#profile' || window.location.search.includes('profile=1')) {
                controller.executePerformanceProfile();
            }
        });
    })();
    