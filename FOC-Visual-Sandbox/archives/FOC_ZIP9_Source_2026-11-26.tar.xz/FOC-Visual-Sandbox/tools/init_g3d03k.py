# -*- coding: utf-8 -*-
"""
tools/init_g3d03k.py
Initializes the G3D03K directory structure for all 6 agents.
"""

import os
import shutil

os.makedirs('G3D03K', exist_ok=True)
for i in range(1, 7):
    os.makedirs(f'G3D03K/AJANLAR/0{i}', exist_ok=True)

# Copy G3D03J_WORKING.html as baseline for G3D03K_WORKING.html
shutil.copy('G3D03J_WORKING.html', 'G3D03K_WORKING.html')
print("G3D-03K workspace directories initialized and G3D03K_WORKING.html created from G3D03J_WORKING.html.")
