# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    html = f.read()

import re

# Extract all script contents
scripts = re.findall(r'<script>(.*?)</script>', html, re.DOTALL)
print(f"Found {len(scripts)} scripts")

for idx, s in enumerate(scripts):
    fname = f'tools/script_{idx}.js'
    with open(fname, 'w', encoding='utf-8') as f:
        f.write(s)
    print(f"Wrote {fname} (length {len(s)})")
