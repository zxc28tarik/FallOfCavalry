# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('class Battle3DPreviewController')
idx_end = text.find('window.addEventListener(\'DOMContentLoaded\'', idx)

import re
matches = re.findall(r'(\.sync\([^)]*\))', text[idx:idx_end])
print("Sync calls in controller:", set(matches))
