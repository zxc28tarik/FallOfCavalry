import math

def screen_to_ground(screen_x, screen_y, w, h, target_x, target_z, dist, yaw, pitch):
    ndc_x = (screen_x / w) * 2 - 1
    ndc_y = 1 - (screen_y / h) * 2
    
    eye_x = target_x + math.sin(yaw) * math.cos(pitch) * dist
    eye_y = math.sin(pitch) * dist
    eye_z = target_z + math.cos(yaw) * math.cos(pitch) * dist
    
    fwd_x = -math.sin(yaw) * math.cos(pitch)
    fwd_y = -math.sin(pitch)
    fwd_z = -math.cos(yaw) * math.cos(pitch)
    
    right_x = math.cos(yaw)
    right_y = 0.0
    right_z = -math.sin(yaw)
    
    up_x = right_y * fwd_z - right_z * fwd_y
    up_y = right_z * fwd_x - right_x * fwd_z
    up_z = right_x * fwd_y - right_y * fwd_x
    
    aspect = w / h
    fov_tan = math.tan(42 * 0.5 * math.pi / 180)
    
    dir_x = fwd_x + right_x * (ndc_x * aspect * fov_tan) + up_x * (ndc_y * fov_tan)
    dir_y = fwd_y + right_y * (ndc_x * aspect * fov_tan) + up_y * (ndc_y * fov_tan)
    dir_z = fwd_z + right_z * (ndc_x * aspect * fov_tan) + up_z * (ndc_y * fov_tan)
    
    if abs(dir_y) < 1e-6:
        return None
    t = -eye_y / dir_y
    return (eye_x + t * dir_x, eye_z + t * dir_z)

# Test center of screen (w/2, h/2) with target at (0, 0)
center_hit = screen_to_ground(500, 300, 1000, 600, 0, 0, 46, 0, 0.88)
print("Center hit:", center_hit)
assert abs(center_hit[0]) < 1e-4 and abs(center_hit[1]) < 1e-4, "Center screen must project exactly to camera target!"
print("Screen to ground raycast test PASSED!")
