with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('syncSoldierRenderQueue')
if idx != -1:
    print(text[idx-50:idx+2500])
