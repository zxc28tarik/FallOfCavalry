# -*- coding: utf-8 -*-
with open('G3D03J_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('function createSoldierPartTemplates')
if idx != -1:
    print(text[idx:idx+800])
