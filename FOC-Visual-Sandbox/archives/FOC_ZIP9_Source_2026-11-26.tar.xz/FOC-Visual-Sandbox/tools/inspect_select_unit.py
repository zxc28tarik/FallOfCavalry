with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('selectUnit(key)')
print(text[idx-50:idx+600])
