with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('<div>Şablon Anahtarı:')
print(text[idx:idx+400])
