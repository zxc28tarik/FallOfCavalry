# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
cases = re.findall(r"runCase\('([^']+)'", text)
print(f"Total runCases found: {len(cases)}")
for c in cases[-10:]:
    print(c)
