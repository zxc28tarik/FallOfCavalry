# -*- coding: utf-8 -*-
import subprocess
import tempfile
import os
import re

profile_dir = tempfile.mkdtemp(prefix='foc_test_debug2_')
html_path = os.path.abspath('G3D03K_WORKING.html')
cmd = [
    r'C:\Program Files\Google\Chrome\Application\chrome.exe',
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={profile_dir}',
    '--dump-dom',
    f'file:///{html_path.replace(os.sep, "/")}?runTests=1#tests'
]

proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15, encoding='utf-8', errors='replace')
dom = proc.stdout
print("DOM length:", len(dom))
summary_m = re.search(r'(\d+)\s*/\s*(\d+)\s*doğrulama testi', dom)
if summary_m:
    print("Found summary:", summary_m.group(0))
else:
    print("Summary NOT found.")

err_m = re.findall(r'class="test-item fail"[^>]*>(.*?)</div>', dom)
print(f"Failures ({len(err_m)}):", err_m[:5])

pass_count = len(re.findall(r'class="test-item pass"', dom))
fail_count = len(re.findall(r'class="test-item fail"', dom))
print(f"Pass: {pass_count}, Fail: {fail_count}")
