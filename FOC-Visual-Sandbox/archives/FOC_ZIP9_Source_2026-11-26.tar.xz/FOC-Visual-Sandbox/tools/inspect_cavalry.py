with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

needle = '0, 1.48, -0.06, 0.44, 0.16, 0.34'
idx = text.find(needle)
if idx != -1:
    print(text[idx-400:idx+1500])
else:
    print("needle not found")
