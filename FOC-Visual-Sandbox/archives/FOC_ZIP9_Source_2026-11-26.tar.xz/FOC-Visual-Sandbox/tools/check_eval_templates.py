with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Let's extract scripts and test in node
import subprocess

test_js = """
const fs = require('fs');
const html = fs.readFileSync('FallOfCavalry_PLAYABLE_RTS.html', 'utf-8');

// evaluate inside mock window
const jsMatch = html.match(/<script>([\\s\\S]*?)<\\/script>/g);
console.log('Script tags found:', jsMatch.length);
"""
print("Checking templates in HTML...")
