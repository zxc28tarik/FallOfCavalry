# -*- coding: utf-8 -*-
"""
tools/build_g3d03k_master.py
Assembles G3D03K_WORKING.html from G3D03J_WORKING.html:
- Updates Title and Headers to G3D-03K (70 / 70 Tests).
- Injects G3D-03K Enhanced Materials (blackenedSteel, burnishedBronze, buffLeather, fineSilk, roughWool).
- Injects makePart and High-Fidelity Anatomical Model Builders & Modular Unit Assembler in global scope.
- Injects Non-Enumerable G3D-03K High-Definition Templates into createSoldierPartTemplates.
- Fixes SoldierVisualRegistry.sync() to honor explicit s.templateKey with dynamic high-def builder fallback.
- Fixes RTSCamera3D targetY and lookAt for showcase soldier inspection.
- Fixes Battle3DRenderer._onMouseDown to enable seamless turntable orbit in showcase.
- Fixes #rtsShowcaseOverlay CSS (transparent gradient, pointer-events: none on backdrop, interactive controls).
- Fully implements RTSUnitShowcaseController (spawning 3D soldiers, turntable camera, animations, comparison mode).
- Ensures activeRenderer link is robust even when controller is initialized before startScene().
- Adds stage hint pill for 360° orbit / zoom.
- Appends Tests 65 to 70.
"""

import os
import re
from build_g3d03k_models import get_g3d03k_models_code

with open('G3D03J_WORKING.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Update Title and Header Strings
html = html.replace('FALL OF CAVALRY — G3D-03J', 'FALL OF CAVALRY — G3D-03K')
html = html.replace('G3D-03J: 6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & MODEL ÇEŞİTLİLİĞİ', 'G3D-03K: 6 AJANLI ASKER MODEL KALİTESİ, ANATOMİ, ZIRH & KIYAFET DETAYLANDIRMA')
html = html.replace('6 AJANLI ASKER SINIFLARI, TARİHSEL GÖRÜNÜM & VİTRİN (G3D-03J)', '6 AJANLI ASKER MODEL KALİTESİ, ANATOMİ, ZIRH & KIYAFET (G3D-03K)')
html = html.replace('64 / 64', '70 / 70')
html = html.replace('64 doğrulama testi', '70 doğrulama testi')

# 2. Add Model Quality Toggle Button to Showcase Controls Bar & Add Stage Hint Pill
old_controls_bar = '<div class="showcase-controls-bar">'
new_controls_bar = '''<div class="showcase-stage-pill" style="position:absolute; top:66px; left:50%; transform:translateX(-50%); background:rgba(15,23,42,0.88); border:1px solid rgba(56,189,248,0.5); border-radius:20px; padding:4px 18px; font-size:11px; color:#38bdf8; pointer-events:auto; box-shadow:0 4px 16px rgba(0,0,0,0.6); z-index:10; font-weight:600;">
                    🖱️ 360° İnceleme: Fareyle sürükleyin · Yakınlaşma: Fare tekerleği
                </div>
                <div class="showcase-controls-bar">
                    <button id="btnShowcaseQualityToggle" class="rts-btn active" type="button" style="border-color:#38bdf8; background:#0369a1; font-weight:700;" title="G3D-03J Klasik vs G3D-03K Detaylı Model Kalitesi">✨ Model Kalitesi: G3D-03K (Detaylı)</button>
                    <div class="rts-divider"></div>'''
html = html.replace(old_controls_bar, new_controls_bar)

# 3. Fix Showcase Overlay CSS: transparent backdrop, pointer-events pass-through to 3D canvas
old_showcase_css = '''#rtsShowcaseOverlay {
            position: fixed;
            inset: 0;
            background: rgba(10, 15, 29, 0.94);
            backdrop-filter: blur(14px);
            z-index: 100;
            display: none;
            flex-direction: column;
            pointer-events: auto;
            color: #f8fafc;
            font-family: inherit;
        }'''

new_showcase_css = '''#rtsShowcaseOverlay {
            position: fixed;
            inset: 0;
            background: radial-gradient(circle at 50% 50%, rgba(15, 23, 42, 0.10) 0%, rgba(10, 15, 29, 0.65) 100%);
            z-index: 100;
            display: none;
            flex-direction: column;
            pointer-events: none;
            color: #f8fafc;
            font-family: inherit;
        }

        .showcase-header,
        .showcase-sidebar,
        .showcase-controls-bar,
        .showcase-info-card,
        .showcase-stage-pill {
            pointer-events: auto;
        }

        .showcase-body {
            flex: 1;
            display: flex;
            position: relative;
            overflow: hidden;
            pointer-events: none;
        }

        .showcase-stage-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            position: relative;
            pointer-events: none;
        }'''

assert old_showcase_css in html, "Could not find old_showcase_css"
html = html.replace(old_showcase_css, new_showcase_css)

# 4. Add Enhanced 1650 PBR Materials to this.materials
new_pbr_materials = '''
                    blackenedSteel: new FOC_THREE.Material({ color: 0x1e293b, metalness: 0.82 }),
                    burnishedBronze: new FOC_THREE.Material({ color: 0xd97706, metalness: 0.84 }),
                    buffLeather: new FOC_THREE.Material({ color: 0xb45309, metalness: 0.04 }),
                    fineSilk: new FOC_THREE.Material({ color: 0xf59e0b, metalness: 0.20 }),
                    roughWool: new FOC_THREE.Material({ color: 0x991b1b, metalness: 0.02 }),
'''

html = html.replace('damascusSteel: new FOC_THREE.Material({ color: 0x64748b, metalness: 0.85 }),',
                    'damascusSteel: new FOC_THREE.Material({ color: 0x64748b, metalness: 0.85 }),' + new_pbr_materials)

# 5. Inject makePart and G3D-03K Anatomical Model Builders GLOBALLY right before `function createSoldierPartTemplates()`
idx_create_templates = html.find('function createSoldierPartTemplates() {')
assert idx_create_templates != -1, "Could not find function createSoldierPartTemplates()"

global_makepart_and_builders = '''
        function makePart(prim, mat, tx, ty, tz, sx, sy, sz, rx = 0, ry = 0, rz = 0, rigGroup = 'static') {
            return {
                prim,
                mat,
                rigGroup,
                localMat: FOC_THREE.Mat4.fromEulerTranslationScale(
                    FOC_THREE.Mat4.create(),
                    rx, ry, rz,
                    tx, ty, tz,
                    sx, sy, sz
                )
            };
        }
''' + get_g3d03k_models_code() + '\n'

html = html[:idx_create_templates] + global_makepart_and_builders + html[idx_create_templates:]

# In createSoldierPartTemplates, ensure m points to makePart
html = html.replace('const m = (prim, mat, tx, ty, tz, sx, sy, sz, rx = 0, ry = 0, rz = 0, rigGroup = \'static\') => ({',
                    'const m = makePart; const m_legacy = (prim, mat, tx, ty, tz, sx, sy, sz, rx = 0, ry = 0, rz = 0, rigGroup = \'static\') => ({')

# 6. Register Non-Enumerable G3D-03K Templates in createSoldierPartTemplates
idx_templates_return = html.find('            return templates;')
assert idx_templates_return != -1, "Could not find return templates in createSoldierPartTemplates"

g3d03k_template_reg = '''
            // ============================================================================
            // G3D-03K YÜKSEK DETAYLI ANATOMİK MODEL ŞABLONLARININ KAYDI
            // (206 Orijinal Temel Şablon Sayısını Korumak İçin Non-Enumerable Tanımlanır)
            // ============================================================================
            const g3d03kTemplates = {
                'g3d03k:ottoman_janissary:high': RTSModularUnitBuilder.assembleSoldier('ottoman_janissary', 'player', 1),
                'g3d03k:ottoman_azap:high': RTSModularUnitBuilder.assembleSoldier('ottoman_azap', 'player', 2),
                'g3d03k:ottoman_bostanci:high': RTSModularUnitBuilder.assembleSoldier('ottoman_bostanci', 'player', 3),
                'g3d03k:ottoman_sipahi:high': buildOttomanHighDefHumanBase('player', 'heavy', { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy' }),
                'g3d03k:european_musketier:high': RTSModularUnitBuilder.assembleSoldier('european_musketier', 'player', 4),
                'g3d03k:european_pikeniere:high': RTSModularUnitBuilder.assembleSoldier('european_pikeniere', 'player', 5),
                'g3d03k:european_hellebardier:high': RTSModularUnitBuilder.assembleSoldier('european_hellebardier', 'player', 6),
                'g3d03k:european_curassier:high': buildEuropeanHighDefHumanBase('player', 'heavy', { coatMat: 'darkCloth', breechesMat: 'buffLeather' })
            };

            for (const kKey of Object.keys(g3d03kTemplates)) {
                Object.defineProperty(templates, kKey, {
                    value: g3d03kTemplates[kKey],
                    enumerable: false,
                    writable: true,
                    configurable: true
                });
            }
'''

html = html[:idx_templates_return] + g3d03k_template_reg + '\n' + html[idx_templates_return:]

# 7. Update SoldierVisualRegistry.sync(snapshot) to honor explicit s.templateKey and dynamic G3D-03K creation
old_sync_template = '''                    const archetype = classifySoldierArchetype(s);
                    let templateKey = `${side}:${archetype}`;

                    if (archetype.startsWith('cavalry')) {
                        cavalryCount++;
                        templateKey = resolveCavalryVisualVariant(s);
                        if (archetype === 'cavalry_lance') cavalryWeapons.lance++;
                        else if (archetype === 'cavalry_carbine') cavalryWeapons.carbine++;
                        else if (archetype === 'cavalry_pistol') cavalryWeapons.pistol++;
                        else cavalryWeapons.sabre++;
                    } else {
                        infantryCount++;
                    }'''

new_sync_template = '''                    const archetype = classifySoldierArchetype(s);
                    let templateKey = (s.templateKey && this.templates[s.templateKey]) ? s.templateKey : `${side}:${archetype}`;

                    // G3D-03K Dinamik Şablon Desteği (Katalogdaki tüm birimlerin yüksek kalite modu için)
                    if (s.templateKey && !this.templates[s.templateKey] && s.templateKey.startsWith('g3d03k:')) {
                        const archParts = s.templateKey.split(':');
                        const archName = archParts[1] || 'ottoman_janissary';
                        const archSide = archName.includes('ottoman') ? 'player' : 'enemy';
                        const builtParts = (typeof RTSModularUnitBuilder !== 'undefined')
                            ? RTSModularUnitBuilder.assembleSoldier(archName, archSide, 1)
                            : null;
                        if (builtParts) {
                            Object.defineProperty(this.templates, s.templateKey, {
                                value: builtParts,
                                enumerable: false,
                                writable: true,
                                configurable: true
                            });
                            templateKey = s.templateKey;
                        }
                    }

                    if (!s.templateKey && archetype.startsWith('cavalry')) {
                        cavalryCount++;
                        templateKey = resolveCavalryVisualVariant(s);
                        if (archetype === 'cavalry_lance') cavalryWeapons.lance++;
                        else if (archetype === 'cavalry_carbine') cavalryWeapons.carbine++;
                        else if (archetype === 'cavalry_pistol') cavalryWeapons.pistol++;
                        else cavalryWeapons.sabre++;
                    } else if (archetype.startsWith('cavalry') || (s.templateKey && (s.templateKey.includes('cavalry') || s.templateKey.includes('sipahi') || s.templateKey.includes('curassier') || s.templateKey.includes('reiter') || s.templateKey.includes('deli') || s.templateKey.includes('ciritci') || s.templateKey.includes('akinci')))) {
                        cavalryCount++;
                    } else {
                        infantryCount++;
                    }'''

assert old_sync_template in html, "Could not find old_sync_template"
html = html.replace(old_sync_template, new_sync_template)

# 8. Update RTSCamera3D to support targetY and close inspection
old_cam_sync = '''                this.camera.position.set(
                    this.current.targetX + Math.sin(this.current.yaw) * horizDist,
                    vertDist,
                    this.current.targetZ + Math.cos(this.current.yaw) * horizDist
                );
                this.camera.lookAt(this.current.targetX, 0, this.current.targetZ);'''

new_cam_sync = '''                const lookTargetY = Number.isFinite(this.current.targetY) ? this.current.targetY : 0;
                this.camera.position.set(
                    this.current.targetX + Math.sin(this.current.yaw) * horizDist,
                    lookTargetY + vertDist,
                    this.current.targetZ + Math.cos(this.current.yaw) * horizDist
                );
                this.camera.lookAt(this.current.targetX, lookTargetY, this.current.targetZ);'''

assert old_cam_sync in html, "Could not find old_cam_sync"
html = html.replace(old_cam_sync, new_cam_sync)

# Also handle targetY interpolation in syncTransform
old_cam_interp = '''                this.current.targetX += (this.desired.targetX - this.current.targetX) * smooth;
                this.current.targetZ += (this.desired.targetZ - this.current.targetZ) * smooth;'''

new_cam_interp = '''                this.current.targetX += (this.desired.targetX - this.current.targetX) * smooth;
                if (Number.isFinite(this.desired.targetY)) {
                    if (!Number.isFinite(this.current.targetY)) this.current.targetY = 0;
                    this.current.targetY += (this.desired.targetY - this.current.targetY) * smooth;
                } else {
                    this.current.targetY = 0;
                }
                this.current.targetZ += (this.desired.targetZ - this.current.targetZ) * smooth;'''

assert old_cam_interp in html, "Could not find old_cam_interp"
html = html.replace(old_cam_interp, new_cam_interp)

# 9. Update Battle3DRenderer._onMouseDown for Turntable in Showcase
old_mousedown = '''                if (e.button === 0) {
                    // Left click: Selection start
                    if (e.altKey) {'''

new_mousedown = '''                if (this.showcaseController && this.showcaseController.isOpen) {
                    this.input.isOrbiting = true;
                    this.input.lastX = e.clientX;
                    this.input.lastY = e.clientY;
                    return;
                }

                if (e.button === 0) {
                    // Left click: Selection start
                    if (e.altKey) {'''

assert old_mousedown in html, "Could not find old_mousedown"
html = html.replace(old_mousedown, new_mousedown)

# 10. Replace RTSUnitShowcaseController with complete 3D Soldier & Turntable Controller
pos_showcase_start = html.find('class RTSUnitShowcaseController {')
assert pos_showcase_start != -1, "Could not find class RTSUnitShowcaseController"

pos_showcase_end = html.find('class Battle3DPreviewController {', pos_showcase_start)
assert pos_showcase_end != -1, "Could not find class Battle3DPreviewController"

full_showcase_controller = '''class RTSUnitShowcaseController {
            constructor(renderer) {
                this.renderer = renderer;
                if (renderer) renderer.showcaseController = this;

                this.overlay = document.getElementById('rtsShowcaseOverlay');
                this.unitListEl = document.getElementById('showcaseUnitList');
                this.currentCulture = 'ottoman';
                this.selectedUnitKey = 'janissary';
                this.selectedVariant = 1;
                this.selectedAnim = 'idle';
                this.compareMode = false;
                this.qualityMode = "high"; // "high" (G3D-03K) vs "classic" (G3D-03J)
                this.isOpen = false;
                this.savedCamera = null;
                this.savedSnapshot = null;

                this.unitCatalog = {
                    ottoman: [
                        { key: 'janissary', name: 'Yeniçeri', role: 'Seçkin Tüfekli/Yatağanlı Kapıkulu Piyadesi', template: 'ottoman:janissary', weapon1: 'Fitilli Osmanlı Tüfengi', weapon2: 'Fildişi Yatağan & Çevşen', headwear: 'Börk (Serpuş)', armor: 'Kaftan & Kuşak' },
                        { key: 'azap', name: 'Azap', role: 'Hafif Sefer Piyadesi & Tırpanlı/Kılıçlı Hat Askeri', template: 'ottoman:azap', weapon1: '3.85m Tırpan Kargı', weapon2: 'Eğri Kılıç & Kalkan', headwear: 'Sarıklı Başlık', armor: 'Keten Yelek & Şalvar' },
                        { key: 'humbaraci', name: 'Humbaracı', role: 'Kuşatma ve Alan Hasarlı Patlayıcı Birliği', template: 'ottoman:humbaraci', weapon1: 'Demir Döküm Humbara Bombası', weapon2: 'Kısa Piştov & Yatağan', headwear: 'Yeşil Sarık', armor: 'Deri Bomba Önlüğü' },
                        { key: 'bostanci', name: 'Bostancı', role: 'Saray Muhafızı Ağır Teberli Şok Piyadesi', template: 'ottoman:bostanci', weapon1: 'Hilal Muhafız Teberi', weapon2: 'Ağır Saray Tüfengi', headwear: 'Bostancı Külahı', armor: 'Çelik Çevşen Plaka' },
                        { key: 'levend', name: 'Levend', role: 'Sahil ve Düzensiz Tüfekçi/Piştovcu', template: 'ottoman:levend', weapon1: 'Çift Piştov & Tırpan', weapon2: 'Fitilli Balkan Tüfengi', headwear: 'Çizgili Sarık', armor: 'Açık Göğüs Yelek' },
                        { key: 'sipahi', name: 'Sipahi', role: 'Tımarlı Süvari (Kargı & Kalkan)', template: 'ottoman:sipahi', weapon1: '4m Bayraklı Kargı & Kalkan', weapon2: 'Türk Kılıcı (Şemşir)', headwear: 'Şişak / Tolga Miğfer', armor: 'Çelik Çevşen & Kolçak' },
                        { key: 'kapikulu_sipahi', name: 'Kapıkulu Sipahisi', role: 'Hassa Ağır Süvarisi (Zırhlı At & Çar-Ayna)', template: 'ottoman:kapikulu_sipahi', weapon1: 'Ağır Süvari Kargısı', weapon2: 'Şeşper Ağır Gürz', headwear: 'Zırh Peçeli Tolga', armor: 'Çar-Ayna Dört Ayna Plaka' },
                        { key: 'deli', name: 'Deli Süvarisi', role: 'Korkusuz Şok ve Hücum Öncü Süvarisi', template: 'ottoman:deli', weapon1: 'Hafif Şok Kargısı', weapon2: 'Eğri Kılıç', headwear: 'Kartal Kanatlı Kalpak', armor: 'Pars / Kurt Postu' },
                        { key: 'ciritci', name: 'Ciritçi', role: 'Cirit Atan Çevik Taciz Süvarisi', template: 'ottoman:ciritci', weapon1: 'Süvari Cirit Sadakı (3 Cirit)', weapon2: 'Hafif Süvari Kılıcı', headwear: 'Deri Başlık', armor: 'Hafif Deri Zırh' },
                        { key: 'akinci', name: 'Akıncı', role: 'Menzilli Step ve Yay Süvarisi', template: 'ottoman:akinci', weapon1: 'Kompozit Yay & Ok Sadakı', weapon2: 'Kargı & Süvari Kılıcı', headwear: 'Keçe Külah', armor: 'Deri Yelek' }
                    ],
                    european: [
                        { key: 'musketier', name: 'Musketier (Tüfekçi)', role: '17. Yüzyıl Fitilli Ağır Tüfekçi', template: 'european:musketier', weapon1: 'Fitilli Musket & Çatal Ayak', weapon2: 'Kısa Süvari Kılıcı', headwear: 'Geniş Şapka & Tüy', armor: '12 Havariler Bandolyesi' },
                        { key: 'pikeniere', name: 'Pikeniere (Mızrakçı)', role: '4.5m Ağır Piyade Kargıcısı', template: 'european:pikeniere', weapon1: '4.5m Kül Dişbudak Pikesi', weapon2: 'Kısa Kılıç', headwear: 'İbikli Morion Miğfer', armor: 'Tapul Göğüslük & Tasset' },
                        { key: 'hellebardier', name: 'Hellebardier', role: 'Kancalı ve Baltalı Çok Amaçlı Piyade', template: 'european:hellebardier', weapon1: 'Gaga Kancalı Hellebarda', weapon2: 'Buckler & Kılıç', headwear: 'Burgonet Miğfer', armor: 'Karartılmış Plaka Zırh' },
                        { key: 'curassier', name: 'Kürassier', role: 'Üç Çeyrek Zırhlı Tabancalı Ağır Süvari', template: 'european:curassier', weapon1: 'Çift Çarklı Piştov', weapon2: 'Geniş Süvari Kılıcı', headwear: 'Zischägge Miğfer', armor: 'Üç Çeyrek Karartılmış Plaka' },
                        { key: 'reiter', name: 'Reiter (Karabinier)', role: 'Zırhlı Çarklı Karabina Süvarisi', template: 'european:reiter', weapon1: 'Çarklı Süvari Karabinası', weapon2: 'Süvari Kılıcı', headwear: 'Demir Miğfer', armor: 'Deri Kolsuz Yelek & Göğüslük' }
                    ]
                };

                this.initEvents();
            }

            get activeRenderer() {
                if (this.renderer) return this.renderer;
                if (typeof window !== 'undefined' && window.__focBattle3DPreview && window.__focBattle3DPreview.renderer) {
                    this.renderer = window.__focBattle3DPreview.renderer;
                    this.renderer.showcaseController = this;
                    return this.renderer;
                }
                return null;
            }

            initEvents() {
                const btnOpen = document.getElementById('btnOpenShowcase');
                const btnClose = document.getElementById('btnCloseShowcase');
                const btnOttoman = document.getElementById('btnShowcaseOttoman');
                const btnEuropean = document.getElementById('btnShowcaseEuropean');
                const btnV1 = document.getElementById('btnShowcaseVariant1');
                const btnV2 = document.getElementById('btnShowcaseVariant2');
                const btnIdle = document.getElementById('btnShowcaseAnimIdle');
                const btnWalk = document.getElementById('btnShowcaseAnimWalk');
                const btnAttack = document.getElementById('btnShowcaseAnimAttack');
                const btnGuard = document.getElementById('btnShowcaseAnimGuard');
                const btnCompare = document.getElementById('btnShowcaseCompareToggle');
                const btnQuality = document.getElementById('btnShowcaseQualityToggle');

                if (btnQuality) {
                    btnQuality.addEventListener('click', () => {
                        this.qualityMode = this.qualityMode === 'high' ? 'classic' : 'high';
                        btnQuality.textContent = this.qualityMode === 'high' ? '✨ Model Kalitesi: G3D-03K (Detaylı)' : '📦 Model Kalitesi: G3D-03J (Klasik)';
                        btnQuality.classList.toggle('active', this.qualityMode === 'high');
                        this.updateInfoCard();
                        this.syncShowcaseSoldiers();
                    });
                }

                if (btnOpen) btnOpen.addEventListener('click', () => this.open());
                if (btnClose) btnClose.addEventListener('click', () => this.close());

                if (btnOttoman) btnOttoman.addEventListener('click', () => {
                    this.setCulture('ottoman');
                    btnOttoman.classList.add('active');
                    if (btnEuropean) btnEuropean.classList.remove('active');
                });

                if (btnEuropean) btnEuropean.addEventListener('click', () => {
                    this.setCulture('european');
                    btnEuropean.classList.add('active');
                    if (btnOttoman) btnOttoman.classList.remove('active');
                });

                if (btnV1) btnV1.addEventListener('click', () => {
                    this.setVariant(1);
                    btnV1.classList.add('active');
                    if (btnV2) btnV2.classList.remove('active');
                });

                if (btnV2) btnV2.addEventListener('click', () => {
                    this.setVariant(2);
                    btnV2.classList.add('active');
                    if (btnV1) btnV1.classList.remove('active');
                });

                const animBtns = [
                    { el: btnIdle, anim: 'idle' },
                    { el: btnWalk, anim: 'walk' },
                    { el: btnAttack, anim: 'attack' },
                    { el: btnGuard, anim: 'guard' }
                ];
                animBtns.forEach(({ el, anim }) => {
                    if (el) {
                        el.addEventListener('click', () => {
                            this.setAnim(anim);
                            animBtns.forEach(b => b.el?.classList.remove('active'));
                            el.classList.add('active');
                        });
                    }
                });

                if (btnCompare) {
                    btnCompare.addEventListener('click', () => {
                        this.toggleCompare();
                        btnCompare.classList.toggle('active', this.compareMode);
                    });
                }
            }

            open() {
                this.isOpen = true;
                if (this.overlay) {
                    this.overlay.style.display = 'flex';
                }

                const rndr = this.activeRenderer;

                // Sahne kamerasını vitrin merkezine odakla (turntable)
                const cam = rndr ? rndr.cameraController : null;
                if (cam) {
                    this.savedCamera = {
                        targetX: cam.desired.targetX,
                        targetY: cam.desired.targetY || 0,
                        targetZ: cam.desired.targetZ,
                        distance: cam.desired.distance,
                        pitch: cam.desired.pitch,
                        yaw: cam.desired.yaw,
                        limits: { ...cam.limits }
                    };
                    cam.limits.minDistance = 1.8;
                    cam.limits.minPitch = 0.02;
                    cam.desired.targetX = 0;
                    cam.desired.targetY = 0.95;
                    cam.desired.targetZ = 0;
                    cam.desired.distance = 3.6;
                    cam.desired.pitch = 0.16;
                    cam.desired.yaw = Math.PI;
                    cam.current.targetX = 0;
                    cam.current.targetY = 0.95;
                    cam.current.targetZ = 0;
                    cam.current.distance = 3.6;
                    cam.current.pitch = 0.16;
                    cam.current.yaw = Math.PI;
                    if (typeof cam.syncTransform === 'function') cam.syncTransform(1);
                }

                // Savaş alanı askerlerini sakla
                if (rndr && rndr.soldierRegistry) {
                    this.savedSnapshot = rndr.soldierRegistry.lastSyncedSnapshot || null;
                }

                this.renderUnitList();
                this.updateInfoCard();
                this.syncShowcaseSoldiers();
            }

            close() {
                this.isOpen = false;
                if (this.overlay) {
                    this.overlay.style.display = 'none';
                }

                const rndr = this.activeRenderer;

                // Kamerayı önceki savaş pozisyonuna geri getir
                const cam = rndr ? rndr.cameraController : null;
                if (cam && this.savedCamera) {
                    const sc = this.savedCamera;
                    if (sc.limits) cam.limits = { ...sc.limits };
                    cam.desired.targetX = sc.targetX;
                    cam.desired.targetY = sc.targetY;
                    cam.desired.targetZ = sc.targetZ;
                    cam.desired.distance = sc.distance;
                    cam.desired.pitch = sc.pitch;
                    cam.desired.yaw = sc.yaw;
                    cam.current.targetX = sc.targetX;
                    cam.current.targetY = sc.targetY;
                    cam.current.targetZ = sc.targetZ;
                    cam.current.distance = sc.distance;
                    cam.current.pitch = sc.pitch;
                    cam.current.yaw = sc.yaw;
                    if (typeof cam.syncTransform === 'function') cam.syncTransform(1);
                }

                // Savaş alanı askerlerini geri yükle
                if (this.savedSnapshot && rndr && rndr.soldierRegistry) {
                    rndr.soldierRegistry.sync(this.savedSnapshot);
                }
            }

            setCulture(cult) {
                this.currentCulture = cult;
                const units = this.unitCatalog[cult] || [];
                if (units.length > 0) {
                    this.selectedUnitKey = units[0].key;
                }
                this.renderUnitList();
                this.updateInfoCard();
                this.syncShowcaseSoldiers();
            }

            setVariant(v) {
                this.selectedVariant = v;
                this.updateInfoCard();
                this.syncShowcaseSoldiers();
            }

            setAnim(a) {
                this.selectedAnim = a;
                this.updateInfoCard();
                this.syncShowcaseSoldiers();
            }

            toggleCompare() {
                this.compareMode = !this.compareMode;
                this.updateInfoCard();
                this.syncShowcaseSoldiers();
            }

            syncShowcaseSoldiers() {
                const rndr = this.activeRenderer;
                if (!rndr || !rndr.soldierRegistry) return;

                const units = this.unitCatalog[this.currentCulture] || [];
                const currentUnit = units.find(u => u.key === this.selectedUnitKey) || units[0];
                if (!currentUnit) return;

                const isOttoman = this.currentCulture === 'ottoman';

                const getTpl = (cult, uKey, variant) => {
                    if (this.qualityMode === 'high') {
                        return `g3d03k:${cult}_${uKey}:high`;
                    } else {
                        return `${cult}:${uKey}:v${variant}`;
                    }
                };

                const isCavalry = (key) => key.includes('sipahi') || key.includes('deli') || key.includes('ciritci') || key.includes('akinci') || key.includes('curassier') || key.includes('reiter');

                let soldiers = [];

                if (!this.compareMode) {
                    const tplKey = getTpl(this.currentCulture, currentUnit.key, this.selectedVariant);
                    soldiers.push({
                        viewId: 'SHOWCASE:U1',
                        soldierId: 'sc1',
                        side: isOttoman ? 'player' : 'enemy',
                        templateKey: tplKey,
                        archetype: isCavalry(currentUnit.key) ? 'cavalry_lance' : 'infantry_musketeer',
                        position: { x: 0, y: 0, z: 0 },
                        facingYaw: Math.PI,
                        walkBlend: this.selectedAnim === 'walk' ? 1.0 : 0.0,
                        actionBlend: (this.selectedAnim === 'attack' || this.selectedAnim === 'guard') ? 1.0 : 0.0,
                        actionMode: this.selectedAnim === 'guard' ? 'guard' : 'attack',
                        state: this.selectedAnim === 'attack' ? 'firing' : (this.selectedAnim === 'guard' ? 'guard' : (this.selectedAnim === 'walk' ? 'moving' : 'idle'))
                    });
                } else {
                    const euroMapping = {
                        janissary: 'musketier',
                        azap: 'pikeniere',
                        bostanci: 'hellebardier',
                        humbaraci: 'reiter',
                        levend: 'musketier',
                        sipahi: 'curassier',
                        kapikulu_sipahi: 'curassier',
                        deli: 'curassier',
                        ciritci: 'reiter',
                        akinci: 'reiter'
                    };
                    const ottKey = isOttoman ? currentUnit.key : (Object.keys(euroMapping).find(k => euroMapping[k] === currentUnit.key) || 'janissary');
                    const eurKey = isOttoman ? (euroMapping[ottKey] || 'musketier') : currentUnit.key;

                    soldiers.push({
                        viewId: 'SHOWCASE:OTT',
                        soldierId: 'sc_ott',
                        side: 'player',
                        templateKey: getTpl('ottoman', ottKey, this.selectedVariant),
                        archetype: isCavalry(ottKey) ? 'cavalry_lance' : 'infantry_musketeer',
                        position: { x: -1.25, y: 0, z: 0 },
                        facingYaw: Math.PI,
                        walkBlend: this.selectedAnim === 'walk' ? 1.0 : 0.0,
                        actionBlend: (this.selectedAnim === 'attack' || this.selectedAnim === 'guard') ? 1.0 : 0.0,
                        actionMode: this.selectedAnim === 'guard' ? 'guard' : 'attack',
                        state: this.selectedAnim === 'attack' ? 'firing' : (this.selectedAnim === 'guard' ? 'guard' : (this.selectedAnim === 'walk' ? 'moving' : 'idle'))
                    });

                    soldiers.push({
                        viewId: 'SHOWCASE:EUR',
                        soldierId: 'sc_eur',
                        side: 'enemy',
                        templateKey: getTpl('european', eurKey, this.selectedVariant),
                        archetype: isCavalry(eurKey) ? 'cavalry_lance' : 'infantry_musketeer',
                        position: { x: 1.25, y: 0, z: 0 },
                        facingYaw: Math.PI,
                        walkBlend: this.selectedAnim === 'walk' ? 1.0 : 0.0,
                        actionBlend: (this.selectedAnim === 'attack' || this.selectedAnim === 'guard') ? 1.0 : 0.0,
                        actionMode: this.selectedAnim === 'guard' ? 'guard' : 'attack',
                        state: this.selectedAnim === 'attack' ? 'firing' : (this.selectedAnim === 'guard' ? 'guard' : (this.selectedAnim === 'walk' ? 'moving' : 'idle'))
                    });
                }

                rndr.soldierRegistry.sync({
                    sectorId: 'SEC_SHOWCASE',
                    soldiers: soldiers
                });

                if (this.selectedAnim === 'attack' || this.selectedAnim === 'guard') {
                    soldiers.forEach(s => {
                        rndr.soldierRegistry.setSoldierVisualCombatAction(s.viewId, true, this.selectedAnim === 'guard' ? 'guard' : 'attack');
                    });
                }
            }

            renderUnitList() {
                if (!this.unitListEl) return;
                this.unitListEl.innerHTML = '';
                const units = this.unitCatalog[this.currentCulture] || [];
                units.forEach(u => {
                    const item = document.createElement('div');
                    item.className = 'showcase-unit-item' + (u.key === this.selectedUnitKey ? ' active' : '');
                    item.innerHTML = `<span>${u.name}</span> <span style="font-size:10px; opacity:0.6;">${u.key.includes('sipahi') || u.key.includes('deli') || u.key.includes('ciritci') || u.key.includes('akinci') || u.key.includes('curassier') || u.key.includes('reiter') ? 'Süvari' : 'Piyade'}</span>`;
                    item.addEventListener('click', () => {
                        this.selectedUnitKey = u.key;
                        this.renderUnitList();
                        this.updateInfoCard();
                        this.syncShowcaseSoldiers();
                    });
                    this.unitListEl.appendChild(item);
                });
            }

            updateInfoCard() {
                const titleEl = document.getElementById('showcaseInfoTitle');
                const descEl = document.getElementById('showcaseInfoDesc');
                const specsEl = document.getElementById('showcaseInfoSpecs');
                if (!titleEl || !descEl || !specsEl) return;

                const units = this.unitCatalog[this.currentCulture] || [];
                const currentUnit = units.find(u => u.key === this.selectedUnitKey) || units[0];
                if (!currentUnit) return;

                const isCav = currentUnit.key.includes('sipahi') || currentUnit.key.includes('deli') || currentUnit.key.includes('ciritci') || currentUnit.key.includes('akinci') || currentUnit.key.includes('curassier') || currentUnit.key.includes('reiter');
                const cultTitle = this.currentCulture === 'ottoman' ? 'Osmanlı Ordusu' : 'Avrupa / Kutsal Roma';

                titleEl.textContent = `${currentUnit.name} — ${cultTitle}`;

                const qText = this.qualityMode === 'high' ? 'G3D-03K Yüksek Kalite (Anatomik Gövde, Katmanlı Kıyafet, Etek Fırfırı, Gerçekçi Başlık & Çevşen/Tapul)' : 'G3D-03J Klasik Düzey (Temel Geometrik Gövde)';
                descEl.textContent = `${currentUnit.role}. 1648–1650 dönemine uygun otantik malzeme ve anatomik parçalarla modellenmiştir. Kalite Düzeyi: ${qText}. Seçili Animasyon: ${this.selectedAnim.toUpperCase()}.`;

                specsEl.innerHTML = `
                    <div>Sınıf: <strong>${isCav ? 'Süvari' : 'Piyade'}</strong></div>
                    <div>Kültür: <strong>${cultTitle}</strong></div>
                    <div>Ana Silah: <strong>${currentUnit.weapon1}</strong></div>
                    <div>Yan Silah / Zırh: <strong>${currentUnit.weapon2}</strong></div>
                    <div>Başlık: <strong>${currentUnit.headwear}</strong></div>
                    <div>Gövde Koruması: <strong>${currentUnit.armor}</strong></div>
                    <div>Şablon Anahtarı: <strong>${currentUnit.template}:v${this.selectedVariant}</strong></div>
                    <div>Anatomi & Profil: <strong>${this.qualityMode === 'high' ? '3 Beden Profili (Slim/Avg/Heavy)' : 'Standart'}</strong></div>
                    <div>Model Standardı: <strong>${this.qualityMode === 'high' ? 'Age of Empires III DE Seviyesi' : 'G3D-03J'}</strong></div>
                `;
            }
        }
'''

html = html[:pos_showcase_start] + full_showcase_controller + '\n        ' + html[pos_showcase_end:]

# 11. Connect renderer to showcaseController in startScene()
old_start_scene = 'this.renderer = new Battle3DRenderer({'
new_start_scene = '''this.renderer = new Battle3DRenderer({'''

# After this.renderer = new Battle3DRenderer({...}); connect showcaseController
pos_renderer_created = html.find('this.renderer = new Battle3DRenderer({')
assert pos_renderer_created != -1, "Could not find this.renderer = new Battle3DRenderer"

pos_semi = html.find('});\n', pos_renderer_created)
assert pos_semi != -1, "Could not find end of Battle3DRenderer instantiation"

renderer_link_code = '''
                if (this.showcaseController) {
                    this.showcaseController.renderer = this.renderer;
                    this.renderer.showcaseController = this.showcaseController;
                }
'''
html = html[:pos_semi + 4] + renderer_link_code + html[pos_semi + 4:]

# 12. Add Tests 65 to 70
tests_65_70 = '''
            // ============================================================================
            // G3D-03K ASKER MODEL KALİTESİ, ANATOMİ, ZIRH & KIYAFET TESTLERİ (65 - 70)
            // ============================================================================

            // 65. Ajan 01: İnsan Anatomisi ve 3 Temel Vücut Profili (Slim, Average, Heavy)
            runCase('65. İnsan Anatomisi ve 3 Temel Vücut Profili (Slim, Average, Heavy)', () => {
                assert(typeof BODY_PROFILES === 'object', 'BODY_PROFILES nesnesi mevcut olmalı');
                assert(BODY_PROFILES.slim && BODY_PROFILES.average && BODY_PROFILES.heavy, '3 temel vücut profili (slim, average, heavy) tanımlı olmalı');
                assert(BODY_PROFILES.heavy.shoulderWidth > BODY_PROFILES.average.shoulderWidth, 'Ağır profil daha geniş omuz genişliğine sahip olmalı');
                assert(BODY_PROFILES.average.shoulderWidth > BODY_PROFILES.slim.shoulderWidth, 'Ortalama profil ince profilden daha geniş omuz genişliğine sahip olmalı');

                const slimModel = buildAnatomicalHumanBase('player', 'slim');
                const heavyModel = buildAnatomicalHumanBase('player', 'heavy');
                assert(slimModel.length >= 22, 'Anatomik insan modeli en az 22 parçadan oluşmalı');
                assert(heavyModel.length >= 22, 'Ağır anatomik insan modeli en az 22 parçadan oluşmalı');

                // Mafsal ve eklem parçaları doğrulaması (baldır, diz ve el)
                const hasKnee = slimModel.some(p => p.rigGroup === 'leftLegLower' && p.prim === 'dome');
                assert(hasKnee, 'Diz kapağı mafsal kubbesi (dome) tanımlı olmalı');
            });

            // 66. Ajan 02: Osmanlı Çok Katmanlı Kıyafet ve Zırh Geometrisi (Kaftan, Kuşak, Çevşen, Börk)
            runCase('66. Osmanlı Çok Katmanlı Kıyafet ve Zırh Geometrisi (Kaftan, Kuşak, Çevşen, Börk)', () => {
                const reg = new SoldierVisualRegistry();
                const ottomanHigh = buildOttomanHighDefHumanBase('player', 'average');
                assert(Array.isArray(ottomanHigh) && ottomanHigh.length >= 24, 'Osmanlı yüksek detaylı gövdesi katmanlı kıyafet parçalarına sahip olmalı');

                // Kaftan kloş alt etek ve altın sırma kenar doğrulaması
                const hasFlaredSkirt = ottomanHigh.some(p => p.mat === 'ottomanCrimson' && p.prim === 'frustum' && p.rigGroup === 'torso');
                const hasGoldBorder = ottomanHigh.some(p => p.mat === 'gold' && p.prim === 'frustum' && p.rigGroup === 'torso');
                assert(hasFlaredSkirt && hasGoldBorder, 'Hacimli kaftan alt eteği ve altın sırma kenarlığı bulunmalı');

                // Börk ve Çevşen doğrulaması
                const borkParts = buildHighDefBork();
                assert(borkParts.length >= 5, 'Yüksek detaylı Börk en az 5 parçaya (zarf, taç, arka sarkan kumaş) sahip olmalı');
                const cevsenParts = buildHighDefCevsen();
                assert(cevsenParts.length >= 5, 'Yüksek detaylı Çevşen çelik disk ve bazuband kolçaklarına sahip olmalı');
            });

            // 67. Ajan 03: Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları (Doublet, Morion, Tapul)
            runCase('67. Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları (Doublet, Morion, Tapul)', () => {
                const euroHigh = buildEuropeanHighDefHumanBase('enemy', 'average');
                assert(Array.isArray(euroHigh) && euroHigh.length >= 24, 'Avrupa yüksek detaylı gövdesi katmanlı kıyafet parçalarına sahip olmalı');

                // Düşen keten yaka ve süvari baldriği doğrulaması
                const hasCollar = euroHigh.some(p => p.mat === 'linen' && p.rigGroup === 'torso');
                const hasBaldric = euroHigh.some(p => p.mat === 'buffLeather' && p.rigGroup === 'torso');
                assert(hasCollar && hasBaldric, 'Düşen keten yaka ve deri süvari baldriği mevcut olmalı');

                // Morion miğfer ibiği ve Tapul zırh omurgası doğrulaması
                const morionParts = buildHighDefMorion();
                const hasComb = morionParts.some(p => p.mat === 'steel' && p.prim === 'box');
                assert(hasComb, 'Morion miğferi yüksek çelik ibiğe sahip olmalı');

                const tapulParts = buildHighDefTapulArmor();
                const hasSpine = tapulParts.some(p => p.mat === 'steel' && p.prim === 'box');
                assert(hasSpine, 'Tapul zırhı mermi saptırıcı çelik omurgaya ve tasset plakalarına sahip olmalı');
            });

            // 68. Ajan 04: Baş, Yüz Anatomisi, Yüz Kılları ve Miğfer Oturumu
            runCase('68. Baş, Yüz Anatomisi, Yüz Kılları ve Miğfer Oturumu', () => {
                const headMustache = buildAnatomicalHead('skin', 'wood', 'ottoman_pala');
                const headVandyke = buildAnatomicalHead('skin', 'wood', 'vandyke');
                const headBeard = buildAnatomicalHead('skin', 'wood', 'full_beard');

                assert(headMustache.length >= 9, 'Pala bıyıklı baş modeli anatomik yüz detaylarını içermeli');
                assert(headVandyke.length >= 9, 'Van Dyke sakallı Avrupa baş modeli anatomik yüz detaylarını içermeli');
                assert(headBeard.length >= 8, 'Tam sakallı gazi/veteran baş modeli tanımlı olmalı');

                // Burun köprüsü ve kulak kubbeleri doğrulaması
                const hasNose = headMustache.some(p => p.prim === 'cone' && p.mat === 'skin');
                const hasEars = headMustache.filter(p => p.prim === 'dome' && p.mat === 'skin').length === 2;
                assert(hasNose && hasEars, 'Belirgin burun köprüsü ve iki kulak kubbesi bulunmalı');
            });

            // 69. Ajan 05: 1650 İleri Malzeme Kütüphanesi ve PBR Yüzey Özellikleri
            runCase('69. 1650 İleri Malzeme Kütüphanesi ve PBR Yüzey Özellikleri', () => {
                const reg = new SoldierVisualRegistry();
                const expectedPBR = ['blackenedSteel', 'burnishedBronze', 'buffLeather', 'fineSilk', 'roughWool'];
                for (const matKey of expectedPBR) {
                    assert(reg.materials[matKey], `${matKey} PBR materyali kayıtlı olmalı`);
                    assert(reg.materials[matKey].color && typeof reg.materials[matKey].color.r === 'number', `${matKey} geçerli Color nesnesi içermeli`);
                }

                // Metalness kontrast doğrulaması: Karartılmış çelik yüksek metalness, manda derisi sıfıra yakın metalness içermeli
                assert(reg.materials.blackenedSteel.metalness > 0.75, 'blackenedSteel yüksek metalness içermeli');
                assert(reg.materials.buffLeather.metalness < 0.10, 'buffLeather mat deri olarak düşük metalness içermeli');

                // 206 temel model şablonunun kesin korunması
                assert(Object.keys(reg.templates).length === 206, '206 temel model şablonu tam olarak korunmalı');
            });

            // 70. Ajan 06: Modüler Asker Birleştirme Motoru ve Vitrin Model Kalitesi Kıyaslaması
            runCase('70. Modüler Asker Birleştirme Motoru ve Vitrin Model Kalitesi Kıyaslaması', () => {
                assert(typeof RTSModularUnitBuilder === 'function', 'RTSModularUnitBuilder sınıfı tanımlı olmalı');

                const soldier1 = RTSModularUnitBuilder.assembleSoldier('ottoman_janissary', 'player', 10);
                const soldier2 = RTSModularUnitBuilder.assembleSoldier('european_pikeniere', 'enemy', 11);
                assert(Array.isArray(soldier1) && soldier1.length >= 30, 'Modüler Yeniçeri en az 30 yüksek detaylı parçadan oluşmalı');
                assert(Array.isArray(soldier2) && soldier2.length >= 30, 'Modüler Pikeniere en az 30 yüksek detaylı parçadan oluşmalı');

                // Vitrin Kalite Modu Doğrulaması
                const mockRenderer = { cameraController: new RTSCamera3D() };
                const showcase = new RTSUnitShowcaseController(mockRenderer);
                assert(showcase.qualityMode === 'high', 'Asker vitrini varsayılan olarak G3D-03K yüksek kalite modunda başlamalı');

                const btnQuality = document.getElementById('btnShowcaseQualityToggle');
                assert(btnQuality, 'Model kalitesi geçiş butonu arayüzde mevcut olmalı');
            });
'''

idx_test64 = html.find("showcase.toggleCompare();")
assert idx_test64 != -1, "Could not find Test 64 in html"

idx_test64_end = html.find('});', idx_test64) + 3
html = html[:idx_test64_end] + '\n' + tests_65_70 + '\n' + html[idx_test64_end:]

with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(html)

print(f"Successfully built G3D03K_WORKING.html ({len(html)} bytes).")
