import re

with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    c = f.read()

rigs = set(re.findall(r"rigGroup\s*===\s*'([^']+)'", c))
print("RIG GROUPS FOUND:")
for r in sorted(rigs):
    print(" -", r)
