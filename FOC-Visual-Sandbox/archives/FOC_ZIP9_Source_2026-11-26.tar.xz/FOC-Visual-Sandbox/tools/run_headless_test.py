import subprocess
import os
import sys
import tempfile
import re

def run_test(html_path, timeout=75):
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    if not os.path.exists(chrome_path):
        return {"error": f"Chrome not found at {chrome_path}"}
    
    temp_profile = os.path.join(tempfile.gettempdir(), f'foc_test_profile_{os.getpid()}_{abs(hash(html_path)) % 100000}')
    
    file_url = 'file:///' + os.path.abspath(html_path).replace('\\', '/') + '?runTests=1#tests'
    cmd = [
        chrome_path,
        '--headless=new',
        '--disable-gpu',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--dump-dom',
        file_url
    ]
    
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, encoding='utf-8', errors='replace')
        dom = proc.stdout
        
        # Parse test results
        items = re.findall(r'<div class="test-item (pass|fail)">(.*?)</div>\s*(?=<div class="test-item|</div>\s*</div>)', dom, re.DOTALL)
        if not items:
            # Fallback simple count
            pass_count = len(re.findall(r'class="test-item pass"', dom))
            fail_count = len(re.findall(r'class="test-item fail"', dom))
            summary_m = re.search(r'(\d+)\s*/\s*(\d+)\s*doğrulama testi', dom)
            summary = summary_m.group(0) if summary_m else f"{pass_count} passed, {fail_count} failed"
            return {
                "total": pass_count + fail_count,
                "pass": pass_count,
                "fail": fail_count,
                "summary": summary,
                "failures": []
            }
            
        pass_count = sum(1 for status, _ in items if status == 'pass')
        fail_count = sum(1 for status, _ in items if status == 'fail')
        failures = []
        for idx, (status, content) in enumerate(items, 1):
            if status == 'fail':
                clean_text = re.sub(r'<[^>]+>', '', content).strip()
                clean_text = re.sub(r'\s+', ' ', clean_text)
                failures.append(f"✘ {clean_text[:120]}")
                
        summary_m = re.search(r'(\d+)\s*/\s*(\d+)\s*doğrulama testi', dom)
        summary = summary_m.group(0) if summary_m else f"{pass_count} passed, {fail_count} failed"
        
        return {
            "total": pass_count + fail_count,
            "pass": pass_count,
            "fail": fail_count,
            "summary": summary,
            "failures": failures
        }
    except Exception as e:
        return {"error": str(e)}

if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else 'G3D03K_WORKING.html'
    res = run_test(target)
    print(res)
