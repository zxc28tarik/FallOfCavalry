import subprocess, os, tempfile, json

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), f'foc_showcase_live_test_{os.getpid()}')
url = 'file:///' + os.path.abspath('G3D03K_WORKING.html').replace('\\', '/')

test_script = """
<script>
window.addEventListener('load', () => {
    setTimeout(() => {
        const out = {};
        try {
            const sc = window.focShowcase;
            const reg = window.__focBattle3DPreview.renderer.soldierRegistry;
            
            out.initialCount = reg.records.size;
            
            sc.open();
            out.isOpen = sc.isOpen;
            out.showcaseCount = reg.records.size;
            out.unitKeys = Array.from(reg.records.keys());
            const u1 = reg.records.get('SHOWCASE:U1');
            out.u1Template = u1 ? u1.templateKey : null;
            
            // Switch to classic
            sc.qualityMode = 'classic';
            sc.syncShowcaseSoldiers();
            const u1Classic = reg.records.get('SHOWCASE:U1');
            out.u1ClassicTemplate = u1Classic ? u1Classic.templateKey : null;
            
            // Compare
            sc.toggleCompare();
            out.compareCount = reg.records.size;
            out.compareKeys = Array.from(reg.records.keys());
            
            // Close
            sc.close();
            out.closedIsOpen = sc.isOpen;
            out.restoredCount = reg.records.size;
        } catch (e) {
            out.error = e.toString() + "\\n" + e.stack;
        }
        const dump = document.createElement('div');
        dump.id = 'showcaseLiveOutput';
        dump.textContent = JSON.stringify(out);
        document.body.appendChild(dump);
    }, 400);
});
</script>
"""

with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    orig = f.read()

patched = orig.replace('</body>', test_script + '</body>')
with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(patched)

cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--dump-dom',
    url
]

proc = subprocess.run(cmd, capture_output=True, text=True, timeout=25, encoding='utf-8', errors='replace')

with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(orig)

pos = proc.stdout.find('id="showcaseLiveOutput"')
if pos != -1:
    end = proc.stdout.find('</div>', pos)
    print("SHOWCASE TEST OUTPUT:")
    print(proc.stdout[pos+24:end])
else:
    print("Could not find showcaseLiveOutput in DOM")
