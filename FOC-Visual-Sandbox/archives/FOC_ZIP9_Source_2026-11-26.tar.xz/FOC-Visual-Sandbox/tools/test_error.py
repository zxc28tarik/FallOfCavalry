import subprocess, os, tempfile

chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), 'foc_test_profile_err')

test_script = """
<script>
window.testErrors = [];
window.addEventListener('error', (e) => {
    window.testErrors.push(e.message + " at " + e.filename + ":" + e.lineno);
});
window.addEventListener('load', () => {
    setTimeout(() => {
        const d = document.createElement('div');
        d.id = 'errorDebugInfo';
        d.textContent = JSON.stringify({
            errors: window.testErrors,
            hasController: !!window.__focBattle3DPreview,
            summaryText: document.getElementById('unitTestSummary')?.textContent
        });
        document.body.appendChild(d);
    }, 200);
});
</script>
"""

with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    orig = f.read()

# Put test_script at the very top of <head>
pos_head = orig.find('<head>')
with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(orig[:pos_head+6] + test_script + orig[pos_head+6:])

file_url = 'file:///' + os.path.abspath('G3D03K_WORKING.html').replace('\\', '/') + '?runTests=1#tests'
cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--virtual-time-budget=3000',
    '--dump-dom',
    file_url
]

proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15, encoding='utf-8', errors='replace')

with open('G3D03K_WORKING.html', 'w', encoding='utf-8') as f:
    f.write(orig)

pos = proc.stdout.find('id="errorDebugInfo"')
if pos != -1:
    end = proc.stdout.find('</div>', pos)
    print("ERROR INFO:", proc.stdout[pos+20:end])
else:
    print("Not found")
