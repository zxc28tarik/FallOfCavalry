# -*- coding: utf-8 -*-
"""
tools/fixed_euro_infantry.py
1650 European / HRE Fixed, Non-Modular Infantry Character Archetypes.

Provides `get_fixed_euro_infantry_code()` returning JavaScript defining
`FIXED_EURO_INFANTRY` with 5 fixed, non-modular character builders:
  1. 'fixed:euro_musketier'
  2. 'fixed:euro_arquebusier'
  3. 'fixed:euro_pikeniere'
  4. 'fixed:euro_hellebardier'
  5. 'fixed:euro_armored_infantry'

Uses unified organic meshes:
  'orgTorsoCoat', 'orgTorsoArmored', 'orgHeadNatural', 'orgLimb', 'orgBoot',
  'orgHand', 'orgHelmetMorion', 'orgHelmetCavalier', 'orgHelmetPointed',
  'orgFallingCollar', 'orgHairCurtain',
  'orgArmMusketL', 'orgArmMusketR', 'orgArmPikeL', 'orgArmPikeR',
  'orgArmSwordR', 'orgArmShieldL'
plus primitives only for thin weapon barrels/stocks/forks/pikes/plumes/buttons
and small trim/cuff accessories.

Coordinate system: +Y up (feet y=0, shoulders y=1.32, head y=1.54),
+Z forward, -X left, +X right.
"""


def get_fixed_euro_infantry_code():
    """Return JavaScript source defining FIXED_EURO_INFANTRY with 5 archetypes."""
    return r'''
        /* ============================================================================
         * 1650 EUROPEAN / HRE FIXED INFANTRY ARCHETYPES (NON-MODULAR, ORGANIC MESHES)
         * ============================================================================ */

        function euroOrgLimb(mat, ax, ay, az, bx, by, bz, widthX, depthZ, rigGroup) {
            const dx = bx - ax;
            const dy = by - ay;
            const dz = bz - az;
            const len = Math.hypot(dx, dy, dz) || 0.001;
            const mx = (ax + bx) * 0.5;
            const my = (ay + by) * 0.5;
            const mz = (az + bz) * 0.5;
            const rx = Math.atan2(dz, dy);
            const rz = -Math.atan2(dx, Math.hypot(dy, dz));
            return makePart('orgLimb', mat, mx, my, mz, widthX, len, depthZ, rx, 0, rz, rigGroup);
        }

        function euroWristCuff(mat, ex, ey, ez, wx, wy, wz, rigGroup) {
            const dx = wx - ex;
            const dy = wy - ey;
            const dz = wz - ez;
            const len = Math.hypot(dx, dy, dz) || 0.001;
            const ux = dx / len;
            const uy = dy / len;
            const uz = dz / len;
            const rx = Math.asin(Math.max(-1, Math.min(1, uz)));
            const rz = Math.atan2(-ux, uy);
            return makePart(
                'cylinder', mat,
                wx - ux * 0.015, wy - uy * 0.015, wz - uz * 0.015,
                0.098, 0.030, 0.098,
                rx, 0, rz,
                rigGroup
            );
        }

        function buildEuroLowerBodyAndHead(breechesMat, bootMat, mustacheMat, collarMat) {
            const parts = [
                // Ground shadow
                makePart('cylinder', 'shadow', 0, 0.02, 0, 1.06, 0.02, 1.06, 0, 0, 0, 'shadow'),

                // Organic boots (feet y=0 .. knee y=0.46)
                makePart('orgBoot', bootMat, -0.14, 0.23, 0.02, 0.16, 0.46, 0.24, 0, 0, 0, 'leftLegLower'),
                makePart('orgBoot', bootMat,  0.14, 0.23, 0.02, 0.16, 0.46, 0.24, 0, 0, 0, 'rightLegLower'),

                // Organic thighs / breeches (knee y=0.46 .. hip y=0.84)
                euroOrgLimb(breechesMat, -0.14, 0.84, 0.0, -0.14, 0.46, 0.0, 0.21, 0.22, 'leftLegUpper'),
                euroOrgLimb(breechesMat,  0.14, 0.84, 0.0,  0.14, 0.46, 0.0, 0.21, 0.22, 'rightLegUpper'),

                // Neck & natural organic head (y=1.54, thick neck seated cleanly into collar/head)
                euroOrgLimb('skin', 0, 1.38, 0.01, 0, 1.49, 0.015, 0.165, 0.165, 'torso'),
                makePart('orgHeadNatural', 'skin', 0, 1.54, 0.02, 0.23, 0.25, 0.23, 0, 0, 0, 'torso'),

                // Sculpted wavy shoulder-length hair curtain framing sides & back of head
                makePart('orgHairCurtain', 'hairDark', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'torso'),

                // Subtle crisp facial features: eyes seated in sculpted sockets + brow lines above
                makePart('sphere', 'eyeDark', -0.036, 1.565, 0.103, 0.022, 0.016, 0.014, 0, 0, 0, 'torso'),
                makePart('sphere', 'eyeDark',  0.036, 1.565, 0.103, 0.022, 0.016, 0.014, 0, 0, 0, 'torso'),
                makePart('box', 'hairDark', -0.036, 1.580, 0.106, 0.024, 0.0055, 0.008, 0, -0.45, -0.08, 'torso'),
                makePart('box', 'hairDark',  0.036, 1.580, 0.106, 0.024, 0.0055, 0.008, 0,  0.45,  0.08, 'torso')
            ];

            if (collarMat) {
                // Wide 17th-century falling white linen collar with twin pointed front tabs
                parts.push(makePart('orgFallingCollar', collarMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'torso'));
            }

            if (mustacheMat) {
                // 1650 handlebar mustache + small imperial goatee (tucked neatly under nose)
                parts.push(makePart('cone', mustacheMat, -0.028, 1.495, 0.108, 0.020, 0.052, 0.018, 0.15,  0.22,  1.38, 'torso'));
                parts.push(makePart('cone', mustacheMat,  0.028, 1.495, 0.108, 0.020, 0.052, 0.018, 0.15, -0.22, -1.38, 'torso'));
                parts.push(makePart('cone', mustacheMat,  0.0,   1.455, 0.102, 0.024, 0.040, 0.020, Math.PI + 0.15, 0, 0, 'torso'));
            }

            return parts;
        }

        function buildEuroMatchlockParts(barrelMat, bandMat, barrelLen, forestockLen, hasFurquet) {
            // Diagonal alignment from right wrist (0.17, 1.24, 0.26) across to left wrist (-0.10, 1.27, 0.62) and onward
            const rx0 = 0.17, ry0 = 1.24, rz0 = 0.26;
            const lx0 = -0.10, ly0 = 1.27, lz0 = 0.62;
            const dx = lx0 - rx0;
            const dy = ly0 - ry0;
            const dz = lz0 - rz0;
            const dist = Math.hypot(dx, dy, dz) || 1;
            const ux = dx / dist, uy = dy / dist, uz = dz / dist;

            const yaw = Math.atan2(dx, dz);
            const slope = Math.atan2(dy, Math.hypot(dx, dz));
            const cylPitch = Math.PI * 0.5 - slope;
            const boxPitch = -slope;

            const pt = (s, yOff = 0) => [rx0 + ux * s, ry0 + uy * s + yOff, rz0 + uz * s];

            const butt = pt(-0.12, -0.026);
            const plate = pt(-0.26, -0.052);
            const fore = pt(forestockLen * 0.5, -0.004);
            const barrel = pt(0.04 + barrelLen * 0.5, 0.018);
            const muzzle = pt(0.04 + barrelLen - 0.045, 0.018);
            const lock = pt(0.05, 0.008);

            const parts = [
                makePart('box',      'wood',      butt[0],   butt[1],   butt[2],   0.066, 0.12, 0.30, boxPitch - 0.18, yaw, 0, 'twoHandMusket'),
                makePart('box',      'steel',     plate[0],  plate[1],  plate[2],  0.068, 0.135, 0.024, boxPitch - 0.18, yaw, 0, 'twoHandMusket'),
                makePart('frustum',  'wood',      fore[0],   fore[1],   fore[2],   0.070, forestockLen, 0.078, cylPitch, yaw, 0, 'twoHandMusket'),
                makePart('cylinder', barrelMat,   barrel[0], barrel[1], barrel[2], 0.046, barrelLen, 0.046, cylPitch, yaw, 0, 'twoHandMusket'),
                makePart('cylinder', bandMat,     muzzle[0], muzzle[1], muzzle[2], 0.054, 0.045, 0.054, cylPitch, yaw, 0, 'twoHandMusket'),
                makePart('box',      bandMat,     lock[0],   lock[1],   lock[2],   0.062, 0.040, 0.075, boxPitch, yaw, 0, 'twoHandMusket')
            ];

            if (hasFurquet) {
                // Furquet rest planted cleanly under left wrist (-0.10, 1.27, 0.62)
                const cosY = Math.cos(yaw);
                const sinY = Math.sin(yaw);
                parts.push(
                    makePart('cylinder', 'wood',   -0.10, 0.625, 0.62, 0.032, 1.25, 0.032, 0, 0, 0, 'twoHandMusket'),
                    makePart('box',      'bronze', -0.10, 1.25,  0.62, 0.095, 0.032, 0.032, 0, yaw, 0, 'twoHandMusket'),
                    makePart('cylinder', 'bronze', -0.10 - 0.036 * cosY, 1.285, 0.62 + 0.036 * sinY, 0.020, 0.070, 0.020, 0, yaw,  0.22, 'twoHandMusket'),
                    makePart('cylinder', 'bronze', -0.10 + 0.036 * cosY, 1.285, 0.62 - 0.036 * sinY, 0.020, 0.070, 0.020, 0, yaw, -0.22, 'twoHandMusket')
                );
            }

            return parts;
        }

        function buildEuroMusketier() {
            return [
                ...buildEuroLowerBodyAndHead('playerBreeches', 'leather', 'hairDark', 'linen'),

                // Sculpted royal blue organic coat torso (waist at y=1.05, 8-fold flared skirt down to y=0.76)
                makePart('orgTorsoCoat', 'playerCloth', 0, 1.09, 0.0, 0.50, 0.66, 0.44, 0, 0, 0, 'torso'),

                // 6 small gold buttons seated flush down sculpted chest & skirt front
                makePart('sphere', 'gold', 0, 1.32, 0.120, 0.022, 0.022, 0.020, 0, 0, 0, 'torso'),
                makePart('sphere', 'gold', 0, 1.26, 0.133, 0.022, 0.022, 0.020, 0, 0, 0, 'torso'),
                makePart('sphere', 'gold', 0, 1.20, 0.121, 0.022, 0.022, 0.020, 0, 0, 0, 'torso'),
                makePart('sphere', 'gold', 0, 1.14, 0.100, 0.022, 0.022, 0.020, 0, 0, 0, 'torso'),
                makePart('sphere', 'gold', 0, 0.99, 0.098, 0.022, 0.022, 0.020, 0, 0, 0, 'torso'),
                makePart('sphere', 'gold', 0, 0.92, 0.110, 0.022, 0.022, 0.020, 0, 0, 0, 'torso'),

                // Waist belt & subtle brass buckle (0.055)
                makePart('cylinder', 'leather', 0, 1.05, 0.005, 0.315, 0.058, 0.225, 0, 0, 0, 'torso'),
                makePart('box', 'gold', 0, 1.05, 0.120, 0.055, 0.052, 0.020, 0, 0, 0, 'torso'),

                // 12 Apostles leather bandolier + hanging wooden powder flasks
                makePart('box', 'leather', 0.0, 1.20,  0.116, 0.38, 0.048, 0.024, 0, 0, -0.68, 'torso'),
                makePart('box', 'leather', 0.0, 1.20, -0.105, 0.38, 0.048, 0.024, 0, 0,  0.68, 'torso'),
                makePart('cylinder', 'wood', -0.11, 1.09, 0.132, 0.036, 0.095, 0.036, 0.08, 0, -0.12, 'torso'),
                makePart('cylinder', 'wood', -0.04, 1.14, 0.135, 0.036, 0.095, 0.036, 0.08, 0, -0.12, 'torso'),
                makePart('cylinder', 'wood',  0.04, 1.19, 0.135, 0.036, 0.095, 0.036, 0.08, 0, -0.12, 'torso'),
                makePart('cylinder', 'wood',  0.11, 1.24, 0.132, 0.036, 0.095, 0.036, 0.08, 0, -0.12, 'torso'),
                makePart('cylinder', 'gold',  0.04, 1.23, 0.135, 0.040, 0.018, 0.040, 0.08, 0, -0.12, 'torso'),

                // Cavalier slouch hat with sky-blue ostrich plume (seated snugly at y=1.63)
                makePart('orgHelmetCavalier', 'feltBlack', 0, 1.63, 0.015, 0.54, 0.24, 0.54, -0.06, 0.08, -0.05, 'torso'),
                makePart('cylinder', 'gold', 0, 1.62, 0.015, 0.28, 0.028, 0.29, -0.06, 0.08, -0.05, 'torso'),
                makePart('frustum', 'playerCloth', 0.14, 1.74, -0.065, 0.09, 0.28, 0.06, -0.85, 0.25, -0.25, 'torso'),
                makePart('cone',    'playerCloth', 0.20, 1.84, -0.185, 0.075, 0.24, 0.05, -1.25, 0.35, -0.30, 'torso'),

                // Single-piece unified bent sleeves + linen wrist cuff rings + orgHand on twoHandMusket
                makePart('orgArmMusketL', 'playerCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandMusket'),
                euroWristCuff('linen', -0.25, 1.15, 0.16, -0.10, 1.25, 0.62, 'twoHandMusket'),
                makePart('orgHand', 'skin', -0.10, 1.25, 0.62, 0.090, 0.090, 0.095, 0, 0, 0, 'twoHandMusket'),

                makePart('orgArmMusketR', 'playerCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandMusket'),
                euroWristCuff('linen', 0.25, 1.14, 0.08, 0.17, 1.23, 0.28, 'twoHandMusket'),
                makePart('orgHand', 'skin', 0.17, 1.23, 0.28, 0.090, 0.090, 0.095, 0, 0, 0, 'twoHandMusket'),

                // Matchlock musket + bronze-forked furquet rest
                ...buildEuroMatchlockParts('blackenedSteel', 'gold', 1.18, 0.78, true)
            ];
        }

        function buildEuroArquebusier() {
            return [
                ...buildEuroLowerBodyAndHead('enemyBreeches', 'leather', 'hairDark', 'linen'),

                // Crimson enemyCloth doublet + sleeveless buffLeather jerkin
                makePart('orgTorsoCoat', 'enemyCloth',  0, 1.09, 0.0,   0.49, 0.66, 0.43, 0, 0, 0, 'torso'),
                makePart('orgTorsoCoat', 'buffLeather', 0, 1.11, 0.008, 0.51, 0.60, 0.45, 0, 0, 0, 'torso'),

                // Leather waist belt, subtle bronze buckle (0.055) & powder pouch
                makePart('cylinder', 'leather', 0, 1.05, 0.005, 0.325, 0.058, 0.235, 0, 0, 0, 'torso'),
                makePart('box', 'bronze', 0, 1.05, 0.125, 0.055, 0.050, 0.020, 0, 0, 0, 'torso'),
                makePart('box', 'leather', 0.17, 0.98, 0.04, 0.07, 0.10, 0.09, 0, 0, -0.1, 'torso'),

                // Broad-brimmed slouch hat without plume (seated snugly at y=1.62)
                makePart('orgHelmetCavalier', 'feltBlack', 0, 1.62, 0.015, 0.52, 0.22, 0.52, -0.04, -0.05, 0.04, 'torso'),
                makePart('cylinder', 'leather', 0, 1.61, 0.015, 0.275, 0.028, 0.285, -0.04, -0.05, 0.04, 'torso'),

                // Single-piece unified bent sleeves + linen wrist cuff rings + orgHand on twoHandMusket
                makePart('orgArmMusketL', 'enemyCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandMusket'),
                euroWristCuff('linen', -0.25, 1.15, 0.16, -0.10, 1.25, 0.62, 'twoHandMusket'),
                makePart('orgHand', 'skin', -0.10, 1.25, 0.62, 0.090, 0.090, 0.095, 0, 0, 0, 'twoHandMusket'),

                makePart('orgArmMusketR', 'enemyCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandMusket'),
                euroWristCuff('linen', 0.25, 1.14, 0.08, 0.17, 1.23, 0.28, 'twoHandMusket'),
                makePart('orgHand', 'skin', 0.17, 1.23, 0.28, 0.090, 0.090, 0.095, 0, 0, 0, 'twoHandMusket'),

                // Lighter matchlock arquebus (shorter barrel, no furquet rest)
                ...buildEuroMatchlockParts('darkSteel', 'bronze', 0.92, 0.62, false)
            ];
        }

        function buildEuroPikeniere() {
            const pikeAngleX = Math.atan2(0.34, 0.20);
            const cosP = Math.cos(pikeAngleX);
            const sinP = Math.sin(pikeAngleX);
            const px = -0.29;
            const p1y = 1.10;
            const p1z = 0.16;

            return [
                ...buildEuroLowerBodyAndHead('buffLeather', 'leather', 'hairDark', null),

                // Dark cloth doublet under sculpted blackenedSteel breastplate with integrated shot ridge & fauld/tassets
                makePart('orgTorsoCoat',    'darkCloth',      0, 1.09, 0.0,   0.47, 0.64, 0.39, 0, 0, 0, 'torso'),
                makePart('orgTorsoArmored', 'blackenedSteel', 0, 1.12, 0.008, 0.54, 0.58, 0.47, 0, 0, 0, 'torso'),
                makePart('frustum',         'steel',          0, 1.40, 0.01,  0.32, 0.065, 0.29, 0, 0, 0, 'torso'),

                // Steel pauldrons seated tightly onto upper arms
                makePart('dome', 'blackenedSteel', -0.235, 1.32, 0.0, 0.20, 0.16, 0.21, 0, 0,  0.24, 'torso'),
                makePart('dome', 'blackenedSteel',  0.235, 1.32, 0.0, 0.20, 0.16, 0.21, 0, 0, -0.24, 'torso'),

                // High-crested Morion helmet (snug at y=1.60)
                makePart('orgHelmetMorion', 'steel', 0, 1.60, 0.015, 0.40, 0.28, 0.46, -0.04, 0, 0, 'torso'),

                // Single-piece unified bent pike arms on twoHandPike
                makePart('orgArmPikeL', 'darkCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandPike'),
                makePart('orgHand', 'leather', -0.31, 1.10, 0.16, 0.095, 0.095, 0.098, 0, 0, 0, 'twoHandPike'),

                makePart('orgArmPikeR', 'darkCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandPike'),
                makePart('orgHand', 'leather', -0.27, 1.30, 0.50, 0.095, 0.095, 0.098, 0, 0, 0, 'twoHandPike'),

                // 4.5m ash pike gripped along x = -0.29 (shaft + steel spearhead + butt-spike)
                makePart('cylinder', 'wood',  px, p1y + 1.25 * cosP, p1z + 1.25 * sinP, 0.040, 4.50, 0.040, pikeAngleX, 0, 0, 'twoHandPike'),
                makePart('cone',     'steel', px, p1y - 0.98 * cosP, p1z - 0.98 * sinP, 0.060, 0.14, 0.060, pikeAngleX + Math.PI, 0, 0, 'twoHandPike'),
                makePart('box',      'steel', px, p1y + 3.25 * cosP, p1z + 3.25 * sinP, 0.050, 0.36, 0.024, pikeAngleX, 0, 0, 'twoHandPike'),
                makePart('cone',     'steel', px, p1y + 3.58 * cosP, p1z + 3.58 * sinP, 0.105, 0.38, 0.052, pikeAngleX, 0, 0, 'twoHandPike')
            ];
        }

        function buildEuroHellebardier() {
            const hPitch = Math.atan2(0.34, 0.20);
            const cosH = Math.cos(hPitch);
            const sinH = Math.sin(hPitch);
            const hx = -0.29;
            const h1y = 1.10;
            const h1z = 0.16;

            return [
                ...buildEuroLowerBodyAndHead('enemyBreeches', 'leather', 'hairDark', 'linen'),

                // Crimson coat + sculpted steel breastplate & gorget
                makePart('orgTorsoCoat',    'enemyCloth', 0, 1.09, 0.0,   0.49, 0.66, 0.42, 0, 0, 0, 'torso'),
                makePart('orgTorsoArmored', 'steel',      0, 1.13, 0.008, 0.53, 0.56, 0.46, 0, 0, 0, 'torso'),
                makePart('frustum',         'steel',      0, 1.40, 0.01,  0.31, 0.060, 0.28, 0, 0, 0, 'torso'),
                makePart('cylinder',        'leather',    0, 1.08, 0.006, 0.33, 0.055, 0.245, 0, 0, 0, 'torso'),

                // Open helmet (lobster-tail / pointed open pot, snug at y=1.60)
                makePart('orgHelmetPointed', 'steel', 0, 1.60, 0.015, 0.31, 0.25, 0.33, 0, 0, 0, 'torso'),
                makePart('box', 'steel', 0, 1.57, 0.16, 0.22, 0.025, 0.11, 0.22, 0, 0, 'torso'),
                makePart('box', 'steel', 0, 1.51, -0.14, 0.24, 0.14, 0.03, -0.35, 0, 0, 'torso'),

                // Single-piece unified bent halberd arms on twoHandPike
                makePart('orgArmPikeL', 'enemyCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandPike'),
                euroWristCuff('linen', -0.29, 1.14, -0.02, -0.31, 1.10, 0.16, 'twoHandPike'),
                makePart('orgHand', 'skin', -0.31, 1.10, 0.16, 0.090, 0.090, 0.095, 0, 0, 0, 'twoHandPike'),

                makePart('orgArmPikeR', 'enemyCloth', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandPike'),
                euroWristCuff('linen', 0.10, 1.18, 0.22, -0.27, 1.30, 0.50, 'twoHandPike'),
                makePart('orgHand', 'skin', -0.27, 1.30, 0.50, 0.090, 0.090, 0.095, 0, 0, 0, 'twoHandPike'),

                // 3.2m Halberd gripped along x = -0.29 (ash shaft + axe blade + rear fluke + top spear spike)
                makePart('cylinder', 'wood',  hx, h1y + 0.85 * cosH, h1z + 0.85 * sinH, 0.044, 3.20, 0.044, hPitch, 0, 0, 'twoHandPike'),
                makePart('cone',     'steel', hx, h1y - 0.75 * cosH, h1z - 0.75 * sinH, 0.058, 0.12, 0.058, hPitch + Math.PI, 0, 0, 'twoHandPike'),
                makePart('cylinder', 'steel', hx, h1y + 2.38 * cosH, h1z + 2.38 * sinH, 0.058, 0.24, 0.058, hPitch, 0, 0, 'twoHandPike'),
                makePart('box',      'steel', hx, h1y + 2.38 * cosH - 0.11 * sinH, h1z + 2.38 * sinH + 0.11 * cosH, 0.025, 0.30, 0.22, hPitch, 0, 0, 'twoHandPike'),
                makePart('cone',     'steel', hx, h1y + 2.38 * cosH + 0.09 * sinH, h1z + 2.38 * sinH - 0.09 * cosH, 0.035, 0.18, 0.035, hPitch - Math.PI * 0.5, 0, 0, 'twoHandPike'),
                makePart('cone',     'steel', hx, h1y + 2.68 * cosH, h1z + 2.68 * sinH, 0.075, 0.44, 0.048, hPitch, 0, 0, 'twoHandPike')
            ];
        }

        function buildEuroArmoredInfantry() {
            const swordPitch = Math.PI * 0.5 - 0.45;
            const sinS = Math.sin(swordPitch);
            const cosS = Math.cos(swordPitch);
            const hx = 0.23;
            const hy = 1.20;
            const hz = 0.32;

            const shieldNx = -Math.sin(0.36);
            const shieldNz =  Math.cos(0.36);

            return [
                ...buildEuroLowerBodyAndHead('darkCloth', 'blackenedSteel', 'hairDark', null),

                // Full sculpted blackenedSteel cuirass with integrated shot ridge & 4-lame fauld/tasset skirt
                makePart('orgTorsoArmored', 'blackenedSteel', 0, 1.12, 0.0, 0.55, 0.60, 0.48, 0, 0, 0, 'torso'),
                makePart('frustum',         'steel',          0, 1.40, 0.01, 0.33, 0.070, 0.30, 0, 0, 0, 'torso'),

                // Layered steel pauldrons seated tightly onto upper arms
                makePart('dome', 'steel', -0.235, 1.32, 0.0, 0.22, 0.18, 0.23, 0, 0,  0.24, 'torso'),
                makePart('dome', 'steel',  0.235, 1.32, 0.0, 0.22, 0.18, 0.23, 0, 0, -0.24, 'torso'),

                // Visored burgonet (seated snugly at y=1.60)
                makePart('orgHelmetPointed', 'blackenedSteel', 0, 1.60, 0.015, 0.32, 0.26, 0.34, 0, 0, 0, 'torso'),
                makePart('box', 'gold',  0, 1.71, 0.015, 0.028, 0.06, 0.22, 0, 0, 0, 'torso'),
                makePart('box', 'steel', 0, 1.58, 0.16, 0.24, 0.032, 0.12, 0.22, 0, 0, 'torso'),
                makePart('box', 'steel', 0, 1.53, 0.15, 0.20, 0.08, 0.03, 0.15, 0, 0, 'torso'),
                makePart('box', 'steel', -0.13, 1.51, 0.04, 0.03, 0.13, 0.11, 0, 0,  0.1, 'torso'),
                makePart('box', 'steel',  0.13, 1.51, 0.04, 0.03, 0.13, 0.11, 0, 0, -0.1, 'torso'),

                // Single-piece unified left shield arm + steel buckler on leftArmWeapon
                makePart('orgArmShieldL', 'blackenedSteel', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'leftArmWeapon'),
                makePart('orgHand', 'blackenedSteel', -0.27, 1.23, 0.30, 0.095, 0.095, 0.098, 0, 0, 0, 'leftArmWeapon'),
                makePart('dome',     'steel',          -0.30,                    1.23, 0.31,                    0.54, 0.12,  0.54, Math.PI * 0.5, -0.36, 0, 'leftArmWeapon'),
                makePart('cylinder', 'blackenedSteel', -0.30 + shieldNx * 0.025, 1.23, 0.31 + shieldNz * 0.025, 0.40, 0.032, 0.40, Math.PI * 0.5, -0.36, 0, 'leftArmWeapon'),
                makePart('sphere',   'gold',           -0.30 + shieldNx * 0.055, 1.23, 0.31 + shieldNz * 0.055, 0.12, 0.12,  0.10, 0, 0, 0, 'leftArmWeapon'),

                // Single-piece unified right sword arm + bastard sword on rightArmWeapon
                makePart('orgArmSwordR', 'blackenedSteel', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'rightArmWeapon'),
                makePart('orgHand', 'blackenedSteel', hx, hy, hz, 0.095, 0.095, 0.098, 0, 0, 0, 'rightArmWeapon'),
                makePart('cylinder', 'leather', hx, hy - 0.04 * cosS, hz - 0.04 * sinS, 0.040, 0.28, 0.040, swordPitch, 0, 0, 'rightArmWeapon'),
                makePart('sphere',   'gold',    hx, hy - 0.19 * cosS, hz - 0.19 * sinS, 0.072, 0.072, 0.072, 0, 0, 0, 'rightArmWeapon'),
                makePart('box',      'gold',    hx, hy + 0.11 * cosS, hz + 0.11 * sinS, 0.28, 0.032, 0.042, swordPitch, 0, 0, 'rightArmWeapon'),
                makePart('box',      'steel',   hx, hy + 0.64 * cosS, hz + 0.64 * sinS, 0.064, 1.04, 0.018, swordPitch, 0, 0, 'rightArmWeapon'),
                makePart('cone',     'steel',   hx, hy + 1.22 * cosS, hz + 1.22 * sinS, 0.064, 0.14, 0.018, swordPitch, 0, 0, 'rightArmWeapon')
            ];
        }

        const FIXED_EURO_INFANTRY = {
            'fixed:euro_musketier':        buildEuroMusketier,
            'fixed:euro_arquebusier':      buildEuroArquebusier,
            'fixed:euro_pikeniere':        buildEuroPikeniere,
            'fixed:euro_hellebardier':     buildEuroHellebardier,
            'fixed:euro_armored_infantry': buildEuroArmoredInfantry
        };
    '''
