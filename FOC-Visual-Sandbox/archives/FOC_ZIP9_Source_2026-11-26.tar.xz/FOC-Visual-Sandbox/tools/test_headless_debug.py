with open('G3D03J_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('class RTSUnitShowcaseController')
pos_next_class = text.find('class ', pos + 10)
print('pos:', pos)
print('pos_next_class:', pos_next_class)
print(text[pos_next_class-50:pos_next_class+100])
