with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx_factory = text.find('class G3D03LModularUnitFactory')
idx_templates = text.find('function createSoldierPartTemplates()')

print('G3D03LModularUnitFactory index:', idx_factory)
print('createSoldierPartTemplates index:', idx_templates)

if idx_factory > idx_templates:
    print('WARNING: G3D03LModularUnitFactory is defined AFTER createSoldierPartTemplates!')
else:
    print('OK: G3D03LModularUnitFactory is defined BEFORE createSoldierPartTemplates.')
