# -*- coding: utf-8 -*-
with open('G3D03H_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = re.findall(r'window\.[A-Za-z0-9_]+', text)
print('window properties:', set(matches))
