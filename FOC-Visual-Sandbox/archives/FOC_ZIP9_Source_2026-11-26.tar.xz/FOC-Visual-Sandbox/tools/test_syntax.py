import ast
with open('tools/build_g3d03k_models.py', 'r', encoding='utf-8') as f:
    src = f.read()
try:
    ast.parse(src)
    print("Parsed successfully!")
except SyntaxError as e:
    print(f"SyntaxError: {e} at line {e.lineno}, offset {e.offset}")
