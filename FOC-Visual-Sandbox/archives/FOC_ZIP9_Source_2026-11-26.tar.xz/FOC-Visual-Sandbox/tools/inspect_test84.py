with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find("84. Savaş Alanı 300 Askerin Tamamının G3D-03L 2.0 Modellerine Bağlanması")
if idx != -1:
    print(text[idx-50:idx+1500])
else:
    print("Test 84 not found")
