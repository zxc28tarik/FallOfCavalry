with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('if (!s.templateKey) {\n                            templateKey = resolveCavalryVisualVariant(s);')
if idx == -1:
    idx = text.find('templateKey = resolveCavalryVisualVariant(s);')
print(text[idx-400:idx+400])
