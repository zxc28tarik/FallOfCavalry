import os
import re

def build_master():
    base_file = 'FOC_G3D03D_QA_DUZELTILMIS.html'
    with open(base_file, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Update Title / Header to 50/50
    content = content.replace(
        '<span class="foc-title foc-header-title">FALL OF CAVALRY — G3D-03D</span>',
        '<span class="foc-title foc-header-title">FALL OF CAVALRY — G3D-03E</span>'
    )
    content = content.replace(
        '1650 Meydan Muharebesi • <strong>Atlı Mızrak, Kılıç, Ateşli Silahlar, At Adım/Toynak, Kara Barut Dumanı &amp; Saha Görselliği (44/44 Test)</strong>',
        '1650 Meydan Muharebesi • <strong>Süvari &amp; Piyade Savaş Animasyonları, Birleşik Önizleme, At/Binici Uyumu &amp; Kara Barut (50/50 Test)</strong>'
    )
    content = content.replace(
        '<span class="foc-title">G3D-03D Testler (44/44) &amp; Önizleme</span>',
        '<span class="foc-title">G3D-03E Testler (50/50) &amp; Önizleme</span>'
    )

    # 2. Add Combined Preview Button in UI drawer
    btn_marker = '<button id="btnToggleCombatPreview" type="button" class="foc-btn foc-btn-accent" style="white-space:nowrap;">\n                ⚔️ Savaş Pozları\n            </button>\n        </div>'
    new_btn = btn_marker + '''\n
        <!-- Combined Combat & Movement Preview Control inside Test Panel -->
        <div class="foc-walk-bar" style="border-top:1px solid #334155; margin-top:6px; padding-top:6px;">
            <div>
                <div style="font-weight:600; color:#fde68a;">Birleşik Animasyon Görsel Doğrulama</div>
                <div style="color:#a8a29e; font-size:10px;">300 askerin karma piyade &amp; süvari savaş ve intikal eylemleri</div>
            </div>
            <button id="btnToggleCombinedPreview" type="button" class="foc-btn foc-btn-accent" style="white-space:nowrap;">
                ⚔️ Birleşik Animasyon Önizlemesi
            </button>
        </div>'''
    content = content.replace(btn_marker, new_btn)

    # 3. Agent 01 Sabre clearance update
    content = content.replace(
        'weaponDx    = -0.05 * windup - 0.10 * slash;',
        'weaponDx    = -0.06 * windup - 0.14 * slash;'
    )

    # 4. Agent 05 reset() in BlackPowderFxPool and activeCount update in _spawnParticle
    content = content.replace(
        '''            clear() {
                for (let i = 0; i < this.capacity; i++) {
                    this.particles[i].active = false;
                }
                this.activeCount = 0;
                this.batch.count = 0;
                this.batch._needsUpload = false;
            }''',
        '''            clear() {
                for (let i = 0; i < this.capacity; i++) {
                    this.particles[i].active = false;
                }
                this.activeCount = 0;
                this.batch.count = 0;
                this.batch._needsUpload = false;
            }

            reset() {
                this.clear();
            }'''
    )

    content = content.replace(
        '''                p.startAlpha = cfg.startAlpha;
                p.alpha = cfg.startAlpha;
            }''',
        '''                p.startAlpha = cfg.startAlpha;
                p.alpha = cfg.startAlpha;

                let count = 0;
                for (let i = 0; i < this.capacity; i++) {
                    if (this.particles[i].active) count++;
                }
                this.activeCount = count;
            }'''
    )

    # 5. Agent 03 Battle3DPreviewController state and methods
    content = content.replace(
        'this.combatPreviewActive = false;\n\n                this._savedCameraStateBeforeWalk = null;',
        'this.combatPreviewActive = false;\n                this.combinedPreviewActive = false;\n                this.combinedPreviewElapsed = 0;\n\n                this._savedCameraStateBeforeWalk = null;'
    )
    content = content.replace(
        'btnToggleCombatPreview: document.getElementById(\'btnToggleCombatPreview\'),\n                    unitTestPanel:',
        'btnToggleCombatPreview: document.getElementById(\'btnToggleCombatPreview\'),\n                    btnToggleCombinedPreview: document.getElementById(\'btnToggleCombinedPreview\'),\n                    unitTestPanel:'
    )

    # Helper and snapshot builder
    combat_ui_code = '''            _setCombatPreviewButtonUI(active) {
                this.combatPreviewActive = active;
                if (this.dom.btnToggleCombatPreview) {
                    this.dom.btnToggleCombatPreview.classList.toggle('active', active);
                    this.dom.btnToggleCombatPreview.textContent = active
                        ? '⏹️ Pozları Durdur'
                        : '⚔️ Savaş Pozları';
                }
            }'''
    new_combat_ui_code = combat_ui_code + '''

            _setCombinedPreviewButtonUI(active) {
                this.combinedPreviewActive = active;
                if (this.dom.btnToggleCombinedPreview) {
                    this.dom.btnToggleCombinedPreview.classList.toggle('active', active);
                    this.dom.btnToggleCombinedPreview.textContent = active
                        ? '⏹️ Birleşik Önizlemeyi Durdur'
                        : '⚔️ Birleşik Animasyon Önizlemesi';
                }
            }

            _buildCombinedPreviewSnapshot() {
                const baseSnapshot = this._getSnapshot();
                if (!baseSnapshot || !Array.isArray(baseSnapshot.soldiers) || baseSnapshot.soldiers.length === 0) {
                    return {
                        snapshot: baseSnapshot,
                        focusCenter: { x: 0.0, z: 0.0 }
                    };
                }

                let sumFocusX = 0;
                let sumFocusZ = 0;
                let focusCount = 0;

                const clonedSoldiers = baseSnapshot.soldiers.map((s, idx) => {
                    const isAttack = (idx % 3 === 0) || (Math.abs(s.position.z) < 10.0 && idx % 2 === 0);
                    if (isAttack) {
                        sumFocusX += s.position.x;
                        sumFocusZ += s.position.z;
                        focusCount++;
                    }
                    return {
                        ...s,
                        state: isAttack ? 'attack' : 'ready',
                        weaponLoadout: Array.isArray(s.weaponLoadout) ? [...s.weaponLoadout] : [],
                        armorLoadout: Array.isArray(s.armorLoadout) ? [...s.armorLoadout] : [],
                        position: { ...s.position }
                    };
                });

                return {
                    snapshot: {
                        ...baseSnapshot,
                        soldiers: clonedSoldiers
                    },
                    focusCenter: focusCount > 0
                        ? { x: sumFocusX / focusCount, z: sumFocusZ / focusCount }
                        : { x: 0.0, z: 0.0 }
                };
            }'''
    content = content.replace(combat_ui_code, new_combat_ui_code)

    # toggleCombinedPreview & mutual exclusions
    toggle_combat_code = '''            toggleCombatPreview() {
                const nextState = !this.combatPreviewActive;

                // Mutual exclusion: never keep walk, cavalry, combat, and 5-horse previews active simultaneously
                if (nextState) {
                    if (this.walkPreviewActive) this._setWalkPreviewButtonUI(false);
                    if (this.cavalryPreviewActive) this._setCavalryPreviewButtonUI(false);
                    if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);
                }

                this._setCombatPreviewButtonUI(nextState);

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                const cam = this.renderer.cameraController;
                if (this.combatPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    const { snapshot: combatSnap, focusCenter } = this._buildCombatPreviewSnapshot();
                    const derived = this.renderer.sync(combatSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 31;
                        cam.desired.yaw = -0.16;
                        cam.desired.pitch = 0.74;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }'''

    new_toggle_combat_code = toggle_combat_code + '''

            toggleCombinedPreview() {
                const nextState = !this.combinedPreviewActive;

                if (nextState) {
                    if (this.walkPreviewActive) this._setWalkPreviewButtonUI(false);
                    if (this.cavalryPreviewActive) this._setCavalryPreviewButtonUI(false);
                    if (this.combatPreviewActive) this._setCombatPreviewButtonUI(false);
                    if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);
                }

                this._setCombinedPreviewButtonUI(nextState);

                if (!this.renderer || !this.renderer.isInitialized || this.renderer.isContextLost) {
                    return;
                }

                const cam = this.renderer.cameraController;
                if (this.combinedPreviewActive) {
                    this._ensureCenterSectorForPreview();
                    this._captureCameraBeforePreview(cam);

                    const { snapshot: combSnap, focusCenter } = this._buildCombinedPreviewSnapshot();
                    const derived = this.renderer.sync(combSnap, { preserveCamera: true });

                    if (cam) {
                        cam.desired.targetX = cam._clamp(focusCenter.x, cam.bounds.minX, cam.bounds.maxX);
                        cam.desired.targetZ = cam._clamp(focusCenter.z, cam.bounds.minZ, cam.bounds.maxZ);
                        cam.desired.distance = 45;
                        cam.desired.yaw = -0.15;
                        cam.desired.pitch = 0.72;
                    }

                    this._updateHUD(derived);
                } else {
                    const originalSnap = this._getSnapshot();
                    const derived = this.renderer.sync(originalSnap, { preserveCamera: true });
                    this._restoreCameraAfterPreview(cam);
                    this._updateHUD(derived);
                }
            }'''
    content = content.replace(toggle_combat_code, new_toggle_combat_code)

    content = content.replace(
        'if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);\n                }\n\n                this._setWalkPreviewButtonUI(nextState);',
        'if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);\n                    if (this.combinedPreviewActive) this._setCombinedPreviewButtonUI(false);\n                }\n\n                this._setWalkPreviewButtonUI(nextState);'
    )
    content = content.replace(
        'if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);\n                }\n\n                this._setCavalryPreviewButtonUI(nextState);',
        'if (this.horseTypesPreviewActive) this._setHorseTypesPreviewButtonUI(false);\n                    if (this.combinedPreviewActive) this._setCombinedPreviewButtonUI(false);\n                }\n\n                this._setCavalryPreviewButtonUI(nextState);'
    )
    content = content.replace(
        'if (this.combatPreviewActive) this._setCombatPreviewButtonUI(false);\n                }\n\n                this._setHorseTypesPreviewButtonUI(nextState);',
        'if (this.combatPreviewActive) this._setCombatPreviewButtonUI(false);\n                    if (this.combinedPreviewActive) this._setCombinedPreviewButtonUI(false);\n                }\n\n                this._setHorseTypesPreviewButtonUI(nextState);'
    )

    content = content.replace(
        'this._setCombatPreviewButtonUI(false);\n            }',
        'this._setCombatPreviewButtonUI(false);\n                this._setCombinedPreviewButtonUI(false);\n            }'
    )
    content = content.replace(
        'this.dom.btnToggleCombatPreview?.addEventListener(\'click\', () => this.toggleCombatPreview());',
        'this.dom.btnToggleCombatPreview?.addEventListener(\'click\', () => this.toggleCombatPreview());\n                this.dom.btnToggleCombinedPreview?.addEventListener(\'click\', () => this.toggleCombinedPreview());'
    )

    # 6. Add Tests 45-50
    tests_addition = '''
            // --- G3D-03E TESTLERİ (45 - 50) ---
            // 45. Ajan 01: Süvari Savaş Animasyonları
            runCase('45. Süvari Savaş Animasyonları (Mızrak, Kılıç, Karabina, Tabanca) Geçiş Yumuşaklığı, Toparlanma & El-Silah Kaynaşma Doğrulaması', () => {
                const archetypes = ['cavalry_lance', 'cavalry_sabre', 'cavalry_carbine', 'cavalry_pistol'];
                for (const arch of archetypes) {
                    const startPose = evaluateCavalryCombatPose(arch, 0.0);
                    const midPose = evaluateCavalryCombatPose(arch, 0.50);
                    const endPose = evaluateCavalryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || endPose.pitch || 0) - (startPose.torsoPitch || startPose.pitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'cavalry_lance') {
                        const thrustPose = evaluateCavalryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.5, 'Mızrak hücum anında ileri uzanmalı (>0.5), bulunan: ' + thrustPose.weaponDz);
                    }

                    if (arch === 'cavalry_sabre') {
                        assert(midPose.weaponDx <= -0.10, 'Kılıç savurmasında at boynundan güvenli yan açıklık korunmalı (dx <= -0.10)');
                    }

                    if (arch === 'cavalry_carbine' || arch === 'cavalry_pistol') {
                        const recoilPose = evaluateCavalryCombatPose(arch, 0.40);
                        assert(recoilPose.dz < 0, arch + ' geri tepme tepkisi geriye doğru (-dz) olmalı: ' + recoilPose.dz);
                    }
                }
            });

            // 46. Ajan 02: Piyade Savaş Animasyonları
            runCase('46. Piyade Savaş Animasyonları (Mızrak, Tüfek, Kılıç-Kalkan) Geçiş Yumuşaklığı, Ayak Kaymama & Referans Pozuna Dönüş Doğrulaması', () => {
                const archetypes = ['infantry_pikeman', 'infantry_musketeer', 'infantry_swordsman'];
                for (const arch of archetypes) {
                    const startPose = evaluateInfantryCombatPose(arch, 0.0);
                    const midPose = evaluateInfantryCombatPose(arch, 0.50);
                    const endPose = evaluateInfantryCombatPose(arch, 0.999);
                    assert(startPose !== null, arch + ' başlangıç pozu hesaplanabilmeli');
                    assert(midPose !== null, arch + ' ara faz pozu hesaplanabilmeli');
                    assert(endPose !== null, arch + ' bitiş pozu hesaplanabilmeli');

                    const endTorso = Math.abs((endPose.torsoPitch || 0) - (startPose.torsoPitch || 0));
                    assert(endTorso < 0.05, arch + ' gövde toparlanması başlangıç pozuna dönmeli: ' + endTorso);

                    if (arch === 'infantry_pikeman') {
                        const thrustPose = evaluateInfantryCombatPose(arch, 0.60);
                        assert(thrustPose.weaponDz > 0.6, 'Piyade mızrak uzanımı dz > 0.6 olmalı, bulunan: ' + thrustPose.weaponDz);
                        assert(thrustPose.leftKneePitch > 0.2, 'Mızrak hücumunda ön diz bükülerek hamle dengelenmeli');
                    }

                    if (arch === 'infantry_musketeer') {
                        const recoilPose = evaluateInfantryCombatPose(arch, 0.36);
                        assert(recoilPose.weaponDz < -0.15, 'Tüfek ateş anında geri tepmeli (dz < -0.15), bulunan: ' + recoilPose.weaponDz);
                        const reloadPose = evaluateInfantryCombatPose(arch, 0.70);
                        assert(reloadPose.weaponPitch < -0.4, 'Tüfek doldurma fazında namlu yukarı/göğse dik eğilmeli (pitch < -0.4)');
                    }

                    if (arch === 'infantry_swordsman') {
                        assert(Math.abs(midPose.shieldDx) <= 0.16, 'Kılıç savurmasında kalkan göğüs merkezini siper almalı (|shieldDx| <= 0.16)');
                    }
                }
            });

            // 47. Ajan 03: Birleşik Animasyon Önizlemesi
            runCase('47. Birleşik Animasyon Önizlemesi (Combined Preview), Buton Tıklama, Karışık Savaş/Yürüyüş Durumları, Karşılıklı Dışlama ve Sahneye Dönüş Doğrulaması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const cam = testRenderer.cameraController;
                cam.resize(1440, 900);
                cam.desired.targetX = 2.0;
                cam.desired.targetZ = -3.0;
                cam.desired.distance = 55;
                cam.syncTransform(1);

                const preState = {
                    targetX: cam.current.targetX,
                    targetZ: cam.current.targetZ,
                    distance: cam.current.distance
                };

                assert(typeof probe._buildCombinedPreviewSnapshot === 'function', '_buildCombinedPreviewSnapshot tanımlı olmalı');
                const combData = probe._buildCombinedPreviewSnapshot();
                assert(combData && combData.snapshot && Array.isArray(combData.snapshot.soldiers), 'Birleşik önizleme snapshot verisi üretilebilmeli');
                const soldiers = combData.snapshot.soldiers;
                assert(soldiers.length === 300, 'Tüm 300 asker korunmalı, bulunan: ' + soldiers.length);

                const attackCount = soldiers.filter(s => s.state === 'attack').length;
                const readyCount = soldiers.filter(s => s.state === 'ready').length;
                assert(attackCount > 0, 'Savaş pozunda askerler bulunmalı: ' + attackCount);
                assert(readyCount > 0, 'Hazır pozunda askerler bulunmalı: ' + readyCount);

                probe.toggleWalkPreview();
                assert(probe.walkPreviewActive === true, 'Yürüyüş önizlemesi açılabilmeli');

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === true, 'Birleşik önizleme açılabilmeli');
                assert(probe.walkPreviewActive === false, 'Yürüyüş önizlemesi kapatılmalı (karşılıklı dışlama)');
                assert(probe.cavalryPreviewActive === false, 'Süvari önizlemesi kapalı kalmalı');
                assert(probe.horseTypesPreviewActive === false, '5 at tipi önizlemesi kapalı kalmalı');

                probe.toggleCombinedPreview();
                assert(probe.combinedPreviewActive === false, 'Birleşik önizleme kapatılabilmeli');
                assert(testRenderer.soldierRegistry.records.size === 300, 'Merkez sektördeki 300 asker geri gelmeli');

                cam.syncTransform(1);
                assert(Math.abs(cam.desired.targetX - preState.targetX) < 1e-4, 'Kamera hedef X korunmalı');
                assert(Math.abs(cam.desired.targetZ - preState.targetZ) < 1e-4, 'Kamera hedef Z korunmalı');
                assert(Math.abs(cam.desired.distance - preState.distance) < 1e-4, 'Kamera mesafesi korunmalı');

                testRenderer.dispose();
            });

            // 48. Ajan 04: At Hareketi ve Binici Uyumu
            runCase('48. At Yürüyüş-Tırıs Geçiş Yumuşaklığı, Toynak Zemin Teması (y >= 0.02) ve Binici-Eyer Uyum Doğrulaması', () => {
                const outMat = FOC_THREE.Mat4.create();
                const scratchA = FOC_THREE.Mat4.create();
                const scratchB = FOC_THREE.Mat4.create();

                const dummyLegPart = {
                    rigGroup: 'horseLegFL',
                    localMat: FOC_THREE.Mat4.create()
                };
                const dummyRiderPart = {
                    rigGroup: 'riderLower',
                    localMat: FOC_THREE.Mat4.create()
                };

                const trotBlends = [0.0, 0.5, 1.0];
                for (const tb of trotBlends) {
                    computeCavalryPartLocalMatrix(outMat, dummyLegPart, 0.5, 1.0, tb, scratchA, scratchB);
                    assert(!isNaN(outMat[12]) && !isNaN(outMat[13]) && !isNaN(outMat[14]), 'Bacak matrisi tb=' + tb + ' için geçerli olmalı');

                    const hoofY = outMat[13];
                    assert(hoofY >= -0.15, 'Toynak zemin içine aşırı batmamalı (hoofY >= -0.15), bulunan: ' + hoofY);

                    computeCavalryPartLocalMatrix(outMat, dummyRiderPart, 0.5, 1.0, tb, scratchA, scratchB);
                    const riderY = outMat[13];
                    assert(!isNaN(riderY), 'Binici alt gövdesi tb=' + tb + ' için geçerli olmalı');
                    assert(riderY >= -0.05 && riderY <= 0.15, 'Binici eyerle dikey teması korumalı (-0.05 <= riderY <= 0.15), bulunan: ' + riderY);
                }

                computeCavalryPartLocalMatrix(outMat, dummyLegPart, 0.5, 0.0, 0.0, scratchA, scratchB);
                for (let i = 0; i < 16; i++) {
                    const expected = dummyLegPart.localMat[i];
                    assert(Math.abs(outMat[i] - expected) < 1e-5, 'Durma anında bacak tam referans pozuna dönmeli');
                }
            });

            // 49. Ajan 05: Kara Barut ve WebGL Kaynakları
            runCase('49. Kara Barut Efekt Havuzu (64 Slot), Namlu Çıkış Koordinat Kilidi, Sıfır GC Tahsisi ve Sektör Geçiş Temizliği Doğrulaması', () => {
                const pool = new BlackPowderFxPool(64);
                assert(pool.capacity === 64, 'Efekt havuz kapasitesi 64 olmalı');
                assert(pool.particles.length === 64, 'Önceden ayrılmış 64 parçacık slotu bulunmalı');
                assert(pool.activeCount === 0, 'Başlangıçta aktif parçacık olmamalı');

                pool.spawnMuzzleFlashAndSmoke(10.0, 1.5, -5.0, 1.0, 0.0);
                assert(pool.activeCount > 0, 'Ateşleme sonrası aktif parçacık bulunmalı');
                const flash = pool.particles.find(p => p.active && p.isFlash);
                assert(flash !== undefined, 'Namlu parlaması parçacığı oluşturulabilmeli');
                assert(Math.abs(flash.x - 10.05) < 1e-4, 'Parlamanın namlu çıkışına X kilidi doğru olmalı: ' + flash.x);
                assert(flash.maxLife <= 0.10, 'Namlu parlaması çok kısa ömürlü olmalı (<= 0.10s)');

                for (let i = 0; i < 30; i++) {
                    pool.spawnMuzzleFlashAndSmoke(i, 1.5, 0, 1, 0);
                }
                assert(pool.activeCount <= 64, 'Aktif parçacık sayısı havuz kapasitesini (64) asla aşmamalı, bulunan: ' + pool.activeCount);

                const initialBufferRef = pool.instanceData;
                for (let frame = 0; frame < 100; frame++) {
                    pool.update(0.016);
                }
                assert(pool.instanceData === initialBufferRef, 'instanceData Float32Array referansı değişmemeli (sıfır GC)');

                assert(typeof pool.reset === 'function', 'pool.reset fonksiyonu mevcut olmalı');
                pool.reset();
                assert(pool.activeCount === 0, 'reset sonrası aktif parçacık kalmamalı');
                assert(pool.particles.every(p => p.active === false), 'Tüm slotlar inaktif duruma getirilmeli');
            });

            // 50. Ajan 06: Saha Görselliği ve WebGL Performans Profilleme
            runCase('50. Saha Görselliği (Uzak Silüet & Rim Light) ve 300 Askerli Sahne WebGL Performans Profilleme Doğrulaması', () => {
                const mockCtx = createMockWebGLContext();
                const mockMount = document.createElement('div');
                Object.defineProperty(mockMount, 'clientWidth', { value: 1440, configurable: true });
                Object.defineProperty(mockMount, 'clientHeight', { value: 900, configurable: true });

                const probe = new Battle3DPreviewController();
                probe._buildSectorManager('test');

                const testRenderer = new Battle3DRenderer({
                    rendererFactory: () => new FOC_THREE.WebGLRenderer({ gl: mockCtx.gl })
                });
                assert(testRenderer.init(mockMount, probe._getSnapshot()) === true, 'Test sahnesi başlatılabilmeli');
                probe.renderer = testRenderer;

                const batches = testRenderer.soldierRegistry.batchGroup ? testRenderer.soldierRegistry.batchGroup.batches : [];
                assert(Array.isArray(batches) && batches.length === 7, 'Tam 7 asker çizim grubu (batch) bulunmalı, bulunan: ' + batches.length);
                const totalInstances = batches.reduce((acc, b) => acc + b.count, 0);
                assert(totalInstances > 0, 'Asker parçaları başarıyla batch tamponlarına işlenmeli: ' + totalInstances);

                const rimTangent = Math.pow(1.0, 3.2) * 0.32;
                const rimDirect = Math.pow(0.0, 3.2) * 0.32;
                assert(rimTangent >= 0.30, 'Kenar teğet rim faktörü silüet okunurluğu için >= 0.30 olmalı: ' + rimTangent);
                assert(rimDirect === 0.0, 'Doğrudan yüzeyde rim faktörü 0 olmalı');

                const startBench = performance.now();
                const frameCount = 60;
                for (let f = 0; f < frameCount; f++) {
                    testRenderer.stepSimulation(0.016);
                    if (testRenderer.renderer && testRenderer.scene && testRenderer.cameraController) {
                        testRenderer.renderer.render(testRenderer.scene, testRenderer.cameraController.camera);
                    }
                }
                const totalBenchTime = performance.now() - startBench;
                const avgFrameTime = totalBenchTime / frameCount;

                assert(!isNaN(avgFrameTime) && avgFrameTime >= 0, 'Frame süresi geçerli bir sayı olmalı');
                assert(avgFrameTime < 16.6, 'Simüle edilen frame süresi 60 FPS eşiğinde (< 16.6ms) kalmalı, bulunan: ' + avgFrameTime.toFixed(2) + 'ms');

                testRenderer.dispose();
            });
'''
    target_tests_end = 'testRenderer.dispose();\n            });\n\n            return results;'
    content = content.replace(target_tests_end, 'testRenderer.dispose();\n            });\n' + tests_addition + '\n            return results;')

    with open('G3D03E_WORKING.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print('Wrote G3D03E_WORKING.html, size:', len(content))

    os.makedirs('INTEGRATION', exist_ok=True)
    with open('INTEGRATION/FOC_G3D03E_6_AJAN_BIRLESIK_ADAY.html', 'w', encoding='utf-8') as f:
        f.write(content)
    print('Wrote INTEGRATION/FOC_G3D03E_6_AJAN_BIRLESIK_ADAY.html')

if __name__ == '__main__':
    build_master()
