with open('tools/build_playable_rts.py', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('new_sync_template =')
print(text[idx:idx+1500])
