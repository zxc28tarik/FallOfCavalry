with open('tools/test_quick_vt.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Let's inspect console errors or what script executed
debug_script = """
import subprocess, os, tempfile, re
chrome_path = r'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
temp_profile = os.path.join(tempfile.gettempdir(), 'foc_test_profile_quick2')
file_url = 'file:///' + os.path.abspath('G3D03K_WORKING.html').replace('\\\\', '/') + '?runTests=1#tests'
cmd = [
    chrome_path,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    f'--user-data-dir={temp_profile}',
    '--virtual-time-budget=3000',
    '--dump-dom',
    file_url
]
proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20, encoding='utf-8', errors='replace')
print("DOM length:", len(proc.stdout))
pos_err = proc.stdout.find('error')
print("pos of error in DOM:", pos_err)
# Check unitTestList
pos_list = proc.stdout.find('id="unitTestList"')
print("pos of unitTestList:", pos_list)
if pos_list != -1:
    print("unitTestList contents:")
    print(proc.stdout[pos_list:pos_list+500])
"""
with open('tools/test_quick_vt.py', 'w', encoding='utf-8') as f:
    f.write(debug_script)
