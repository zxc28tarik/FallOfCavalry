# -*- coding: utf-8 -*-
"""
build_all_models.py:
Generates complete model builder definitions for G3D-03J:
- ottomanHumanBase
- 5 Ottoman Infantry Builders (Janissary, Azap, Humbaraci, Bostanci, Levend)
- 5 Ottoman Cavalry Builders (Sipahi, Kapikulu Sipahi, Deli, Ciritci, Akinci)
- 5 European / HRE Builders (Musketier, Pikeniere, Hellebardier, Curassier, Reiter)
"""

def get_all_builders_code():
    return '''
            /* ============================================================================
             * G3D-03J OSMANLI VE AVRUPA / HRE TARİHSEL MODEL ŞABLONLARI
             * ============================================================================ */

            const ottomanHumanBase = (side, options = {}) => {
                const isEnemy = side === 'enemy';
                const kaftanMat = options.kaftanMat || (isEnemy ? 'enemyCloth' : 'ottomanCrimson');
                const salvarMat = options.salvarMat || 'ottomanNavy';
                const kusakMat = options.kusakMat || 'ottomanSaffron';

                return [
                    m('cylinder', 'shadow', 0, 0.02, 0, 1.08, 0.02, 1.08, 0, 0, 0, 'shadow'),
                    // Yemeni leather shoes
                    m('box', 'leather', -0.14, 0.025, 0.04, 0.12, 0.05, 0.24, 0, 0, 0, 'leftLegLower'),
                    m('box', 'leather',  0.14, 0.025, 0.04, 0.12, 0.05, 0.24, 0, 0, 0, 'rightLegLower'),
                    // Salvar baggy trousers
                    m('frustum', salvarMat, -0.14, 0.24, 0.0, 0.19, 0.42, 0.21, 0, 0, 0, 'leftLegLower'),
                    m('frustum', salvarMat,  0.14, 0.24, 0.0, 0.19, 0.42, 0.21, 0, 0, 0, 'rightLegLower'),
                    m('sphere', salvarMat, -0.14, 0.48, 0.01, 0.22, 0.12, 0.23, 0, 0, 0, 'leftLegLower'),
                    m('sphere', salvarMat,  0.14, 0.48, 0.01, 0.22, 0.12, 0.23, 0, 0, 0, 'rightLegLower'),
                    m('frustum', salvarMat, -0.14, 0.68, 0.0, 0.24, 0.38, 0.25, Math.PI, 0, 0, 'leftLegUpper'),
                    m('frustum', salvarMat,  0.14, 0.68, 0.0, 0.24, 0.38, 0.25, Math.PI, 0, 0, 'rightLegUpper'),
                    // Draped Kaftan lower skirt (split front)
                    m('frustum', kaftanMat, 0, 0.86, -0.01, 0.54, 0.32, 0.40, 0, 0, 0, 'torso'),
                    m('frustum', 'gold', 0, 0.71, -0.01, 0.55, 0.025, 0.41, 0, 0, 0, 'torso'),
                    // Upper Dolaman jacket torso
                    m('frustum', kaftanMat, 0, 1.20, 0.0, 0.52, 0.44, 0.34, Math.PI, 0, 0, 'torso'),
                    // Broad silk Kusak sash
                    m('cylinder', kusakMat, 0, 0.98, 0.0, 0.44, 0.10, 0.33, 0, 0, 0, 'torso'),
                    m('box', 'gold', 0, 0.98, 0.17, 0.10, 0.09, 0.04, 0, 0, 0, 'torso'),
                    // Yatagan scabbard tucked in sash
                    m('box', 'leather', 0.22, 0.98, 0.10, 0.04, 0.12, 0.38, 0.42, 0.25, -0.2, 'torso'),
                    m('box', 'gold', 0.23, 0.99, 0.28, 0.05, 0.14, 0.08, 0.42, 0.25, -0.2, 'torso'),
                    // Neck
                    m('cylinder', 'skin', 0, 1.46, 0.01, 0.13, 0.12, 0.13, 0, 0, 0, 'torso'),
                    // Head
                    m('sphere', 'skin', 0, 1.58, 0.02, 0.24, 0.26, 0.25, 0, 0, 0, 'torso'),
                    // Drooping Ottoman mustache
                    m('cone', 'wood', 0, 1.51, 0.13, 0.14, 0.08, 0.07, Math.PI + 0.3, 0, 0, 'torso')
                ];
            };

            // 1. Yeniçeri (Janissary)
            const buildOttomanJanissary = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                const borkParts = [
                    // Zarf (brass spoon holder)
                    m('box', 'gold', 0, 1.68, 0.15, 0.06, 0.18, 0.04, 0.1, 0, 0, 'torso'),
                    // White felt Bork crown
                    m('frustum', 'ottomanWhite', 0, 1.82, 0.02, 0.28, 0.32, 0.29, 0, 0, 0, 'torso'),
                    // Rear flowing flap
                    m('frustum', 'ottomanWhite', 0, 1.58, -0.15, 0.24, 0.46, 0.08, -0.35, 0, 0, 'torso'),
                    m('sphere', 'gold', 0, 1.76, 0.16, 0.05, 0.05, 0.03, 0, 0, 0, 'torso')
                ];

                if (variant === 1) {
                    // Tufenkli Janissary (Ranged)
                    const bYaw = 0.14;
                    const bPitch = Math.PI * 0.5 - 0.08;
                    return [
                        ...base,
                        ...borkParts,
                        limb('ottomanCrimson', -0.26, 1.33, 0.0, -0.32, 1.14, 0.08, 0.075, 0.062, 'twoHandMusket'),
                        limb('linen', -0.32, 1.14, 0.08, -0.17, 1.24, 0.28, 0.058, 0.048, 'twoHandMusket'),
                        m('sphere', 'skin', -0.17, 1.24, 0.28, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandMusket'),
                        limb('ottomanCrimson', 0.26, 1.33, 0.0, 0.16, 1.14, 0.36, 0.075, 0.062, 'twoHandMusket'),
                        limb('linen', 0.16, 1.14, 0.36, -0.10, 1.27, 0.72, 0.058, 0.048, 'twoHandMusket'),
                        m('sphere', 'skin', -0.10, 1.27, 0.72, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandMusket'),
                        // Long Ottoman Tufenk musket
                        m('box', 'wood', -0.185, 1.22, 0.14, 0.075, 0.15, 0.34, -0.26, bYaw, 0, 'twoHandMusket'),
                        m('cylinder', 'damascusSteel', -0.095, 1.305, 0.82, 0.052, 1.26, 0.052, bPitch, bYaw, 0, 'twoHandMusket'),
                        m('cylinder', 'bronze', -0.095, 1.305, 0.65, 0.056, 0.04, 0.056, bPitch, bYaw, 0, 'twoHandMusket'),
                        m('cylinder', 'bronze', -0.035, 1.332, 1.34, 0.058, 0.05, 0.058, bPitch, bYaw, 0, 'twoHandMusket'),
                        m('box', 'leather', 0.18, 1.05, -0.08, 0.12, 0.14, 0.08, 0, 0, 0, 'torso')
                    ];
                } else {
                    // Yataganli & Cevsenli Janissary (Melee)
                    return [
                        ...base,
                        ...borkParts,
                        // Steel cevsen chest disc
                        m('cylinder', 'damascusSteel', 0, 1.22, 0.175, 0.26, 0.025, 0.26, Math.PI * 0.5, 0, 0, 'torso'),
                        m('sphere', 'gold', 0, 1.22, 0.19, 0.07, 0.07, 0.07, 0, 0, 0, 'torso'),
                        // Left arm holding round kalkan shield
                        limb('ottomanCrimson', 0.27, 1.32, 0.0, 0.34, 1.15, 0.10, 0.075, 0.062, 'leftArmWeapon'),
                        limb('leather', 0.34, 1.15, 0.10, 0.36, 1.16, 0.28, 0.062, 0.052, 'leftArmWeapon'),
                        m('dome', 'damascusSteel', 0.39, 1.16, 0.30, 0.58, 0.12, 0.58, Math.PI * 0.5, 0.36, 0, 'leftArmWeapon'),
                        m('sphere', 'bronze', 0.44, 1.16, 0.32, 0.14, 0.14, 0.12, 0, 0, 0, 'leftArmWeapon'),
                        // Right arm holding curved yatagan
                        limb('ottomanCrimson', -0.27, 1.32, 0.0, -0.34, 1.14, 0.08, 0.075, 0.062, 'rightArmWeapon'),
                        limb('skin', -0.34, 1.14, 0.08, -0.30, 1.12, 0.30, 0.062, 0.052, 'rightArmWeapon'),
                        m('sphere', 'skin', -0.30, 1.12, 0.30, 0.10, 0.10, 0.10, 0, 0, 0, 'rightArmWeapon'),
                        // Yatagan forward blade
                        m('box', 'gold', -0.30, 1.12, 0.38, 0.04, 0.12, 0.05, 0, 0, 0, 'rightArmWeapon'),
                        m('frustum', 'damascusSteel', -0.30, 1.16, 0.72, 0.07, 0.68, 0.025, Math.PI * 0.5 - 0.2, 0, 0, 'rightArmWeapon')
                    ];
                }
            };

            // 2. Azap (Azap Hafif Piyadesi)
            const buildOttomanAzap = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'linen', salvarMat: 'leather', kusakMat: 'ottomanCrimson' });
                const sarikParts = [
                    m('cylinder', 'ottomanWhite', 0, 1.66, 0.02, 0.32, 0.12, 0.32, 0, 0, 0, 'torso'),
                    m('cone', 'ottomanCrimson', 0, 1.76, 0.02, 0.18, 0.18, 0.18, 0, 0, 0, 'torso')
                ];

                if (variant === 1) {
                    // Tirpanli / Kargili Azap
                    const pAngleX = Math.atan2(0.38, 0.24);
                    const cosP = Math.cos(pAngleX);
                    const sinP = Math.sin(pAngleX);
                    const px = -0.32, p1y = 1.08, p1z = 0.18;
                    return [
                        ...base,
                        ...sarikParts,
                        limb('linen', -0.27, 1.32, 0.0, -0.34, 1.12, -0.04, 0.075, 0.062, 'twoHandPike'),
                        limb('skin', -0.34, 1.12, -0.04, px, p1y, p1z, 0.062, 0.052, 'twoHandPike'),
                        m('sphere', 'skin', px, p1y, p1z, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                        limb('linen', 0.27, 1.32, 0.0, 0.08, 1.18, 0.26, 0.075, 0.062, 'twoHandPike'),
                        limb('skin', 0.08, 1.18, 0.26, px, 1.32, 0.56, 0.062, 0.052, 'twoHandPike'),
                        m('sphere', 'skin', px, 1.32, 0.56, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                        m('cylinder', 'wood', px, p1y + 1.18 * cosP, p1z + 1.18 * sinP, 0.042, 3.85, 0.042, pAngleX, 0, 0, 'twoHandPike'),
                        m('cone', 'damascusSteel', px, p1y + 3.05 * cosP, p1z + 3.05 * sinP, 0.09, 0.42, 0.04, pAngleX, 0, 0, 'twoHandPike')
                    ];
                } else {
                    // Kilicli Azap
                    return [
                        ...base,
                        ...sarikParts,
                        limb('linen', 0.27, 1.32, 0.0, 0.34, 1.15, 0.10, 0.075, 0.062, 'leftArmWeapon'),
                        limb('skin', 0.34, 1.15, 0.10, 0.36, 1.16, 0.28, 0.062, 0.052, 'leftArmWeapon'),
                        m('dome', 'leather', 0.39, 1.16, 0.30, 0.52, 0.11, 0.52, Math.PI * 0.5, 0.36, 0, 'leftArmWeapon'),
                        limb('linen', -0.27, 1.32, 0.0, -0.34, 1.14, 0.08, 0.075, 0.062, 'rightArmWeapon'),
                        limb('skin', -0.34, 1.14, 0.08, -0.30, 1.12, 0.30, 0.062, 0.052, 'rightArmWeapon'),
                        m('sphere', 'skin', -0.30, 1.12, 0.30, 0.10, 0.10, 0.10, 0, 0, 0, 'rightArmWeapon'),
                        m('frustum', 'damascusSteel', -0.30, 1.16, 0.65, 0.065, 0.74, 0.024, Math.PI * 0.5 - 0.3, 0, 0, 'rightArmWeapon')
                    ];
                }
            };

            // 3. Humbaracı (Bombardier / Grenadier)
            const buildOttomanHumbaraci = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanEmerald', salvarMat: 'leather', kusakMat: 'leather' });
                return [
                    ...base,
                    // Leather apron
                    m('box', 'leather', 0, 1.05, 0.18, 0.36, 0.42, 0.04, 0, 0, 0, 'torso'),
                    // Sarik
                    m('cylinder', 'ottomanWhite', 0, 1.66, 0.02, 0.32, 0.12, 0.32, 0, 0, 0, 'torso'),
                    m('cone', 'ottomanEmerald', 0, 1.76, 0.02, 0.18, 0.16, 0.18, 0, 0, 0, 'torso'),
                    // Grenade pouch
                    m('box', 'leather', -0.22, 0.94, 0.05, 0.14, 0.16, 0.14, 0, 0, 0, 'torso'),
                    // Arm holding Humbara (iron grenade)
                    limb('ottomanEmerald', -0.27, 1.32, 0.0, -0.34, 1.20, 0.15, 0.075, 0.062, 'rightArmWeapon'),
                    limb('skin', -0.34, 1.20, 0.15, -0.28, 1.28, 0.38, 0.062, 0.052, 'rightArmWeapon'),
                    m('sphere', 'skin', -0.28, 1.28, 0.38, 0.10, 0.10, 0.10, 0, 0, 0, 'rightArmWeapon'),
                    // Iron sphere grenade with burning fuse
                    m('sphere', 'darkSteel', -0.28, 1.40, 0.42, 0.16, 0.16, 0.16, 0, 0, 0, 'rightArmWeapon'),
                    m('cone', 'gold', -0.28, 1.50, 0.42, 0.04, 0.08, 0.04, 0, 0, 0, 'rightArmWeapon')
                ];
            };

            // 4. Bostancı (Palace Elite Guard)
            const buildOttomanBostanci = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanCrimson', salvarMat: 'ottomanNavy', kusakMat: 'ottomanSaffron' });
                const bostanciHead = [
                    // Tall red Bostanci kulah
                    m('cone', 'ottomanCrimson', 0, 1.88, 0.02, 0.26, 0.52, 0.26, 0, 0, 0, 'torso'),
                    m('cylinder', 'gold', 0, 1.63, 0.02, 0.28, 0.04, 0.28, 0, 0, 0, 'torso'),
                    // Heavy cevsen mail & plate armor
                    m('frustum', 'damascusSteel', 0, 1.20, 0.005, 0.54, 0.40, 0.36, Math.PI, 0, 0, 'torso'),
                    m('cylinder', 'gold', 0, 1.24, 0.185, 0.22, 0.02, 0.22, Math.PI * 0.5, 0, 0, 'torso')
                ];

                const pAngleX = Math.atan2(0.38, 0.24);
                const cosP = Math.cos(pAngleX);
                const sinP = Math.sin(pAngleX);
                const px = -0.32, p1y = 1.08, p1z = 0.18;

                return [
                    ...base,
                    ...bostanciHead,
                    limb('ottomanCrimson', -0.27, 1.32, 0.0, -0.34, 1.12, -0.04, 0.075, 0.062, 'twoHandPike'),
                    limb('damascusSteel', -0.34, 1.12, -0.04, px, p1y, p1z, 0.062, 0.052, 'twoHandPike'),
                    m('sphere', 'skin', px, p1y, p1z, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                    limb('ottomanCrimson', 0.27, 1.32, 0.0, 0.08, 1.18, 0.26, 0.075, 0.062, 'twoHandPike'),
                    limb('damascusSteel', 0.08, 1.18, 0.26, px, 1.32, 0.56, 0.062, 0.052, 'twoHandPike'),
                    m('sphere', 'skin', px, 1.32, 0.56, 0.10, 0.10, 0.10, 0, 0, 0, 'twoHandPike'),
                    // Heavy Teber (crescent poleaxe)
                    m('cylinder', 'wood', px, p1y + 1.18 * cosP, p1z + 1.18 * sinP, 0.045, 3.20, 0.045, pAngleX, 0, 0, 'twoHandPike'),
                    m('cone', 'gold', px, p1y + 2.70 * cosP, p1z + 2.70 * sinP, 0.26, 0.38, 0.05, pAngleX, 0, 0, 'twoHandPike')
                ];
            };

            // 5. Levend (Irregular / Coastal Skirmisher)
            const buildOttomanLevend = (side, variant = 1) => {
                const base = ottomanHumanBase(side, { kaftanMat: 'ottomanNavy', salvarMat: 'linen', kusakMat: 'ottomanCrimson' });
                return [
                    ...base,
                    // Striped headwrap
                    m('cylinder', 'ottomanSaffron', 0, 1.66, 0.02, 0.32, 0.12, 0.32, 0, 0, 0, 'torso'),
                    m('cone', 'ottomanNavy', 0, 1.74, 0.02, 0.20, 0.16, 0.20, 0, 0, 0, 'torso'),
                    // Dual pistols in sash
                    m('box', 'wood', 0.12, 1.04, 0.18, 0.05, 0.16, 0.08, 0.45, 0, -0.2, 'torso'),
                    m('box', 'wood', -0.12, 1.04, 0.18, 0.05, 0.16, 0.08, 0.45, 0, 0.2, 'torso')
                ];
            };

            // 6. Sipahi (Timarlı Süvari)
            const buildOttomanSipahi = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'courser_horse', 'harquebusier');
                return [
                    ...cavBase,
                    // Şişak Tolga Helmet spike
                    m('cone', 'gold', 0, 2.36, -0.03, 0.12, 0.26, 0.12, 0, 0, 0, 'riderUpper'),
                    m('cylinder', 'damascusSteel', 0, 2.22, -0.03, 0.28, 0.06, 0.28, 0, 0, 0, 'riderUpper'),
                    // Wicker Kalkan on left arm
                    m('dome', 'gold', 0.36, 1.74, 0.26, 0.52, 0.12, 0.52, Math.PI * 0.5, 0.36, 0, 'riderUpper')
                ];
            };

            // 7. Kapıkulu Sipahisi (Imperial Heavy Guard Cavalry)
            const buildOttomanKapikuluSipahi = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'heavy_warhorse', 'heavy_cuirassier');
                return [
                    ...cavBase,
                    // Char-aina mirror breastplate
                    m('box', 'damascusSteel', 0, 1.84, 0.17, 0.32, 0.34, 0.05, 0, 0, 0, 'riderUpper'),
                    m('cylinder', 'gold', 0, 1.84, 0.198, 0.18, 0.02, 0.18, Math.PI * 0.5, 0, 0, 'riderUpper'),
                    // Horse steel chamfron (alınlık)
                    m('cone', 'damascusSteel', 0, 1.58, 1.56, 0.22, 0.42, 0.14, 0.65, 0, 0, 'horseNeckHead')
                ];
            };

            // 8. Deli Süvarisi (Daring Vanguard Shock Cavalry)
            const buildOttomanDeli = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'courser_horse', 'light_skirmisher');
                return [
                    ...cavBase,
                    // Leopard Pelt draped over torso
                    m('frustum', 'leopardPelt', 0, 1.84, -0.04, 0.52, 0.36, 0.34, Math.PI, 0, 0, 'riderUpper'),
                    // Winged headdress (Deli kartal kanatları)
                    m('box', 'ottomanWhite', -0.18, 2.38, -0.06, 0.03, 0.38, 0.16, -0.3, 0, 0.2, 'riderUpper'),
                    m('box', 'ottomanWhite',  0.18, 2.38, -0.06, 0.03, 0.38, 0.16, -0.3, 0, -0.2, 'riderUpper'),
                    m('cone', 'ottomanCrimson', 0, 2.32, -0.03, 0.18, 0.32, 0.18, 0, 0, 0, 'riderUpper')
                ];
            };

            // 9. Ciritçi (Javelin Light Skirmisher Cavalry)
            const buildOttomanCiritci = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_lance', 'steppe_horse', 'light_skirmisher');
                return [
                    ...cavBase,
                    // Saddle quiver with 3 javelins
                    m('cylinder', 'leather', 0.26, 1.34, -0.20, 0.12, 0.55, 0.12, 0.35, 0, 0.2, 'horseBody'),
                    m('cylinder', 'wood', 0.26, 1.62, -0.12, 0.03, 0.85, 0.03, 0.35, 0, 0.2, 'horseBody')
                ];
            };

            // 10. Akıncı (Mounted Archer / Steppe Cavalry)
            const buildOttomanAkinci = (side, variant = 1) => {
                const cavBase = buildCavalryUnit1650(side, 'cavalry_carbine', 'steppe_horse', 'light_skirmisher');
                return [
                    ...cavBase,
                    // Composite recurve bow & arrow quiver (tirkeş)
                    m('box', 'leather', -0.28, 1.38, -0.15, 0.14, 0.60, 0.12, -0.3, 0, -0.2, 'horseBody'),
                    m('cylinder', 'wood', -0.28, 1.72, -0.08, 0.04, 0.80, 0.04, -0.3, 0, -0.2, 'horseBody')
                ];
            };

            // 11. HRE Pikeniere
            const buildHREPikeniere = (side, variant = 1) => {
                return buildInfantryPikeman(side);
            };

            // 12. HRE Musketier
            const buildHREMusketier = (side, variant = 1) => {
                return buildInfantryMusketeer(side);
            };

            // 13. HRE Hellebardier (Halberdier)
            const buildHREHellebardier = (side, variant = 1) => {
                const base = buildInfantrySwordsman(side);
                return [
                    ...base,
                    // Halberd ax blade on weapon
                    m('box', 'steel', -0.30, 1.72, 0.65, 0.24, 0.28, 0.03, -0.45, 0, 0, 'rightArmWeapon')
                ];
            };

            // 14. HRE Kürassier (Heavy Cuirassier)
            const buildHRECurassier = (side, variant = 1) => {
                return buildCavalryUnit1650(side, 'cavalry_pistol', 'heavy_warhorse', 'heavy_cuirassier');
            };

            // 15. HRE Reiter (Blackened Carbine Cavalry)
            const buildHREReiter = (side, variant = 1) => {
                return buildCavalryUnit1650(side, 'cavalry_carbine', 'charger_horse', 'reiter');
            };
    '''
