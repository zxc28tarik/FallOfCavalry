# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('class Battle3DPreviewController')
idx_mode = text.find('setMode(', idx)
if idx_mode != -1:
    print(text[idx_mode:idx_mode+800])
