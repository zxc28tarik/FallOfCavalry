import subprocess
import os
import tempfile
import json
import re
import base64
import io
from PIL import Image
import numpy as np

def test_which_batch():
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    
    with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
        base_html = f.read()

    base_html = base_html.replace("alpha: false,", "alpha: false, preserveDrawingBuffer: true,")

    # Let's test disabling each batch i from 0 to 6
    for skip_idx in range(-1, 7):
        html = base_html
        if skip_idx >= 0:
            html = html.replace(
                "for (let i = 0; i < batchGroup.batches.length; i++) {",
                f"for (let i = 0; i < batchGroup.batches.length; i++) {{ if (i === {skip_idx}) continue;"
            )
        
        diag = '''
<script>
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        try {
            const cvs = document.querySelector('canvas');
            const res = { img: cvs ? cvs.toDataURL('image/png') : '' };
            const pre = document.createElement('pre');
            pre.id = 'renderOutput';
            pre.textContent = JSON.stringify(res);
            document.body.appendChild(pre);
        } catch (e) {}
    }, 1200);
});
</script>
'''
        temp_html = f'temp_batch_test_{skip_idx}.html'
        with open(temp_html, 'w', encoding='utf-8') as f:
            f.write(html.replace('</body>', diag + '</body>'))

        temp_profile = os.path.join(tempfile.gettempdir(), f'foc_prof_test_{skip_idx}')
        cmd = [
            chrome_path,
            '--headless=new',
            '--disable-gpu-sandbox',
            '--enable-webgl',
            '--use-gl=angle',
            '--use-angle=d3d11',
            '--no-sandbox',
            f'--user-data-dir={temp_profile}',
            '--virtual-time-budget=10000',
            '--dump-dom',
            'file:///' + os.path.abspath(temp_html).replace('\\', '/')
        ]

        res = subprocess.run(cmd, capture_output=True, text=True, timeout=20, encoding='utf-8', errors='replace')
        m = re.search(r'<pre id="renderOutput">(.*?)</pre>', res.stdout, re.DOTALL)
        if m:
            data = json.loads(m.group(1))
            if data.get('img'):
                raw = base64.b64decode(data['img'].split(',')[1])
                img = Image.open(io.BytesIO(raw))
                arr = np.array(img)
                red_count = np.sum((arr[:, :, 0] > 180) & (arr[:, :, 1] < 50) & (arr[:, :, 2] < 50))
                print(f"Skip batch {skip_idx}: red pixels = {red_count}")
        else:
            print(f"Skip batch {skip_idx}: could not capture")

        if os.path.exists(temp_html):
            os.remove(temp_html)

if __name__ == '__main__':
    test_which_batch()
