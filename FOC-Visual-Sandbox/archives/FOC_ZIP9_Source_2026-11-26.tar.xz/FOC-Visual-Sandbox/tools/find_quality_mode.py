with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
for m in re.finditer(r'qualityMode', text):
    print(text[m.start()-40:m.start()+150])
