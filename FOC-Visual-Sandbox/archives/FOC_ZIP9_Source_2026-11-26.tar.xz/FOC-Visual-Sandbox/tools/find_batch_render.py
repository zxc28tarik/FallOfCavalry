import subprocess
import os
import tempfile
import json
import re
import base64
from PIL import Image
import numpy as np

def test_batches():
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
        html = f.read()

    # In WebGLRenderer render method or in soldierRegistry, we can check which batch causes red
    # Let's inspect the render loop:
    # Look at where `this.batchGroup` is rendered in FOC_THREE.WebGLRenderer
    pass

if __name__ == '__main__':
    with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
        text = f.read()
    
    # Search for where instanced batches are drawn
    idx = text.find('renderInstancedBatchGroup')
    if idx == -1:
        idx = text.find('InstancedBatchGroup')
    print('Found InstancedBatchGroup at:', idx)
    print(text[idx-50:idx+600])
