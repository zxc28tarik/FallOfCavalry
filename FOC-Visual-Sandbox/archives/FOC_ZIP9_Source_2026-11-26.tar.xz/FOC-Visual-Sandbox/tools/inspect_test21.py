with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('21. Üst Menü ve Test Panelinin')
print(text[pos:pos+1500])
