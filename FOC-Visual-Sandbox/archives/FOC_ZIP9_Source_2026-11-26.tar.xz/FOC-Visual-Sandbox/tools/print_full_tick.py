# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('class Battle3DPreviewController')
idx_tick = text.find('_onFrameTick(dt) {', idx)
idx_tick_end = text.find('\n        }', idx_tick)
print(text[idx_tick:idx_tick+3000])
