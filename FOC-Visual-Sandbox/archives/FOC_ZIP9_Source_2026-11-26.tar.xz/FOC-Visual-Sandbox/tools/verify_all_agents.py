import os
import sys
sys.path.insert(0, os.path.abspath('.'))
from tools.run_headless_test import run_test

stage = sys.argv[1] if len(sys.argv) > 1 else 'G3D03K'
required_tests = 70 if stage == 'G3D03K' else 64
agents = [f'0{i}' for i in range(1, 7)]
results = {}
all_passed = True

print(f"=== VERIFYING ALL 6 AGENTS FOR {stage} (Required: {required_tests}) ===")
for a in agents:
    target = os.path.join(stage, 'AJANLAR', a, 'DELIVERABLE.html')
    res = run_test(target)
    results[a] = res
    status = 'PASS' if res.get('fail', 1) == 0 and res.get('total', 0) >= required_tests else 'FAIL'
    if status != 'PASS':
        all_passed = False
    print(f'AJAN {a}: {res.get("summary", "NO SUMMARY")} -> {status}')

print(f"OVERALL STATUS: {'ALL 6 AGENTS PASSED (' + str(required_tests) + '/' + str(required_tests) + ')' if all_passed else 'SOME AGENTS FAILED'}")
