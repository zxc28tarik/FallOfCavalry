with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = [m.start() for m in re.finditer(r'this\.yaw|cam\.yaw', text)]
print('Matches:', len(matches))
for m in matches[:5]:
    print(text[m-50:m+200])
