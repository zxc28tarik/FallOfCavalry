# -*- coding: utf-8 -*-
"""
tools/fixed_ottoman_cavalry.py
1650 Ottoman Cavalry — 6 Fixed, Non-Modular Mounted Archetypes.

Uses unified organic meshes:
  'orgHorseBody', 'orgHorseNeckHead', 'orgHorseSaddle',
  'orgHorseLegUpper', 'orgHorseLegLower',
  'orgTorsoCoat', 'orgTorsoArmored', 'orgHeadNatural',
  'orgArmRiderReinsL', 'orgArmRiderWeaponR',
  'orgLimb', 'orgBoot', 'orgHand',
  'orgHelmetPointed', 'orgHelmetTurban'
Plus primitives ONLY for tail, stirrups, lances, shields, sabres, maces,
carbines, and thin historical harness/armor straps.
"""


def get_fixed_ottoman_cavalry_code():
    """Return JavaScript defining the 6 fixed 1650 Ottoman cavalry archetypes."""
    return r"""
        /* ============================================================================
         * 1650 OTTOMAN CAVALRY — 6 FIXED, NON-MODULAR MOUNTED ARCHETYPES
         * ============================================================================ */

        function cavLimb(prim, mat, ax, ay, az, bx, by, bz, rStart, rEnd, rigGroup) {
            const dx = bx - ax;
            const dy = by - ay;
            const dz = bz - az;
            const len = Math.hypot(dx, dy, dz) || 0.001;
            const mx = (ax + bx) * 0.5;
            const my = (ay + by) * 0.5;
            const mz = (az + bz) * 0.5;
            // Orient +Y toward the larger-radius end (a if rStart >= rEnd, else b) without quadrant sign bugs
            const dir = rStart >= rEnd ? -1 : 1;
            const ux = (dx * dir) / len;
            const uy = (dy * dir) / len;
            const uz = (dz * dir) / len;
            const rx = Math.asin(Math.max(-1, Math.min(1, uz)));
            const rz = Math.atan2(-ux, uy);
            const avgScale = Math.max(rStart, rEnd) * 2.0;
            return makePart(prim, mat, mx, my, mz, avgScale, len, avgScale, rx, 0, rz, rigGroup);
        }

        function buildFixedOttomanWarhorse(coatMat, maneMat, clothMat, options = {}) {
            const isArmored = Boolean(options.armored);
            const isLeopardSaddle = Boolean(options.leopardSaddle);
            const trimMat = options.trimMat || 'gold';
            const blanketMat = isLeopardSaddle ? 'leopardPelt' : clothMat;

            const parts = [
                makePart('cylinder', 'shadow', 0, 0.02, 0.0, 2.24, 0.02, 1.32, 0, 0, 0, 'shadow'),

                // Unified organic horse barrel (y=1.20) and downward-angled neck+head flowing out of withers/chest
                makePart('orgHorseBody', coatMat, 0, 1.20, 0.0, 0.68, 0.72, 1.36, 0, 0, 0, 'horseBody'),
                makePart('orgHorseNeckHead', coatMat, 0, 1.60, 0.80, 0.34, 0.76, 0.72, 0, 0, 0, 'horseNeckHead'),

                // Sleek thin leather bridle & bit bosses hugging orgHorseNeckHead
                makePart('cylinder', 'leather', 0, 1.67, 1.03, 0.056, 0.015, 0.095, 0.78, 0, 0, 'horseNeckHead'),
                makePart('cylinder', 'leather', 0, 1.81, 0.93, 0.092, 0.015, 0.125, 0.72, 0, 0, 'horseNeckHead'),
                cavLimb('cylinder', 'leather', -0.043, 1.82, 0.92, -0.029, 1.62, 1.09, 0.006, 0.006, 'horseNeckHead'),
                cavLimb('cylinder', 'leather',  0.043, 1.82, 0.92,  0.029, 1.62, 1.09, 0.006, 0.006, 'horseNeckHead'),
                makePart('sphere', trimMat, -0.030, 1.62, 1.09, 0.020, 0.020, 0.020, 0, 0, 0, 'horseNeckHead'),
                makePart('sphere', trimMat,  0.030, 1.62, 1.09, 0.020, 0.020, 0.020, 0, 0, 0, 'horseNeckHead'),

                // Lifelike dark shiny equine eyes nestled in sculpted orbits
                makePart('sphere', 'eyeDark', -0.039, 1.815, 0.875, 0.016, 0.016, 0.016, 0, 0, 0, 'horseNeckHead'),
                makePart('sphere', 'eyeDark',  0.039, 1.815, 0.875, 0.016, 0.016, 0.016, 0, 0, 0, 'horseNeckHead'),

                // Flowing sculpted organic horse tail (horseTail)
                makePart('orgHorseTail', maneMat, 0, 1.06, -0.82, 0.22, 0.78, 0.34, 0, 0, 0, 'horseTail'),

                // 4 Anatomical Equine Legs: orgHorseLegUpper tucked into shoulder/hindquarter sockets + orgHorseLegLower with tapered cannons & hooves
                // Front Left
                makePart('orgHorseLegUpper', coatMat, -0.19, 0.85, 0.50, 0.28, 0.68, 0.34, -0.13, 0, 0, 'horseLegFL'),
                makePart('orgHorseLegLower', coatMat, -0.19, 0.29, 0.58, 0.34, 0.58, 0.34,  0.00, 0, 0, 'horseLegFLLower'),

                // Front Right
                makePart('orgHorseLegUpper', coatMat,  0.19, 0.85, 0.50, 0.28, 0.68, 0.34, -0.13, 0, 0, 'horseLegFR'),
                makePart('orgHorseLegLower', coatMat,  0.19, 0.29, 0.58, 0.34, 0.58, 0.34,  0.00, 0, 0, 'horseLegFRLower'),

                // Hind Left
                makePart('orgHorseLegUpper', coatMat, -0.19, 0.88, -0.55, 0.32, 0.72, 0.42, 0.24, 0, 0, 'horseLegHL'),
                makePart('orgHorseLegLower', coatMat, -0.19, 0.29, -0.60, 0.34, 0.58, 0.34, 0.00, 0, 0, 'horseLegHLLower'),

                // Hind Right
                makePart('orgHorseLegUpper', coatMat,  0.19, 0.88, -0.55, 0.32, 0.72, 0.42, 0.24, 0, 0, 'horseLegHR'),
                makePart('orgHorseLegLower', coatMat,  0.19, 0.29, -0.60, 0.34, 0.58, 0.34, 0.00, 0, 0, 'horseLegHRLower'),

                // Contoured saddle cloth (shabrack), fitted pad, girth & sleek breastplate straps hugging chest (horseBody)
                makePart('orgHorseSaddle', blanketMat, 0, 1.415, -0.06, 0.57, 0.27, 0.76, 0, 0, 0, 'horseBody'),
                makePart('cylinder', blanketMat, 0, 1.25, -0.05, 0.31, 0.48, 0.31, Math.PI * 0.5, 0, 0, 'horseBody'),
                makePart('cylinder', 'leather', 0, 1.20, 0.02, 0.328, 0.042, 0.335, 0, 0, 0, 'horseBody'),
                cavLimb('cylinder', 'leather', -0.18, 1.34, 0.32, -0.155, 1.22, 0.58, 0.010, 0.010, 'horseBody'),
                cavLimb('cylinder', 'leather',  0.18, 1.34, 0.32,  0.155, 1.22, 0.58, 0.010, 0.010, 'horseBody'),
                cavLimb('cylinder', 'leather', -0.155, 1.22, 0.58, 0.0, 1.18, 0.675, 0.010, 0.010, 'horseBody'),
                cavLimb('cylinder', 'leather',  0.155, 1.22, 0.58, 0.0, 1.18, 0.675, 0.010, 0.010, 'horseBody'),
                cavLimb('cylinder', 'leather', 0.0, 1.18, 0.675, 0.0, 1.00, 0.44, 0.008, 0.008, 'horseBody'),
                makePart('sphere', trimMat, 0, 1.18, 0.68, 0.044, 0.044, 0.020, 0, 0, 0, 'horseBody'),

                // Reins leading cleanly from bit to rider's left hand at (-0.14, 1.65, 0.31)
                cavLimb('cylinder', 'buffLeather', -0.030, 1.62, 1.09, -0.14, 1.65, 0.31, 0.007, 0.007, 'horseBody'),
                cavLimb('cylinder', 'buffLeather',  0.030, 1.62, 1.09, -0.14, 1.65, 0.31, 0.007, 0.007, 'horseBody'),

                // Contoured Ottoman Warhorse Saddle at y=1.44 & thin bronze/leather stirrup straps at x=±0.40, y=0.76 (riderSaddle)
                makePart('orgHorseSaddle', 'leather', 0, 1.44, -0.05, 0.58, 0.30, 0.66, 0, 0, 0, 'riderSaddle'),
                cavLimb('box', 'leather', -0.19, 1.38, 0.02, -0.40, 0.79, 0.04, 0.012, 0.012, 'riderSaddle'),
                cavLimb('box', 'leather',  0.19, 1.38, 0.02,  0.40, 0.79, 0.04, 0.012, 0.012, 'riderSaddle'),
                makePart('box', 'burnishedBronze', -0.40, 0.76, 0.04, 0.04, 0.09, 0.12, 0, 0, 0, 'riderSaddle'),
                makePart('box', 'burnishedBronze',  0.40, 0.76, 0.04, 0.04, 0.09, 0.12, 0, 0, 0, 'riderSaddle')
            ];

            if (isArmored) {
                parts.push(
                    // Sleek Steel Chamfron & Crinet hugging orgHorseNeckHead
                    cavLimb('frustum', 'damascusSteel', 0, 1.87, 0.94, 0, 1.66, 1.08, 0.042, 0.028, 'horseNeckHead'),
                    cavLimb('box', 'gold', 0, 1.88, 0.95, 0, 1.67, 1.09, 0.009, 0.009, 'horseNeckHead'),
                    cavLimb('frustum', 'damascusSteel', 0, 1.38, 0.65, 0, 1.78, 0.84, 0.068, 0.046, 'horseNeckHead'),
                    // Peytral (chest barding) & slim Flank plates hugging horseBody (inside rider leg clearance)
                    makePart('frustum', 'damascusSteel', 0, 1.18, 0.56, 0.39, 0.26, 0.28, 0.45, 0, 0, 'horseBody'),
                    makePart('box', 'damascusSteel', -0.185, 1.19, -0.14, 0.024, 0.22, 0.68, 0, 0, 0, 'horseBody'),
                    makePart('box', 'damascusSteel',  0.185, 1.19, -0.14, 0.024, 0.22, 0.68, 0, 0, 0, 'horseBody')
                );
            }

            return parts;
        }

        function buildSeatedOttomanRiderBase(breechesMat, bootMat, coatMat, torsoPrim, options = {}) {
            const sashMat = options.sashMat || 'ottomanSaffron';
            const sleeveMat = options.sleeveMat || coatMat;
            const parts = [
                // Pelvis seated cleanly on saddle at y=1.50 (riderLower)
                makePart('frustum', breechesMat, 0, 1.50, -0.05, 0.44, 0.16, 0.36, Math.PI, 0, 0, 'riderLower'),

                // Upper-thigh breeches blend at hip (x=±0.20, y=1.46) into contoured rider leg+boot
                makePart('sphere', breechesMat, -0.20, 1.46, -0.01, 0.18, 0.17, 0.20, 0, 0, 0, 'riderLower'),
                makePart('sphere', breechesMat,  0.20, 1.46, -0.01, 0.18, 0.17, 0.20, 0, 0, 0, 'riderLower'),
                cavLimb('orgLimb', breechesMat, -0.19, 1.47, -0.02, -0.27, 1.37, 0.08, 0.090, 0.082, 'riderLower'),
                cavLimb('orgLimb', breechesMat,  0.19, 1.47, -0.02,  0.27, 1.37, 0.08, 0.090, 0.082, 'riderLower'),

                // Single-piece contoured rider leg + boot resting in stirrups at (±0.35, 0.77, 0.06)
                makePart('orgRiderLegL', bootMat || 'leather', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderLower'),
                makePart('orgRiderLegR', bootMat || 'leather', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderLower'),

                // Upper torso at y=1.62..1.90 (riderUpper)
                makePart(torsoPrim, coatMat, 0, 1.76, -0.04, 0.48, 0.38, 0.32, 0, 0, 0, 'riderUpper'),
                makePart('cylinder', sashMat, 0, 1.64, -0.04, 0.45, 0.09, 0.31, 0, 0, 0, 'riderUpper'),
                makePart('box', 'gold', 0, 1.64, 0.12, 0.09, 0.08, 0.03, 0, 0, 0, 'riderUpper'),

                // Neck & Natural Head at y=2.10 (riderUpper)
                makePart('frustum', 'skin', 0, 1.99, -0.02, 0.16, 0.12, 0.15, 0.08, 0, 0, 'riderUpper'),
                makePart('orgHeadNatural', 'skin', 0, 2.10, -0.01, 0.22, 0.24, 0.22, 0, 0, 0, 'riderUpper'),

                // Sculpted eyes, eyebrows & authentic Ottoman handlebar mustache
                makePart('sphere', 'eyeDark',  -0.030, 2.118, 0.076, 0.015, 0.012, 0.013, 0, 0, 0, 'riderUpper'),
                makePart('sphere', 'eyeDark',   0.030, 2.118, 0.076, 0.015, 0.012, 0.013, 0, 0, 0, 'riderUpper'),
                makePart('box',    'hairDark', -0.030, 2.131, 0.080, 0.026, 0.007, 0.011, 0, 0,  0.08, 'riderUpper'),
                makePart('box',    'hairDark',  0.030, 2.131, 0.080, 0.026, 0.007, 0.011, 0, 0, -0.08, 'riderUpper'),
                makePart('cone',   'hairDark', -0.032, 2.062, 0.070, 0.022, 0.060, 0.018, 0.15,  0.30,  1.32, 'riderUpper'),
                makePart('cone',   'hairDark',  0.032, 2.062, 0.070, 0.022, 0.060, 0.018, 0.15, -0.30, -1.32, 'riderUpper'),

                // Unified single-piece Left Arm holding reins at (-0.14, 1.65, 0.31) (riderUpper)
                makePart('orgArmRiderReinsL', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderUpper'),
                makePart('orgHand', 'skin', -0.14, 1.65, 0.31, 0.075, 0.075, 0.075, -0.15, 0, 0, 'riderUpper')
            ];
            return parts;
        }

        function buildRiderRightArm(sleeveMat) {
            return [
                // Unified single-piece Right Arm with hand at (0.22, 1.67, 0.32) (riderRightArmWeapon)
                makePart('orgArmRiderWeaponR', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'riderRightArmWeapon'),
                makePart('orgHand', 'skin', 0.22, 1.67, 0.32, 0.075, 0.075, 0.075, 0.2, 0, 0, 'riderRightArmWeapon')
            ];
        }

        function buildOttomanLanceParts(handX, handY, handZ, shaftLength, pennantMat, options = {}) {
            const pitch = options.pitch !== undefined ? options.pitch : 1.05;
            const sinP = Math.sin(pitch);
            const cosP = Math.cos(pitch);
            const midOffset = shaftLength * 0.28;
            const tipOffset = shaftLength * 0.78;
            const parts = [
                makePart('cylinder', 'wood', handX, handY + midOffset * cosP, handZ + midOffset * sinP, 0.042, shaftLength, 0.042, pitch, 0, 0, 'riderRightArmWeapon'),
                makePart('cone', 'steel', handX, handY + tipOffset * cosP, handZ + tipOffset * sinP, 0.065, 0.28, 0.032, pitch, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'gold', handX, handY + (tipOffset - 0.15) * cosP, handZ + (tipOffset - 0.15) * sinP, 0.052, 0.05, 0.052, pitch, 0, 0, 'riderRightArmWeapon'),
                makePart('box', pennantMat, handX, handY + (tipOffset - 0.42) * cosP - 0.12, handZ + (tipOffset - 0.42) * sinP, 0.015, 0.22, 0.56, pitch - 0.25, 0, 0, 'riderRightArmWeapon')
            ];
            if (options.tasselMat) {
                parts.push(
                    makePart('cone', options.tasselMat, handX, handY + (tipOffset - 0.28) * cosP - 0.10, handZ + (tipOffset - 0.28) * sinP, 0.09, 0.26, 0.09, 0.15, 0, 0, 'riderRightArmWeapon')
                );
            }
            return parts;
        }

        function buildOttomanSabreParts(handX, handY, handZ, bladeLen, guardMat) {
            return [
                makePart('cylinder', 'leather', handX, handY, handZ + 0.02, 0.036, 0.14, 0.036, 0.42, 0, 0, 'riderRightArmWeapon'),
                makePart('sphere', guardMat, handX, handY - 0.05, handZ - 0.01, 0.052, 0.052, 0.052, 0, 0, 0, 'riderRightArmWeapon'),
                makePart('box', guardMat, handX, handY + 0.05, handZ + 0.06, 0.14, 0.022, 0.045, 0.42, 0, 0, 'riderRightArmWeapon'),
                makePart('box', 'steel', handX, handY + bladeLen * 0.30, handZ + 0.20, 0.018, bladeLen * 0.56, 0.052, 0.38, 0, 0, 'riderRightArmWeapon'),
                makePart('frustum', 'steel', handX, handY + bladeLen * 0.72, handZ + 0.40, 0.016, bladeLen * 0.48, 0.048, 0.62, 0, 0, 'riderRightArmWeapon')
            ];
        }

        function buildSisakHelmetParts(metalMat, trimMat) {
            return [
                makePart('orgHelmetPointed', metalMat, 0, 2.17, -0.01, 0.26, 0.22, 0.27, 0, 0, 0, 'riderUpper'),
                makePart('cone', trimMat, 0, 2.30, -0.01, 0.04, 0.12, 0.04, 0, 0, 0, 'riderUpper'),
                makePart('frustum', metalMat, 0, 2.12, 0.11, 0.22, 0.03, 0.12, 0.22, 0, 0, 'riderUpper'),
                makePart('box', 'steel', 0, 2.08, 0.13, 0.02, 0.14, 0.015, 0, 0, 0, 'riderUpper'),
                makePart('box', metalMat, -0.12, 2.06, 0.0, 0.025, 0.13, 0.09, 0, 0, 0.12, 'riderUpper'),
                makePart('box', metalMat,  0.12, 2.06, 0.0, 0.025, 0.13, 0.09, 0, 0, -0.12, 'riderUpper')
            ];
        }

        function buildDeliWingedKalpakParts() {
            return [
                makePart('orgHelmetTurban', 'horseDark', 0, 2.16, -0.01, 0.28, 0.20, 0.29, 0, 0, 0, 'riderUpper'),
                makePart('cylinder', 'horseDark', 0, 2.19, -0.01, 0.26, 0.18, 0.26, 0, 0, 0, 'riderUpper'),
                // Twin eagle wings sweeping upward and back
                makePart('frustum', 'ottomanWhite', -0.13, 2.34, -0.04, 0.04, 0.34, 0.14, -0.28, 0,  0.22, 'riderUpper'),
                makePart('frustum', 'ottomanWhite',  0.13, 2.34, -0.04, 0.04, 0.34, 0.14, -0.28, 0, -0.22, 'riderUpper'),
                makePart('box', 'gold', 0, 2.21, 0.13, 0.05, 0.06, 0.02, 0, 0, 0, 'riderUpper')
            ];
        }

        function buildLeopardPeltMantleParts() {
            return [
                makePart('frustum', 'leopardPelt', 0, 1.88, -0.05, 0.54, 0.22, 0.36, Math.PI, 0, 0, 'riderUpper'),
                makePart('box', 'leopardPelt', -0.04, 1.78, 0.13, 0.12, 0.34, 0.04, 0, 0, -0.52, 'riderUpper'),
                makePart('box', 'leopardPelt', 0.0, 1.76, -0.19, 0.44, 0.36, 0.04, -0.14, 0, 0, 'riderUpper')
            ];
        }

        // 1. Sipahi Mızraklı
        function buildFixedOttomanSipahiLance() {
            return [
                ...buildFixedOttomanWarhorse('horseChestnut', 'horseDark', 'ottomanCrimson'),
                ...buildSeatedOttomanRiderBase('ottomanEmerald', 'leather', 'ottomanCrimson', 'orgTorsoCoat', { sashMat: 'ottomanSaffron' }),
                // Çar-Ayna mirror plate (breast & back disc) with damascus steel & brass trim
                makePart('cylinder', 'damascusSteel', 0, 1.78, 0.115, 0.26, 0.024, 0.26, Math.PI * 0.5, 0, 0, 'riderUpper'),
                makePart('cylinder', 'burnishedBronze', 0, 1.78, 0.118, 0.28, 0.008, 0.28, Math.PI * 0.5, 0, 0, 'riderUpper'),
                makePart('cylinder', 'damascusSteel', 0, 1.76, -0.165, 0.24, 0.022, 0.24, Math.PI * 0.5, 0, 0, 'riderUpper'),
                makePart('sphere', 'gold', 0, 1.78, 0.130, 0.09, 0.09, 0.04, 0, 0, 0, 'riderUpper'),
                // Steel Kolçak (vambrace) on right arm
                makePart('cylinder', 'damascusSteel', 0.22, 1.67, 0.32, 0.065, 0.16, 0.065, 0.2, 0, 0, 'riderRightArmWeapon'),
                ...buildSisakHelmetParts('damascusSteel', 'gold'),
                ...buildRiderRightArm('ottomanCrimson'),
                ...buildOttomanLanceParts(0.22, 1.67, 0.32, 4.0, 'ottomanCrimson', { pitch: 1.02 })
            ];
        }

        // 2. Sipahi Kılıç + Kalkanlı
        function buildFixedOttomanSipahiSwordShield() {
            return [
                ...buildFixedOttomanWarhorse('horseBay', 'horseDark', 'ottomanEmerald'),
                ...buildSeatedOttomanRiderBase('ottomanCrimson', 'leather', 'ottomanEmerald', 'orgTorsoCoat', { sashMat: 'ottomanSaffron' }),
                // Çar-Ayna chest & back mirror plate
                makePart('cylinder', 'damascusSteel', 0, 1.78, 0.115, 0.26, 0.024, 0.26, Math.PI * 0.5, 0, 0, 'riderUpper'),
                makePart('cylinder', 'burnishedBronze', 0, 1.78, 0.118, 0.28, 0.008, 0.28, Math.PI * 0.5, 0, 0, 'riderUpper'),
                makePart('cylinder', 'damascusSteel', 0, 1.76, -0.165, 0.24, 0.022, 0.24, Math.PI * 0.5, 0, 0, 'riderUpper'),
                makePart('sphere', 'gold', 0, 1.78, 0.130, 0.09, 0.09, 0.04, 0, 0, 0, 'riderUpper'),
                // Steel Kolçak on right arm
                makePart('cylinder', 'damascusSteel', 0.22, 1.67, 0.32, 0.065, 0.16, 0.065, 0.2, 0, 0, 'riderRightArmWeapon'),
                ...buildSisakHelmetParts('damascusSteel', 'gold'),
                // Round Kalkan shield hugging left forearm of orgArmRiderReinsL (riderUpper)
                makePart('cylinder', 'buffLeather', -0.28, 1.68, 0.20, 0.54, 0.04, 0.54, Math.PI * 0.5, 0.45, 0, 'riderUpper'),
                makePart('dome', 'gold', -0.32, 1.68, 0.22, 0.18, 0.08, 0.18, Math.PI * 0.5, 0.45, 0, 'riderUpper'),
                ...buildRiderRightArm('ottomanEmerald'),
                ...buildOttomanSabreParts(0.22, 1.67, 0.32, 0.86, 'gold')
            ];
        }

        // 3. Ağır Kapıkulu Sipahisi
        function buildFixedOttomanKapikuluHeavy() {
            return [
                ...buildFixedOttomanWarhorse('horseDark', 'horseDark', 'ottomanCrimson', { armored: true }),
                ...buildSeatedOttomanRiderBase('ottomanNavy', 'darkSteel', 'damascusSteel', 'orgTorsoArmored', {
                    sashMat: 'ottomanCrimson',
                    sleeveMat: 'damascusSteel'
                }),
                // Çar-Ayna four-mirror steel armor plates
                makePart('box', 'steel', 0, 1.82, 0.14, 0.24, 0.24, 0.035, 0, 0, 0, 'riderUpper'),
                makePart('box', 'steel', 0, 1.82, -0.18, 0.24, 0.24, 0.035, 0, 0, 0, 'riderUpper'),
                makePart('box', 'steel', -0.22, 1.82, -0.02, 0.035, 0.22, 0.20, 0, 0, 0, 'riderUpper'),
                makePart('box', 'steel',  0.22, 1.82, -0.02, 0.035, 0.22, 0.20, 0, 0, 0, 'riderUpper'),
                makePart('sphere', 'gold', 0, 1.82, 0.16, 0.08, 0.08, 0.025, 0, 0, 0, 'riderUpper'),
                // Visored Tolga helmet
                makePart('orgHelmetPointed', 'steel', 0, 2.17, -0.01, 0.27, 0.23, 0.28, 0, 0, 0, 'riderUpper'),
                makePart('cone', 'gold', 0, 2.31, -0.01, 0.04, 0.12, 0.04, 0, 0, 0, 'riderUpper'),
                makePart('frustum', 'steel', 0, 2.12, 0.12, 0.23, 0.03, 0.13, 0.20, 0, 0, 'riderUpper'),
                makePart('box', 'damascusSteel', 0, 2.06, 0.13, 0.16, 0.11, 0.02, 0, 0, 0, 'riderUpper'),
                // Heavy flanged Şeşper mace gripped cleanly in right hand (0.22, 1.67, 0.32)
                ...buildRiderRightArm('damascusSteel'),
                makePart('cylinder', 'wood', 0.22, 1.823, 0.394, 0.038, 0.62, 0.038, 0.45, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'gold', 0.22, 2.021, 0.490, 0.055, 0.05, 0.055, 0.45, 0, 0, 'riderRightArmWeapon'),
                makePart('sphere', 'steel', 0.22, 2.111, 0.533, 0.15, 0.17, 0.15, 0.45, 0, 0, 'riderRightArmWeapon'),
                makePart('box', 'steel', 0.22, 2.111, 0.533, 0.19, 0.15, 0.025, 0.45, 0, 0, 'riderRightArmWeapon'),
                makePart('box', 'steel', 0.22, 2.111, 0.533, 0.025, 0.15, 0.19, 0.45, 0, 0, 'riderRightArmWeapon')
            ];
        }

        // 4. Deli Mızraklı
        function buildFixedOttomanDeliLance() {
            return [
                ...buildFixedOttomanWarhorse('horseDun', 'horseDark', 'ottomanCrimson', { leopardSaddle: true }),
                ...buildSeatedOttomanRiderBase('ottomanCrimson', 'leather', 'ottomanCrimson', 'orgTorsoCoat', { sashMat: 'ottomanSaffron' }),
                ...buildLeopardPeltMantleParts(),
                ...buildDeliWingedKalpakParts(),
                ...buildRiderRightArm('ottomanCrimson'),
                ...buildOttomanLanceParts(0.22, 1.67, 0.32, 3.8, 'ottomanSaffron', { pitch: 0.98, tasselMat: 'leopardPelt' })
            ];
        }

        // 5. Deli Kılıçlı
        function buildFixedOttomanDeliSword() {
            return [
                ...buildFixedOttomanWarhorse('horseChestnut', 'horseDark', 'ottomanNavy', { leopardSaddle: true }),
                ...buildSeatedOttomanRiderBase('ottomanNavy', 'leather', 'roughWool', 'orgTorsoCoat', { sashMat: 'ottomanCrimson' }),
                ...buildLeopardPeltMantleParts(),
                ...buildDeliWingedKalpakParts(),
                ...buildRiderRightArm('roughWool'),
                ...buildOttomanSabreParts(0.22, 1.67, 0.32, 0.92, 'burnishedBronze')
            ];
        }

        // 6. Akıncı / Hafif Atlı Ateşli
        function buildFixedOttomanAkinciCarbine() {
            return [
                ...buildFixedOttomanWarhorse('horseDun', 'wood', 'ottomanSaffron'),
                ...buildSeatedOttomanRiderBase('ottomanNavy', 'buffLeather', 'buffLeather', 'orgTorsoCoat', { sashMat: 'ottomanCrimson' }),
                // Felt külah + wrapped turban band
                makePart('orgHelmetPointed', 'buffLeather', 0, 2.18, -0.01, 0.23, 0.28, 0.24, -0.08, 0, 0, 'riderUpper'),
                makePart('orgHelmetTurban', 'ottomanWhite', 0, 2.14, -0.01, 0.27, 0.11, 0.28, 0, 0, 0, 'riderUpper'),
                // Slung composite bow & quiver on riderUpper
                makePart('box', 'leather', -0.24, 1.68, -0.14, 0.08, 0.36, 0.12, -0.35, 0, 0.2, 'riderUpper'),
                makePart('frustum', 'wood', -0.25, 1.84, -0.18, 0.03, 0.42, 0.03, -0.35, 0, 0.2, 'riderUpper'),
                // Mounted Ottoman carbine gripped cleanly in right hand (0.22, 1.67, 0.32)
                ...buildRiderRightArm('buffLeather'),
                makePart('frustum', 'wood', 0.22, 1.67, 0.22, 0.055, 0.24, 0.085, 1.35, 0, 0, 'riderRightArmWeapon'),
                makePart('box', 'wood', 0.22, 1.70, 0.46, 0.045, 0.055, 0.36, -0.12, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'steel', 0.22, 1.73, 0.66, 0.034, 0.66, 0.034, 1.45, 0, 0, 'riderRightArmWeapon'),
                makePart('cylinder', 'burnishedBronze', 0.22, 1.72, 0.60, 0.042, 0.04, 0.042, 1.45, 0, 0, 'riderRightArmWeapon')
            ];
        }

        const FIXED_OTTOMAN_CAVALRY = {
            'fixed:ottoman_sipahi_lance': buildFixedOttomanSipahiLance(),
            'fixed:ottoman_sipahi_sword_shield': buildFixedOttomanSipahiSwordShield(),
            'fixed:ottoman_kapikulu_heavy': buildFixedOttomanKapikuluHeavy(),
            'fixed:ottoman_deli_lance': buildFixedOttomanDeliLance(),
            'fixed:ottoman_deli_sword': buildFixedOttomanDeliSword(),
            'fixed:ottoman_akinci_carbine': buildFixedOttomanAkinciCarbine()
        };
    """
