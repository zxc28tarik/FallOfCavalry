# -*- coding: utf-8 -*-
"""
tools/build_organic_geometries.py
Procedural WebGL BufferGeometry generator for organic 3D character, bent arm sleeves,
headwear, saddle, and warhorse meshes (FOC_THREE.BufferGeometry compatible).
"""


def get_organic_geometries_code():
    """Return JavaScript source defining OrganicCharacterGeometries."""
    return r'''
const OrganicCharacterGeometries = (() => {
    const TWO_PI = Math.PI * 2;

    class MeshBuilder {
        constructor() {
            this.pos = [];
            this.idx = [];
        }

        _vCount() {
            return this.pos.length / 3;
        }

        addVertex(x, y, z) {
            const i = this._vCount();
            this.pos.push(x, y, z);
            return i;
        }

        addTri(a, b, c) {
            this.idx.push(a, b, c);
        }

        /**
         * Loft a closed sequence of rings along any curve.
         * Each ring is an array of [x, y, z] of length radialSegs.
         * Parameterization assumes ring points wind +U -> +F -> -U -> -F
         * where T x F = U when progressing from start ring to end ring (outward CCW).
         */
        addLoft(rings, capStart = true, capEnd = true, flipWinding = false) {
            const numRings = rings.length;
            if (numRings < 2) return;
            const segs = rings[0].length;
            const base = this._vCount();

            for (let r = 0; r < numRings; r++) {
                const ring = rings[r];
                for (let i = 0; i < segs; i++) {
                    this.pos.push(ring[i][0], ring[i][1], ring[i][2]);
                }
            }

            for (let r = 0; r < numRings - 1; r++) {
                const r0 = base + r * segs;
                const r1 = base + (r + 1) * segs;
                for (let i = 0; i < segs; i++) {
                    const ni = (i + 1) % segs;
                    const a = r0 + i;
                    const b = r0 + ni;
                    const c = r1 + i;
                    const d = r1 + ni;
                    if (flipWinding) {
                        this.idx.push(a, d, c, a, b, d);
                    } else {
                        this.idx.push(a, c, d, a, d, b);
                    }
                }
            }

            if (capStart) {
                const ring0 = rings[0];
                let cx = 0, cy = 0, cz = 0;
                for (let i = 0; i < segs; i++) {
                    cx += ring0[i][0];
                    cy += ring0[i][1];
                    cz += ring0[i][2];
                }
                const cIdx = this.addVertex(cx / segs, cy / segs, cz / segs);
                for (let i = 0; i < segs; i++) {
                    const ni = (i + 1) % segs;
                    if (flipWinding) {
                        this.idx.push(cIdx, base + ni, base + i);
                    } else {
                        this.idx.push(cIdx, base + i, base + ni);
                    }
                }
            }

            if (capEnd) {
                const lastRing = rings[numRings - 1];
                const lastBase = base + (numRings - 1) * segs;
                let cx = 0, cy = 0, cz = 0;
                for (let i = 0; i < segs; i++) {
                    cx += lastRing[i][0];
                    cy += lastRing[i][1];
                    cz += lastRing[i][2];
                }
                const cIdx = this.addVertex(cx / segs, cy / segs, cz / segs);
                for (let i = 0; i < segs; i++) {
                    const ni = (i + 1) % segs;
                    if (flipWinding) {
                        this.idx.push(cIdx, lastBase + i, lastBase + ni);
                    } else {
                        this.idx.push(cIdx, lastBase + ni, lastBase + i);
                    }
                }
            }
        }

        /**
         * Add an ellipsoid centered at (cx, cy, cz) with radii (rx, ry, rz)
         * and optional Euler rotation (rotX, rotY, rotZ).
         */
        addEllipsoid(cx, cy, cz, rx, ry, rz, segsU = 16, segsV = 10, rotX = 0, rotY = 0, rotZ = 0) {
            const rings = [];
            for (let v = 1; v < segsV; v++) {
                const phi = -Math.PI * 0.5 + (v / segsV) * Math.PI;
                const cp = Math.cos(phi);
                const sp = Math.sin(phi);
                const ring = [];
                for (let u = 0; u < segsU; u++) {
                    const theta = (u / segsU) * TWO_PI;
                    const p = rotateXYZ(
                        rx * cp * Math.cos(theta),
                        ry * sp,
                        rz * cp * Math.sin(theta),
                        rotX, rotY, rotZ
                    );
                    ring.push([cx + p[0], cy + p[1], cz + p[2]]);
                }
                rings.push(ring);
            }
            const botP = rotateXYZ(0, -ry, 0, rotX, rotY, rotZ);
            const topP = rotateXYZ(0, ry, 0, rotX, rotY, rotZ);
            this.addLoft(rings, false, false);

            const totalRingVerts = rings.length * segsU;
            const firstRingStart = this._vCount() - totalRingVerts;
            const lastRingStart = this._vCount() - segsU;

            const botIdx = this.addVertex(cx + botP[0], cy + botP[1], cz + botP[2]);
            const topIdx = this.addVertex(cx + topP[0], cy + topP[1], cz + topP[2]);

            for (let u = 0; u < segsU; u++) {
                const nu = (u + 1) % segsU;
                this.idx.push(botIdx, firstRingStart + u, firstRingStart + nu);
                this.idx.push(topIdx, lastRingStart + nu, lastRingStart + u);
            }
        }

        /**
         * Add a closed torus/wrapped ring with optional wave modulation.
         */
        addTorus(cx, cy, cz, majorR, minorR, segsU = 28, segsV = 10, rotX = 0, rotY = 0, rotZ = 0, waveAmp = 0, waveFreq = 0) {
            const base = this._vCount();
            for (let u = 0; u < segsU; u++) {
                const theta = (u / segsU) * TWO_PI;
                const ct = Math.cos(theta);
                const st = Math.sin(theta);
                const rMod = minorR * (1 + waveAmp * Math.sin(theta * waveFreq));
                for (let v = 0; v < segsV; v++) {
                    const phi = (v / segsV) * TWO_PI;
                    const cp = Math.cos(phi);
                    const sp = Math.sin(phi);
                    const r = majorR + rMod * cp;
                    const p = rotateXYZ(r * ct, rMod * sp, r * st, rotX, rotY, rotZ);
                    this.pos.push(cx + p[0], cy + p[1], cz + p[2]);
                }
            }
            for (let u = 0; u < segsU; u++) {
                const nu = (u + 1) % segsU;
                for (let v = 0; v < segsV; v++) {
                    const nv = (v + 1) % segsV;
                    const a = base + u * segsV + v;
                    const b = base + nu * segsV + v;
                    const c = base + u * segsV + nv;
                    const d = base + nu * segsV + nv;
                    this.idx.push(a, c, d, a, d, b);
                }
            }
        }

        /**
         * Add a sculpted capsule/limb along a 3D spine:
         * spine = [{x, y, z, rx, rz}, ...]
         */
        addSpineLoft(spine, radialSegs = 14, capStart = true, capEnd = true) {
            const rings = [];
            for (let s = 0; s < spine.length; s++) {
                const pt = spine[s];
                let tx, ty, tz;
                if (s === 0) {
                    tx = spine[1].x - pt.x;
                    ty = spine[1].y - pt.y;
                    tz = spine[1].z - pt.z;
                } else if (s === spine.length - 1) {
                    tx = pt.x - spine[s - 1].x;
                    ty = pt.y - spine[s - 1].y;
                    tz = pt.z - spine[s - 1].z;
                } else {
                    tx = spine[s + 1].x - spine[s - 1].x;
                    ty = spine[s + 1].y - spine[s - 1].y;
                    tz = spine[s + 1].z - spine[s - 1].z;
                }
                const tLen = Math.hypot(tx, ty, tz) || 1;
                tx /= tLen; ty /= tLen; tz /= tLen;

                // Construct stable frame (right, tangent, forward)
                let rxVec = [1, 0, 0];
                if (Math.abs(tx) > 0.9) rxVec = [0, 0, 1];
                // forward = right x tangent
                let fx = rxVec[1] * tz - rxVec[2] * ty;
                let fy = rxVec[2] * tx - rxVec[0] * tz;
                let fz = rxVec[0] * ty - rxVec[1] * tx;
                const fLen = Math.hypot(fx, fy, fz) || 1;
                fx /= fLen; fy /= fLen; fz /= fLen;
                // right = tangent x forward
                const ux = ty * fz - tz * fy;
                const uy = tz * fx - tx * fz;
                const uz = tx * fy - ty * fx;

                const ring = [];
                for (let i = 0; i < radialSegs; i++) {
                    const a = (i / radialSegs) * TWO_PI;
                    const ca = Math.cos(a) * pt.rx;
                    const sa = Math.sin(a) * pt.rz;
                    ring.push([
                        pt.x + ux * ca + fx * sa,
                        pt.y + uy * ca + fy * sa,
                        pt.z + uz * ca + fz * sa
                    ]);
                }
                rings.push(ring);
            }
            this.addLoft(rings, capStart, capEnd);
        }

        /**
         * Build FOC_THREE.BufferGeometry with smooth area-weighted outward normals.
         * When normalize = true (default), centers at (0,0,0) and scales max span to 1.0.
         * When normalize = false, preserves exact world/character-space meter coordinates.
         */
        toBufferGeometry(normalize = true) {
            const pArr = new Float32Array(this.pos);
            const iArr = new Uint16Array(this.idx);
            const vCount = pArr.length / 3;

            if (normalize && vCount > 0) {
                let minX = Infinity, minY = Infinity, minZ = Infinity;
                let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
                for (let i = 0; i < vCount; i++) {
                    const x = pArr[i * 3];
                    const y = pArr[i * 3 + 1];
                    const z = pArr[i * 3 + 2];
                    if (x < minX) minX = x;
                    if (y < minY) minY = y;
                    if (z < minZ) minZ = z;
                    if (x > maxX) maxX = x;
                    if (y > maxY) maxY = y;
                    if (z > maxZ) maxZ = z;
                }
                const cx = (minX + maxX) * 0.5;
                const cy = (minY + maxY) * 0.5;
                const cz = (minZ + maxZ) * 0.5;
                const span = Math.max(maxX - minX, maxY - minY, maxZ - minZ) || 1;
                const invSpan = 1.0 / span;

                for (let i = 0; i < vCount; i++) {
                    pArr[i * 3] = (pArr[i * 3] - cx) * invSpan;
                    pArr[i * 3 + 1] = (pArr[i * 3 + 1] - cy) * invSpan;
                    pArr[i * 3 + 2] = (pArr[i * 3 + 2] - cz) * invSpan;
                }
            }

            // Smooth area-weighted vertex normals
            const nArr = new Float32Array(pArr.length);
            for (let t = 0; t < iArr.length; t += 3) {
                const ia = iArr[t] * 3;
                const ib = iArr[t + 1] * 3;
                const ic = iArr[t + 2] * 3;

                const ax = pArr[ia], ay = pArr[ia + 1], az = pArr[ia + 2];
                const e1x = pArr[ib] - ax, e1y = pArr[ib + 1] - ay, e1z = pArr[ib + 2] - az;
                const e2x = pArr[ic] - ax, e2y = pArr[ic + 1] - ay, e2z = pArr[ic + 2] - az;

                const nx = e1y * e2z - e1z * e2y;
                const ny = e1z * e2x - e1x * e2z;
                const nz = e1x * e2y - e1y * e2x;

                nArr[ia] += nx; nArr[ia + 1] += ny; nArr[ia + 2] += nz;
                nArr[ib] += nx; nArr[ib + 1] += ny; nArr[ib + 2] += nz;
                nArr[ic] += nx; nArr[ic + 1] += ny; nArr[ic + 2] += nz;
            }

            for (let i = 0; i < vCount; i++) {
                const o = i * 3;
                const len = Math.hypot(nArr[o], nArr[o + 1], nArr[o + 2]);
                if (len > 1e-8) {
                    nArr[o] /= len;
                    nArr[o + 1] /= len;
                    nArr[o + 2] /= len;
                } else {
                    nArr[o + 1] = 1.0;
                }
            }

            const geo = new FOC_THREE.BufferGeometry();
            geo.positions = pArr;
            geo.normals = nArr;
            geo.indices = iArr;
            return geo;
        }
    }

    function rotateXYZ(x, y, z, rx, ry, rz) {
        if (rx !== 0) {
            const c = Math.cos(rx), s = Math.sin(rx);
            const ny = y * c - z * s;
            const nz = y * s + z * c;
            y = ny; z = nz;
        }
        if (ry !== 0) {
            const c = Math.cos(ry), s = Math.sin(ry);
            const nx = x * c + z * s;
            const nz = -x * s + z * c;
            x = nx; z = nz;
        }
        if (rz !== 0) {
            const c = Math.cos(rz), s = Math.sin(rz);
            const nx = x * c - y * s;
            const ny = x * s + y * c;
            x = nx; y = ny;
        }
        return [x, y, z];
    }

    function smoothstep(edge0, edge1, x) {
        const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
        return t * t * (3 - 2 * t);
    }

    function lerp(a, b, t) {
        return a + (b - a) * t;
    }

    function gauss(x, mu, sigma) {
        const d = (x - mu) / sigma;
        return Math.exp(-0.5 * d * d);
    }

    /**
     * Build a single continuous bent sleeve in exact character-space coordinates
     * using parallel-transport framing (twist-free across arbitrary 3D elbow bends),
     * rounded shoulder deltoid cap, natural elbow crease folds, forearm taper, and cuff lip.
     */
    function buildBentArmSleeve(shoulder, elbow, wrist, opts = {}) {
        const mb = new MeshBuilder();
        const rShoulder = opts.rShoulder || 0.078;
        const rElbow = opts.rElbow || 0.056;
        const rWrist = opts.rWrist || 0.046;
        const radialSegs = opts.radialSegs || 16;

        const sx = shoulder[0], sy = shoulder[1], sz = shoulder[2];
        const ex = elbow[0], ey = elbow[1], ez = elbow[2];
        const wx = wrist[0], wy = wrist[1], wz = wrist[2];

        const d1x = ex - sx, d1y = ey - sy, d1z = ez - sz;
        const len1 = Math.hypot(d1x, d1y, d1z) || 0.01;
        const u1x = d1x / len1, u1y = d1y / len1, u1z = d1z / len1;

        const d2x = wx - ex, d2y = wy - ey, d2z = wz - ez;
        const len2 = Math.hypot(d2x, d2y, d2z) || 0.01;
        const u2x = d2x / len2, u2y = d2y / len2, u2z = d2z / len2;

        // Smooth rounded elbow transition length without self-intersection
        const blendDist = Math.min(len1, len2) * 0.58;
        const einX = ex - u1x * blendDist, einY = ey - u1y * blendDist, einZ = ez - u1z * blendDist;
        const eoutX = ex + u2x * blendDist, eoutY = ey + u2y * blendDist, eoutZ = ez + u2z * blendDist;

        // Inner-bend vector (points toward inside of elbow crease)
        let bx = u2x - u1x, by = u2y - u1y, bz = u2z - u1z;
        const bLen = Math.hypot(bx, by, bz);
        if (bLen > 1e-4) {
            bx /= bLen; by /= bLen; bz /= bLen;
        } else {
            bx = 0; by = 0; bz = 1;
        }

        // Station parameterization t in [-0.06, 1.0]: negative t tucks rounded deltoid cap into torso socket
        const tSamples = [
            -0.06, 0.0, 0.09, 0.21, 0.34,
            0.44, 0.50, 0.56,
            0.66, 0.77, 0.86, 0.91, 0.95, 0.98, 1.0
        ];

        const pathPts = [];
        for (let k = 0; k < tSamples.length; k++) {
            const t = tSamples[k];
            let px, py, pz, r;
            if (t < 0) {
                // Tucked shoulder cap continuing straight back into torso socket along -u1
                px = sx - u1x * 0.028;
                py = sy - u1y * 0.028;
                pz = sz - u1z * 0.028;
                r = rShoulder * 0.62;
            } else if (t <= 0.34) {
                const u = t / 0.34;
                px = lerp(sx, einX, u);
                py = lerp(sy, einY, u);
                pz = lerp(sz, einZ, u);
                const deltoidSwell = 0.005 * Math.sin(u * Math.PI);
                r = lerp(rShoulder, lerp(rShoulder, rElbow, 0.72), smoothstep(0, 1, u)) + deltoidSwell;
            } else if (t <= 0.66) {
                const u = (t - 0.34) / 0.32;
                const om = 1 - u;
                px = om * om * einX + 2 * om * u * ex + u * u * eoutX;
                py = om * om * einY + 2 * om * u * ey + u * u * eoutY;
                pz = om * om * einZ + 2 * om * u * ez + u * u * eoutZ;
                r = lerp(lerp(rShoulder, rElbow, 0.72), rElbow, u);
            } else {
                const u = (t - 0.66) / 0.34;
                px = lerp(eoutX, wx, u);
                py = lerp(eoutY, wy, u);
                pz = lerp(eoutZ, wz, u);
                const baseR = lerp(rElbow, rWrist, smoothstep(0, 0.80, u));
                // Tailored 1650 turned-back sleeve cuff flare at wrist
                const cuffLip = gauss(u, 0.83, 0.085) * 0.0085;
                const endTaper = u > 0.94 ? lerp(1.0, 0.82, (u - 0.94) / 0.06) : 1.0;
                r = (baseR + cuffLip) * endTaper;
            }
            pathPts.push({ x: px, y: py, z: pz, r, t });
        }

        // Parallel transport Bishop frame along pathPts
        let prevUx = 0, prevUy = 0, prevUz = 0;
        const rings = [];
        for (let s = 0; s < pathPts.length; s++) {
            const pt = pathPts[s];
            let tx, ty, tz;
            if (s === 0) {
                tx = pathPts[1].x - pt.x;
                ty = pathPts[1].y - pt.y;
                tz = pathPts[1].z - pt.z;
            } else if (s === pathPts.length - 1) {
                tx = pt.x - pathPts[s - 1].x;
                ty = pt.y - pathPts[s - 1].y;
                tz = pt.z - pathPts[s - 1].z;
            } else {
                tx = pathPts[s + 1].x - pathPts[s - 1].x;
                ty = pathPts[s + 1].y - pathPts[s - 1].y;
                tz = pathPts[s + 1].z - pathPts[s - 1].z;
            }
            const tLen = Math.hypot(tx, ty, tz) || 1;
            tx /= tLen; ty /= tLen; tz /= tLen;

            let ux, uy, uz;
            if (s === 0) {
                let refX = 0, refY = 1, refZ = 0;
                if (Math.abs(ty) > 0.9) { refX = 0; refY = 0; refZ = 1; }
                // U = normalize(ref x T)
                ux = refY * tz - refZ * ty;
                uy = refZ * tx - refX * tz;
                uz = refX * ty - refY * tx;
            } else {
                // Parallel transport previous U orthogonal to current T
                const dot = prevUx * tx + prevUy * ty + prevUz * tz;
                ux = prevUx - dot * tx;
                uy = prevUy - dot * ty;
                uz = prevUz - dot * tz;
            }
            let uLen = Math.hypot(ux, uy, uz);
            if (uLen < 1e-5) {
                ux = 1; uy = 0; uz = 0;
                if (Math.abs(tx) > 0.9) { ux = 0; uz = 1; }
                uLen = 1;
            }
            ux /= uLen; uy /= uLen; uz /= uLen;

            // F = U x T, then re-orthogonalize U = T x F so T x F = U strictly
            let fx = uy * tz - uz * ty;
            let fy = uz * tx - ux * tz;
            let fz = ux * ty - uy * tx;
            const fLen = Math.hypot(fx, fy, fz) || 1;
            fx /= fLen; fy /= fLen; fz /= fLen;

            ux = ty * fz - tz * fy;
            uy = tz * fx - tx * fz;
            uz = tx * fy - ty * fx;
            prevUx = ux; prevUy = uy; prevUz = uz;

            const ring = [];
            const elbowProx = gauss(pt.t, 0.50, 0.11);
            const foldFade = pt.t > 0.05 && pt.t < 0.84 ? 1.0 : 0.0;
            for (let i = 0; i < radialSegs; i++) {
                const a = (i / radialSegs) * TWO_PI;
                const ca = Math.cos(a);
                const sa = Math.sin(a);
                // World-space radial direction for elbow crease alignment
                const rdx = ux * ca + fx * sa;
                const rdy = uy * ca + fy * sa;
                const rdz = uz * ca + fz * sa;
                const bendDot = rdx * bx + rdy * by + rdz * bz;
                const innerDot = Math.max(0, bendDot);
                const outerDot = Math.max(0, -bendDot);

                // Natural sleeve drape folds + inner-elbow fabric bunching
                const drape = 0.0036 * Math.cos(4 * a + pt.t * 5.5) * foldFade;
                const crease = elbowProx * (0.0055 * innerDot * Math.cos((pt.t - 0.50) * 44.0));
                // Anatomical bony Olecranon elbow point on the outer bend
                const olecranon = elbowProx * 0.018 * Math.pow(outerDot, 2.4);
                // Deltoid muscle cap blending seamlessly into shoulder socket at pt.t < 0.28
                const deltoid = (pt.t < 0.28) ? 0.022 * Math.sin(Math.max(0, pt.t / 0.28) * Math.PI) * (1.0 + 0.40 * outerDot) : 0;
                // Forearm brachioradialis muscle taper
                const forearm = (pt.t > 0.60 && pt.t < 0.90) ? 0.010 * Math.sin(((pt.t - 0.60) / 0.30) * Math.PI) : 0;
                // Tailored sleeve cuff flare at wrist
                const cuffFlare = (pt.t >= 0.91) ? 0.014 * Math.sin(((pt.t - 0.91) / 0.09) * Math.PI) : 0;

                const rad = Math.max(0.015, pt.r + drape + crease + olecranon + deltoid + forearm + cuffFlare);
                ring.push([
                    pt.x + rdx * rad,
                    pt.y + rdy * rad,
                    pt.z + rdz * rad
                ]);
            }
            rings.push(ring);
        }

        mb.addLoft(rings, true, true);
        return mb.toBufferGeometry(false);
    }

    /**
     * Build a single continuous contoured mounted rider leg + knee + cavalry boot
     * in exact character-space coordinates (normalize = false).
     * side = -1 (left) or +1 (right).
     */
    function buildRiderLeg(side) {
        const mb = new MeshBuilder();

        // Continuous thigh -> knee -> turned-down bucket cuff -> calf -> ankle -> heel
        const legSpine = [
            { x: side * 0.160, y: 1.480, z: -0.040, rx: 0.082, rz: 0.088 },
            { x: side * 0.225, y: 1.420, z:  0.030, rx: 0.080, rz: 0.086 },
            { x: side * 0.295, y: 1.340, z:  0.110, rx: 0.072, rz: 0.078 },
            { x: side * 0.340, y: 1.250, z:  0.160, rx: 0.063, rz: 0.069 },
            { x: side * 0.342, y: 1.215, z:  0.148, rx: 0.058, rz: 0.064 },
            { x: side * 0.345, y: 1.190, z:  0.138, rx: 0.074, rz: 0.078 },
            { x: side * 0.346, y: 1.160, z:  0.128, rx: 0.070, rz: 0.074 },
            { x: side * 0.348, y: 1.135, z:  0.118, rx: 0.055, rz: 0.061 },
            { x: side * 0.350, y: 1.030, z:  0.085, rx: 0.058, rz: 0.068 },
            { x: side * 0.350, y: 0.920, z:  0.058, rx: 0.049, rz: 0.056 },
            { x: side * 0.350, y: 0.840, z:  0.040, rx: 0.046, rz: 0.052 },
            { x: side * 0.350, y: 0.785, z:  0.025, rx: 0.048, rz: 0.056 }
        ];
        mb.addSpineLoft(legSpine, 18, true, true);

        // Sculpted forward-pointing boot foot resting in stirrup at (±0.35, 0.77, 0.09)
        const footSpine = [
            { x: side * 0.350, y: 0.782, z: -0.015, rx: 0.043, rz: 0.032 },
            { x: side * 0.350, y: 0.778, z:  0.035, rx: 0.047, rz: 0.036 },
            { x: side * 0.350, y: 0.770, z:  0.090, rx: 0.048, rz: 0.030 },
            { x: side * 0.350, y: 0.766, z:  0.145, rx: 0.040, rz: 0.023 },
            { x: side * 0.350, y: 0.764, z:  0.180, rx: 0.024, rz: 0.016 }
        ];
        mb.addSpineLoft(footSpine, 14, true, true);
        mb.addEllipsoid(side * 0.350, 0.752, 0.005, 0.040, 0.018, 0.030, 12, 6);

        return mb.toBufferGeometry(false);
    }

    return {
        /**
         * 1. Athletic sculpted human torso + collarbone/trapezius slope + kaftan/doublet
         *    collar opening + 1650 peascod doublet front + folded belt ridge +
         *    deeper shoulder socket blend + 8-fold flared cloth coat skirt.
         */
        createTorsoCoat() {
            const mb = new MeshBuilder();
            const segs = 36;
            const yLevels = [
                -0.50, -0.45, -0.38, -0.30, -0.22, -0.15, -0.10,
                -0.082, -0.055, -0.028, 0.00, 0.05, 0.11, 0.18, 0.25,
                0.31, 0.36, 0.40, 0.44, 0.47, 0.49, 0.50
            ];
            const rings = [];

            for (let r = 0; r < yLevels.length; r++) {
                const y = yLevels[r];
                let rx, rz, zShift = 0, beltBump = 0, pleatAmp = 0;

                if (y <= -0.09) {
                    // Flared 8-fold cloth coat skirt below belt
                    const t = (y - (-0.50)) / 0.41;
                    const s = smoothstep(0, 1, t);
                    rx = lerp(0.47, 0.27, s);
                    rz = lerp(0.31, 0.195, s);
                    pleatAmp = lerp(0.025, 0.003, s);
                    zShift = lerp(-0.008, 0.010, s);
                } else if (y <= -0.01) {
                    // Pinched belted waist with crisp folded belt/sash ridge
                    rx = 0.255;
                    rz = 0.185;
                    beltBump = 0.028 * gauss(y, -0.055, 0.018)
                        + 0.016 * gauss(y, -0.028, 0.012)
                        + 0.012 * gauss(y, -0.082, 0.012);
                    zShift = 0.010;
                } else if (y <= 0.34) {
                    // Athletic ribcage to wide elliptical shoulders (rx = 0.485, rz = 0.25)
                    const t = (y - (-0.01)) / 0.35;
                    rx = lerp(0.27, 0.485, Math.pow(smoothstep(0, 1, t), 0.85));
                    rz = lerp(0.195, 0.25, smoothstep(0, 0.78, t));
                    zShift = 0.016 * Math.sin(t * Math.PI * 0.85);
                } else {
                    // Distinct collarbone & trapezius slope up to neck collar
                    const t = (y - 0.34) / 0.16;
                    const s = smoothstep(0, 1, t);
                    rx = lerp(0.485, 0.20, Math.pow(s, 0.88));
                    rz = lerp(0.25, 0.18, s);
                    zShift = lerp(0.007, 0.0, s);
                }

                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const ca = Math.cos(a);
                    const sa = Math.sin(a);

                    // Bilateral pectoral chest swell (+Z) with subtle sternum center hollow
                    const pecProfile = (sa > 0 && y > 0.05 && y < 0.40)
                        ? Math.pow(sa, 1.3) * Math.sin(((y - 0.05) / 0.35) * Math.PI)
                            * (0.042 * (gauss(ca, 0.42, 0.36) + gauss(ca, -0.42, 0.36)) - 0.006 * gauss(ca, 0, 0.16))
                        : 0;

                    // 1650 peascod doublet front silhouette + crisp central placket seam
                    const peascodBelly = (sa > 0.15 && y > -0.07 && y < 0.28)
                        ? 0.032 * Math.pow(sa, 2.2) * gauss(y, 0.08, 0.105)
                        : 0;
                    const placketRidge = (sa > 0.55 && y > -0.10 && y < 0.37)
                        ? 0.014 * gauss(ca, 0, 0.12) * Math.sin(((y + 0.10) / 0.47) * Math.PI)
                        : 0;

                    // Kaftan / doublet front collar opening & raised lapel edges
                    const collarOpen = (sa > 0.35 && y > 0.35)
                        ? -0.018 * gauss(ca, 0, 0.24) * smoothstep(0.35, 0.49, y)
                        : 0;
                    const collarLapel = (sa > 0.35 && y > 0.35)
                        ? 0.011 * (gauss(ca, 0.29, 0.11) + gauss(ca, -0.29, 0.11)) * smoothstep(0.35, 0.48, y)
                        : 0;

                    // Subtle collarbone ridge sloping outward on upper front chest
                    const clavicle = (sa > 0.2 && y > 0.35 && y < 0.44)
                        ? 0.011 * sa * gauss(y, 0.39, 0.024) * (1 - 0.3 * ca * ca)
                        : 0;

                    // Upper-back shoulder blades & central dorsal spine groove (-Z)
                    const backFade = (sa < 0 && y > 0.02 && y < 0.42)
                        ? Math.pow(-sa, 1.3) * Math.sin(((y - 0.02) / 0.40) * Math.PI)
                        : 0;
                    const scapulae = backFade * 0.026 * (gauss(ca, 0.44, 0.34) + gauss(ca, -0.44, 0.34));
                    const spineGroove = backFade * 0.020 * gauss(ca, 0, 0.20);

                    // Deeper sculpted shoulder socket / armscye blend so orgArm* sleeves merge naturally
                    const armholeSide = Math.pow(Math.max(0, Math.abs(ca) - 0.60) / 0.40, 1.5);
                    const shoulderSocket = (y > 0.16 && y < 0.40)
                        ? 0.032 * gauss(y, 0.28, 0.068) * armholeSide
                        : 0;

                    // Sculpted 8-fold cloth skirt / coat-tails with front opening vent
                    const pleats = pleatAmp * Math.cos(a * 8);
                    const skirtVent = (y < -0.10 && sa > 0.70)
                        ? -0.016 * gauss(ca, 0, 0.16) * smoothstep(-0.10, -0.48, y)
                        : 0;

                    const px = (rx + beltBump + pleats - shoulderSocket) * ca;
                    const pz = zShift + (rz + beltBump + pleats) * sa
                        + pecProfile + peascodBelly + placketRidge + collarOpen + collarLapel + clavicle
                        - scapulae + spineGroove + skirtVent;
                    ring.push([px, y, pz]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry();
        },

        /**
         * 2. Sculpted 1650 breastplate/cuirass with sharpened peascod tapul ridge (+Z),
         *    gorget collar opening, folded waist flange ridge, deeper shoulder socket blend,
         *    and integrated articulated fauld/tasset armor ridges.
         */
        createTorsoArmored() {
            const mb = new MeshBuilder();
            const segs = 36;
            const yLevels = [
                -0.50, -0.45, -0.40, -0.35, -0.30, -0.25, -0.20, -0.15, -0.10,
                -0.065, -0.025, 0.04, 0.11, 0.18, 0.25, 0.31,
                0.36, 0.41, 0.45, 0.48, 0.50
            ];
            const rings = [];

            for (let r = 0; r < yLevels.length; r++) {
                const y = yLevels[r];
                let rx, rz, zShift = 0, lameRidge = 0, waistFlange = 0;

                if (y <= -0.09) {
                    // Integrated articulated 4-lame fauld / tasset armor skirt
                    const t = (y - (-0.50)) / 0.41;
                    const s = smoothstep(0, 1, t);
                    rx = lerp(0.45, 0.28, s);
                    rz = lerp(0.29, 0.21, s);
                    // Crisp overlapping articulated armor lames (stepped outward at bottom of each lame)
                    const phase = (t * 4.0) % 1.0;
                    lameRidge = 0.015 * Math.sin(phase * Math.PI) + 0.008 * (1.0 - phase);
                    zShift = 0.008;
                } else if (y <= 0.01) {
                    // Pinched cuirass waist + folded waist flange & belt ridge
                    rx = 0.275;
                    rz = 0.205;
                    waistFlange = 0.028 * gauss(y, -0.065, 0.016) + 0.014 * gauss(y, -0.025, 0.012);
                    zShift = 0.012;
                } else if (y <= 0.34) {
                    // Sculpted 1650 breastplate torso
                    const t = (y - 0.01) / 0.33;
                    rx = lerp(0.275, 0.478, Math.pow(smoothstep(0, 1, t), 0.85));
                    rz = lerp(0.205, 0.255, smoothstep(0, 0.78, t));
                    zShift = 0.018 * Math.sin(t * Math.PI * 0.88);
                } else {
                    // Rolled shoulder bevels up to gorget neck ring
                    const t = (y - 0.34) / 0.16;
                    const s = smoothstep(0, 1, t);
                    rx = lerp(0.478, 0.21, Math.pow(s, 0.88));
                    rz = lerp(0.255, 0.19, s);
                    zShift = lerp(0.007, 0.0, s);
                }

                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const ca = Math.cos(a);
                    const sa = Math.sin(a);

                    // Sharpened 1650 peascod tapul shot-deflecting ridge along +Z (peaking at y=0.13)
                    const frontFactor = Math.max(0, sa);
                    const ridgeEnv = (y > -0.07 && y < 0.42)
                        ? Math.sin(((y + 0.07) / 0.49) * Math.PI)
                        : 0;
                    const peascodCurve = (y > -0.05 && y < 0.26)
                        ? 0.018 * gauss(y, 0.08, 0.095) * Math.pow(frontFactor, 2.4)
                        : 0;
                    const shotRidge = ridgeEnv * (0.092 * Math.pow(frontFactor, 7.5) + 0.026 * Math.pow(frontFactor, 2.0)) + peascodCurve;

                    // Gorget / collar opening contour & rolled neck bevel
                    const collarOpen = (sa > 0.35 && y > 0.36)
                        ? -0.014 * gauss(ca, 0, 0.22) * smoothstep(0.36, 0.49, y)
                        : 0;
                    const gorgetRim = (y > 0.38) ? 0.009 * gauss(y, 0.47, 0.018) : 0;

                    // Backplate scapular fullness + subtle dorsal spine crease
                    const backEnv = (sa < 0 && y > 0.04 && y < 0.42)
                        ? Math.pow(-sa, 1.35) * Math.sin(((y - 0.04) / 0.38) * Math.PI)
                        : 0;
                    const backPlate = backEnv * 0.024 * (gauss(ca, 0.42, 0.38) + gauss(ca, -0.42, 0.38));
                    const backCrease = backEnv * 0.012 * gauss(ca, 0, 0.18);

                    // Deeper shoulder socket / armhole gusset blend for orgArm* sleeves
                    const armholeSide = Math.pow(Math.max(0, Math.abs(ca) - 0.60) / 0.40, 1.5);
                    const shoulderSocket = (y > 0.18 && y < 0.40)
                        ? 0.030 * gauss(y, 0.28, 0.068) * armholeSide
                        : 0;

                    // Bilateral tasset plate parting contour in lower skirt
                    const tassetSplit = (y <= -0.10)
                        ? -0.014 * gauss(ca, 0, 0.20) * (1.0 - smoothstep(-0.50, -0.10, y))
                        : 0;

                    const sq = 1 + 0.028 * Math.cos(4 * a);
                    const radBoost = lameRidge + waistFlange + gorgetRim;
                    const px = (rx * sq + radBoost - shoulderSocket) * ca;
                    const pz = zShift + (rz * sq + radBoost + tassetSplit) * sa
                        + shotRidge + collarOpen - backPlate + backCrease;
                    ring.push([px, y, pz]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry();
        },

        /**
         * 3. Unified human head with thick, short neck base (radius ~0.34 at y=-0.5),
         *    fuller jaw/chin (+Z), cheekbones, nose bridge (+Z), brow ridge, and cranium.
         */
        createHeadNatural() {
            const mb = new MeshBuilder();
            const segs = 30;
            const yLevels = [
                -0.50, -0.44, -0.37, -0.31, -0.24, -0.16,
                -0.08, 0.0, 0.07, 0.14, 0.22, 0.31, 0.40, 0.46, 0.50
            ];
            const rings = [];

            for (let r = 0; r < yLevels.length; r++) {
                const y = yLevels[r];
                let rx, rz, zShift = 0;

                if (y <= -0.36) {
                    const t = (y - (-0.50)) / 0.14;
                    const s = smoothstep(0, 1, t);
                    rx = lerp(0.34, 0.27, s);
                    rz = lerp(0.34, 0.28, s);
                    zShift = lerp(-0.02, -0.01, s);
                } else if (y <= 0.18) {
                    const t = (y - (-0.36)) / 0.54;
                    rx = lerp(0.27, 0.39, smoothstep(0, 0.72, t));
                    rz = lerp(0.29, 0.43, smoothstep(0, 0.82, t));
                    zShift = lerp(0.02, 0.0, t);
                } else {
                    const t = (y - 0.18) / 0.32;
                    const dome = Math.sqrt(Math.max(0.04, 1 - t * t));
                    rx = 0.39 * dome;
                    rz = 0.44 * dome;
                    zShift = -0.02 * t;
                }

                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const ca = Math.cos(a);
                    const sa = Math.sin(a);
                    const frontAngle = Math.atan2(ca, sa); // 0 at +Z

                    const chin = gauss(y, -0.25, 0.065) * gauss(frontAngle, 0, 0.44) * 0.105;
                    const jawSide = gauss(y, -0.22, 0.075) * (gauss(frontAngle, 0.85, 0.35) + gauss(frontAngle, -0.85, 0.35)) * 0.032;
                    const cheekLat = gauss(y, -0.03, 0.07) * (gauss(frontAngle, 0.64, 0.36) + gauss(frontAngle, -0.64, 0.36)) * 0.046;
                    const cheekFwd = gauss(y, -0.03, 0.065) * (gauss(frontAngle, 0.48, 0.28) + gauss(frontAngle, -0.48, 0.28)) * 0.030;
                    const eyeHollow = gauss(y, 0.06, 0.038) * (gauss(frontAngle, 0.38, 0.20) + gauss(frontAngle, -0.38, 0.20)) * 0.024;
                    const nose = gauss(y, -0.01, 0.09) * gauss(frontAngle, 0, 0.16) * 0.105;
                    const brow = gauss(y, 0.13, 0.045) * gauss(frontAngle, 0, 0.58) * 0.054;

                    const extraZ = chin + cheekFwd + nose + brow - eyeHollow;
                    const px = (rx + cheekLat + jawSide) * ca;
                    const pz = zShift + rz * sa + extraZ * Math.max(0, sa);
                    ring.push([px, y, pz]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry();
        },

        /**
         * 4. Smooth anatomical limb segment: rounded shoulder/hip cap at y=+0.5,
         *    muscular calf/bicep swell, tapered wrist/ankle at y=-0.5.
         */
        createLimbOrganic() {
            const mb = new MeshBuilder();
            const segs = 18;
            const yLevels = [
                -0.50, -0.42, -0.30, -0.15, 0.0,
                0.15, 0.28, 0.38, 0.45, 0.485, 0.50
            ];
            const rings = [];

            for (let r = 0; r < yLevels.length; r++) {
                const y = yLevels[r];
                let rx, rz, zShift = 0;

                if (y <= 0.32) {
                    const t = (y - (-0.50)) / 0.82;
                    const swell = Math.sin(Math.pow(t, 0.75) * Math.PI * 0.85);
                    rx = lerp(0.23, 0.41, t) + 0.055 * swell;
                    rz = lerp(0.24, 0.43, t) + 0.065 * swell;
                    zShift = 0.025 * swell;
                } else {
                    const t = (y - 0.32) / 0.18;
                    const cap = Math.sqrt(Math.max(0.03, 1 - t * t));
                    rx = 0.42 * cap;
                    rz = 0.43 * cap;
                }

                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    ring.push([rx * Math.cos(a), y, zShift + rz * Math.sin(a)]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry();
        },

        /**
         * 5. Unified cavalry/infantry boot (foot + toe extending +Z, heel, ankle,
         *    calf shaft, and flared turned-down bucket cuff at top).
         */
        createBootCavalier() {
            const mb = new MeshBuilder();
            const segs = 18;

            const shaftY = [
                -0.46, -0.34, -0.22, -0.08, 0.08, 0.20,
                0.28, 0.35, 0.42, 0.48, 0.50
            ];
            const shaftR = [
                0.18, 0.15, 0.16, 0.18, 0.20, 0.21,
                0.23, 0.28, 0.31, 0.29, 0.22
            ];
            const shaftRings = [];
            for (let r = 0; r < shaftY.length; r++) {
                const y = shaftY[r];
                const rad = shaftR[r];
                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const calfZ = (y > -0.05 && y < 0.25) ? -0.025 * Math.sin(((y + 0.05) / 0.30) * Math.PI) : 0;
                    ring.push([rad * 0.92 * Math.cos(a), y, calfZ + rad * 1.05 * Math.sin(a)]);
                }
                shaftRings.push(ring);
            }
            mb.addLoft(shaftRings, true, true);

            const footSpine = [
                { x: 0, y: -0.43, z: -0.20, rx: 0.145, rz: 0.085 },
                { x: 0, y: -0.43, z: -0.05, rx: 0.155, rz: 0.095 },
                { x: 0, y: -0.44, z: 0.12, rx: 0.150, rz: 0.085 },
                { x: 0, y: -0.45, z: 0.28, rx: 0.130, rz: 0.068 },
                { x: 0, y: -0.455, z: 0.39, rx: 0.095, rz: 0.048 },
                { x: 0, y: -0.46, z: 0.44, rx: 0.050, rz: 0.030 }
            ];
            mb.addSpineLoft(footSpine, 14, true, true);
            mb.addEllipsoid(0, -0.475, -0.14, 0.13, 0.045, 0.09, 12, 6);

            return mb.toBufferGeometry();
        },

        /**
         * 6. Unified sculpted hand (palm, angled thumb, curled fingers mass) for weapon/reins holding.
         */
        createHandGrip() {
            const mb = new MeshBuilder();

            mb.addEllipsoid(0, 0.02, -0.05, 0.24, 0.26, 0.15, 16, 10, 0.1, 0, 0);
            mb.addEllipsoid(0, -0.22, -0.08, 0.17, 0.14, 0.13, 12, 8);

            const fingerSpine = [
                { x: 0, y: 0.22, z: 0.02, rx: 0.22, rz: 0.11 },
                { x: 0, y: 0.26, z: 0.16, rx: 0.21, rz: 0.11 },
                { x: 0, y: 0.18, z: 0.28, rx: 0.20, rz: 0.10 },
                { x: 0, y: 0.03, z: 0.30, rx: 0.19, rz: 0.095 },
                { x: 0, y: -0.06, z: 0.21, rx: 0.17, rz: 0.08 }
            ];
            mb.addSpineLoft(fingerSpine, 12, true, true);

            const thumbSpine = [
                { x: -0.19, y: -0.05, z: -0.02, rx: 0.095, rz: 0.095 },
                { x: -0.25, y: 0.06, z: 0.09, rx: 0.085, rz: 0.085 },
                { x: -0.21, y: 0.14, z: 0.21, rx: 0.072, rz: 0.072 },
                { x: -0.13, y: 0.16, z: 0.28, rx: 0.055, rz: 0.055 }
            ];
            mb.addSpineLoft(thumbSpine, 10, true, true);

            return mb.toBufferGeometry();
        },

        /**
         * 7. Authentic Ottoman Janissary Börk (fitted cylindrical felt cap +
         *    rearward/side hanging cloth fold + front brass holder).
         */
        createHelmetBork() {
            const mb = new MeshBuilder();
            const segs = 22;

            const capY = [-0.28, -0.22, -0.05, 0.15, 0.34, 0.46, 0.50];
            const capR = [0.27, 0.26, 0.25, 0.26, 0.27, 0.26, 0.21];
            const capRings = [];
            for (let r = 0; r < capY.length; r++) {
                const y = capY[r];
                const rad = capR[r];
                const zTilt = (y + 0.28) * 0.08;
                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    ring.push([rad * 0.94 * Math.cos(a), y, zTilt + rad * Math.sin(a)]);
                }
                capRings.push(ring);
            }
            mb.addLoft(capRings, true, true);

            const flapSpine = [
                { x: 0, y: 0.44, z: -0.12, rx: 0.22, rz: 0.07 },
                { x: 0, y: 0.26, z: -0.24, rx: 0.23, rz: 0.065 },
                { x: 0, y: 0.02, z: -0.32, rx: 0.24, rz: 0.060 },
                { x: 0, y: -0.22, z: -0.38, rx: 0.23, rz: 0.055 },
                { x: 0, y: -0.44, z: -0.41, rx: 0.20, rz: 0.045 }
            ];
            mb.addSpineLoft(flapSpine, 14, true, true);

            mb.addEllipsoid(0, 0.02, 0.29, 0.06, 0.17, 0.045, 12, 8, -0.12, 0, 0);
            mb.addEllipsoid(0, 0.18, 0.30, 0.045, 0.05, 0.04, 10, 6);

            return mb.toBufferGeometry();
        },

        /**
         * 8. Multi-layered wrapped Ottoman turban/sarık around a central taj/külah dome.
         */
        createHelmetTurban() {
            const mb = new MeshBuilder();
            const segs = 22;

            const domeY = [-0.20, 0.0, 0.18, 0.34, 0.45, 0.50];
            const domeR = [0.27, 0.29, 0.26, 0.19, 0.10, 0.03];
            const domeRings = [];
            for (let r = 0; r < domeY.length; r++) {
                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const rib = 1 + 0.035 * Math.cos(a * 10);
                    ring.push([domeR[r] * rib * Math.cos(a), domeY[r], domeR[r] * rib * Math.sin(a)]);
                }
                domeRings.push(ring);
            }
            mb.addLoft(domeRings, true, true);

            mb.addTorus(0, -0.09, 0.01, 0.31, 0.115, 28, 10, 0.12, 0, 0.08, 0.08, 4);
            mb.addTorus(0, 0.02, -0.01, 0.33, 0.120, 28, 10, -0.10, 0.3, -0.12, 0.07, 5);
            mb.addTorus(0, 0.12, 0.01, 0.29, 0.105, 26, 10, 0.16, -0.2, 0.14, 0.06, 4);

            return mb.toBufferGeometry();
        },

        /**
         * 9. Pointed Ottoman Şişak/Tolga helmet with fluted dome, brow peak,
         *    nasal bar, and rear neck guard.
         */
        createHelmetPointed() {
            const mb = new MeshBuilder();
            const segs = 24;

            const domeY = [-0.14, -0.04, 0.08, 0.20, 0.32, 0.42, 0.48, 0.54];
            const domeR = [0.33, 0.32, 0.29, 0.23, 0.14, 0.05, 0.025, 0.012];
            const domeRings = [];
            for (let r = 0; r < domeY.length; r++) {
                const ring = [];
                const fluteAmp = (r > 0 && r < 5) ? 0.04 : 0.0;
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const flute = 1 + fluteAmp * Math.cos(a * 12);
                    ring.push([domeR[r] * 0.94 * flute * Math.cos(a), domeY[r], domeR[r] * 1.02 * flute * Math.sin(a)]);
                }
                domeRings.push(ring);
            }
            mb.addLoft(domeRings, true, true);

            const peakSpine = [
                { x: -0.22, y: -0.15, z: 0.22, rx: 0.08, rz: 0.022 },
                { x: 0.0, y: -0.16, z: 0.38, rx: 0.10, rz: 0.022 },
                { x: 0.22, y: -0.15, z: 0.22, rx: 0.08, rz: 0.022 }
            ];
            mb.addSpineLoft(peakSpine, 10, true, true);

            const nasalSpine = [
                { x: 0, y: -0.06, z: 0.36, rx: 0.032, rz: 0.020 },
                { x: 0, y: -0.22, z: 0.39, rx: 0.024, rz: 0.018 },
                { x: 0, y: -0.38, z: 0.39, rx: 0.032, rz: 0.020 }
            ];
            mb.addSpineLoft(nasalSpine, 8, true, true);

            const neckGuardSpine = [
                { x: 0, y: -0.12, z: -0.27, rx: 0.28, rz: 0.035 },
                { x: 0, y: -0.25, z: -0.34, rx: 0.31, rz: 0.032 },
                { x: 0, y: -0.38, z: -0.40, rx: 0.33, rz: 0.028 }
            ];
            mb.addSpineLoft(neckGuardSpine, 12, true, true);

            return mb.toBufferGeometry();
        },

        /**
         * 10. European Morion helmet with high central comb/crest and curved boat-shaped brim.
         */
        createHelmetMorion() {
            const mb = new MeshBuilder();
            const segs = 28;

            const domeY = [-0.14, -0.06, 0.04, 0.14, 0.23, 0.29, 0.32];
            const domeR = [0.31, 0.305, 0.28, 0.23, 0.16, 0.08, 0.025];
            const domeRings = [];
            for (let r = 0; r < domeY.length; r++) {
                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    ring.push([domeR[r] * 0.88 * Math.cos(a), domeY[r], domeR[r] * 1.08 * Math.sin(a)]);
                }
                domeRings.push(ring);
            }
            mb.addLoft(domeRings, true, true);

            const combSpine = [
                { x: 0, y: -0.04, z: -0.30, rx: 0.024, rz: 0.095 },
                { x: 0, y: 0.14, z: -0.23, rx: 0.024, rz: 0.125 },
                { x: 0, y: 0.28, z: -0.12, rx: 0.022, rz: 0.140 },
                { x: 0, y: 0.34, z: 0.00, rx: 0.022, rz: 0.145 },
                { x: 0, y: 0.28, z: 0.12, rx: 0.022, rz: 0.140 },
                { x: 0, y: 0.14, z: 0.23, rx: 0.024, rz: 0.125 },
                { x: 0, y: -0.04, z: 0.30, rx: 0.024, rz: 0.095 }
            ];
            mb.addSpineLoft(combSpine, 12, true, true);

            const brimBase = mb._vCount();
            const brimSegs = 36;
            const profSegs = 10;
            for (let u = 0; u < brimSegs; u++) {
                const theta = (u / brimSegs) * TWO_PI;
                const ct = Math.cos(theta);
                const st = Math.sin(theta);
                const brimCurve = 0.09 * (ct * ct) - 0.10 * (st * st);
                const rOut = 0.45 + 0.07 * st * st;
                const rIn = 0.26;
                const rMid = (rOut + rIn) * 0.5;
                const halfW = (rOut - rIn) * 0.5;

                for (let v = 0; v < profSegs; v++) {
                    const phi = (v / profSegs) * TWO_PI;
                    const r = rMid + halfW * Math.cos(phi);
                    const radialFactor = Math.max(0, (r - rIn) / (rOut - rIn));
                    const y = -0.14 + brimCurve * radialFactor + 0.020 * Math.sin(phi);
                    mb.pos.push(r * 0.90 * ct, y, r * 1.08 * st);
                }
            }
            for (let u = 0; u < brimSegs; u++) {
                const nu = (u + 1) % brimSegs;
                for (let v = 0; v < profSegs; v++) {
                    const nv = (v + 1) % profSegs;
                    const a = brimBase + u * profSegs + v;
                    const b = brimBase + nu * profSegs + v;
                    const c = brimBase + u * profSegs + nv;
                    const d = brimBase + nu * profSegs + nv;
                    mb.idx.push(a, c, d, a, d, b);
                }
            }

            return mb.toBufferGeometry();
        },

        /**
         * 11. Broad-brimmed Cavalier slouch hat (snug lower/wider crown + band + upturned left brim).
         */
        createHelmetCavalier() {
            const mb = new MeshBuilder();
            const segs = 28;

            const crownY = [-0.14, -0.06, 0.04, 0.14, 0.23, 0.28];
            const crownR = [0.295, 0.290, 0.275, 0.250, 0.215, 0.135];
            const crownRings = [];
            for (let r = 0; r < crownY.length; r++) {
                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    ring.push([crownR[r] * Math.cos(a), crownY[r], crownR[r] * 1.07 * Math.sin(a)]);
                }
                crownRings.push(ring);
            }
            mb.addLoft(crownRings, true, true);
            mb.addTorus(0, -0.06, 0, 0.295, 0.024, 28, 10);

            const brimBase = mb._vCount();
            const brimSegs = 36;
            const profSegs = 10;
            for (let u = 0; u < brimSegs; u++) {
                const theta = (u / brimSegs) * TWO_PI;
                const ct = Math.cos(theta);
                const st = Math.sin(theta);
                const leftUpturn = ct < 0 ? 0.24 * Math.pow(-ct, 1.5) : -0.035 * Math.pow(ct, 1.2);
                const rIn = 0.265;
                const rOut = 0.54;
                const rMid = (rIn + rOut) * 0.5;
                const halfW = (rOut - rIn) * 0.5;

                for (let v = 0; v < profSegs; v++) {
                    const phi = (v / profSegs) * TWO_PI;
                    const r = rMid + halfW * Math.cos(phi);
                    const radialFactor = Math.max(0, (r - rIn) / (rOut - rIn));
                    const y = -0.10 + leftUpturn * radialFactor + 0.017 * Math.sin(phi);
                    mb.pos.push(r * ct, y, r * 1.05 * st);
                }
            }
            for (let u = 0; u < brimSegs; u++) {
                const nu = (u + 1) % brimSegs;
                for (let v = 0; v < profSegs; v++) {
                    const nv = (v + 1) % profSegs;
                    const a = brimBase + u * profSegs + v;
                    const b = brimBase + nu * profSegs + v;
                    const c = brimBase + u * profSegs + nv;
                    const d = brimBase + nu * profSegs + nv;
                    mb.idx.push(a, c, d, a, d, b);
                }
            }

            return mb.toBufferGeometry();
        },

        /**
         * 12. Anatomically sculpted warhorse barrel:
         *     raised muscular hindquarters/croup (-Z,+Y), sleek saddle dip along spine,
         *     athletic tucked-up belly curve toward flank, prominent withers (+Y,+Z crest),
         *     and wider deep muscular chest (+Z, rx=0.275+) so upper legs tuck seamlessly.
         */
        createHorseBody() {
            const mb = new MeshBuilder();
            const segs = 36;
            const zLevels = [
                -0.50, -0.47, -0.43, -0.38, -0.32, -0.26, -0.19, -0.12,
                -0.05, 0.02, 0.09, 0.16, 0.23, 0.29, 0.35, 0.40,
                0.44, 0.475, 0.492, 0.50
            ];
            const rings = [];

            for (let r = 0; r < zLevels.length; r++) {
                const z = zLevels[r];
                const t = z + 0.50; // 0 = rump (-Z), 1 = chest (+Z)

                let rx, yTop, yBot;
                if (t < 0.14) {
                    // Rounded muscular rump cap (-Z)
                    const u = t / 0.14;
                    const c = Math.sqrt(Math.max(0.05, 1 - (1 - u) * (1 - u)));
                    rx = 0.245 * c;
                    const cy = lerp(0.06, 0.075, u);
                    yTop = cy + 0.205 * c;
                    yBot = cy - 0.195 * c;
                } else if (t > 0.89) {
                    // Broad muscular chest & pectoral rounding (+Z, rx=0.275+ shoulder tuck)
                    const u = (t - 0.89) / 0.11;
                    const c = Math.sqrt(Math.max(0.05, 1 - u * u));
                    rx = 0.285 * c;
                    const cy = lerp(-0.025, -0.055, u);
                    yTop = cy + 0.245 * c;
                    yBot = cy - 0.255 * c;
                } else {
                    // Main equine torso from hindquarters -> tucked flank/saddle dip -> withers & wide chest
                    const croup = gauss(t, 0.22, 0.13);
                    const saddleDip = gauss(t, 0.48, 0.13);
                    const withers = gauss(t, 0.76, 0.088);
                    const ribBelly = gauss(t, 0.62, 0.20);
                    const flankTuck = gauss(t, 0.25, 0.11);
                    const chestKeel = gauss(t, 0.80, 0.095);

                    // Top dorsal silhouette: raised croup -> sleek saddle dip -> prominent withers crest
                    yTop = 0.21 + 0.075 * croup - 0.042 * saddleDip + 0.120 * withers;
                    // Bottom ventral silhouette: tucked-up flank -> deep ribcage -> deep muscular chest keel
                    yBot = -0.17 + 0.058 * flankTuck - 0.095 * ribBelly - 0.082 * chestKeel;
                    // Width profile: broad hindquarters, sleek waist at flank, wider chest/shoulder (rx >= 0.275)
                    rx = 0.235 + 0.032 * croup - 0.014 * gauss(t, 0.36, 0.10) + 0.054 * smoothstep(0.45, 0.82, t);
                }

                const yCenter = (yTop + yBot) * 0.5;
                const ry = Math.max(0.035, (yTop - yBot) * 0.5);

                // Loft along +Z: x = rx*cos(a), y = -ry*sin(a) keeps outward CCW winding
                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const ca = Math.cos(a);
                    const sa = -Math.sin(a);

                    // Sharpen withers ridge slightly on top-front, broaden croup double-muscle at rear
                    const withersPinch = (sa > 0.2 && t > 0.60 && t < 0.86)
                        ? 1.0 - 0.20 * sa * gauss(t, 0.75, 0.09)
                        : 1.0;
                    // Muscular scapular / shoulder blade bulge on lateral sides
                    const shoulderBulge = (t > 0.66 && t < 0.90)
                        ? 0.028 * Math.pow(Math.abs(ca), 1.6) * gauss(t, 0.78, 0.082) * (1.0 + 0.35 * Math.max(0, sa))
                        : 0.0;
                    const croupCleft = (sa > 0.35 && t > 0.10 && t < 0.36)
                        ? -0.022 * gauss(ca, 0, 0.20) * gauss(t, 0.22, 0.08)
                        : 0.0;
                    // Deep chest keel contour at bottom-front (+Z, -Y)
                    const keelDrop = (sa < -0.30 && t > 0.66 && t < 0.92)
                        ? -0.034 * Math.pow(-sa, 2.2) * gauss(t, 0.80, 0.085)
                        : 0.0;

                    ring.push([
                        (rx * withersPinch + shoulderBulge) * ca,
                        yCenter + ry * sa + croupCleft + keelDrop,
                        z
                    ]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry();
        },

        /**
         * 13. Boldly arched muscular stallion neck (rx=0.21 base) + sculpted flowing mane crest +
         *     Baroque Friesian/Andalusian head angling DOWNWARD ~45 degrees from poll with
         *     slightly convex Roman nose bridge, sculpted brow/orbit ridge, rounded cheek jowl,
         *     wider muzzle/nostrils, and alert ears.
         */
        createHorseNeckHead() {
            const mb = new MeshBuilder();

            // 1. Thicker muscular stallion neck crest rising boldly from chest/withers to poll
            const neckPts = [
                { x: 0, y: -0.46, z: -0.30, rx: 0.215, rz: 0.275 },
                { x: 0, y: -0.30, z: -0.25, rx: 0.206, rz: 0.258 },
                { x: 0, y: -0.13, z: -0.19, rx: 0.186, rz: 0.234 },
                { x: 0, y: 0.05,  z: -0.12, rx: 0.162, rz: 0.206 },
                { x: 0, y: 0.21,  z: -0.05, rx: 0.140, rz: 0.178 },
                { x: 0, y: 0.33,  z: 0.00,  rx: 0.124, rz: 0.152 },
                { x: 0, y: 0.39,  z: 0.04,  rx: 0.110, rz: 0.136 }
            ];
            mb.addSpineLoft(neckPts, 24, true, true);

            // 2. Sculpted arched stallion mane crest along top-rear edge of neck
            const maneSpine = [
                { x: 0, y: -0.34, z: -0.41, rx: 0.036, rz: 0.078 },
                { x: 0, y: -0.17, z: -0.34, rx: 0.042, rz: 0.088 },
                { x: 0, y: 0.01,  z: -0.25, rx: 0.044, rz: 0.092 },
                { x: 0, y: 0.18,  z: -0.16, rx: 0.040, rz: 0.082 },
                { x: 0, y: 0.32,  z: -0.08, rx: 0.032, rz: 0.068 },
                { x: 0, y: 0.41,  z: -0.02, rx: 0.024, rz: 0.050 }
            ];
            mb.addSpineLoft(maneSpine, 16, true, true);

            // 3. Baroque Friesian/Andalusian head angling DOWNWARD ~45 deg from poll (0, 0.37, 0.00) to muzzle (0, -0.01, 0.38)
            const headSegs = 28;
            const p0y = 0.37, p0z = 0.00;
            const p1y = -0.01, p1z = 0.38;
            // Unit axis T = (0, -1/sqrt(2), +1/sqrt(2)), U = (1,0,0), F = U x T = (0, -1/sqrt(2), -1/sqrt(2))
            // -F points toward forehead/nasal bridge (+Y,+Z); +F points toward jowl/jaw (-Y,-Z); T x F = U (outward CCW)
            const invSqrt2 = Math.SQRT1_2;
            const fy = -invSqrt2, fz = -invSqrt2;

            const tSteps = [0.0, 0.08, 0.18, 0.28, 0.40, 0.54, 0.68, 0.80, 0.89, 0.95, 1.0];
            const headRings = [];
            for (let k = 0; k < tSteps.length; k++) {
                const t = tSteps[k];
                const ay = lerp(p0y, p1y, t);
                const az = lerp(p0z, p1z, t);

                // Width (lateral X): broad forehead/cheek jowls, tapered bridge, wider Baroque muzzle
                let halfW = lerp(0.122, 0.080, smoothstep(0.18, 0.78, t)) + 0.034 * gauss(t, 0.26, 0.12);
                halfW += 0.024 * gauss(t, 0.89, 0.065); // wider expressive muzzle flare
                if (t < 0.08) halfW *= lerp(0.68, 1.0, t / 0.08);
                if (t > 0.94) halfW *= lerp(1.0, 0.48, (t - 0.94) / 0.06);

                // Dorsal bridge radius (-F side): convex Roman nose arch along nasal bridge
                const romanBridge = (t > 0.18 && t < 0.88)
                    ? 0.022 * Math.sin(((t - 0.18) / 0.70) * Math.PI)
                    : 0;
                let dorsalR = lerp(0.108, 0.068, smoothstep(0.12, 0.84, t))
                    + 0.018 * gauss(t, 0.20, 0.11)
                    + romanBridge;
                if (t < 0.08) dorsalR *= lerp(0.65, 1.0, t / 0.08);
                if (t > 0.94) dorsalR *= lerp(1.0, 0.48, (t - 0.94) / 0.06);

                // Ventral jaw radius (+F side): deep rounded Baroque cheek jowl tapering to chin
                let jawR = lerp(0.124, 0.064, smoothstep(0.28, 0.86, t)) + 0.096 * gauss(t, 0.29, 0.115);
                if (t < 0.08) jawR *= lerp(0.65, 1.0, t / 0.08);
                if (t > 0.94) jawR *= lerp(1.0, 0.48, (t - 0.94) / 0.06);

                const ring = [];
                for (let i = 0; i < headSegs; i++) {
                    const a = (i / headSegs) * TWO_PI;
                    const ca = Math.cos(a);
                    const sa = Math.sin(a);

                    // Sculpted eye brow / orbit ridge & recessed eye socket just below
                    const browOrbit = 0.024 * gauss(t, 0.24, 0.052)
                        * gauss(Math.abs(ca), 0.82, 0.20)
                        * gauss(sa, -0.28, 0.32);
                    const eyeSocket = -0.016 * gauss(t, 0.26, 0.042)
                        * gauss(Math.abs(ca), 0.86, 0.16)
                        * gauss(sa, -0.05, 0.22);

                    // Mandibular disc cheek jowl definition (ganache)
                    const jowlDisc = 0.024 * gauss(t, 0.29, 0.09)
                        * gauss(Math.abs(ca), 0.78, 0.24)
                        * Math.max(0, sa);

                    // Subtle central Roman nose crest along dorsal centerline
                    const romanCrest = (sa < -0.3)
                        ? romanBridge * 0.45 * gauss(ca, 0, 0.45) * (-sa)
                        : 0;

                    // Flared nostrils on wider upper-lateral muzzle
                    const nostrilWing = (sa < -0.1)
                        ? 0.020 * gauss(t, 0.89, 0.045) * gauss(Math.abs(ca), 0.74, 0.22)
                        : 0;
                    const nostrilHole = (sa < -0.2)
                        ? -0.012 * gauss(t, 0.92, 0.035) * gauss(Math.abs(ca), 0.68, 0.18)
                        : 0;

                    // Rounded chin bulb under lower lip
                    const chinBulb = (sa > 0.3 && t > 0.88)
                        ? 0.014 * gauss(t, 0.94, 0.045) * gauss(ca, 0, 0.40)
                        : 0;

                    // sa > 0 is +F (jaw/jowl side), sa < 0 is -F (forehead/nasal bridge side)
                    const fCoord = sa >= 0
                        ? (jawR + jowlDisc + chinBulb) * sa
                        : (dorsalR + romanCrest + nostrilHole) * sa - browOrbit * 0.4;
                    const px = (halfW + nostrilWing + browOrbit + eyeSocket) * ca;
                    const py = ay + fy * fCoord;
                    const pz = az + fz * fCoord;
                    ring.push([px, py, pz]);
                }
                headRings.push(ring);
            }
            mb.addLoft(headRings, true, true);

            // 4. Two alert forward-canted ears at poll
            for (const side of [-1, 1]) {
                const earSpine = [
                    { x: side * 0.080, y: 0.38, z: -0.01, rx: 0.032, rz: 0.036 },
                    { x: side * 0.092, y: 0.44, z: 0.01,  rx: 0.026, rz: 0.030 },
                    { x: side * 0.100, y: 0.49, z: 0.035, rx: 0.017, rz: 0.020 },
                    { x: side * 0.102, y: 0.54, z: 0.06,  rx: 0.006, rz: 0.008 }
                ];
                mb.addSpineLoft(earSpine, 12, true, true);
            }

            return mb.toBufferGeometry();
        },

        /**
         * 14. Single continuous bent left musket sleeve (character-space, normalize=false).
         */
        createArmMusketL() {
            return buildBentArmSleeve(
                [-0.23, 1.32, 0.0],
                [-0.25, 1.15, 0.16],
                [-0.10, 1.25, 0.62],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 15. Single continuous bent right musket sleeve (character-space, normalize=false).
         */
        createArmMusketR() {
            return buildBentArmSleeve(
                [0.23, 1.32, 0.0],
                [0.25, 1.14, 0.08],
                [0.17, 1.23, 0.28],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 16. Single continuous bent left pike sleeve (character-space, normalize=false).
         */
        createArmPikeL() {
            return buildBentArmSleeve(
                [-0.23, 1.32, 0.0],
                [-0.29, 1.14, -0.02],
                [-0.31, 1.10, 0.16],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 17. Single continuous bent right pike sleeve curving across chest (character-space, normalize=false).
         */
        createArmPikeR() {
            return buildBentArmSleeve(
                [0.23, 1.32, 0.0],
                [0.10, 1.18, 0.22],
                [-0.27, 1.30, 0.50],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 18. Single continuous bent right sword sleeve (character-space, normalize=false).
         */
        createArmSwordR() {
            return buildBentArmSleeve(
                [0.23, 1.32, 0.0],
                [0.28, 1.13, 0.10],
                [0.23, 1.20, 0.32],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 19. Single continuous bent left shield/pistol sleeve (character-space, normalize=false).
         */
        createArmShieldL() {
            return buildBentArmSleeve(
                [-0.23, 1.32, 0.0],
                [-0.30, 1.14, 0.10],
                [-0.27, 1.23, 0.30],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 20. Single continuous bent left mounted-rider reins sleeve (character-space, normalize=false).
         */
        createArmRiderReinsL() {
            return buildBentArmSleeve(
                [-0.23, 1.85, -0.02],
                [-0.25, 1.69, 0.11],
                [-0.14, 1.65, 0.31],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 21. Single continuous bent right mounted-rider weapon sleeve (character-space, normalize=false).
         */
        createArmRiderWeaponR() {
            return buildBentArmSleeve(
                [0.23, 1.85, -0.02],
                [0.27, 1.70, 0.10],
                [0.22, 1.67, 0.32],
                { rShoulder: 0.078, rElbow: 0.056, rWrist: 0.046 }
            );
        },

        /**
         * 22. Curved, contoured 1650 war saddle (unit-centered, normalize=true) with
         *     raised front pommel, deep seat dip, raised rear cantle, and sleek
         *     downward side flaps hugging the horse barrel.
         */
        createHorseSaddle() {
            const mb = new MeshBuilder();
            const zSteps = [
                -0.46, -0.43, -0.37, -0.29, -0.20, -0.10,
                0.0, 0.10, 0.20, 0.29, 0.37, 0.43, 0.46
            ];
            const uSteps = 14; // samples across arch from -1 (left flap) to +1 (right flap)
            const rings = [];

            for (let r = 0; r < zSteps.length; r++) {
                const z = zSteps[r];
                const endFade = Math.sqrt(Math.max(0.06, 1.0 - Math.pow(z / 0.465, 4)));
                // Flap extent narrows cleanly toward front pommel & rear cantle
                const flapReach = lerp(0.55, 1.0, gauss(z, 0.02, 0.26));
                const barrelRx = lerp(0.28, 0.31, smoothstep(-0.46, 0.46, z));
                const barrelRy = 0.27;

                // Longitudinal pommel/seat/cantle height profile along center spine
                const cantleRise = 0.23 * gauss(z, -0.36, 0.095);
                const pommelRise = 0.19 * gauss(z, 0.35, 0.095);
                const seatDip = -0.065 * gauss(z, -0.02, 0.17);

                const outerPts = [];
                const innerPts = [];

                for (let k = 0; k <= uSteps; k++) {
                    const uRaw = -1.0 + (2.0 * k) / uSteps;
                    const u = uRaw * flapReach;
                    const theta = u * Math.PI * 0.56; // arch hugging barrel sides
                    const st = Math.sin(theta);
                    const ct = Math.cos(theta);

                    // Barrel-hugging centerline arch
                    const mx = barrelRx * st;
                    // Side flaps sweep cleanly downward along barrel curve
                    const flapDrop = -0.09 * Math.pow(Math.abs(u), 1.8) * gauss(z, 0.02, 0.24);
                    const archRise = (cantleRise + pommelRise) * Math.pow(Math.max(0, ct), 1.35)
                        + seatDip * Math.pow(Math.max(0, ct), 1.8);
                    const my = barrelRy * (ct - 0.52) + archRise + flapDrop;

                    // Outward normal of the barrel arch in XY plane
                    let nx = st;
                    let ny = ct;
                    const nLen = Math.hypot(nx, ny) || 1;
                    nx /= nLen; ny /= nLen;

                    // Tapered thickness: thicker padded cantle/pommel rolls, sleek leather flaps
                    const edgeTaper = Math.sqrt(Math.max(0.08, 1.0 - uRaw * uRaw * 0.88));
                    const rollBoost = 0.018 * (gauss(z, -0.36, 0.08) + gauss(z, 0.35, 0.08)) * Math.max(0, ct);
                    const halfT = (0.022 + rollBoost) * edgeTaper * endFade;

                    outerPts.push([mx + nx * halfT, my + ny * halfT, z]);
                    innerPts.push([mx - nx * halfT, my - ny * halfT, z]);
                }

                // Ring winds: outer (-1 -> +1), then inner (+1 -> -1) so T x F = U outward
                const ring = [];
                for (let k = 0; k < outerPts.length; k++) ring.push(outerPts[k]);
                for (let k = innerPts.length - 1; k >= 0; k--) ring.push(innerPts[k]);
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry(true);
        },

        /**
         * 23. Anatomically tapered upper equine leg (muscular forearm/gaskin at +Y
         *     tapering smoothly down to knee/hock joint at -Y, unit-centered).
         */
        createHorseLegUpper() {
            const mb = new MeshBuilder();
            const segs = 20;
            const yLevels = [
                -0.50, -0.46, -0.40, -0.28, -0.12,
                0.06, 0.22, 0.35, 0.44, 0.485, 0.50
            ];
            const rings = [];

            for (let r = 0; r < yLevels.length; r++) {
                const y = yLevels[r];
                const t = y + 0.50; // 0 = knee/hock (-Y), 1 = muscular top (+Y)
                let rx, rz, zShift = 0;

                if (t < 0.10) {
                    // Rounded knee / hock joint cap at bottom
                    const u = t / 0.10;
                    const c = Math.sqrt(Math.max(0.08, 1 - (1 - u) * (1 - u)));
                    rx = 0.175 * c;
                    rz = 0.215 * c;
                    zShift = 0.010;
                } else if (t <= 0.80) {
                    // Muscular forearm/gaskin taper
                    const u = (t - 0.10) / 0.70;
                    const muscle = Math.sin(Math.pow(u, 0.78) * Math.PI * 0.85);
                    rx = lerp(0.175, 0.340, smoothstep(0, 1, u)) + 0.032 * muscle;
                    rz = lerp(0.215, 0.420, smoothstep(0, 1, u)) + 0.042 * muscle;
                    zShift = lerp(0.010, -0.025, u) + 0.018 * muscle;
                } else {
                    // Rounded shoulder / thigh insertion cap at top
                    const u = (t - 0.80) / 0.20;
                    const c = Math.sqrt(Math.max(0.04, 1 - u * u));
                    rx = 0.345 * c;
                    rz = 0.425 * c;
                    zShift = -0.025 * (1 - u);
                }

                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const ca = Math.cos(a);
                    const sa = Math.sin(a);
                    // Calcaneus hock tuber backward spur and anterior knee cap rounding
                    const hockSpur = (t > 0.05 && t < 0.22 && sa < -0.30)
                        ? -0.032 * Math.pow(-sa, 2.2) * gauss(t, 0.12, 0.045)
                        : 0;
                    const kneeCap = (t > 0.05 && t < 0.22 && sa > 0.35)
                        ? 0.016 * Math.pow(sa, 2.0) * gauss(t, 0.11, 0.045)
                        : 0;
                    ring.push([rx * ca, y, zShift + (rz + kneeCap) * sa + hockSpur]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry(true);
        },

        /**
         * 24. Anatomically tapered lower equine leg (knee/hock at +Y, slender cannon bone
         *     with flexor tendon, fetlock joint angle sloping pastern +Z, and flared
         *     trapezoidal hoof at bottom -Y, unit-centered).
         */
        createHorseLegLower() {
            const mb = new MeshBuilder();
            const segs = 20;
            // Profile stations from hoof sole (-0.50) up to knee/hock (+0.50)
            const stations = [
                { y: -0.50, z: 0.135, rx: 0.215, rz: 0.235, hoof: 1.0 },
                { y: -0.44, z: 0.120, rx: 0.185, rz: 0.205, hoof: 0.85 },
                { y: -0.37, z: 0.095, rx: 0.142, rz: 0.160, hoof: 0.25 },
                { y: -0.30, z: 0.048, rx: 0.118, rz: 0.132, hoof: 0.0 },
                { y: -0.22, z: -0.008, rx: 0.145, rz: 0.168, hoof: 0.0 }, // fetlock joint
                { y: -0.14, z: -0.002, rx: 0.118, rz: 0.144, hoof: 0.0 },
                { y: 0.04,  z: 0.000, rx: 0.112, rz: 0.140, hoof: 0.0 }, // slender cannon bone
                { y: 0.24,  z: 0.002, rx: 0.118, rz: 0.146, hoof: 0.0 },
                { y: 0.37,  z: 0.006, rx: 0.146, rz: 0.175, hoof: 0.0 }, // knee/hock swell
                { y: 0.45,  z: 0.006, rx: 0.160, rz: 0.188, hoof: 0.0 },
                { y: 0.49,  z: 0.004, rx: 0.120, rz: 0.140, hoof: 0.0 },
                { y: 0.50,  z: 0.004, rx: 0.055, rz: 0.065, hoof: 0.0 }
            ];

            const rings = [];
            for (let r = 0; r < stations.length; r++) {
                const st = stations[r];
                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const ca = Math.cos(a);
                    const sa = Math.sin(a);
                    // Trapezoidal hoof flare: broader rounded front toe (+Z), slightly narrower heel (-Z)
                    const trap = st.hoof > 0 ? (1.0 + st.hoof * (0.14 * sa - 0.06 * sa * sa)) : 1.0;
                    // Coronet band ridge at top of hoof wall (y=-0.44)
                    const coronetRidge = gauss(st.y, -0.44, 0.016) * 0.016;
                    // Posterior fetlock joint tuft / ergot
                    const fetlockTuft = (st.y > -0.26 && st.y < -0.16 && sa < -0.35)
                        ? -0.024 * Math.pow(-sa, 2.2) * gauss(st.y, -0.21, 0.032)
                        : 0;
                    // Subtle flexor tendon ridge along back (-Z) of cannon bone
                    const tendon = (st.y > -0.16 && st.y < 0.34 && sa < -0.4)
                        ? -0.018 * Math.pow(-sa, 2.0) * gauss(ca, 0, 0.4)
                        : 0;
                    ring.push([
                        (st.rx * trap + coronetRidge) * ca,
                        st.y,
                        st.z + (st.rz * trap + coronetRidge) * sa + tendon + fetlockTuft
                    ]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry(true);
        },

        /**
         * 25. Contoured 17th-century European falling white linen collar wrapping around
         *     the neck (0, 1.41, 0.0) and draping smoothly over upper shoulders/chest
         *     with TWO distinct pointed front collar tabs (x=±0.06, y=1.32, z=0.14).
         */
        createFallingCollar() {
            const mb = new MeshBuilder();
            const numPhi = 44;
            const phiStart = 0.08;
            const phiEnd = TWO_PI - 0.08;
            const nSurf = 6;
            const rings = [];

            for (let u = 0; u < numPhi; u++) {
                const phi = lerp(phiStart, phiEnd, u / (numPhi - 1));
                const sp = Math.sin(phi);
                const cp = Math.cos(phi);
                const ang = Math.min(phi, TWO_PI - phi);

                const zCenter = 0.008;
                const rIn = 0.082;
                const yIn = 1.422 - 0.014 * cp;

                let rOut, yOut;
                if (ang <= 0.41) {
                    const k = (ang - phiStart) / (0.41 - phiStart);
                    const p = Math.pow(Math.max(0, k), 0.85);
                    rOut = lerp(0.098, 0.152, p);
                    yOut = lerp(1.385, 1.318, p);
                } else if (ang <= 0.72) {
                    const k = (ang - 0.41) / (0.72 - 0.41);
                    const s = smoothstep(0, 1, k);
                    rOut = lerp(0.152, 0.165, s);
                    yOut = lerp(1.318, 1.362, Math.pow(s, 0.75));
                } else {
                    const k = (ang - 0.72) / (Math.PI - 0.72);
                    const shoulderWave = Math.sin(k * Math.PI * 0.9);
                    rOut = lerp(0.165, 0.142, smoothstep(0, 1, k)) + 0.026 * shoulderWave;
                    yOut = lerp(1.362, 1.355, k) - 0.006 * shoulderWave;
                }

                // Ring winds +U (outer rim) -> +F (top surface to neck) -> -U (inner neck) -> -F (bottom surface to outer rim)
                const ring = [];
                // Top surface from outer hem (s=1) inward to neckband (s=0)
                for (let k = nSurf; k >= 0; k--) {
                    const s = k / nSurf;
                    const r = lerp(rIn, rOut, s);
                    const arch = 0.012 * Math.sin(s * Math.PI);
                    const ripple = 0.0025 * Math.cos(ang * 12) * s;
                    const yMid = lerp(yIn, yOut, Math.pow(s, 1.15)) + arch + ripple;
                    const halfT = lerp(0.006, 0.0035, s);
                    ring.push([r * sp, yMid + halfT, zCenter + r * cp]);
                }
                // Inner neckband midpoint bevel
                ring.push([(rIn - 0.002) * sp, yIn, zCenter + (rIn - 0.002) * cp]);
                // Bottom surface from neckband (s=0) outward to hem (s=1)
                for (let k = 0; k <= nSurf; k++) {
                    const s = k / nSurf;
                    const r = lerp(rIn, rOut, s);
                    const arch = 0.012 * Math.sin(s * Math.PI);
                    const ripple = 0.0025 * Math.cos(ang * 12) * s;
                    const yMid = lerp(yIn, yOut, Math.pow(s, 1.15)) + arch + ripple;
                    const halfT = lerp(0.006, 0.0035, s);
                    ring.push([r * sp, yMid - halfT, zCenter + r * cp]);
                }
                // Outer linen hem midpoint bevel
                ring.push([(rOut + 0.002) * sp, yOut, zCenter + (rOut + 0.002) * cp]);

                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry(false);
        },

        /**
         * 26. Sculpted wavy shoulder-length hair curtain framing the sides and back
         *     of the head (y=1.42..1.60, tucked around ears and neck nape).
         */
        createHairCurtain() {
            const mb = new MeshBuilder();
            const numPhi = 36;
            const phiStart = 0.98;
            const phiEnd = TWO_PI - 0.98;
            const nVert = 7;
            const rings = [];

            for (let u = 0; u < numPhi; u++) {
                const phi = lerp(phiStart, phiEnd, u / (numPhi - 1));
                const sp = Math.sin(phi);
                const cp = Math.cos(phi);
                const ang = Math.min(phi, TWO_PI - phi);

                const zCenter = 0.015;
                const sideFade = smoothstep(0.94, 1.38, ang);
                const yBot = 1.418 + 0.020 * gauss(ang, phiStart, 0.26) + 0.005 * Math.cos(ang * 9);
                const yTop = 1.602 - 0.016 * gauss(ang, phiStart, 0.24);

                const ring = [];
                // Outer wavy hair curtain from bottom curl (v=0) up to crown (v=1)
                for (let k = 0; k <= nVert; k++) {
                    const v = k / nVert;
                    const y = lerp(yBot, yTop, v);
                    const napeTuck = -0.009 * gauss(v, 0.45, 0.14) * smoothstep(1.8, Math.PI, ang);
                    const curlSwell = 0.014 * gauss(v, 0.16, 0.13);
                    const crownTaper = smoothstep(1.0, 0.76, v);
                    const waveLock = 0.007 * Math.cos(ang * 11 + v * 3.8) * (1 - 0.55 * v);
                    const earCurve = 0.006 * gauss(ang, 1.58, 0.25) * gauss(v, 0.55, 0.22);

                    const thick = (0.014 + 0.014 * sideFade) * crownTaper + curlSwell + napeTuck + waveLock + earCurve;
                    const rxIn = lerp(0.088, 0.082, smoothstep(0.25, 0.85, v));
                    const rzIn = lerp(0.092, 0.088, smoothstep(0.25, 0.85, v));
                    const rxOut = rxIn + Math.max(0.005, thick);
                    const rzOut = rzIn + Math.max(0.005, thick);

                    ring.push([rxOut * sp, y, zCenter + rzOut * cp]);
                }
                // Inner skull/neck-hugging surface from top (v=1) back down to bottom (v=0)
                for (let k = nVert; k >= 0; k--) {
                    const v = k / nVert;
                    const y = lerp(yBot, yTop, v);
                    const rxIn = lerp(0.088, 0.082, smoothstep(0.25, 0.85, v));
                    const rzIn = lerp(0.092, 0.088, smoothstep(0.25, 0.85, v));
                    ring.push([rxIn * sp, y, zCenter + rzIn * cp]);
                }

                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry(false);
        },

        /**
         * 27. Single continuous contoured left mounted rider leg + knee + cavalry boot
         *     (character-space, normalize=false).
         */
        createRiderLegL() {
            return buildRiderLeg(-1);
        },

        /**
         * 28. Single continuous contoured right mounted rider leg + knee + cavalry boot
         *     (character-space, normalize=false).
         */
        createRiderLegR() {
            return buildRiderLeg(1);
        },

        /**
         * 29. Flowing arched horse tail rising from dock (0, 0.42, -0.15) and
         *     sweeping smoothly down in a lush curved taper (unit-centered, normalize=true).
         */
        createHorseTail() {
            const mb = new MeshBuilder();
            const segs = 18;
            const stations = [
                { y:  0.42, z: -0.15, rx: 0.055, rz: 0.058, wave: 0.00 },
                { y:  0.47, z: -0.21, rx: 0.068, rz: 0.072, wave: 0.03 },
                { y:  0.44, z: -0.28, rx: 0.088, rz: 0.096, wave: 0.06 },
                { y:  0.31, z: -0.35, rx: 0.112, rz: 0.122, wave: 0.09 },
                { y:  0.13, z: -0.40, rx: 0.122, rz: 0.132, wave: 0.10 },
                { y: -0.07, z: -0.43, rx: 0.112, rz: 0.120, wave: 0.10 },
                { y: -0.26, z: -0.45, rx: 0.088, rz: 0.094, wave: 0.09 },
                { y: -0.41, z: -0.46, rx: 0.055, rz: 0.060, wave: 0.06 },
                { y: -0.50, z: -0.47, rx: 0.022, rz: 0.024, wave: 0.02 }
            ];

            const rings = [];
            for (let s = 0; s < stations.length; s++) {
                const pt = stations[s];
                let ty, tz;
                if (s === 0) {
                    ty = stations[1].y - pt.y;
                    tz = stations[1].z - pt.z;
                } else if (s === stations.length - 1) {
                    ty = pt.y - stations[s - 1].y;
                    tz = pt.z - stations[s - 1].z;
                } else {
                    ty = stations[s + 1].y - stations[s - 1].y;
                    tz = stations[s + 1].z - stations[s - 1].z;
                }
                const tLen = Math.hypot(ty, tz) || 1;
                ty /= tLen; tz /= tLen;

                // F = right(1,0,0) x T(0,ty,tz) = (0, -tz, ty); U = T x F = (-1, 0, 0)
                // Wait: F = (0, -tz, ty) gives U = T x F = (0,ty,tz) x (0,-tz,ty) = (ty^2+tz^2, 0, 0) = (+1, 0, 0)
                const fy = -tz, fz = ty;
                const ux = 1.0;

                const ring = [];
                for (let i = 0; i < segs; i++) {
                    const a = (i / segs) * TWO_PI;
                    const hairFlute = 1.0 + pt.wave * (0.8 * Math.cos(a * 7 + s * 0.6) + 0.4 * Math.cos(a * 13 - s * 0.4));
                    const ca = Math.cos(a) * pt.rx * hairFlute;
                    const sa = Math.sin(a) * pt.rz * hairFlute;
                    ring.push([
                        ux * ca,
                        pt.y + fy * sa,
                        pt.z + fz * sa
                    ]);
                }
                rings.push(ring);
            }

            mb.addLoft(rings, true, true);
            return mb.toBufferGeometry(true);
        }
    };
})();
'''
