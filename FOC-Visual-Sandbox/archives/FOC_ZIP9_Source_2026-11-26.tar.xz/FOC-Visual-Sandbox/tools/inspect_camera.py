import subprocess
import os
import tempfile
import json
import re

def inspect_cam():
    with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
        html = f.read()

    script = '''
<script>
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const c = window.__focBattle3DPreview;
        const cam = c.renderer.camera;
        const res = {
            camPos: [cam.position.x, cam.position.y, cam.position.z],
            target: [c.renderer.cameraTarget.x, c.renderer.cameraTarget.y, c.renderer.cameraTarget.z],
            fov: cam.fov,
            aspect: cam.aspect,
            near: cam.near,
            far: cam.far,
            viewMatrix: Array.from(cam.viewMatrix),
            projMatrix: Array.from(cam.projectionMatrix)
        };
        const pre = document.createElement('pre');
        pre.id = 'camInfo';
        pre.textContent = JSON.stringify(res, null, 2);
        document.body.appendChild(pre);
    }, 1000);
});
</script>
'''

    temp_html = 'test_cam.html'
    with open(temp_html, 'w', encoding='utf-8') as f:
        f.write(html.replace('</body>', script + '</body>'))

    temp_profile = os.path.join(tempfile.gettempdir(), 'foc_cam_prof')
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    cmd = [
        chrome_path,
        '--headless=new',
        '--disable-gpu-sandbox',
        '--enable-webgl',
        '--use-gl=angle',
        '--use-angle=d3d11',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--virtual-time-budget=5000',
        '--dump-dom',
        'file:///' + os.path.abspath(temp_html).replace('\\', '/')
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=15, encoding='utf-8', errors='replace')
    m = re.search(r'<pre id="camInfo">(.*?)</pre>', res.stdout, re.DOTALL)
    if m:
        print(m.group(1))
    if os.path.exists(temp_html):
        os.remove(temp_html)

if __name__ == '__main__':
    inspect_cam()
