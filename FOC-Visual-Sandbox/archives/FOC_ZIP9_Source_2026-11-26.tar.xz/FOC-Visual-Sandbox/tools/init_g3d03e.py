import os
import shutil

base_file = 'FOC_G3D03D_QA_DUZELTILMIS.html'
for i in range(1, 7):
    agent_dir = os.path.join('G3D03E', 'AJANLAR', f'{i:02d}')
    os.makedirs(agent_dir, exist_ok=True)
    dst = os.path.join(agent_dir, 'WORKING.html')
    shutil.copyfile(base_file, dst)
    print(f'Initialized {dst} ({os.path.getsize(dst)} bytes)')
