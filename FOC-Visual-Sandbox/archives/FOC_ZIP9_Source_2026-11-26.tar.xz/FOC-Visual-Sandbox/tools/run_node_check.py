with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

# Let's write a small node test to run in headless or node
test_node = """
const fs = require('fs');
const html = fs.readFileSync('FallOfCavalry_PLAYABLE_RTS.html', 'utf-8');

// Find createSoldierPartTemplates
const idx = html.indexOf('function createSoldierPartTemplates()');
const endIdx = html.indexOf('function smoothstep', idx);
const code = html.substring(idx, endIdx);

// Also we need FOC_THREE mock
const makePart = (prim, mat, tx, ty, tz, sx, sy, sz, rx=0, ry=0, rz=0, rigGroup='static') => ({
    prim, mat, rigGroup, tx, ty, tz, sx, sy, sz, rx, ry, rz
});

// Run in eval
const fn = new Function('makePart', code + '\\n return createSoldierPartTemplates();');
const tpls = fn(makePart);
console.log('g3d03l:european_musketier:high length:', tpls['g3d03l:european_musketier:high'] ? tpls['g3d03l:european_musketier:high'].length : 'undefined');
console.log('g3d03l:european_curassier:high length:', tpls['g3d03l:european_curassier:high'] ? tpls['g3d03l:european_curassier:high'].length : 'undefined');
"""
with open('tools/test_tpls.js', 'w', encoding='utf-8') as f:
    f.write(test_node)
print("Wrote test_tpls.js")
