# -*- coding: utf-8 -*-
"""
tools/fixed_ottoman_infantry.py
1650 Ottoman Military Character Archetypes (9 Fixed, Non-Modular Units).

Generates JavaScript code via `get_fixed_ottoman_infantry_code()` defining 9
self-contained, non-modular Ottoman infantry builders and the
`FIXED_OTTOMAN_INFANTRY` lookup map using unified organic meshes:
  - 'orgTorsoCoat', 'orgTorsoArmored', 'orgHeadNatural', 'orgHairCurtain', 'orgLimb',
    'orgBoot', 'orgHand', 'orgHelmetBork', 'orgHelmetTurban', 'orgHelmetPointed'
  - Single-piece bent sleeve meshes: 'orgArmMusketL', 'orgArmMusketR',
    'orgArmPikeL', 'orgArmPikeR', 'orgArmSwordR', 'orgArmShieldL'
  - Primitives ('cylinder', 'cone', 'box', 'sphere') ONLY for ground shadow,
    thin cuffs, snug waist sashes, weapon barrels/blades/shafts, shields, and plumes.
"""


def get_fixed_ottoman_infantry_code() -> str:
    """Return JavaScript code defining 9 fixed 1650 Ottoman infantry archetypes."""
    return r"""
        /* ============================================================================
         * 1650 OTTOMAN INFANTRY — 9 FIXED, NON-MODULAR ARCHETYPES
         * Coordinate system: +Y up (feet y=0, shoulders y=1.32, head y=1.54),
         *                    +Z forward, -X left, +X right.
         * ============================================================================ */

        function _orgLimbSeg(mat, ax, ay, az, bx, by, bz, width, depth, rigGroup) {
            const dx = bx - ax;
            const dy = by - ay;
            const dz = bz - az;
            const len = Math.hypot(dx, dy, dz) || 0.001;
            const mx = (ax + bx) * 0.5;
            const my = (ay + by) * 0.5;
            const mz = (az + bz) * 0.5;
            const rx = Math.asin(Math.max(-1, Math.min(1, dz / len)));
            const rz = -Math.atan2(dx, dy);
            return makePart('orgLimb', mat, mx, my, mz, width, len, depth, rx, 0, rz, rigGroup);
        }

        function _fixedOrientY(ux, uy, uz) {
            const len = Math.hypot(ux, uy, uz) || 1;
            const nx = ux / len, ny = uy / len, nz = uz / len;
            return {
                rx: Math.asin(Math.max(-1, Math.min(1, nz))),
                rz: -Math.atan2(nx, ny)
            };
        }

        function _fixedWristCuffAndHand(cuffMat, handMat, wrist, elbow, handScale, rigGroup) {
            const dx = wrist[0] - elbow[0];
            const dy = wrist[1] - elbow[1];
            const dz = wrist[2] - elbow[2];
            const len = Math.hypot(dx, dy, dz) || 1;
            const ux = dx / len, uy = dy / len, uz = dz / len;
            const rot = _fixedOrientY(ux, uy, uz);
            // Thin linen cuff tucked 1.5 cm behind wrist endpoint along forearm axis
            const cx = wrist[0] - ux * 0.015;
            const cy = wrist[1] - uy * 0.015;
            const cz = wrist[2] - uz * 0.015;
            return [
                makePart('cylinder', cuffMat, cx, cy, cz, 0.096, 0.036, 0.096, rot.rx, 0, rot.rz, rigGroup),
                makePart('orgHand', handMat, wrist[0], wrist[1], wrist[2], handScale, handScale * 1.05, handScale, rot.rx * 0.25, 0, 0, rigGroup)
            ];
        }

        function _fixedOttomanHeadAndNeck(collarMat, mustacheMat = 'hairDark', beardMat = null, hasHairNape = false) {
            const parts = [
                // Crisp kaftan collar & thickened anatomical neck
                makePart('cylinder', collarMat, 0, 1.38, 0.005, 0.21, 0.045, 0.20, 0, 0, 0, 'torso'),
                makePart('orgLimb', 'skin', 0, 1.43, 0.01, 0.165, 0.16, 0.155, 0, 0, 0, 'torso'),
                // Natural human head-to-shoulder proportions
                makePart('orgHeadNatural', 'skin', 0, 1.54, 0.01, 0.23, 0.25, 0.23, 0, 0, 0, 'torso'),
                // Crisp dark eyes & sculpted brow ridge accents
                makePart('sphere', 'eyeDark', -0.036, 1.565, 0.095, 0.022, 0.016, 0.014, 0, 0, 0, 'torso'),
                makePart('sphere', 'eyeDark',  0.036, 1.565, 0.095, 0.022, 0.016, 0.014, 0, 0, 0, 'torso'),
                makePart('orgLimb', 'hairDark', -0.036, 1.578, 0.097, 0.009, 0.034, 0.012, 0.35, 0, -1.52, 'torso'),
                makePart('orgLimb', 'hairDark',  0.036, 1.578, 0.097, 0.009, 0.034, 0.012, 0.35, 0,  1.52, 'torso'),
                // Tucked Ottoman mustache cleanly against upper lip (z=0.11..0.12)
                makePart('orgLimb', mustacheMat, -0.025, 1.505, 0.112, 0.018, 0.052, 0.016, 0.10,  0.28,  1.32, 'torso'),
                makePart('orgLimb', mustacheMat,  0.025, 1.505, 0.112, 0.018, 0.052, 0.016, 0.10, -0.28, -1.32, 'torso')
            ];
            if (beardMat) {
                parts.push(makePart('orgLimb', beardMat, 0.0, 1.478, 0.105, 0.026, 0.040, 0.020, 0.22, 0, 0, 'torso'));
            }
            if (hasHairNape) {
                // Compact dark hair nape tucked cleanly under turban (y=1.418..1.586)
                parts.push(makePart('orgHairCurtain', 'hairDark', 0, 0.16, -0.004, 0.90, 0.89, 0.90, 0, 0, 0, 'torso'));
            }
            return parts;
        }

        function _fixedOttomanLegs(salvarMat, bootMat, legScale = 1.0) {
            const w = 0.23 * legScale;
            const lw = 0.19 * legScale;
            return [
                makePart('cylinder', 'shadow', 0, 0.02, 0, 1.08, 0.02, 1.08, 0, 0, 0, 'shadow'),
                // Unified boots
                makePart('orgBoot', bootMat, -0.14, 0.07, 0.03, 0.13 * legScale, 0.14, 0.25, 0, 0, 0, 'leftLegLower'),
                makePart('orgBoot', bootMat,  0.14, 0.07, 0.03, 0.13 * legScale, 0.14, 0.25, 0, 0, 0, 'rightLegLower'),
                // Lower şalvar calves
                _orgLimbSeg(salvarMat, -0.14, 0.46, 0.0, -0.14, 0.12, 0.0, lw, lw * 1.05, 'leftLegLower'),
                _orgLimbSeg(salvarMat,  0.14, 0.46, 0.0,  0.14, 0.12, 0.0, lw, lw * 1.05, 'rightLegLower'),
                // Upper şalvar thighs
                _orgLimbSeg(salvarMat, -0.14, 0.84, 0.0, -0.14, 0.45, 0.0, w, w * 1.05, 'leftLegUpper'),
                _orgLimbSeg(salvarMat,  0.14, 0.84, 0.0,  0.14, 0.45, 0.0, w, w * 1.05, 'rightLegUpper')
            ];
        }

        function _fixedSnugWaistSash(sashMat, coatSx, coatSz, armored = false, height = 0.085) {
            // orgTorsoCoat waist (y=-0.06) has normalized width 0.579, depth 0.429, zMid +0.018.
            // orgTorsoArmored waist (y=-0.06) adds slight armor thickness (~0.02m).
            const w = (armored ? 0.615 : 0.585) * coatSx + 0.022;
            const d = (armored ? 0.465 : 0.435) * coatSz + 0.022;
            const zCenter = 0.018 * coatSz;
            return makePart('cylinder', sashMat, 0, 1.05, zCenter, w, height, d, 0, 0, 0, 'torso');
        }

        function _fixedTwoHandPikeParts(sleeveMat, handMat, shaftLength, isTeber = false) {
            const wL = [-0.31, 1.10, 0.16];
            const eL = [-0.29, 1.14, -0.02];
            const wR = [-0.27, 1.30, 0.50];
            const eR = [ 0.10, 1.18, 0.22];

            // Shaft passes squarely through both wrist grips wL -> wR
            const dx = wR[0] - wL[0];
            const dy = wR[1] - wL[1];
            const dz = wR[2] - wL[2];
            const gripSpan = Math.hypot(dx, dy, dz) || 1;
            const ux = dx / gripSpan, uy = dy / gripSpan, uz = dz / gripSpan;
            const rot = _fixedOrientY(ux, uy, uz);

            // Perpendicular forward-downward vector (+localZ of rot) for axe blade offset
            const cz = Math.cos(rot.rz), sz = Math.sin(rot.rz), sx = Math.sin(rot.rx), cx = Math.cos(rot.rx);
            const zx = sz * sx, zy = -cz * sx, zz = cx;

            const rearOverhang = isTeber ? 0.52 : 0.78;
            const centerS = shaftLength * 0.5 - rearOverhang;
            const pt = (s) => [wL[0] + ux * s, wL[1] + uy * s, wL[2] + uz * s];
            const cPos = pt(centerS);

            const parts = [
                makePart('orgArmPikeL', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandPike'),
                ..._fixedWristCuffAndHand('linen', handMat, wL, eL, 0.092, 'twoHandPike'),
                makePart('orgArmPikeR', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandPike'),
                ..._fixedWristCuffAndHand('linen', handMat, wR, eR, 0.092, 'twoHandPike'),
                // Hardwood shaft aligned through both hands
                makePart('cylinder', 'wood', cPos[0], cPos[1], cPos[2], 0.042, shaftLength, 0.042, rot.rx, 0, rot.rz, 'twoHandPike')
            ];

            if (isTeber) {
                const tipS = centerS + shaftLength * 0.5 + 0.14;
                const headS = tipS - 0.30;
                const tipPos = pt(tipS);
                const headPos = pt(headS);
                const buttPos = pt(centerS - shaftLength * 0.5 - 0.04);
                parts.push(
                    makePart('cone', 'steel', tipPos[0], tipPos[1], tipPos[2], 0.075, 0.34, 0.04, rot.rx, 0, rot.rz, 'twoHandPike'),
                    makePart('box', 'damascusSteel', headPos[0] + zx * 0.11, headPos[1] + zy * 0.11, headPos[2] + zz * 0.11, 0.024, 0.34, 0.22, rot.rx, 0, rot.rz, 'twoHandPike'),
                    makePart('cone', 'gold', headPos[0] - zx * 0.08, headPos[1] - zy * 0.08, headPos[2] - zz * 0.08, 0.04, 0.15, 0.04, rot.rx - Math.PI * 0.5, 0, rot.rz, 'twoHandPike'),
                    makePart('cone', 'bronze', buttPos[0], buttPos[1], buttPos[2], 0.048, 0.11, 0.048, -rot.rx, 0, rot.rz + Math.PI, 'twoHandPike')
                );
            } else {
                const tipPos = pt(centerS + shaftLength * 0.5 + 0.18);
                const buttPos = pt(centerS - shaftLength * 0.5 - 0.05);
                parts.push(
                    makePart('cone', 'damascusSteel', tipPos[0], tipPos[1], tipPos[2], 0.082, 0.42, 0.04, rot.rx, 0, rot.rz, 'twoHandPike'),
                    makePart('cone', 'bronze', buttPos[0], buttPos[1], buttPos[2], 0.05, 0.12, 0.05, -rot.rx, 0, rot.rz + Math.PI, 'twoHandPike')
                );
            }
            return parts;
        }

        function _fixedTwoHandMusketParts(sleeveMat, handMat, barrelMat, bandMat) {
            const wL = [-0.10, 1.25, 0.62];
            const eL = [-0.25, 1.15, 0.16];
            const wR = [ 0.17, 1.23, 0.28];
            const eR = [ 0.25, 1.14, 0.08];

            // Diagonal musket axis from right grip (0.17, 1.24, 0.26) through left grip (-0.10, 1.27, 0.62)
            const rx0 = 0.17, ry0 = 1.24, rz0 = 0.26;
            const lx0 = -0.10, ly0 = 1.27, lz0 = 0.62;
            const dx = lx0 - rx0;
            const dy = ly0 - ry0;
            const dz = lz0 - rz0;
            const span = Math.hypot(dx, dy, dz) || 1;
            const ux = dx / span, uy = dy / span, uz = dz / span;

            // With rz=0: cylinder +Y aligns with (ux, uy, uz) via (bPitch, bYaw, 0);
            // box +Z aligns with (ux, uy, uz) via (stockPitch, bYaw, 0).
            const bYaw = Math.atan2(ux, uz);
            const bPitch = Math.acos(Math.max(-1, Math.min(1, uy)));
            const stockPitch = -Math.asin(Math.max(-1, Math.min(1, uy)));

            const pt = (s, yOff = 0) => [rx0 + ux * s, ry0 + uy * s + yOff, rz0 + uz * s];
            const butt = pt(-0.12, -0.015);
            const fore = pt(0.40, 0.0);
            const lock = pt(0.10, 0.022);
            const brl  = pt(0.58, 0.032);
            const bnd1 = pt(0.52, 0.032);
            const bnd2 = pt(1.10, 0.032);

            return [
                makePart('orgArmMusketL', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandMusket'),
                ..._fixedWristCuffAndHand('linen', handMat, wL, eL, 0.092, 'twoHandMusket'),
                makePart('orgArmMusketR', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'twoHandMusket'),
                ..._fixedWristCuffAndHand('linen', handMat, wR, eR, 0.092, 'twoHandMusket'),
                // Ottoman Tüfenk matchlock musket aligned along right->left grip diagonal
                makePart('box', 'wood', butt[0], butt[1], butt[2], 0.068, 0.125, 0.30, stockPitch - 0.16, bYaw, 0, 'twoHandMusket'),
                makePart('box', 'wood', fore[0], fore[1], fore[2], 0.062, 0.070, 0.78, stockPitch, bYaw, 0, 'twoHandMusket'),
                makePart('cylinder', barrelMat, brl[0], brl[1], brl[2], 0.050, 1.16, 0.050, bPitch, bYaw, 0, 'twoHandMusket'),
                makePart('cylinder', bandMat, bnd1[0], bnd1[1], bnd1[2], 0.058, 0.04, 0.058, bPitch, bYaw, 0, 'twoHandMusket'),
                makePart('cylinder', bandMat, bnd2[0], bnd2[1], bnd2[2], 0.060, 0.05, 0.060, bPitch, bYaw, 0, 'twoHandMusket'),
                makePart('box', 'gold', lock[0], lock[1], lock[2], 0.068, 0.045, 0.085, stockPitch, bYaw, 0, 'twoHandMusket')
            ];
        }

        function _fixedKalkanLeftArm(sleeveMat, shieldMat, bossMat, diameter = 0.56) {
            const wL = [-0.27, 1.23, 0.30];
            const eL = [-0.30, 1.14, 0.10];
            // Shield normal (-0.52, 0, +0.85) clears chest and hugs outer left forearm
            const ry = -0.55;
            const nx = Math.sin(ry), nz = Math.cos(ry);
            const sx = -0.32, sy = 1.23, sz = 0.33;
            return [
                makePart('orgArmShieldL', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'leftArmWeapon'),
                ..._fixedWristCuffAndHand('linen', 'skin', wL, eL, 0.092, 'leftArmWeapon'),
                makePart('cylinder', shieldMat, sx, sy, sz, diameter, 0.04, diameter, Math.PI * 0.5, ry, 0, 'leftArmWeapon'),
                makePart('sphere', bossMat, sx + nx * 0.025, sy, sz + nz * 0.025, 0.14, 0.14, 0.10, 0, ry, 0, 'leftArmWeapon')
            ];
        }

        function _fixedYataganRightArm(sleeveMat, hiltMat, bladeMat, bladeLen = 0.66) {
            const wR = [0.23, 1.20, 0.32];
            const eR = [0.28, 1.13, 0.10];
            return [
                makePart('orgArmSwordR', sleeveMat, 0, 0, 0, 1, 1, 1, 0, 0, 0, 'rightArmWeapon'),
                ..._fixedWristCuffAndHand('linen', 'skin', wR, eR, 0.092, 'rightArmWeapon'),
                // Eared yatağan hilt seated cleanly in right palm (0.23, 1.20, 0.32)
                makePart('box', hiltMat, 0.23, 1.20, 0.33, 0.040, 0.11, 0.052, 0.25, 0, 0, 'rightArmWeapon'),
                makePart('box', 'gold',  0.23, 1.22, 0.38, 0.048, 0.065, 0.04, 0.25, 0, 0, 'rightArmWeapon'),
                // Forward-curved yatağan blade
                makePart('box', bladeMat, 0.23, 1.27, 0.38 + bladeLen * 0.48, 0.022, 0.055, bladeLen, -0.18, 0, 0, 'rightArmWeapon')
            ];
        }

        // 1. Azap Mızraklı
        function buildFixedOttomanAzapPike() {
            return [
                ..._fixedOttomanLegs('ottomanNavy', 'buffLeather', 0.96),
                makePart('orgTorsoCoat', 'ottomanWhite', 0, 1.09, 0.0, 0.52, 0.56, 0.35, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('ottomanCrimson', 0.52, 0.35, false, 0.08),
                ..._fixedOttomanHeadAndNeck('ottomanNavy', 'hairDark', null, true),
                makePart('orgHelmetTurban', 'ottomanWhite', 0, 1.62, 0.01, 0.33, 0.23, 0.33, 0, 0, 0, 'torso'),
                ..._fixedTwoHandPikeParts('ottomanNavy', 'skin', 3.85, false)
            ];
        }

        // 2. Azap Mızrak + Kılıçlı (Left arm kalkan shield + Right arm mızrak spear + hip scimitar)
        function buildFixedOttomanAzapPikeSword() {
            const wR = [0.23, 1.20, 0.32];
            const eR = [0.28, 1.13, 0.10];
            const spearPitch = 0.72;
            const cosP = Math.cos(spearPitch), sinP = Math.sin(spearPitch);
            const shaftLen = 3.00;
            const centerS = 0.55;
            return [
                ..._fixedOttomanLegs('ottomanNavy', 'leather', 0.98),
                makePart('orgTorsoCoat', 'ottomanCrimson', 0, 1.09, 0.0, 0.53, 0.56, 0.35, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('ottomanSaffron', 0.53, 0.35, false, 0.08),
                // Curved scimitar scabbard hugging left hip
                makePart('box', 'buffLeather', -0.175, 0.94, -0.02, 0.030, 0.055, 0.48, 0.42, -0.18, 0.14, 'torso'),
                makePart('box', 'gold',        -0.180, 1.01,  0.19, 0.042, 0.10,  0.045, 0.42, -0.18, 0.14, 'torso'),
                ..._fixedOttomanHeadAndNeck('ottomanCrimson', 'hairDark'),
                makePart('orgHelmetTurban', 'ottomanWhite', 0, 1.62, 0.01, 0.33, 0.23, 0.33, 0, 0, 0, 'torso'),
                // Right arm spear on rightArmWeapon aligned through wrist (0.23, 1.20, 0.32)
                makePart('orgArmSwordR', 'ottomanNavy', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'rightArmWeapon'),
                ..._fixedWristCuffAndHand('linen', 'skin', wR, eR, 0.092, 'rightArmWeapon'),
                makePart('cylinder', 'wood', wR[0], wR[1] + centerS * cosP, wR[2] + centerS * sinP, 0.040, shaftLen, 0.040, spearPitch, 0, 0, 'rightArmWeapon'),
                makePart('cone', 'damascusSteel', wR[0], wR[1] + (centerS + shaftLen * 0.5 + 0.18) * cosP, wR[2] + (centerS + shaftLen * 0.5 + 0.18) * sinP, 0.078, 0.40, 0.04, spearPitch, 0, 0, 'rightArmWeapon'),
                makePart('cone', 'bronze', wR[0], wR[1] + (centerS - shaftLen * 0.5 - 0.05) * cosP, wR[2] + (centerS - shaftLen * 0.5 - 0.05) * sinP, 0.048, 0.11, 0.048, spearPitch + Math.PI, 0, 0, 'rightArmWeapon'),
                // Round kalkan shield on leftArmWeapon
                ..._fixedKalkanLeftArm('ottomanNavy', 'buffLeather', 'bronze', 0.50)
            ];
        }

        // 3. Azap Tüfekli
        function buildFixedOttomanAzapMusket() {
            return [
                ..._fixedOttomanLegs('ottomanNavy', 'buffLeather', 0.96),
                makePart('orgTorsoCoat', 'ottomanSaffron', 0, 1.09, 0.0, 0.52, 0.56, 0.35, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('ottomanNavy', 0.52, 0.35, false, 0.08),
                // Compact palaska cartridge pouch tucked snugly at front-right waist
                makePart('box', 'buffLeather', 0.11, 1.04, 0.082, 0.075, 0.085, 0.040, 0, 0.35, 0, 'torso'),
                ..._fixedOttomanHeadAndNeck('ottomanSaffron', 'hairDark'),
                makePart('orgHelmetTurban', 'ottomanWhite', 0, 1.62, 0.01, 0.32, 0.22, 0.32, 0, 0, 0, 'torso'),
                ..._fixedTwoHandMusketParts('ottomanSaffron', 'skin', 'darkSteel', 'bronze')
            ];
        }

        // 4. Yeniçeri Tüfekli
        function buildFixedOttomanJanissaryMusket() {
            return [
                ..._fixedOttomanLegs('ottomanNavy', 'leather', 1.0),
                makePart('orgTorsoCoat', 'crimsonVelvet', 0, 1.09, 0.0, 0.55, 0.58, 0.37, 0, 0, 0, 'torso'),
                makePart('orgTorsoArmored', 'damascusSteel', 0, 1.09, 0.015, 0.56, 0.54, 0.39, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('ottomanSaffron', 0.55, 0.37, true, 0.085),
                makePart('box', 'buffLeather', 0.12, 1.04, 0.090, 0.075, 0.085, 0.040, 0, 0.35, 0, 'torso'),
                ..._fixedOttomanHeadAndNeck('crimsonVelvet', 'hairDark', 'hairDark'),
                // Authentic Janissary Börk + brass zarf spoon holder
                makePart('orgHelmetBork', 'ottomanWhite', 0, 1.65, 0.0, 0.29, 0.39, 0.31, 0, 0, 0, 'torso'),
                makePart('box', 'gold', 0, 1.61, 0.115, 0.038, 0.13, 0.026, 0.08, 0, 0, 'torso'),
                ..._fixedTwoHandMusketParts('ottomanCrimson', 'skin', 'damascusSteel', 'gold')
            ];
        }

        // 5. Yeniçeri Kılıçlı
        function buildFixedOttomanJanissarySword() {
            return [
                ..._fixedOttomanLegs('ottomanNavy', 'buffLeather', 1.02),
                makePart('orgTorsoCoat', 'crimsonVelvet', 0, 1.09, 0.0, 0.55, 0.58, 0.37, 0, 0, 0, 'torso'),
                makePart('orgTorsoArmored', 'damascusSteel', 0, 1.09, 0.015, 0.56, 0.54, 0.39, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('ottomanSaffron', 0.55, 0.37, true, 0.085),
                ..._fixedOttomanHeadAndNeck('crimsonVelvet', 'hairDark', 'hairDark'),
                makePart('orgHelmetBork', 'ottomanWhite', 0, 1.65, 0.0, 0.29, 0.39, 0.31, 0, 0, 0, 'torso'),
                makePart('box', 'gold', 0, 1.61, 0.115, 0.038, 0.13, 0.026, 0.08, 0, 0, 'torso'),
                // Ivory-hilted Yatağan + round bronze-bossed Kalkan
                ..._fixedYataganRightArm('ottomanCrimson', 'ottomanWhite', 'damascusSteel', 0.66),
                ..._fixedKalkanLeftArm('ottomanCrimson', 'damascusSteel', 'bronze', 0.56)
            ];
        }

        // 6. Bostancı Baltalı
        function buildFixedOttomanBostanciAxe() {
            return [
                ..._fixedOttomanLegs('ottomanNavy', 'buffLeather', 1.08),
                makePart('orgTorsoCoat', 'crimsonVelvet', 0, 1.09, 0.0, 0.57, 0.58, 0.38, 0, 0, 0, 'torso'),
                makePart('orgTorsoArmored', 'damascusSteel', 0, 1.09, 0.015, 0.58, 0.54, 0.40, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('ottomanEmerald', 0.57, 0.38, true, 0.09),
                ..._fixedOttomanHeadAndNeck('ottomanEmerald', 'hairDark', 'hairDark'),
                makePart('orgHelmetPointed', 'ottomanCrimson', 0, 1.63, 0.01, 0.27, 0.43, 0.28, 0, 0, 0, 'torso'),
                makePart('cylinder', 'gold', 0, 1.57, 0.01, 0.26, 0.036, 0.27, 0, 0, 0, 'torso'),
                ..._fixedTwoHandPikeParts('ottomanEmerald', 'skin', 3.10, true)
            ];
        }

        // 7. Bostancı Mızraklı
        function buildFixedOttomanBostanciPike() {
            return [
                ..._fixedOttomanLegs('ottomanNavy', 'leather', 1.10),
                makePart('orgTorsoCoat', 'crimsonVelvet', 0, 1.09, 0.0, 0.58, 0.58, 0.38, 0, 0, 0, 'torso'),
                makePart('orgTorsoArmored', 'steel', 0, 1.09, 0.015, 0.59, 0.54, 0.40, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('gold', 0.58, 0.38, true, 0.085),
                ..._fixedOttomanHeadAndNeck('crimsonVelvet', 'hairDark', 'hairDark'),
                makePart('orgHelmetPointed', 'ottomanCrimson', 0, 1.63, 0.01, 0.27, 0.43, 0.28, 0, 0, 0, 'torso'),
                makePart('cylinder', 'gold', 0, 1.57, 0.01, 0.26, 0.036, 0.27, 0, 0, 0, 'torso'),
                ..._fixedTwoHandPikeParts('ottomanCrimson', 'skin', 4.20, false)
            ];
        }

        // 8. Humbaracı
        function buildFixedOttomanHumbaraci() {
            const wR = [0.23, 1.20, 0.32];
            const eR = [0.28, 1.13, 0.10];
            const wL = [-0.27, 1.23, 0.30];
            const eL = [-0.30, 1.14, 0.10];
            return [
                ..._fixedOttomanLegs('buffLeather', 'leather', 1.04),
                makePart('orgTorsoCoat', 'crimsonVelvet', 0, 1.09, 0.0, 0.56, 0.58, 0.37, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('ottomanSaffron', 0.56, 0.37, false, 0.085),
                // Snug leather belt & compact hip bomb pouch + yatağan scabbard
                makePart('cylinder', 'leather', 0, 1.03, 0.007, 0.348, 0.030, 0.184, 0, 0, 0, 'torso'),
                makePart('box', 'buffLeather',  0.175, 0.99,  0.02, 0.065, 0.095, 0.075, 0, 0, 0, 'torso'),
                makePart('box', 'buffLeather', -0.175, 0.94, -0.02, 0.030, 0.055, 0.46, 0.40, -0.20, 0.14, 'torso'),
                makePart('box', 'gold',        -0.180, 1.01,  0.18, 0.040, 0.095, 0.045, 0.40, -0.20, 0.14, 'torso'),
                ..._fixedOttomanHeadAndNeck('crimsonVelvet', 'hairDark', 'hairDark'),
                makePart('orgHelmetTurban', 'ottomanEmerald', 0, 1.62, 0.01, 0.33, 0.23, 0.33, 0, 0, 0, 'torso'),
                // Right arm holding cast-iron humbara bomb cleanly in hand (0.23, 1.20, 0.32)
                makePart('orgArmSwordR', 'ottomanCrimson', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'rightArmWeapon'),
                ..._fixedWristCuffAndHand('linen', 'skin', wR, eR, 0.092, 'rightArmWeapon'),
                makePart('sphere', 'darkSteel',     0.23, 1.28, 0.34, 0.15, 0.15, 0.15, 0, 0, 0, 'rightArmWeapon'),
                makePart('cone',   'ottomanSaffron', 0.23, 1.37, 0.34, 0.038, 0.075, 0.038, 0, 0, 0, 'rightArmWeapon'),
                // Left arm holding slow-match linstock cleanly in hand (-0.27, 1.23, 0.30)
                makePart('orgArmShieldL', 'ottomanCrimson', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'leftArmWeapon'),
                ..._fixedWristCuffAndHand('linen', 'skin', wL, eL, 0.092, 'leftArmWeapon'),
                makePart('cylinder', 'wood',          -0.27, 1.29, 0.35, 0.024, 0.26, 0.024, 0.52, 0, 0, 'leftArmWeapon'),
                makePart('sphere',   'ottomanSaffron', -0.27, 1.40, 0.42, 0.036, 0.036, 0.036, 0, 0, 0, 'leftArmWeapon')
            ];
        }

        // 9. Levend
        function buildFixedOttomanLevend() {
            const wL = [-0.27, 1.23, 0.30];
            const eL = [-0.30, 1.14, 0.10];
            return [
                ..._fixedOttomanLegs('linen', 'buffLeather', 0.98),
                makePart('orgTorsoCoat', 'ottomanNavy', 0, 1.09, 0.0, 0.53, 0.56, 0.35, 0, 0, 0, 'torso'),
                _fixedSnugWaistSash('crimsonVelvet', 0.53, 0.35, false, 0.088),
                // Spare flintlock pistol tucked snugly into front-left of waist sash
                makePart('box', 'wood', -0.075, 1.045, 0.085, 0.034, 0.14, 0.055, 0.30, 0.22, 0.20, 'torso'),
                ..._fixedOttomanHeadAndNeck('ottomanNavy', 'hairDark', null, true),
                // Striped saffron/navy turban
                makePart('orgHelmetTurban', 'ottomanSaffron', 0, 1.62, 0.01, 0.33, 0.22, 0.33, 0, 0, 0, 'torso'),
                makePart('cylinder', 'ottomanNavy', 0, 1.63, 0.01, 0.34, 0.045, 0.34, 0.1, 0, 0.12, 'torso'),
                // Curved Yatağan in rightArmWeapon
                ..._fixedYataganRightArm('ottomanNavy', 'gold', 'damascusSteel', 0.64),
                // Ottoman flintlock pistol in leftArmWeapon (-0.27, 1.23, 0.30)
                makePart('orgArmShieldL', 'ottomanNavy', 0, 0, 0, 1, 1, 1, 0, 0, 0, 'leftArmWeapon'),
                ..._fixedWristCuffAndHand('linen', 'skin', wL, eL, 0.092, 'leftArmWeapon'),
                makePart('box', 'wood', -0.27, 1.22, 0.31, 0.042, 0.105, 0.075, 0.35, 0, 0, 'leftArmWeapon'),
                makePart('cylinder', 'damascusSteel', -0.27, 1.265, 0.45, 0.034, 0.30, 0.034, Math.PI * 0.5, 0, 0, 'leftArmWeapon'),
                makePart('box', 'gold', -0.27, 1.255, 0.36, 0.038, 0.040, 0.062, 0, 0, 0, 'leftArmWeapon')
            ];
        }

        const FIXED_OTTOMAN_INFANTRY = {
            'fixed:ottoman_azap_pike': buildFixedOttomanAzapPike(),
            'fixed:ottoman_azap_pike_sword': buildFixedOttomanAzapPikeSword(),
            'fixed:ottoman_azap_musket': buildFixedOttomanAzapMusket(),
            'fixed:ottoman_janissary_musket': buildFixedOttomanJanissaryMusket(),
            'fixed:ottoman_janissary_sword': buildFixedOttomanJanissarySword(),
            'fixed:ottoman_bostanci_axe': buildFixedOttomanBostanciAxe(),
            'fixed:ottoman_bostanci_pike': buildFixedOttomanBostanciPike(),
            'fixed:ottoman_humbaraci': buildFixedOttomanHumbaraci(),
            'fixed:ottoman_levend': buildFixedOttomanLevend()
        };
    """
