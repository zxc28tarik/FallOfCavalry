with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find("g3d03lTemplates =")
print(text[idx:idx+700])
