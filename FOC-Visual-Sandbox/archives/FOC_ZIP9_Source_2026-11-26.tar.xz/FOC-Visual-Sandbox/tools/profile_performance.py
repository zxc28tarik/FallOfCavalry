import subprocess
import os
import sys
import tempfile
import json
import re

def run_performance_profile(html_path='G3D03F_WORKING.html', timeout=40):
    chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
    if not os.path.exists(chrome_path):
        return {"error": f"Chrome not found at {chrome_path}"}
    
    temp_profile = os.path.join(tempfile.gettempdir(), 'foc_profile_perf_data')
    target_url = 'file:///' + os.path.abspath(html_path).replace('\\', '/') + '#profile'
    
    cmd = [
        chrome_path,
        '--headless',
        '--disable-gpu-sandbox',
        '--enable-webgl',
        '--ignore-gpu-blocklist',
        '--no-sandbox',
        f'--user-data-dir={temp_profile}',
        '--virtual-time-budget=20000',
        '--dump-dom',
        target_url
    ]
    
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, encoding='utf-8', errors='replace')
        dom = proc.stdout
        
        m = re.search(r'<script id="perfProfileData" type="application/json">(.*?)</script>', dom, re.DOTALL)
        if m:
            raw_json = m.group(1).strip()
            data = json.loads(raw_json)
            return data
        
        return {"error": "perfProfileData script tag not found in DOM", "stdout_length": len(dom)}
    except Exception as e:
        return {"error": str(e)}

if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else 'G3D03F_WORKING.html'
    print(f"Running real Chromium performance profile on {target}...")
    res = run_performance_profile(target)
    print(json.dumps(res, indent=2))
