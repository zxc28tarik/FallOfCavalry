import os
import subprocess

with open('G3D03G_WORKING.html', 'r', encoding='utf-8') as f:
    master_html = f.read()

target_phrase = """                        if (buffers.norm && aNorm >= 0) {
                            gl.bindBuffer(gl.ARRAY_BUFFER, buffers.norm);
                            gl.enableVertexAttribArray(aNorm);
                            gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);
                        }

                        const stride = INSTANCE_STRIDE_FLOATS * 4;"""

replacement = """                        if (buffers.norm && aNorm >= 0) {
                            gl.bindBuffer(gl.ARRAY_BUFFER, buffers.norm);
                            gl.enableVertexAttribArray(aNorm);
                            gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);
                        }

                        gl.bindBuffer(gl.ARRAY_BUFFER, batch._glInstanceBuffer);
                        const stride = INSTANCE_STRIDE_FLOATS * 4;"""

for i in range(1, 7):
    dir_path = f"G3D03G/AJANLAR/0{i}"
    for fname in ["WORKING.html", "DELIVERABLE.html"]:
        fpath = os.path.join(dir_path, fname)
        if os.path.exists(fpath):
            with open(fpath, 'r', encoding='utf-8') as f:
                content = f.read()
            if target_phrase in content:
                content = content.replace(target_phrase, replacement)
                with open(fpath, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Updated {fpath}")
            elif "gl.bindBuffer(gl.ARRAY_BUFFER, batch._glInstanceBuffer);" in content:
                print(f"Already updated {fpath}")
            else:
                # Sync master
                with open(fpath, 'w', encoding='utf-8') as f:
                    f.write(master_html)
                print(f"Synced master to {fpath}")

print("All agent files updated successfully!")
