# -*- coding: utf-8 -*-
import json, subprocess, os, re, html as htmllib

html = open('FallOfCavalry_PLAYABLE_RTS.html', encoding='utf-8').read()
script = '''
<script>
try {
    const reg = new SoldierVisualRegistry();
    const parts = reg.templates['g3d03l:european_musketier:high'];
    const summary = parts ? parts.map(p => ({prim: p.prim, mat: p.mat, rig: p.rigGroup})) : null;
    document.title = "PARTS_COUNT_" + (parts ? parts.length : 0);
} catch(e) {
    document.title = "ERROR_" + e.message;
}
</script>
'''
temp_path = os.path.abspath('temp_inspect.html')
open(temp_path, 'w', encoding='utf-8').write(html.replace('</body>', script + '</body>'))

cmd = [
    r'C:\Program Files\Google\Chrome\Application\chrome.exe',
    '--headless=new',
    '--disable-gpu',
    '--dump-dom',
    'file:///' + temp_path.replace(os.sep, '/')
]

res = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=15)
m = re.search(r'<title>(.*?)</title>', res.stdout)
if m:
    print("Page Title Result:", m.group(1))

