# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

import re
methods = re.findall(r'(\b[a-zA-Z0-9_]+\s*\([^)]*\)\s*\{)', text[text.find('class Battle3DPreviewController'):text.find('class Battle3DPreviewController')+5000])
for m in methods[:30]:
    print(m)
