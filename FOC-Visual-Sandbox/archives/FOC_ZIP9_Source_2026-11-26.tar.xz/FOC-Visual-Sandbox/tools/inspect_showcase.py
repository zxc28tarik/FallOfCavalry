with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('rtsShowcaseOverlay')
while pos != -1:
    tag_start = text.rfind('<div', 0, pos)
    print("Found at", pos, "tag_start:", tag_start)
    if tag_start != -1 and 'id=' in text[tag_start:pos+30]:
        print("DOM HTML:")
        print(text[tag_start:tag_start+2500])
        break
    pos = text.find('rtsShowcaseOverlay', pos+1)
