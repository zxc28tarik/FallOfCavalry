with open('FallOfCavalry_PLAYABLE_RTS.html', 'r', encoding='utf-8') as f:
    text = f.read()

needle = "let templateKey = (s.templateKey && this.templates[s.templateKey]) ? s.templateKey : `${side}:${archetype}`;"
idx = text.find(needle)
if idx != -1:
    print(text[idx-500:idx+600])
else:
    print("needle not found")
