# -*- coding: utf-8 -*-
with open('G3D03K_WORKING.html', 'r', encoding='utf-8') as f:
    text = f.read()

start = text.find('class Battle3DPreviewController')
end = text.find('window.addEventListener(\'DOMContentLoaded\'', start)
print(f"Length of Battle3DPreviewController: {end - start}")
print(text[start:start+2500])
