# G3D-03F / AJAN 03 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## 300 ASKERLİ SÜREKLİ GÖRSEL SAVAŞ ÖNİZLEMESİ & DÖNGÜSEL İLERLEME (BULGU A)

### 1. `_buildCombinedPreviewSnapshot(legIndex = 0)` ve 4-Bacaklı Savaş Döngüsü
- Tek seferlik `attack`/`ready` atamasının yarattığı donma (BULGU A) giderildi.
- 4 farklı savaş fazı modellendi:
  - **Bacak 0 (İntikal / İlerleme - Advance):** Ön saflar çatışma hattında, orta ve arka saflar ileri intikalde (`moving` ile ileri `targetPosition`), kanat süvarileri hazır.
  - **Bacak 1 (Ön Hat Çarpışması / Yaylım Ateşi - Clash & Volley):** Tüfekçiler yaylım ateşi fazında (`attack`), mızraklılar hücumda (`attack`), süvari taarruzu aktif.
  - **Bacak 2 (Mızrak İtme & Doldurma Döngüsü - Push of Pike & Reload):** Tüfekçiler doldurma pozisyonuna geçerken (`ready`), mızraklılar itişme/savunma fazında, süvari ikinci hamlesini yapar.
  - **Bacak 3 (Yeniden Düzen Alma / Manevra - Re-formation):** Hatlar destek intikali ve toparlanma yapar, ardından kesintisiz biçimde Bacak 0'a döner.
- Her bacakta 300 asker korunur; `attackCount > 0` ve `readyCount > 0` garanti edilir.

### 2. `_onFrameTick(dt)` Sürekli İlerleme Entegrasyonu
- `_onFrameTick(dt)` metoduna `else if (this.combinedPreviewActive)` dalı eklendi.
- Her 2.8 saniyede bir `combinedPreviewLeg = (combinedPreviewLeg + 1) % 4` mantığıyla bacak ilerletilir ve `{ preserveCamera: true }` ile render senkronizasyonu yapılır.
- `toggleCombinedPreview()` içinde zaman sayaçları (`combinedPreviewElapsed = 0`, `combinedPreviewNextLegAt = 2.8`) sıfırlanır.

### 3. Test 47 Sertleştirildi (QA Hardening)
- `47. Birleşik Animasyon Önizlemesi (300 Asker Savaş & İntikal Döngüsü, 4 Bacaklı İlerleme, HUD & Kamera Koruma Doğrulaması)`
- 4 bacağın tamamında 300 asker, `attack` ve `ready` sayıları doğrulandı.
- `probe._onFrameTick(3.0)` simülasyonu ile otomatik bacak ilerlemesi kanıtlandı.
- Karşılıklı dışlama ve kapatma anında 300 asker ile kamera koordinatlarının korunması test edildi.

### 4. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 50 / 50 test BAŞARILI (%100).
- BULGU A eksiksiz çözüldü, simülasyon verisi yan etkisi sıfır.
