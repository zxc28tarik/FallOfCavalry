# G3D-03F / AJAN 03 GÖREV BELGESİ
## 300 ASKERLİ SÜREKLİ GÖRSEL SAVAŞ ÖNİZLEMESİ & DÖNGÜSEL İLERLEME (BULGU A)

### Görev Tanımı
1. ChatGPT bağımsız QA denetiminde tespit edilen **BULGU A**'yı çöz:
   - `_buildCombinedPreviewSnapshot()` fonksiyonunu 4 taktik bacaklı (leg) döngüsel sistem haline getir.
   - Her bacakta 300 askerin karma piyade & süvari formasyonunda savaş (`attack`), intikal (`moving`) ve toparlanma/hazır (`ready`) durumlarını dinamik olarak güncelle.
   - `_onFrameTick(dt)` içine `else if (this.combinedPreviewActive)` döngüsünü entegre et; 2.8 saniyede bir bacakları ilerlet ve sahne kamerasını sarsmadan senkronize et.
2. Karşılıklı dışlama (mutual exclusion) kuralını koru (Yürüyüş, Süvari, 5 At Tipi ve Birleşik önizlemeler asla aynı anda açık kalamaz).
3. Önizleme kapatıldığında (`toggleCombinedPreview`) kamera hedefi, mesafesi ve orijinal 300 asker verisinin eksiksiz restore edilmesini sağla.
4. Test 47'yi 4 taktik bacak, kare ilerlemesi (`_onFrameTick`) ve kamera koruması yönünde sertleştir; 50/50 test başarısını sağla.
