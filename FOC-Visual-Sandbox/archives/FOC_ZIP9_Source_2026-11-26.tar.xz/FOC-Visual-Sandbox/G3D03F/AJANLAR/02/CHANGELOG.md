# G3D-03F / AJAN 02 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## PİYADE HAREKET VE SAVAŞ GEÇİŞLERİ & QA HARDENING

### 1. `SoldierVisualRegistry.prototype.update(dt)` & Piyade Kinematiği
- Ateşli silah namlu çıkış algılayıcısına (`isFirearm`) piyade tüfekçisi (`infantry_musketeer`) ve süvari ateşli silahları entegre edildi.
- Faz aralığı geçiş kontrolü (`crossingFire` / `insideFire`) ile tüfekçinin $0.28 \le phase < 0.44$ ateş anında duman ve parlama üretimi güvenli hale getirildi.
- Hareket halindeyken saldırı ve saldırı ortasında hareket emri durumunda `actionBlend` ile `walkBlend` ağırlıklı toplamının sayısal olarak geçerli matrisler ürettiği ve ayak kayma telafisinin korunduğu doğrulandı.

### 2. Test 46 Sertleştirildi (QA Hardening)
- `46. Piyade Savaş Animasyonları (Mızrak, Tüfek, Kılıç-Kalkan) Geçiş Yumuşaklığı, Ayak Kaymama, Doldurma & Hareketli Saldırı Doğrulaması`
- Mızrak uzanımı ($> 0.60$), tüfek dipçik omza yaslanma ($dx \le 0.12$), kılıç savurma esnasında kalkan göğüs siperi ($|shieldDx| \le 0.16$) korundu.
- Hareket halinde mızrak hamlesi (`computeInfantryPartLocalMatrix` ile `walkBlend = 0.7`, `actionBlend = 0.8`, `actionMode = 'attack'`) simüle edilerek bacak ve silah matrislerinin sayısal kararlılığı kanıtlandı.

### 3. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 50 / 50 test BAŞARILI (%100).
- Sıfır gerileme, model şablonları ve 442 asker kaynak verisi eksiksiz korundu.
