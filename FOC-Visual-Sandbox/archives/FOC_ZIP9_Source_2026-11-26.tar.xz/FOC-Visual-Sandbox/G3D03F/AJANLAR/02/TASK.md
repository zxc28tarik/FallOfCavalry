# G3D-03F / AJAN 02 GÖREV BELGESİ
## PİYADE HAREKET VE SAVAŞ GEÇİŞLERİ & QA HARDENING

### Görev Tanımı
1. Piyade birimleri (mızraklı, tüfekçi, kılıç-kalkanlı) için yürüme, koşma, savaş pozuna geçiş ve toparlanma döngülerini birbirine bağla.
2. Tüfekçinin ateşleme sonrası doldurma animasyonunu kesintisiz döngüye al (Ateş → Barut Koyma → Harbi Çekme → Doldurma → Hazır).
3. Mızraklının hücum pozunda ileri hamle yaparken ayak kaymasını engelle (foot-slide compensation).
4. Kılıç-kalkanlı askerin savunma ve savurma fazlarında kalkanın göğüs merkezini korumasını garanti et.
5. Hareket halinde saldırı komutu veya saldırı ortasında hareket emri senaryolarında matris sürekliliğini doğrula.
6. Test 46'yı sertleştir ve 50/50 test başarısını sağla.
