# G3D-03F / AJAN 04 GÖREV BELGESİ
## AT KİNEMATİĞİ VE DÜNYA KOORDİNATLARINDA ZEMİN TEMASI (BULGU E)

### Görev Tanımı
1. ChatGPT bağımsız QA denetiminde tespit edilen **BULGU E**'yi çöz:
   - Toynak kinematiğinin yalnızca izole yerel matris üzerinden değil, asker dünya matrisi ($M_{world} = M_{soldier} \times M_{local}$) ve gerçek model şablonu (`templates`) üzerinden zeminle fiziksel temasını ($Y_{world} \ge -0.05$) doğrula.
2. 4-zamanlı adımlama (walk) ve 2-zamanlı tırıs (trot) hareketlerinde toynak ucunun zemin içine gömülmediğini ve duruş (stance) fazında zemin kotuna ($y = 0.00$) oturduğunu kanıtla.
3. Binicinin alt gövdesinin (`riderLower`) at gövdesinin salınımıyla uyumlu biçimde eyer temasını ($-0.05 \le riderDy \le 0.15$) koruduğunu doğrula.
4. Test 48'i dünya koordinatları, gerçek model şablonu parçaları ve 16 adımlık döngü boyunca sertleştir; 50/50 test başarısını sağla.
