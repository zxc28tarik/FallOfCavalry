# G3D-03F / AJAN 04 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## AT KİNEMATİĞİ VE DÜNYA KOORDİNATLARINDA ZEMİN TEMASI (BULGU E)

### 1. Gerçek Model Şablonu ve Dünya Koordinat Doğrulaması
- Sahte (dummy) birim matris parçaları yerine `createSoldierPartTemplates()` içindeki gerçek süvari şablonu parçaları (`horseLegFLLower` frustum toynak ve `riderLower` eyer oturuşu) kullanıldı.
- Süvari askerinin dünya dönüşüm matrisi ($M_{world} = M_{soldier} \times M_{local}$) bileşimi kurularak toynak tabanının ($y = -0.5$ frustum ucu) dünya koordinatları hesaplandı.

### 2. Test 48 Sertleştirildi (QA Hardening & BULGU E Çözümü)
- `48. At Yürüyüş-Tırıs Geçiş Yumuşaklığı, Toynak Dünya Koordinat Zemin Teması ve Binici-Eyer Uyum Doğrulaması`
- Yürüyüş ($tb = 0.0$), ara geçiş ($tb = 0.5$) ve tırıs ($tb = 1.0$) hareketlerinde 16 adım boyunca dünya Y kotu denetlendi.
- Duruş fazında toynak tabanının zemin seviyesine ($y \approx 0.00$) oturduğu, salınım fazında yumuşakça yükseldiği ve zemin içine batmadığı ($bottomY \ge -0.05$) kanıtlandı.
- Binici eyer dikey yer değiştirmesinin ($-0.05 \le riderDy \le 0.15$) korunduğu ve duruş anında referans pozuna tam dönüş sağlandığı doğrulandı.

### 3. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 50 / 50 test BAŞARILI (%100).
- BULGU E tamamen çözüldü, model bütünlüğü ve kinematik kararlılık korundu.
