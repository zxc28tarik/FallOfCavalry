# G3D-03F / AJAN 05 GÖREV BELGESİ
## WEBGL KAYNAK YAŞAM DÖNGÜSÜ VE KARA BARUT (BULGU B & BULGU D)

### Görev Tanımı
1. ChatGPT bağımsız QA denetiminde tespit edilen **BULGU B**'yi çöz:
   - `SoldierVisualRegistry.prototype.invalidateGpuHandles()` içinde `BlackPowderFxPool.invalidateGpuHandles()` çağrısını entegre et.
   - `BlackPowderFxPool.prototype.invalidateGpuHandles()` içindeki hatalı `this.powderFxPool` referansını düzelt; parçacık batch'inin `_gl`, `_glInstanceBuffer` işaretçilerini sıfırla ve `_needsUpload = true` bayrağını kur.
2. ChatGPT bağımsız QA denetiminde tespit edilen **BULGU D**'yi çöz:
   - Registry simülasyon döngüsünde (`update(dt)`) her karede yeni Float32Array, geçici matris veya nesne tahsis edilmediğini (sıfır GC baskısı) kanıtla.
   - Önceden tahsis edilmiş scratch matrislerinin (`_scratchA`, `_scratchB`, `_tmpPartLocalMat`, `_tmpWorldPartMat`) yeniden oluşturulmadan referans kararlılığıyla kullanıldığını doğrula.
3. Süvari ateşli silahları (`cavalry_carbine`, `cavalry_pistol`) için namlu dumanı ve parlama üretimini $0.34 \le phase < 0.50$ fazında süvari yüksekliğine ($y = 1.75$) kilitle.
4. Test 49'u GPU handle temizliği, context kaybı simülasyonu ve sıfır GC referans kararlılığı yönünde sertleştir; 50/50 test başarısını sağla.
