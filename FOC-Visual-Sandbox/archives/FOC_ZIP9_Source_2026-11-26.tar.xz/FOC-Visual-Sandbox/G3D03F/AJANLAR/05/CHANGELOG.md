# G3D-03F / AJAN 05 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## WEBGL KAYNAK YAŞAM DÖNGÜSÜ VE KARA BARUT (BULGU B & BULGU D)

### 1. GPU Handle Sıfırlama ve Context Kaybı Onarımı (BULGU B)
- `BlackPowderFxPool.prototype.invalidateGpuHandles()` yöntemi yeniden yazıldı:
  - Batch'in `_gl = null`, `_glInstanceBuffer = null` ve `_needsUpload = true` durumuna getirilmesi sağlandı.
  - Varsa alt `batchGroup.invalidateGpuHandles()` zincirleme tetiklendi.
- `SoldierVisualRegistry.prototype.invalidateGpuHandles()` içine `this.powderFxPool.invalidateGpuHandles()` çağrısı eklendi.
- WebGL Context kaybı ve geri kazanımında asılı GPU nesnesi kalmaması garanti altına alındı.

### 2. Sıfır GC ve Scratch Matris Referans Kararlılığı (BULGU D)
- `SoldierVisualRegistry.prototype.update(dt)` iç döngüsünde her kare matris oluşturma kaldırıldı; `_scratchA`, `_scratchB`, `_tmpPartLocalMat`, `_tmpWorldPartMat` tamponları yeniden tahsis edilmeden kullanıldı.
- 100 karelik ve 300 askerlik simülasyon adımlarında scratch nesnelerinin referans eşitliği korundu.

### 3. Süvari Ateşli Silah Olay Akışı
- Karabina ve tabancalı süvariler için ateş anında namlu çıkış koordinatları ($y = 1.75$, $fwd = 0.65$) hesaplandı.
- Faz aralığı geçiş kontrolü (`crossingFire` / `insideFire`) ile deşarj anında tek seferlik parlama ve duman üretimi sağlandı.

### 4. Test 49 Sertleştirildi (QA Hardening)
- `49. Kara Barut Efekt Havuzu (64 Slot), GPU Handle Yaşam Döngüsü, Sıfır GC Tahsisi ve Context Kaybı Doğrulaması`
- Registry üzerinden context kaybı simüle edilerek BlackPowderFxPool batch tamponlarının sıfırlandığı ve yeniden yükleme bayrağının (`_needsUpload = true`) açıldığı test edildi.
- Simülasyon döngüsünde scratch matris referanslarının değişmediği kanıtlandı.

### 5. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 50 / 50 test BAŞARILI (%100).
- BULGU B ve BULGU D eksiksiz çözüldü.
