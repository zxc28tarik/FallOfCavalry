# G3D-03F / AJAN 01 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## SÜVARİ ANİMASYON OLAY AKIŞI VE QA HARDENING

### 1. `SoldierVisualRegistry.prototype.update(dt)` İyileştirmeleri
- Süvari ateşli silahları (`cavalry_carbine`, `cavalry_pistol`) için görsel deşarj anında namlu parlaması ve duman üretimi eklendi:
  - Süvari yüksekliğine uygun namlu konumu ($yOffset = 1.75$, $fwdOffset = 0.65$) hesaplandı.
  - Faz geçiş algılayıcısı (`crossingFire` / `insideFire`) ile $0.34 \le phase < 0.50$ aralığında tek seferlik ve tutarlı efekt tetiklenmesi sağlandı.
- Saldırı devam ederken hareket emri gelmesi durumunda yumuşak sönümlenme (`actionBlend` ve `walkBlend` eşzamanlı interpolasyonu) korundu.

### 2. Test 45 Sertleştirildi (QA Hardening)
- `45. Süvari Savaş Animasyonları (Mızrak, Kılıç, Karabina, Tabanca) Geçiş Yumuşaklığı, Toparlanma, Olay Akışı & Kesinti Toleransı`
- 4 süvari sınıfında başlangıç/ara/bitiş pozları doğrulandı.
- Saldırı ortasında (`actionBlend = 0.8`) hareket geçişi (`walkBlend = 0.6`) simüle edilerek matris elemanlarının geçerliliği ve sayısal kararlılığı kanıtlandı.

### 3. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 50 / 50 test BAŞARILI (%100).
- Sıfır gerileme, sıfır NaN matris hatası.
