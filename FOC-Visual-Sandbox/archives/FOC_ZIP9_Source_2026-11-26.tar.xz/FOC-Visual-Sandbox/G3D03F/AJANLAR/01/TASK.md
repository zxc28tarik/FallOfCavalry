# G3D-03F / AJAN 01 GÖREV BELGESİ
## SÜVARİ ANİMASYON OLAY AKIŞI VE QA HARDENING

### Görev Tanımı
1. Süvari birimleri (mızraklı süvari, süvari kılıçlı, karabinalı ve tabancalı süvari) için sürekli görsel eylem döngüsü kur (Hareket → Hazırlanma → Saldırı → Toparlanma → Hareket).
2. Mızrak hücum uzanımını atın ileri hareketiyle eşleştir.
3. Kılıç savuruşunda at-binici ve el-silah bağlantılarını koru; at boynundan yan açıklığı muhafaza et.
4. Karabina ve tabanca ateşleme anını görsel animasyon olayı olarak üret ve namlu parlaması/duman efektiyle eşleştir.
5. Görsel olayların yanlışlıkla gerçek savaş mekaniği (hasar/isabet) oluşturmasını engelle.
6. Saldırının yarıda kesilmesi (hareket komutu verilmesi) ve tekrar başlaması senaryolarında matris geçerliliğini doğrula.
7. Test 45'i sertleştir ve 50/50 test başarısını sağla.
