# G3D-03F / AJAN 06 GÖREV BELGESİ
## GERÇEK PERFORMANS, GÖRSEL QA VE TEST ALTYAPISI (BULGU C)

### Görev Tanımı
1. ChatGPT bağımsız QA denetiminde tespit edilen **BULGU C**'yi çöz:
   - Test 50'nin mock WebGL ile sınırlı kalmasını aşarak gerçek tarayıcı ortamında (Chromium) çalışan profil çıkarma betiği (`tools/profile_performance.py`) geliştir.
   - Gerçek tarayıcıda WebGL donanım hızlandırma / SwiftShader durumunu, 300 askerin render edildiği sahnede FPS, P95/P99 kare gecikmelerini ve bellek değişimini 8 farklı senaryoda ölç.
2. 7 instanced batch çizim çağrısı mimarisini ve teğet kenar ışığı (rim light) faktörlerini doğrula.
3. Test 50'yi ve performans profilleme altyapısını sertleştir; 50/50 test başarısını sağla.
