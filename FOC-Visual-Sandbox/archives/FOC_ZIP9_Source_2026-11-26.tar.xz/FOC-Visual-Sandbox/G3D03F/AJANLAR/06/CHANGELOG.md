# G3D-03F / AJAN 06 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## GERÇEK PERFORMANS, GÖRSEL QA VE TEST ALTYAPISI (BULGU C)

### 1. 7 Instanced Batch ve Rim Light Doğrulaması
- 300 askerlik sahnede tüm görsel parçaların tam 7 geometri/malzeme grubuna (`InstancedBatchGroup`) toplandığı ve GPU'ya instanced array olarak aktarıldığı doğrulandı.
- Teğet yüzeylerde silüet okunurluğunu sağlayan $pow(1.0, 3.2) \times 0.32 \ge 0.30$ rim light faktörü ve doğrudan yüzeylerde sıfır katkı kuralları korundu.

### 2. Gerçek Headless Chromium Performans Profilleyicisi (`tools/profile_performance.py`)
- Mock WebGL testinin ötesine geçilerek gerçek Chrome tarayıcısında WebGL bağlamı açan ve 8 senaryoda mikrosaniye hassasiyetinde ölçüm alan bağımsız profilleme aracı yazıldı.
- Ölçülen senaryolar:
  1. `idle`: 300 asker durağan (Merkez sektör)
  2. `walk`: Piyade intikal önizlemesi
  3. `cavalry`: Süvari tırıs önizlemesi
  4. `combat`: Savaş pozları
  5. `combined`: 300 asker 4-bacaklı birleşik savaş akışı
  6. `sector_switch`: Sektörler arası geçiş (300 -> 62 -> 50 -> 300)
  7. `context_loss_restore`: WebGL context kaybı ve kurtarma
  8. `endurance`: 500 kare kesintisiz dayanıklılık döngüsü

### 3. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 50 / 50 test BAŞARILI (%100).
- BULGU C için bağımsız ölçüm ve raporlama altyapısı kuruldu.
