# AJAN 5: Küçük namlu parlaması ve kara barut dumanı

GÖREV: Yalnız mevcut piyade tüfek ateş görsel fazına bir kez tetiklenen, ömrü kısa, çok hafif namlu parlaması ve kara barut dumanı ekle. Havuzlanmış GL kaynakları kullan; her frame mesh/buffer yaratma, sürekli smoke yok. Gerçek cephane, damage/fireRate ekleme. 7 soldier batch ve yaşam döngüsünü bozma.

TÜM AJANLARIN ZORUNLU KAPILARI:
- Kendi WORKING.html dosyan dışında hiçbir dosyayı DEĞİŞTİRME; sonuç DELIVERABLE.html olarak kendi klasörüne, rapor CHANGELOG.md olarak kendi klasörüne yaz.
- Ortak BASE ve diğer ajanların dosyaları salt okunur. GitHub commit/push/merge, Unity veya gerçek FallOfCavalry savaş koduna dokunma.
- 206 model şablonunun bütün prim/mat/localMat değerleri, 200 süvari varyantı, 44/43/41 piyade parçaları, 12 grup ve 442 askerlik ham veri korunacak.
- 37 mevcut test silinmeyecek, gevşetilmeyecek veya başarı sayısı uydurulmayacak. Aynı viewId, activeWeapon, armorLoadout, mountType ve HP sabit.
- 150/150 görünür limit; merkez300, batı62, doğu50, boş0; önceki piyade/at animasyonları, kamera, WebGL lifecycle korunacak.
- SADECE görsel state ve poz. Savaş AI, yol bulma, fizik, hasar, çarpışma, gerçek oyun animasyon otoritesi, cephane YASAK.
- Gerçek Chromium/WebGL testi yapabiliyorsan çalıştır; yapamıyorsan TEST EDİLMEDİ yaz. FPS veya file:// testi uydurma.
- Çıktıyı başka ajanlarla otomatik birleştirme. Sadece tek DELIVERABLE.html, CHANGELOG.md ve mümkünse PATCH.diff / test PNG üret. Bitince DUR.
