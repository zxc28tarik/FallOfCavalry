# AJAN 5 (05_KARA_BARUT) - DEĞİŞİKLİK GÜNLÜĞÜ VE DOĞRULAMA RAPORU

**Paket / Faz:** Fall of Cavalry - G3D-03D (05_KARA_BARUT)  
**Tarih:** 2026-11-24  
**Durum:** TAMAMLANDI (38 / 38 Test Başarılı)  
**Çalışma Dosyası:** `c:\Users\zxc28\Desktop\FOC-Visual-Sandbox\FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\05_KARA_BARUT\WORKING.html`  
**Teslim Dosyası:** `c:\Users\zxc28\Desktop\FOC-Visual-Sandbox\FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\05_KARA_BARUT\DELIVERABLE.html`  

---

## 1. GÖREV ÖZETİ VE KAPSAM
Yalnız mevcut 1650 piyade tüfek/arkebüz ateş görsel fazına (`infantry_musketeer` için `actionPhase in [0.28..0.44]`) bir kez tetiklenen, ömrü kısa, çok hafif namlu parlaması (muzzle flash) ve kara barut dumanı (black powder smoke) efekti eklendi.
- **Havuzlanmış Kaynaklar:** Sabit kapasiteli (64 parçacık slotu) CPU ve GPU havuz yapısı kullanıldı. Kare başına (`frame-by-frame`) yeni mesh, buffer veya nesne üretilmez.
- **Sürekli Duman Engeli:** Ateş döngüsü başına tek seferlik tetikleme bayrağı (`muzzleFired`) ile continuous smoke kesinlikle engellendi.
- **Gerçekçi 17. Yüzyıl Görseli:** Muzzle flash için anlık altın sarısı/sıcak alev (~0.07s), kara barut dumanı için namlu ucundan ileri ivmeyle fırlayıp yukarı doğru süzülerek genişleyen ve sönümlenen gri-kükürt tonlu duman bulutu (~0.5s) üretildi.
- **7 Soldier Batch ve Yaşam Döngüsü Korundu:** Askerlerin 7 instanced batch yapısına dokunulmadı; asker batch'leri merkez sektörde 7, boş sektörde 0 olarak sabit kaldı.
- **Mevcut 37 Test Korundu & Test 38 Eklendi:** Önceki 37 testin tamamı eksiksiz korundu. Namlu parlaması ve kara barut duman havuzunun GPU buffer sızıntısı yapmadığını ve kaynak temizliğini doğrulayan **Test 38** eklendi.

---

## 2. YAPILAN TEKNİK DEĞİŞİKLİKLER

### A. `BlackPowderFxPool` Sınıfı Eklendi
- Sabit kapasiteli (64 slot) Float32Array (`64 * 21 floats`) ve parçacık havuzu oluşturuldu.
- Parçacık tipleri:
  1. **Namlu Parlaması (isFlash):** Parlak sıcak alev (`r:1.0, g:0.88, b:0.48, alpha:0.95`), namlu ucunda ~0.18m'den ~0.06m'ye küçülerek ~0.07s içinde sönümlenir.
  2. **Kara Barut Dumanı (Smoke):** Namlu yönü ve konik yayılımla fırlayan 3 adet hafif duman kümesi (`r:0.76, g:0.76, b:0.73, alpha:0.58`), aerodinamik sürtünmeyle yavaşlar, yukarı süzülür (`vy`), ~0.08m'den ~0.32m'ye genişler ve ~0.5s içinde sönümlenir.
- **Havuz Yönetimi:** Slotlar dolduğunda en yaşlı parçacık dairesel olarak yeniden kullanılır; çöp toplayıcı (GC) yükü 0'dır.
- **GPU Entegrasyonu:** Mevcut `InstancedBatchGroup` ve `sphere` geometri tamponları yeniden kullanılır; ayrı shader veya 4. program eklenmez.

### B. `SoldierVisualRegistry` ve Namlu Konumu Entegrasyonu
- `SoldierVisualRegistry` içine `this.powderFxPool = new BlackPowderFxPool(64, this.geometries.sphere)` bağlandı.
- Askerin dünya matrisi (`rec.worldMat`), yönü (`rec.yaw`) ve tüfek namlu ucu yerel ofsetleri (`forward: 1.40m, height: 1.38m, side: -0.035m`) kullanılarak tam namlu ucu koordinatı hesaplandı.
- `update(safeDt)` içerisinde tüfekçi ateş fazına girdiğinde (`0.28 <= phase < 0.44`) `rec.muzzleFired` ile yalnız 1 kez tetikleme yapıldı.
- Sektör değişimi, boş veri ve `dispose` durumlarında `powderFxPool.clear()` ve `powderFxPool.dispose()` çağrıları entegre edildi.

### C. `WebGLRenderer` Instanced Buffer Havuz Güncellemesi
- `_renderInstancedBatches` fonksiyonunda, havuz instance buffer'ı ilk render sırasında `gl.createBuffer()` ve `gl.bufferData` ile oluşturulacak şekilde düzenlendi.
- Sonraki tüm animasyon ve ateşleme karelerinde mevcut buffer `gl.bufferSubData` ile yerinde güncellendi; kare başına yeni GPU buffer oluşturulması kesin olarak engellendi.
- Kapatma sırasında `InstancedBatchGroup.dispose()` ile `gl.deleteBuffer()` çağrılarak tam temizlik sağlandı.

### D. Test 38 Eklendi & UI Başlığı Güncellendi
- UI başlığı ve kod içi yorumlar `G3D-03D (38/38 Test)` olarak güncellendi.
- `Test 38: Kara Barut Dumanı & Namlu Parlaması Havuzu GPU Buffer Sızıntısı Yok Doğrulaması (G3D-03D Ajan 5)` eklendi.

---

## 3. DOĞRULAMA VE TEST SONUÇLARI

Gerçek Chromium / Microsoft Edge Headless motoru (`--headless --disable-gpu`) ile `WORKING.html?runTests=1` üzerinde çalıştırılan birim test sonuçları:

```
Sonuç: 38 / 38 doğrulama testi başarıyla geçti.
```

Tüm testlerin durumu:
- ✔ 1. Merkez Sektörde 300 Asker, 7 Batch (<= 10) & R2 Gruplarının Korunması
- ✔ 2. B2 Piyade Şablonlarının (44, 43, 41 Parça) & Anatomik At Modellerinin Doğrulanması
- ✔ 3. Süvari Aktif Silah Seçimi (activeWeapon: Mızrak, Kılıç, Karabina, Tabanca) Doğrulanması
- ✔ 4. Aynı Asker İçin Çift Oluşturma Önleme (viewId Güncelleme) & Boş Sektör Temizliği
- ✔ 5. RTSCamera3D Sınır Kelepçeleme ve Yaşam Döngüsü (Init -> Dispose -> Re-Init)
- ✔ 6. Shader Programı Link Hatasında Güvenli Başarısızlık & GPU Program Temizliği
- ✔ 7. WebGL Context Oluşturulamadığında Düzgün Fallback & Sahnenin Aktif Olmaması
- ✔ 8. Kapatma, Çift Kapatma ve Yeniden Başlatmada Kaynak & Dinleyici Temizliği
- ✔ 9. WebGL Yok Testi Sonrasında Tekrar Çalışma (Başlat -> WebGL Yok -> Yeniden Başlat)
- ✔ 10. Boş Veri ve Normal Asker Verisi Arasında Geçiş (Normal -> Boş -> Yeniden Başlat / Normal)
- ✔ 11. Instancing Desteği Olmadığında Alternatif Çizim Yolu & Context Kaybı Geri Dönüşü
- ✔ 12. Hareket Sırasında Aynı Asker Kimliğinin (viewId) Korunması
- ✔ 13. Konum Değişiminde Yumuşak İnterpolasyon, Yön Dönüşü & Tekrarlayan Snapshot Koruması
- ✔ 14. Yürüyüş Başlangıcı ve Sonunda Hazır Duruşuna Dönüş (Kendi Kendine Yürümeme)
- ✔ 15. Sağ ve Sol Bacak Hareketlerinin Farklı Fazlarda Olması (Mızraklı, Tüfekçi, Kılıçlı)
- ✔ 16. Silah ve Zırh Modellerinin Korunması (44, 43, 41 Parça & El-Silah Hizası)
- ✔ 17. Sektör Değişiminde Eski Asker ve Animasyon Kayıtlarının Temizlenmesi
- ✔ 18. Boş Veri ve Yeniden Başlatmada Animasyon Kayıtlarının Temizlenmesi
- ✔ 19. GPU Çizim Gruplarının (7 Batch) & Mevcut Buffer Havuzunun Frame Başına Yeniden Oluşturulmaması
- ✔ 20. WebGL Context Kaybı ve Geri Yükleme Sisteminin Yürüyüş Sırasında Korunması
- ✔ 21. Üst Menü ve Test Panelinin Çakışmasız Yerleşimi & Gerçek Fare Tıklaması
- ✔ 22. Yürüyüş Önizlemesi Kimlik, Sınıf, Silah, Ekipman Korunumu ve Kapanış Regresyon Testi
- ✔ 23. Yürüyüş Önizlemesi Kamera Kadrajı Regresyon Testi (Yürüyen Piyade Kümesi & Panel Arası Görünürlük)
- ✔ 24. Çok Aşamalı Yürüyüş (walkPreviewLeg 0 -> 1 -> 2 -> 3) Kamera Odağı & Kullanıcı Kontrolü Koruması
- ✔ 25. Süvari Modellerinin, 206 Görsel Şablonun ve Aktif Silahların (Mızrak, Kılıç, Karabina, Tabanca) Korunması
- ✔ 26. Süvari Snapshot Konum Değişimi, Asker Kimliği Sürekliliği & Hareket Hızı Değişmezliği
- ✔ 27. At Yürüyüşünde (4-Beat Walk) Dört Bacağın Ayrı Fazlarda Hareketi & Diz/Toynak Bağlantısı
- ✔ 28. Tırıs Hareketi (2-Beat Diagonal Trot) & Binici-Eyer-Üzengi-Silah Bütünlüğü
- ✔ 29. Süvari Hareket Önizlemesi, Piyade Önizlemesi ile Karşılıklı Dışlama & Kamera Koruması
- ✔ 30. Sektör Geçişleri, GPU Kaynak Havuzu, Context Kurtarma & 12 Grup / 442 Askerlik Ordu Koruması
- ✔ 31. Mızraklı Piyade Savaş Eylemi (Hazırlanma, İleri Hamle, Bekleme, Geri Çekilme & El-Mızrak Bütünlüğü)
- ✔ 32. Tüfekçi ve Arkebüzcü Nişan Alma, Ateşleme/Geri Tepme, İndirme & Yeniden Doldurma Pozları
- ✔ 33. Kılıç-Kalkanlı Piyade Kontrollü Kılıç Savuruşu & Bağımsız Kalkan Koruma Pozu (Sentetik Test Karakteri)
- ✔ 34. Savaş Pozları Sırasında Model Kimliği, Sınıf, Silah, Konum & Kaynak Veri Değişmezliği
- ✔ 35. Piyade Savaş Pozları Önizlemesi, Diğer Önizlemelerle Karşılıklı Dışlama & Kamera Koruması
- ✔ 36. Savaş Pozlarında 7 Batch, GPU Buffer Yeniden Kullanımı, Sektör Geçişi & WebGL Kurtarma
- ✔ 37. Tek Seferlik Saldırı Eylemi Döngüsü (Tek Saldırı Talebinde Animasyonun Bir Kez Oynayıp Hazır Duruşuna Dönmesi)
- ✔ 38. Kara Barut Dumanı & Namlu Parlaması Havuzu GPU Buffer Sızıntısı Yok Doğrulaması (G3D-03D Ajan 5)

---

## 4. KATI KURAL UYUM ÇİZELGESİ
- [x] Kendi klasörü dışındaki hiçbir dosyaya dokunulmadı (`BASE` ve diğer ajan klasörleri salt okunur tutuldu).
- [x] Unity, git remote, veya gerçek savaş simülasyonu mantığına dokunulmadı.
- [x] Gerçek AI, hasar, mermi fiziği, can kaybı eklenmedi; salt görsel parçacık ve animasyon fazı eklendi.
- [x] 206 model şablonu, 200 süvari varyantı, 44/43/41 piyade parçaları, 12 grup ve 442 askerlik veri korundu.
- [x] 150/150 görünürlük limiti, merkez 300, batı 62, doğu 50, boş 0 korundu.
- [x] 7 asker batch yapısı korundu.
- [x] 37 mevcut test silinmedi veya gevşetilmedi; 38/38 olarak doğrulandı.
- [x] `DELIVERABLE.html` ve `CHANGELOG.md` üretildi.
