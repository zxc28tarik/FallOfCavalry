# AJAN 1: ATLI MIZRAK (01_ATLI_MIZRAK) — DEĞİŞİKLİK RAPORU (CHANGELOG)

**Tarih:** 2026-11-24  
**Görev Kapsamı:** `war_lance` / `lancer` süvarisinin yalnız görsel hazırlanma → ileri mızrak hamlesi → toparlanma → idle animasyonunun oluşturulması; at-eyer-üzengi ve el-mızrak bağlantılarının korunması; gait (yürüyüş/tırıs) ile eylem çakışmasının engellenmesi; 37 mevcut testin korunması ve Test 38'in eklenmesi.  
**Çalışma Dosyaları:**
- Kaynak / Düzenlenen: `WORKING.html`
- Nihai Teslimat: `DELIVERABLE.html`

---

## 1. Yapılan Değişiklikler ve Mimari Uygulama

### A. Atlı Mızrak Savaş Pozu Kinematik Değerlendiricisi (`evaluateCavalryLanceCombatPose`)
- 1650 dönemi demi-lancer / mızraklı süvarisi için özelleşmiş 4 fazlı görsel savaş eylem kinematiği tanımlandı:
  1. **Hazırlanma / Couching (`u in [0.00..0.25]`):** Dinlenme duruşundaki dik açı (~75.6°, 1.32 rad) mızrak seviyesinden hücum seviyesine indirilir; mızrak geriye çekilerek kurulur (`thrust = -0.32 * k`, `weaponDz = -0.136m`), binici gövdesi hafifçe eyerde öne yatar (`torsoPitch = -0.06`).
  2. **İleri Mızrak Hamlesi (`u in [0.25..0.50]`):** Sağ kol, el ve mızrak patlayıcı biçimde öne fırlar (`thrust: -0.32 -> +1.00`, `weaponDz = +0.72m`), mızrak ucu tam hücum açısına oturur (`weaponPitch = 0.38`), binici hamleye eşlik ederek ileri yatar (`torsoPitch = -0.18`).
  3. **Penetrasyon ve Bekleme (`u in [0.50..0.70]`):** Tam uzanışta (`thrust = 1.00`) vuruş derinliği korunur.
  4. **Toparlanma ve Çekilme (`u in [0.70..1.00]`):** Mızrak sarsıntısız biçimde geri çekilir, gövde doğrulur ve başlangıç hazır duruşuna yaklaşır.

### B. Süvari Yerel Matris Kinematik Katmanı (`computeCavalryPartLocalMatrix`)
- `computeCavalryPartLocalMatrix` fonksiyonu eylem parametreleri (`actionPhase`, `actionBlend`, `actionMode`, `archetype`, `partIndex`, `totalParts`) ile genişletildi.
- **At, Eyer ve Üzengi Korunumu:** `riderSaddle` ve `riderLower` parçaları savaş eyleminden doğrudan etkilenmez; yalnızca atın gövde salınımını (`bodyDy`, `bodyPitch`, `bodyRoll`) takip eder. Bu sayede üzengi (`partIndex: 49`) ile binici çizmesi (`partIndex: 59`) arasındaki mesafe (`restFootStirrupDist`) sıfır hata ile korunur; ayak eyerden veya üzengiden asla kopmaz.
- **El ve Mızrak Bağlantısı:** Sağ kol ve mızrak montajı (omuz, ön kol, el, mızrak çanağı, ahşap gövde, çelik uç, flamalar) sağ omuz eklemi `(-0.25, 1.92, -0.04)` pivotundan rijit izometri ile dönüştürülür. Bu sayede sağ el (`tplLen - 6`) ile mızrak ucu (`tplLen - 3`) arasındaki mesafe hamle boyunca matematiksel olarak sabit kalır (`|thrustDist - restDist| < 1e-4`).
- **Gait ile Eylem Çakışmama:** Tırıs (`trotBlend`) ve 4 zamanlı yürüyüş (`walkBlend`) dinamikleri ile mızrak hamlesi ayrıştırıldı. Tırıs sırasında at bacakları ve gövdesi tırıs salınımını sürdürürken, mızrak hamlesi binicinin gövdesine pürüzsüzce katmanlanır (`riderGaitPitch * 0.5 + pose.weaponPitch * ab`).
- **Hazır Duruşuna (Idle) Dönüş:** `actionBlend === 0` ve `walkBlend === 0` olduğunda tüm parçalar orijinal `part.localMat` matrisine 1e-5 hassasiyetle tam olarak geri döner.

### C. Görsel Kayıt Yönetimi (`SoldierVisualRegistry`)
- `sync(snapshot)`: `cavalry_lance` tipi süvariler için snapshot üzerinden gelen `state: 'attack'` / `state: 'combat'` durumları algılanarak tek seferlik görsel saldırı döngüsü başlatıldı.
- `update(safeDt)`: `cavalry_lance` için 1.85 saniyelik tek eylem döngüsü tanımlandı. `actionPhase >= 1.0` olduğunda `isCombatActing` otomatik olarak sonlandırılır (`combatFinished = true`), `actionBlend` sönümlenerek hazır duruşuna dönülür (sonsuz döngü engellendi).
- `setSoldierVisualCombatAction`: `cavalry_lance` türü için görsel eylem tetikleme desteği eklendi.
- `_updateBatchBuffersInPlace` ve `_rebuildInstanceBatches`: Süvari için eylem durumu (`actionBlend > 1e-4`) yerinde GPU buffer güncellemesine bağlandı.

### D. Model Şablonları ve Sınır Koruması
- 206 model şablonunun bütün `prim`, `mat` ve `localMat` değerleri, 200 süvari varyantı, 44/43/41 piyade parçaları, 12 birlik grubu ve 442 askerlik veri tabanı kesinlikle bozulmadan korundu.
- Yalnızca `buildCavalryUnit1650` içinde mızrak kolu parçalarına tanımlayıcı `subGroup = 'lance'` etiketi eklendi (`rigGroup` değeri `'riderUpper'` olarak korundu).

---

## 2. Test Doğrulama ve Sonuçlar

Mevcut 37 birim testinin tamamı korunmuş ve süvarinin görsel mızrak eylemini doğrulayan yeni bir test eklenmiştir:

### Yeni Eklenen Test 38:
**"38. Atlı Mızrak Savaş Eylemi (Hazırlanma, İleri Hamle, Toparlanma, Hazır Duruşuna Dönüş & At-Eyer-Üzengi-Mızrak Bütünlüğü)"**
1. **Sınıflandırma Doğrulaması:** `demi_lancer` + `war_lance` süvarisinin `cavalry_lance` olarak doğru sınıflandırıldığı teyit edildi.
2. **Dinlenme Duruşu Ölçümü:** Başlangıçta binici ayağı ile üzengi arasındaki mesafe (`restFootStirrupDist`) ve sağ el ile mızrak ucu arasındaki mesafe (`restHandToTipDist = 2.6437m > 2.0m`) kaydedildi.
3. **Faz 1 (Hazırlanma / Kurulma - u=0.14):** Mızrak ucunun dinlenme pozisyonuna göre geriye çekildiği (`windupTipZ < restTipZ - 0.08m`), el-mızrak mesafesinin (< 1e-4) ve ayak-üzengi mesafesinin (< 1e-4) korunduğu doğrulandı.
4. **Faz 2 & 3 (İleri Mızrak Hamlesi - u=0.56):** Mızrak ucunun +Z yönünde güçlü biçimde uzandığı (`thrustTipZ > restTipZ + 0.50m`), tam uzanışta el-mızrak bağlantısının (< 1e-4) ve ayak-üzengi bağlantısının (< 1e-4) bozulmadığı doğrulandı.
5. **Gait Çakışmama Testi:** Yüksek tırıs (`walkBlend = 0.85, trotBlend = 0.80`) ile eşzamanlı mızrak hamlesinde ayak-üzengi ve el-mızrak bütünlüğünün (< 1e-4) korunduğu, mızrağın öne uzanışını sürdürdüğü doğrulandı.
6. **Tek Niyet Tek Hareket & Hazır Duruşuna Dönüş:** Tek saldırı talebinin döngüyü tamamladıktan sonra durduğu (`isCombatActing === false, actionBlend === 0, actionPhase === 0`), mızrak ucu ve el matrislerinin ilk dinlenme matrisine (< 1e-5) eşitlendiği, `combatPosingCount` değerinin 0'a döndüğü doğrulandı.

### Chromium Headless Doğrulama Çıktısı:
```text
Platform: Windows (Google Chrome Headless)
Target: DELIVERABLE.html#tests
Result: 38 / 38 doğrulama testi başarıyla geçti.
Failures: 0 (NO FAILURES)
```

---

## 3. Katı Kurallara Uyum Beyanı
- Kendi klasörü (`AJANLAR\01_ATLI_MIZRAK`) haricindeki hiçbir dosyaya dokunulmamıştır.
- Ortak BASE ve diğer ajan klasörleri salt okunur tutulmuştur.
- Git, GitHub commit/push/merge, Unity veya gerçek FallOfCavalry savaş mantığına dokunulmamıştır.
- Gerçek AI, yol bulma, fizik, hasar veya çarpışma mekaniği eklenmemiştir; sadece görsel kinematik ve WebGL çizim katmanı uygulanmıştır.
- `DELIVERABLE.html` ve `CHANGELOG.md` eksiksiz oluşturulmuştur.
