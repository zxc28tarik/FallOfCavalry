# Fall of Cavalry — Antigravity 6 İzole Görsel Ajan Paketi

## Windows'ta kullanım
1. ZIP'i aç. İçindeki FOC_ANTIGRAVITY_6_AJAN_PAKETI klasörünü mevcut FOC-Visual-Sandbox klasörünün içine kopyala.
2. Antigravity'de mevcut FOC-Visual-Sandbox projesini aç, New Conversation'a bas.
3. İleti kutusuna `FOC_ANTIGRAVITY_6_AJAN_PAKETI/KOORDINATOR_PROMPT.md dosyasını oku ve görevlerini uygula.` yaz. Gerekirse KOORDINATOR_PROMPT.md içeriğini doğrudan yapıştır.
4. Agent/Alt ajan desteği hesabında açıksa 6 işi izole ajanlara dağıt. Değilse altı ayrı konuşmada ilgili AJANLAR/XX/TASK.md ile elle başlat; her konuşma yalnız kendi WORKING.html dosyasında çalışmalı.
5. İş bitince altı DELIVERABLE.html ve CHANGELOG.md dosyasını buraya gönder. Nihai QA ve seçici birleştirmeyi ChatGPT yapacak.

## Sınırlar
- Antigravity yalnız görsel uygulama yapar, mimari/Unity/AI/hasar/gerçek oyun entegrasyonu yapmaz.
- Klasördeki BASE_KORUNMUS_G3D03C_R1.html dokunulmaz orijinal referanstır.
- Mevcut kaynak 37/37 kabul edilmiş Chromium testlerine sahiptir; yeni sürümler bu testleri gerçekten geçmelidir.
- Her ajan ayrı WORKING.html üzerinde çalışır; aynı dosyaya eşzamanlı yazmayın. Otomatik merge yok.
- Mevcut 3D prototip FOC_THREE özel WebGL'dir, gerçek FallOfCavalry Unity savaş motoru değildir.
- Önceden kota dolduğu için 6 ajan eşzamanlı çalışmayabilir; 2+2+2 çalışmak da uygundur. Otomatik ücretli kota aşımı yok.
