# FOC — 6 ANTiGRAVITY GÖRSEL AJANI / KOORDİNATÖR TALİMATI

Rolün yalnız görsel üretim koordinatörüdür. Ana geliştirici, mimar, GitHub/BEST sorumlusu, Unity entegrasyoncusu ve nihai QA hakemi ChatGPT'dir.

Bu klasördeki BASE_KORUNMUS_G3D03C_R1.html kaynak dosyası **salt okunur**. SHA256: 8b2eb0974937531fe1734f775335579aa9e171e923262cee27ee73ffaa8e0063. Kaynak, bağımsız testlerde 37/37 PASS almış HTML görsel prototipidir.

ÖNCE AJANLAR altındaki altı TASK.md belgesinin tümünü oku. Her birinin kendi WORKING.html kopyası vardır. Alt ajanların her biri yalnız kendi alt klasöründe değişiklik yapabilir.

Erişim varsa invoke_subagent ile 6 ayrı alt ajanı paralel çağır; her birine kendine ait TASK.md ve çalışma dosyası yolunu açıkça ver. Alt ajanlar aynı dosyayı paylaşamaz. Yerel git repo yoksa worktree oluşturmak şart değildir; birbirinden ayrı WORKING.html dosyalarıyla Local Checkout'ta bile çakışmadan çalışılabilir. Alt ajan mekanizması kullanılamıyorsa 6 ayrı bağımsız konuşma kurulmasını öner ve otomatik başlattığını iddia etme.

Ajan 01: 01_ATLI_MIZRAK / Atlı mızrak görsel eylemi
Ajan 02: 02_ATLI_KILIC / Atlı kılıç görsel eylemi
Ajan 03: 03_ATLI_ATESLI / Atlı karabina ve tabanca nişan pozları
Ajan 04: 04_AT_TOYNAK / At yürüyüş ve tırıs cilası
Ajan 05: 05_KARA_BARUT / Piyade namlu parlaması ve kısa duman
Ajan 06: 06_SAHA_GORSELLIK / Zemin, sis ve savaş alanı okunurluğu

GÜVENLİK: Ortak BASE, main repo, GitHub, BEST, Unity ve diğer ajan klasörleri değişmez. 206 model şablonu / tüm geometri matrisleri / 442 orijinal asker / 37 eski test kayıpsız korunur. Gerçek AI, isabet, hasar, atış, fizik, yol bulma, mekanik entegrasyonu yapılmaz. Sonuçları birleştirmeye çalışma.

KOTA: Önceden kullanım kotası hatası yaşandı. Kotayı ve aynı anda alt ajan limitini kontrol et. 6 eşzamanlı hakkı yoksa 2+2+2 dalga halinde çalıştır. Ücretli overage/upgrade asla açma; kullanıcıdan onay almadan ek masraf yapma.

TESLİM: Her ajandan kendi klasörüne DELIVERABLE.html, CHANGELOG.md ve mümkünse PATCH.diff iste. 37 eski testin gerçek sonuçlarını raporlasın; WebGL test edilemediyse açıkça yazsın. PNG istenirse kendi klasöründe tutulsun. Sonuçları otomatik birleştirme. Koordinatör bir tabloyla 6 ajanın durumunu ve dosya yollarını raporlasın. Başka göreve geçme.
