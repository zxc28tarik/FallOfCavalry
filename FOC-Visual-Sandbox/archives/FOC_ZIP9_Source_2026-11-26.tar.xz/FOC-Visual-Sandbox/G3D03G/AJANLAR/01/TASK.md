# G3D-03G / AJAN 01 GÖREV BELGESİ (REVİZYON 3)
## ÖZEL ALAN: PİYADE SURAT VE KAFA ÇİZGİLERİ (FACIAL & HEAD CONTOURS)

### 1. Görev Tanımı
Kullanıcı emri doğrultusunda Ajan 01 kendini **Piyade Surat ve Kafa Çizgilerini** geliştirmeye adamıştır:
1. İnsan yüz silüetinin belirginleştirilmesi: Alın eğimi, kaş kemeri, burun köprüsü, elmacık kemiği ve çene konturları.
2. 1650 dönemi karakteristik bıyık ve keçi sakalı (musketeer goatee) çizgilerinin yüz anatomisiyle organik birleşimi.
3. Boyun anatomisi (sternocleidomastoid kas eğimi) ve boğaz açılı silindir geçişi.
4. Omuzlara dökülen dantelli rabat yakanın (falling linen collar) kıvrım çizgileri.
5. Pikeman (44 parça), Musketeer (43 parça) ve Swordsman (41 parça) sınırlarını %100 koru.
6. 50/50 test başarısını sağla.
