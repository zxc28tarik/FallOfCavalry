# G3D-03G / AJAN 06 GÖREV BELGESİ (REVİZYON 3)
## ÖZEL ALAN: SAHA FORMASYON ÇİZGİLERİ, BİRLEŞİK KALİTE QA & PERFORMANS DOĞRULAMA (FORMATION LINES, QA & PERFORMANCE)

### 1. Görev Tanımı
Kullanıcı emri doğrultusunda Ajan 06 kendini **Saha Formasyon Çizgileri, Birleşik Kalite QA ve Performans Doğrulamaya** adamıştır:
1. 300 askerlik merkez sektörde kuşbakışı RTS kamerasından tabur, saf ve süvari hatlarının (formasyon çizgilerinin) net okunabilirliği.
2. 5 ajanın geliştirdiği surat, vücut, at ve shader çizgilerinin tek birleşik HTML içinde çakışmasız harmanlanması.
3. 50/50 otomatik birim testin Chromium ortamında eksiksiz doğrulanması.
4. 8 senaryoda Chromium rAF zaman serisi FPS profillemesi, P95/P99 kare süresi ve heap bellek trendinin ölçülmesi.
5. Öncesi/sonrası detaylı görsel karşılaştırma matrisinin güncellenmesi.
