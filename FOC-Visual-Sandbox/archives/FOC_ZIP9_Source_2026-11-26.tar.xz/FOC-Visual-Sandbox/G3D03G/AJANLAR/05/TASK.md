# G3D-03G / AJAN 05 GÖREV BELGESİ (REVİZYON 3)
## ÖZEL ALAN: AT KAFA PROFİLİ, TOYNAK ÇİZGİLERİ & SPEKÜLER KONTUR SHADERI (HORSE PROFILE, HOOVES & CONTOUR SPECULAR)

### 1. Görev Tanımı
Kullanıcı emri doğrultusunda Ajan 05 kendini **At Kafa Profili, Toynak Çizgileri ve Işık-Gölge Vurgularına** adamıştır:
1. Atın kafa profili: İnce burun köprüsü, belirgin burun delikleri, çene kemiği kavisleri ve dik kulak çizgileri.
2. Arka bacaklarda hock/stifle eklem hatları, ön bacaklarda fetlock ve zemine açılı basan toynak geometrisi.
3. Vücut, surat ve at kas çizgilerini ortaya çıkaran Blinn-Phong speküler yansıma ve teğetsel rim lighting shaderı:
   - Parlak zırh çeliği (0.88), altın/pirinç (0.85) ve yağlı çelik (0.62) üzerinde kas ve plaka hatlarını parlatan ışık vurgusu.
4. Sıfır GC ve 7 instanced batch tampon altyapısını muhafaza et.
