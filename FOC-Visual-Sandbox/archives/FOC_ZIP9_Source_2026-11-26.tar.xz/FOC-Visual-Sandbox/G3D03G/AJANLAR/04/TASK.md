# G3D-03G / AJAN 04 GÖREV BELGESİ (REVİZYON 3)
## ÖZEL ALAN: SURAT SİPERLİKLERİ, MİĞFER ÇİZGİLERİ & SİLAH TUTUŞ HATLARI (HELMETS, VISORS & HAND-WELD)

### 1. Görev Tanımı
Kullanıcı emri doğrultusunda Ajan 04 kendini **Surat Siperlikleri, Miğfer Çizgileri ve El Tutuş Hatlarına** adamıştır:
1. Morion miğferinin kavisli yüksek tarak çizgisi ve perçinli siperlik hatları.
2. Zischägge miğferinin 3 barlı yüz siperi (triple nasal bar) ve kulaklık kalkanı konturları.
3. Doğu miğferi (şişak) burun koruma demiri, tepe alemi ve yanaklık siperlikleri.
4. El bileği ve modellenmiş parmak çizgileri: Mızrak, tüfek ve kılıç kabzasını kavrayan hand-weld geometrisi (İndeks 35 el, İndeks 40 namlu mesafesi tam korunmalı).
5. Kinematik animasyon uyumunu ve Test 16 / Test 46 geçişini sağla.
