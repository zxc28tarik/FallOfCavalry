# G3D-03G / AJAN 02 GÖREV BELGESİ (REVİZYON 3)
## ÖZEL ALAN: AT GÖVDE, BOYUN VE SAĞRI ÇİZGİLERİ (HORSE MUSCULATURE & SILHOUETTE CONTOURS)

### 1. Görev Tanımı
Kullanıcı emri doğrultusunda Ajan 02 kendini **At Gövde, Boyun ve Sağrı Çizgilerini** geliştirmeye adamıştır:
1. Atın asil silüetini oluşturan kavisli boyun tepesi (crested neck) ve omuz geçiş çizgileri.
2. Göğüs kas kütlesi (pectoralis major) ve derin kaburga kafesi konturları.
3. Karın çekikliği (flank tuck) ve güçlü eğimli sağrı (sloping croup) hatları.
4. Çift katmanlı dalgalı kuyruk ve boyun boyunca uzanan yele çizgileri.
5. Test 48 kapsamındaki toynak zemin teması (bottomY >= -0.05) ve binici-eyer uyumunu (-0.05 <= riderDy <= 0.15) koru.
6. 5 at ırkının (Warhorse, Charger, Courser, Rouncey, Steppe) gövde oranlarını zenginleştir.
