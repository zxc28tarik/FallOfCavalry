# G3D-03G / AJAN 03 GÖREV BELGESİ (REVİZYON 3)
## ÖZEL ALAN: VÜCUT ZIRHI VE KIYAFET HATLARI (BODY ARMOR & UNIFORM SILHOUETTE)

### 1. Görev Tanımı
Kullanıcı emri doğrultusunda Ajan 03 kendini **Vücut Zırhı ve Kıyafet Hatlarını** geliştirmeye adamıştır:
1. Merkezi omurgalı göğüs zırhı (peascod cuirass tapul ridge) ve kurşun geçirmez çelik bombe çizgileri.
2. Kalçadan dizlere inen 3 kademeli mafsallı butlukların (laminated tassets) bacak üstü kıvrım çizgileri.
3. 1650 dökümlü ceket etekleri (doublet basques) ve altın sırma kenar şeritleri.
4. Form-fitted rhingrave breeches ve bacak hareketini destekleyen kumaş pileleri.
5. 7 Instanced batch ve 206 model şablonu sınırını koru.
