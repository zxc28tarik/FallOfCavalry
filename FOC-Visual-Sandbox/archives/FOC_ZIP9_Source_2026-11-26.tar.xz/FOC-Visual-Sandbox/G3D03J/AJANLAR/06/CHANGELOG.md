# AJAN 06 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSUnitShowcaseController` sınıfı.
- Eklendi: `#btnOpenShowcase` üst bar butonu.
- Eklendi: `#rtsShowcaseOverlay` interaktif vitrin modalı.
- Eklendi: Varyant 1 / 2, Idle / Walk / Attack / Guard ve Yan Yana Karşılaştır kontrolleri.
- Eklendi: Test 64 (Asker Vitrini Doğrulaması).
