# AJAN 04 — MODÜLER DONANIM HAVUZLARI VE KÜLTÜR AYIRIMI

## 1. GÖREV TANIMI
Askerlerin donanımlarını modüler ve genişletilebilir bir veri tabanına bağlamak:
- `RTS_EQUIPMENT_POOLS` nesnesi altında kültür ayrımı (`ottoman` ve `european`).
- Donanım kategorileri: `headwear`, `armor`, `weapons`, `shields`, `mounts`.
- Kültür izolasyonu: Osmanlı havuzundaki yatağan, sarık, börk, çevşen, leopar postu Avrupa havuzunda yer alamaz; Avrupa havuzundaki morion, tapul, hellebarda, burgonet Osmanlı havuzunda yer alamaz.
- `resolveUnitEquipment(culture, unitClass, seed)` fonksiyonu ile deterministik yükleme üretimi (aynı seed her zaman aynı donanım kombinasyonunu üretir).

## 2. TAMAMLANAN GELİŞTİRMELER
- `RTS_EQUIPMENT_POOLS` küresel nesnesi geliştirildi.
- 13 Osmanlı ve 11 Avrupa otantik donanım öğesi tanımlandı.
- `resolveUnitEquipment` fonksiyonu deterministik modülo algoritmasıyla yazıldı.
- Test 62 başarıyla tanımlandı ve 64/64 test paketinde %100 doğrulandı.
