# AJAN 04 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTS_EQUIPMENT_POOLS` nesnesi (Osmanlı ve Avrupa 5 kategorili donanım havuzları).
- Eklendi: `resolveUnitEquipment` deterministik donanım çözücü fonksiyonu.
- Eklendi: Kültür izolasyonu ve tarihsel eşleşme kuralları.
- Eklendi: Test 62 (Modüler Ekipman Havuzları Doğrulaması).
