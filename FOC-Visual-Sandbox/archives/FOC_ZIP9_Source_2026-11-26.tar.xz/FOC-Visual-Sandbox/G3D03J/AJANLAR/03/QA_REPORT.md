# AJAN 03 KALİTE GÜVENCE RAPORU

- Test 61: Avrupa / HRE Asker Sınıfları -> PASS
- Test 16 Regresyonu: Pikeman (44), Musketeer (43), Swordsman (41) parça sayıları ve Index 35/40 el-silah hizaları %100 korundu.
- Görsel Ayrım: HRE ve Osmanlı siluetleri uzaktan dahi anında ayırt edilmektedir.
- Performans: 120 FPS.
