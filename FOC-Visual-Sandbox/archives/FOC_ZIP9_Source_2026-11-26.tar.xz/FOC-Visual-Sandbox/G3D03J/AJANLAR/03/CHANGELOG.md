# AJAN 03 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `buildHREMusketier` (12 havariler bandolyesi, fitilli musket).
- Eklendi: `buildHREPikeniere` (Morion miğfer, tapul zırhı, 4.5m pike).
- Eklendi: `buildHREHellebardier` (Burgonet, hellebarda balta bıçağı).
- Eklendi: `buildHRECurassier` (Üç çeyrek zırh, çift piştov).
- Eklendi: `buildHREReiter` (Buff coat, çarklı karabina).
- Eklendi: Test 61 (Avrupa / HRE Asker Sınıfları Doğrulaması).
