# AJAN 03 — AVRUPA / KUTSAL ROMA (HRE) ASKER SINIFLARI

## 1. GÖREV TANIMI
30 Yıl Savaşları sonu (1648–1650) dönemi Avrupa / Kutsal Roma İmparatorluğu birliklerini tarihsel siluetleriyle oluşturmak:
- Musketier: Geniş kenarlı devekuşu tüylü süvari şapkası, göğüste 12 Havariler barutluk bandolyesi, fitilli ağır musket ve namlu çatal ayağı.
- Pikeniere: Yüksek ibikli İspanyol/Alman Morion miğferi, sivri omurgalı tapul göğüs zırhı ve tassetler, 4.5m dişbudak pikesi.
- Hellebardier: Siperlikli Burgonet miğferi, gaga kancalı ve sivri uçlu hellebarda baltası.
- Kürassier: Üç çeyrek karartılmış çelik plaka zırh, 3 çubuklu burun siperli Zischägge miğferi, çift çarklı piştov.
- Reiter: Karartılmış demir göğüslük, süvari mandası deri yeleği (buff coat), çarklı süvari karabinası.
- Test 16 Parça Sayısı Güvencesi: Mızraklı (44), Tüfekçi (43), Kılıçlı (41) temel parça sayıları bozulmadan korundu.

## 2. TAMAMLANAN GELİŞTİRMELER
- `buildHREMusketier` fonksiyonu entegre edildi.
- `buildHREPikeniere` fonksiyonu entegre edildi.
- `buildHREHellebardier` fonksiyonu yazıldı (balta başlığı ve kancası eklendi).
- `buildHRECurassier` fonksiyonu entegre edildi (üç çeyrek zırh).
- `buildHREReiter` fonksiyonu entegre edildi (karabina).
- Test 61 başarıyla tanımlandı ve 64/64 test paketinde %100 doğrulandı.
