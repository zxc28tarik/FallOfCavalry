# AJAN 05 KALİTE GÜVENCE RAPORU

- Test 63: 1650 Tarihsel Malzeme Kütüphanesi & Siluet / LOD / Çizim Kararlılığı -> PASS
- Test 25 Regresyonu: Toplam 206 görsel şablon anahtarı tam olarak korundu (`=== 206`).
- Batch Mimarisi: 7 instanced batch grubu değişmedi.
- Performans: 120 FPS, 17.36 MB bellek kullanımı.
