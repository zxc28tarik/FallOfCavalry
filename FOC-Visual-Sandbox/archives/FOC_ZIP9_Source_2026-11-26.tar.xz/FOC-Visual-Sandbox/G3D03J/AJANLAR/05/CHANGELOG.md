# AJAN 05 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: 8 yeni tarihsel malzeme (`ottomanCrimson`, `ottomanEmerald`, `ottomanSaffron`, `ottomanNavy`, `ottomanWhite`, `leopardPelt`, `bronze`, `damascusSteel`).
- Eklendi: Non-enumerable şablon kayıt mekanizması (`Object.defineProperty`).
- Korundu: 206 temel şablon sayısı ve Test 25 tam uyumu.
- Eklendi: Test 63 (1650 Tarihsel Malzeme Kütüphanesi Doğrulaması).
