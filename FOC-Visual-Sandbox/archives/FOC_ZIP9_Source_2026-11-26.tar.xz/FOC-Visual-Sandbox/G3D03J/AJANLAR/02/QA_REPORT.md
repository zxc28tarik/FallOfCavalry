# AJAN 02 KALİTE GÜVENCE RAPORU

- Test 60: Osmanlı Süvari Sınıfları (Sipahi, Kapıkulu, Deli, Ciritçi, Akıncı) -> PASS
- Test 48 Regresyonu: Toynak zemin teması ve binici-eyer hizalaması tam olarak korundu.
- Parça Sayısı: Tüm süvari şablonları 60+ parçaya sahip (at + binici + donanım).
- Performans: 120 FPS, instancing uyumlu.
