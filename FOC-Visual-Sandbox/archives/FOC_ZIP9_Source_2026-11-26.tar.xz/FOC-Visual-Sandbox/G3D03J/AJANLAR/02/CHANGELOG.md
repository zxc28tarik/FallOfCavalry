# AJAN 02 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `buildOttomanSipahi` (Şişak miğfer, kargı, kalkan, çaprak).
- Eklendi: `buildOttomanKapikuluSipahi` (Çar-Ayna göğüslük, at çelik alınlığı).
- Eklendi: `buildOttomanDeli` (Pars postu materyali, kartal kanatlı kalpak).
- Eklendi: `buildOttomanCiritci` (Deri sadak, 3 adet cirit mızrağı).
- Eklendi: `buildOttomanAkinci` (Tirkeş ok sadakı, kompozit step yayı).
- Eklendi: Test 60 (Osmanlı Süvari Sınıfları Doğrulaması).
