# AJAN 02 — OSMANLI SÜVARİ SINIFLARI

## 1. GÖREV TANIMI
1648–1650 Osmanlı atlı birliklerini siluet, zırh ve donanımlarıyla ayırt edilebilir kılmak:
- Sipahi: Burunluklu şişak/tolga miğfer, çelik çevşen göğüslük, 4 metrelik bayraklı kargı, örme hasır kalkan (kalkan), işlemeli çapraklı harp atı.
- Kapıkulu Sipahisi: Çar-ayna dört ayna göğüs zırhı, zırh peçeli tolga, çelik alınlıklı (chamfron) zırhlı hassa atı, ağır kargı ve şeşper gürz.
- Deli Süvarisi: Gövdeye sarılı gerçek pars/leopar postu (`leopardPelt`), kartal kanatlı yüksek kalpak, hafif şok kargısı ve eğri kılıç.
- Ciritçi: Eyer arkasında 3 cirit taşıyan deri cirit sadakı, hafif deri zırh, çevik Anadolu atı.
- Akıncı: Sırtta kompozit yay ve ok sadakı (tirkeş), step atı, hafif kargı.
- At-Binici Uyum Güvencesi: Toynak zemin teması ($bottomY \ge -0.05$) ve binici eyer yüksekliği ($-0.05 \le dy \le 0.15$) korunacak.

## 2. TAMAMLANAN GELİŞTİRMELER
- `buildOttomanSipahi` fonksiyonu yazıldı.
- `buildOttomanKapikuluSipahi` fonksiyonu yazıldı (Çar-ayna ve at alınlığı eklendi).
- `buildOttomanDeli` fonksiyonu yazıldı (Leopar postu ve kanatlı başlık eklendi).
- `buildOttomanCiritci` fonksiyonu yazıldı (Eyer cirit sadakı eklendi).
- `buildOttomanAkinci` fonksiyonu yazıldı (Kompozit yay ve tirkeş eklendi).
- Test 60 başarıyla tanımlandı ve 64/64 test paketinde %100 doğrulandı.
