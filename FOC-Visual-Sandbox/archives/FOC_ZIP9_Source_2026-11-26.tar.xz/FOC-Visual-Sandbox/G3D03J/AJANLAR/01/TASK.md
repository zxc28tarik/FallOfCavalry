# AJAN 01 — OSMANLI PİYADE SINIFLARI

## 1. GÖREV TANIMI
1648–1650 dönemi Osmanlı ordusunun çekirdeğini oluşturan piyade sınıflarını görsel, anatomik ve tarihsel donanımlarıyla modellemek:
- Yeniçeri: Beyaz keçe Börk/Serpuş, pirinç kaşıklık (zarf), arkaya sarkan kumaş, fildişi kabzalı yatağan, fitilli Osmanlı tüfengi, çelik çevşen plaka.
- Azap: Sarıklı başlık, keten yelek ve şalvar, 3.85m tırpan kargı veya kavisli kılıç/kalkan donanımı.
- Humbaracı: Deri koruyucu önlük, yeşil sarık, omuzdan asma mühimmat çantası, yanan fitilli döküm demir humbara bombası.
- Bostancı: Yüksek kırmızı konik Bostancı külahı, ağır çelik çevşen göğüslük, iki elle tutulan hilal muhafız teberi.
- Levend: Çizgili baş sargısı, açık göğüs yeleği, kuşakta çift piştov, fitilli sahil/balkan tüfengi.
- Ortak Osmanlı anatomik temeli (`ottomanHumanBase`): Bol şalvar, yırtmaçlı etekli kaftan, ipek kuşak, deri yemeni ayakkabı ve sarkık bıyık.

## 2. TAMAMLANAN GELİŞTİRMELER
- `ottomanHumanBase` anatomik ve kıyafet iskeleti inşa edildi.
- `buildOttomanJanissary` (Varyant 1 Ranged, Varyant 2 Melee) yazıldı.
- `buildOttomanAzap` (Varyant 1 Tırpanlı, Varyant 2 Kılıçlı) yazıldı.
- `buildOttomanHumbaraci` (Varyant 1 El Humbaracısı) yazıldı.
- `buildOttomanBostanci` (Varyant 1 Teberli Saray Muhafızı) yazıldı.
- `buildOttomanLevend` (Varyant 1 Çift Piştovlu) yazıldı.
- Test 59 başarıyla tanımlandı ve 64/64 test paketinde %100 doğrulandı.
