# AJAN 01 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `ottomanHumanBase` fonksiyonu (şalvar, kaftan, kuşak, yemeni, bıyık).
- Eklendi: `buildOttomanJanissary` (Börk, zarf, tüfenk, yatağan, çevşen).
- Eklendi: `buildOttomanAzap` (Sarık, tırpan kargı, şemşir kılıç, kalkan).
- Eklendi: `buildOttomanHumbaraci` (Deri önlük, el bombası, fitil).
- Eklendi: `buildOttomanBostanci` (Bostancı külahı, teber hilal baltası, zırh).
- Eklendi: `buildOttomanLevend` (Çizgili sarık, çift piştov, yelek).
- Eklendi: Test 59 (Osmanlı Piyade Sınıfları ve Model Şablonları Doğrulaması).
