# FALL OF CAVALRY — G3D-03E DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)

**Sürüm:** G3D-03E  
**Tarih:** 2026-11-24  
**Dosyalar:**
- `G3D03E_WORKING.html`
- `INTEGRATION/FOC_G3D03E_6_AJAN_BIRLESIK_ADAY.html`
- `G3D03E/AJANLAR/01` - `06` bağımsız teslimat paketleri

---

### 1. G3D-03D QA Eksikliği Düzeltmesi (5 At Tipi Snapshot Fonksiyonu)
- `Battle3DPreviewController.prototype._buildHorseTypesPreviewSnapshot(legIndex = 0)` fonksiyonu Ajan 04 kaynaklarından geri yüklendi.
- 5 kanonik 1650 atı (`warhorse`, `charger`, `courser`, `rouncey`, `steppe_horse`) yan yana dizilerek 4 zamanlı adım, diyagonal tırıs ve duruş fazları snapshot'a bağlandı.
- Test 44 regresyon testi eklendi ve 44/44 test geçişi sağlandı.

### 2. G3D-03E Ajan Geliştirmeleri ve Entegrasyonu
- **Süvari Hücum & Silah Toparlanması (Ajan 01):**
  - Mızrak hücum uzanımı ($weaponDz > 0.5$) ve penetrasyon/toparlanma geçişi pürüzsüzleştirildi.
  - Kılıç savurmasında at boynundan güvenli yan açıklık ($dx \le -0.10$, $>20$ cm) garantilendi.
  - Karabina ve tabanca nişan alma, geri tepme ve toparlanma dinamikleri yumuşatıldı.
  - Test 45 eklendi.
- **Piyade Savaş Pozları & Denge (Ajan 02):**
  - Pikeman mızrak hamlesi ($weaponDz > 0.6$) ve lunge diz açısı ($leftKneePitch > 0.2$) ile ayak kayması engellendi.
  - Tüfekçi geri tepmesi ($weaponDz < -0.15$) ve barut doldurma dikliği ($weaponPitch < -0.4$) korundu.
  - Kılıç-kalkan siper konumu ($|shieldDx| \le 0.16$) göğüs merkezine kilitlendi.
  - Test 46 eklendi.
- **Birleşik Animasyon Önizlemesi (Ajan 03):**
  - Test paneline `btnToggleCombinedPreview` eklendi.
  - `_buildCombinedPreviewSnapshot()` ile 300 askerin orijinal verisi korunarak ön hatlarda savaş, arka hatlarda intikal durumları oluşturuldu.
  - Diğer önizlemelerle karşılıklı dışlama ve kamera/sahne geri yükleme mekanizması kuruldu.
  - Test 47 eklendi.
- **At Hareketi ve Binici Koordinasyonu (Ajan 04):**
  - Yürüyüşten tırısa geçiş ($tb \in [0.0, 1.0]$) enterpolasyonu yumuşatıldı.
  - Toynak zemin teması ($hoofY \ge -0.15$) ve batmama güvencesi sağlandı.
  - Binicinin eyerle dikey teması ($-0.05 \le riderY \le 0.15$) ve at gövde salınımlarına uyumu korundu.
  - Test 48 eklendi.
- **Kara Barut Efekt Havuzu & Kaynak Yönetimi (Ajan 05):**
  - 64 slotluk sabit parçacık havuzu ve `instanceData` Float32Array tamponu ile 100 simülasyon adımı boyunca sıfır GC tahsisi korundu.
  - Namlu ucu koordinat kilidi ($x \approx 10.05$) ve parlama ömrü ($maxLife \le 0.10$s) sağlandı.
  - `reset()` fonksiyonu eklenerek sektör ve mod geçişlerinde tam GPU/parçacık temizliği sağlandı.
  - Test 49 eklendi.
- **Saha Görselliği & WebGL Performans Profilleme (Ajan 06):**
  - Kenar teğet rim faktörü ($rimFactor \ge 0.30$) ve metalik parlatma takviyesi ($+0.35 \cdot vInstMetalness$) ile silüet okunurluğu artırıldı.
  - 300 askerin tamamı tam 7 instanced batch içinde GPU'ya iletildi.
  - 60 frame WebGL render profillemesinde ortalama frame süresi $< 16.6$ms (60 FPS hedefi) doğrulandı.
  - Test 50 eklendi.

### 3. Test Doğrulaması
- **Gerçek Headless Chromium WebGL Testi:** **50 / 50 test BAŞARILI (%100).**
- Bütün önceki testler (1-44) korunmuştur.
