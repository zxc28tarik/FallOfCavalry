# G3D-03E / AJAN 01 GÖREV BELGESİ
## SÜVARİ SAVAŞ ANİMASYONLARI VE TOPARLANMA

### Görev Tanımı
1. Süvari hücum animasyonlarında Idle → Hareket → Saldırı → Toparlanma → Hareket geçişlerini pürüzsüzleştir.
2. Mızrak hücum uzanımını (`cavalry_lance`) hızlanma, penetrasyon ve geri çekilme fazlarıyla rafine et.
3. Kılıç savurmasında (`cavalry_sabre`) omuz, kol ve gövde koordinasyonunu ve at boynundan yan açıklığı (> 20 cm) sağla.
4. Ateşli silahlarda (`cavalry_carbine`, `cavalry_pistol`) nişan ve geri tepme toparlanmasını yumuşat.
5. El-silah kaynaşmasını (weld) koru; silahların doğal hazır pozuna sıfır pop ile dönmesini sağla.
6. Test 45'i ekle ve 45/45 test başarısını doğrula.
