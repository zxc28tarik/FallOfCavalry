# G3D-03E / AJAN 04 GÖREV BELGESİ
## AT HAREKETİ VE BİNİCİ UYUMU

### Görev Tanımı
1. 4 zamanlı yürüyüşten 2 zamanlı çapraz tırısa ve tırıstan yürüyüşe yumuşak geçişleri (`trotBlend`) pürüzsüzleştir.
2. Toynak zemin temasını ve askı yaylanmasını (suspension arc) doğrula; toynakların zemine batmasını engelle ($y \ge 0.02$).
3. Binicinin eyerle dikey temasını ve pelvik uyumunu koru ($bodyPitch$, $bodyRoll$ ve $bodyDy$ senkronizasyonu); binicinin eyerden kopmasını veya ata batmasını engelle.
4. Üzengi ve dizgin bağını hücum hareketleri boyunca muhafaza et.
5. 5 at tipinde (`warhorse`, `charger`, `courser`, `rouncey`, `steppe_horse`) hareket tutarlılığını ve durunca tam referans pozuna dönüşü sağla.
6. Test 45'i ekle ve 45/45 test başarısını doğrula.
