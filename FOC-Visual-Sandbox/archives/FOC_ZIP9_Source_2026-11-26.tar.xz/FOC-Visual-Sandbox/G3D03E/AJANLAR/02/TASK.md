# G3D-03E / AJAN 02 GÖREV BELGESİ
## PİYADE SAVAŞ ANİMASYONLARI VE TOPARLANMA

### Görev Tanımı
1. Piyade yürüyüş-saldırı geçişlerini (`idle` → `walk` → `attack` → `recovery` → `idle`) pürüzsüzleştir.
2. Mızraklı askerin (`infantry_pikeman`) iki elle mızrak hamlesi, seviyeleme ve hamle dengesini ayak kayması olmadan sağla.
3. Tüfekçinin (`infantry_musketeer`) nişan, ateş geri tepmesi ve barut doldurma/harbi hareketlerini pürüzsüzleştir.
4. Kılıç-kalkanlı askerin (`infantry_swordsman`) kılıç savurmasında kalkanı göğüs merkezine siper alma mesafesini ($|shieldDx| \le 0.16$) ve siper toparlanmasını koru.
5. Animasyon sonlarında ($u \to 1.0$) sıfır pop ile referans duruşuna dönüşü sağla.
6. Test 45'i ekle ve 45/45 test başarısını doğrula.
