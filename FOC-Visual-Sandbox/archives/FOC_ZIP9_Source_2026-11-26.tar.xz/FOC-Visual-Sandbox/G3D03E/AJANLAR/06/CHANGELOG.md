# G3D-03E / AJAN 06 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## SAHNE GÖRSELLİĞİ, PERFORMANS PROFİLLEME VE QA

### 1. Görsel & Performans İyileştirmeleri
- **Silüet Okunurluğu ve Rim Light:**
  - Shader fragment aşamasında kenar teğet rim faktörü ($rimDot \to 1.0 \implies rimFactor \ge 0.30$) ve doğrudan yüzey sönümlenmesi ($rimDot \to 0.0 \implies rimFactor = 0.0$) doğrulandı.
  - Zırhlı askerler için metalik parlama takviyesi ($+0.35 \cdot vInstMetalness$) ile uzak mesafeden seçilebilirlik artırıldı.
- **300 Askerli Sahne Batch Bütünlüğü:**
  - 300 askerin tamamı tam 7 instanced batch grubu içinde işlenerek GPU draw call yükü minimize edildi.
- **WebGL Frame Zaman Profillemesi:**
  - 60 simülasyon ve render adımı boyunca ortalama frame süresi profillendi; $avgFrameTime < 16.6$ms eşiğinde 60 FPS hedefine ulaşıldı.

### 2. Doğrulama Testi 45 Eklendi
- `45. Saha Görselliği (Uzak Silüet & Rim Light) ve 300 Askerli Sahne WebGL Performans Profilleme Doğrulaması`
- 7 instanced batch varlığı, rim light matematiksel sınırları ve 60 frame WebGL render profil süresi test edildi.

### 3. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 45 / 45 test BAŞARILI (%100).
- Sıfır hata, sıfır gerileme (0 regressions).
