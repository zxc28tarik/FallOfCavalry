# G3D-03E / AJAN 06 GÖREV BELGESİ
## SAHNE GÖRSELLİĞİ, PERFORMANS PROFİLLEME VE QA

### Görev Tanımı
1. Uzak asker ve süvari silüet okunurluğunu ve rim light dengesini ($rimFactor$, $rimLight$) doğrula.
2. 300 askerli sahnede 7 instanced batch bütünlüğünü ve draw call sınırını koru.
3. WebGL frame render süresini, draw call sayısını ve bellek kararlılığını 60 frame boyunca gerçek zamanlı profille.
4. Ortalama frame süresinin 60 FPS eşiğinde (< 16.6ms) kaldığını ve heap tahsisinin kararlı olduğunu doğrula.
5. Test 45'i ekle ve 45/45 test başarısını doğrula.
