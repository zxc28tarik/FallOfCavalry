# G3D-03E / AJAN 03 GÖREV BELGESİ
## BİRLEŞİK ANİMASYON ÖNİZLEMESİ

### Görev Tanımı
1. Arayüze "Birleşik Animasyon Önizlemesi" butonu (`btnToggleCombinedPreview`) ekle.
2. `Battle3DPreviewController` içerisine `_buildCombinedPreviewSnapshot()` fonksiyonunu ekle; Merkez Sektördeki 300 askere kademeli/karışık savaş pozları ve yürüyüş durumları ata.
3. Önizleme başlatma, durdurma ve sıfırlama mekanizmasını kamera koruması ile kur.
4. Diğer önizlemelerle (yürüyüş, süvari, 5 at tipi, savaş pozları) tam karşılıklı dışlama (mutual exclusion) sağla.
5. Önizleme kapatıldığında 300 askeri ve kamera açılarını sıfır sapmayla geri yükle.
6. Test 45'i ekle ve 45/45 test başarısını doğrula.
