# G3D-03E / AJAN 05 GÖREV BELGESİ
## KARA BARUT VE WEBGL KAYNAK YÖNETİMİ

### Görev Tanımı
1. Namlu çıkış parlamasını ateş animasyonu tepe fazıyla tam senkronize et (~0.07s).
2. Kara barut dumanı başlangıç noktasını namlu çıkış koordinatlarına tam kilitle; dumanın doğal genişleme ve sönümlenme eğrisini (~0.5s) doğrula.
3. WebGL buffer kullanımını ve çöp toplayıcı (GC) baskısını denetle; efekt havuzunun (64 slot) sıfır bellek sızıntısı (zero GC) ile çalışmasını sağla.
4. Sektör ve mod geçişlerinde tüm parçacıkların ve GPU tamponlarının temizlenmesini (`reset()` / `clear()`) garanti et.
5. Test 45'i ekle ve 45/45 test başarısını doğrula.
