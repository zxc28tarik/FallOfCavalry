# G3D-03E / AJAN 05 DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG)
## KARA BARUT VE WEBGL KAYNAK YÖNETİMİ

### 1. `BlackPowderFxPool` İyileştirmeleri
- **Namlu Çıkış Kilidi ve Parlama Senkronizasyonu:**
  - Namlu parlaması (`isFlash`) için maksimum ömür $maxLife = 0.07$s olarak ayarlandı.
  - Namlu ucu çıkış koordinatlarına ($x + dirX \cdot 0.05$) tam kilit sağlandı.
- **Duman Yayılımı ve Sönümlenme:**
  - 3'lü duman kümesi ($smokePuffs = 3$) için karesel sönümlenme ve aerodinamik sürtünme eğrisi korundu ($maxLife \approx 0.5$s).
- **Sıfır GC ve Bellek Güvencesi:**
  - 64 slotluk sabit `instanceData` Float32Array tamponu yeniden kullanılarak frame başına 0 yeni heap tahsisi garantilendi.
  - 64 slot saturasyonunda en eski parçacığı geri dönüştüren döngüsel mantık (ring buffer recycle) korundu.
- **Sektör Geçiş Temizliği:**
  - `reset()` fonksiyonu eklendi; sahne ve sektör geçişlerinde tüm parçacık slotları inaktif duruma getirilmektedir.

### 2. Doğrulama Testi 45 Eklendi
- `45. Kara Barut Efekt Havuzu (64 Slot), Namlu Çıkış Koordinat Kilidi, Sıfır GC Tahsisi ve Sektör Geçiş Temizliği Doğrulaması`
- 64 slotluk kapasite, namlu çıkış kilidi, 64 slot aşımında geri dönüştürme, 100 frame boyunca sıfır GC ve `reset()` temizliği test edildi.

### 3. Test Sonuçları
- **Gerçek Headless Chromium WebGL Testi:** 45 / 45 test BAŞARILI (%100).
- Sıfır hata, sıfır gerileme (0 regressions).
