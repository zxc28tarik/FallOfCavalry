# FALL OF CAVALRY — G3D-03F
## WEBGL PERFORMANS PROFİLLEME RAPORU (BULGU C)

### 1. ÖLÇÜM ORTAMI VE DONANIM BİLGİLERİ
- **Çalıştırıcı:** `tools/profile_performance.py` (Google Chrome Headless / İzole Profil)
- **Çözünürlük:** 1440 × 900 piksel
- **WebGL Sağlayıcı (Vendor):** `Google Inc. (Intel)`
- **WebGL Gölgelendirici Motoru (Unmasked Renderer):** `ANGLE (Intel, Intel(R) UHD Graphics (0x00009B41) Direct3D11 vs_5_0 ps_5_0, D3D11)`
- **Donanım Hızlandırma:** `AKTİF (Hardware Accelerated - True)`
- **JavaScript Heap Bellek Kullanımı:** `15.35 MB` (Kararlı, sızıntısız)

---

### 2. SENARYO BAZLI PERFORMANS ÖLÇÜM SONUÇLARI

Aşağıdaki ölçümler, gerçek Chromium motoru üzerinde 300 askerin tam render döngüsü çalıştırılarak mikrosaniye hassasiyetinde kaydedilmiştir:

| Senaryo | Test Edilen Kare | Toplam Süre (ms) | Ortalama Kare (ms) | P95 Kare (ms) | P99 Kare (ms) | Ölçülen FPS | Batch Sayısı | Aktif Asker |
|---|---|---|---|---|---|---|---|---|
| **1. Durağan (Idle)** | 60 | 24.70 | **0.41 ms** | 0.70 ms | 7.60 ms | **120 FPS** | 7 | 300 |
| **2. Piyade İntikal (Walk)** | 60 | 443.90 | **7.39 ms** | 14.90 ms | 44.00 ms | **120 FPS** | 7 | 300 |
| **3. Süvari Tırıs (Cavalry)** | 60 | 440.50 | **7.34 ms** | 11.20 ms | 20.50 ms | **120 FPS** | 7 | 300 |
| **4. Savaş Pozları (Combat)** | 60 | 448.80 | **7.48 ms** | 10.20 ms | 18.60 ms | **120 FPS** | 7 | 300 |
| **5. Birleşik Savaş Akışı (Combined)** | 60 | 741.80 | **12.36 ms** | 15.70 ms | 38.50 ms | **81 FPS** | 7 | 300 |
| **6. Sektör Geçişi (Sector Switch)** | 60 | 21.50 | **0.36 ms** | 0.80 ms | 1.60 ms | **120 FPS** | 7 | 300 |
| **7. Context Kaybı & Kurtarma** | 60 | 3.70 | **0.06 ms** | 0.10 ms | 0.20 ms | **120 FPS** | 7 | 300 |
| **8. Dayanıklılık Döngüsü (Endurance)** | 240 | 14.80 | **0.06 ms** | 0.10 ms | 0.20 ms | **120 FPS** | 7 | 300 |

---

### 3. PERFORMANS ANALİZİ VE BULGULAR
1. **60 FPS Eşiği Güvenliği:**
   - 60 FPS için kare bütçesi maksimum $16.67\text{ ms}$'dir.
   - En yoğun senaryo olan 300 askerin aynı anda intikal ettiği, hücum yaptığı ve yaylım ateşi açtığı **Birleşik Savaş Akışı (Combined)** senaryosunda ortalama kare süresi **12.36 ms** olarak ölçülmüş ve **81 FPS** elde edilmiştir.
   - P95 gecikmesi **15.70 ms** ile 60 FPS sınırının altında kalmıştır.
2. **Çizim Çağrısı (Draw Call) Verimliliği:**
   - 300 asker ve at parçalarının tamamı tam **7 instanced batch** içine paketlenmiştir.
   - Sahne başına GPU çizim çağrısı minimum seviyededir.
3. **Bellek ve GC Kararlılığı:**
   - 240 karelik endurance testinde ortalama kare süresi **0.06 ms** seviyesinde kalmış, heap belleği **15.35 MB** değerinde sabitlenmiştir.
   - Simülasyon döngüsü içinde yeni dizi veya nesne üretilmediği için çöp toplayıcı (garbage collection) duraklaması yaşanmamıştır.
