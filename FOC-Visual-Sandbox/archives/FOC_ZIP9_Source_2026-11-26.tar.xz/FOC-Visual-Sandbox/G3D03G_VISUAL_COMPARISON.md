# FALL OF CAVALRY — G3D-03G GÖRSEL KARŞILAŞTIRMA RAPORU (REVİZYON 3)
## SURAT, VÜCUT VE AT ÇİZGİLERİ GÖRSEL ANALİZİ

### 1. KULLANICI EMRİ VE ODAK
Kullanıcı emri: "HER BİRİ SURAT VÜCUT AT ÇİZGİLERİNİ GELİŞTİRMEYE ADASIN KENDİNİ ARALARINDA GÖREVLERİ DAĞITSINLAR."

Bu doğrultuda 6 ajan insan suratı, vücut hatları ve at silüetinin her bir kritik anatomik ve donanımsal bileşenine odaklanarak Age of Empires III: Definitive Edition seviyesinde çizgi ve form kalitesine ulaşmıştır.

---

### 2. SURAT, VÜCUT VE AT ÇİZGİLERİ KARŞILAŞTIRMA TABLOSU

| Bölge / Bileşen | G3D-03F (Temel Sürüm) | G3D-03G (Surat, Vücut, At Çizgileri Geliştirmesi) | Görsel Kazanç |
|---|---|---|---|
| **Piyade Yüz ve Surat Çizgileri (Ajan 01)** | Tek parça küre kafa, basit koni burun. | Alın eğimi, kaş kemeri, burun köprüsü, elmacık kemikleri, çene hattı, 1650 bıyık ve sivri keçi sakalı (musketeer goatee), boğaz açılı boyun silindiri. | Yakınlaştırmada askerlerin yüz ifadesi, duruş yönü ve mimik ciddiyeti netleşti. |
| **Yaka ve Boyun Çizgileri (Ajan 01)** | Düz silindir boyun. | Sternocleidomastoid boyun kas eğimi ve omuzlara dökülen dantelli rabat yakanın (falling linen collar) kıvrımları. | Kafa ve gövde arasında yumuşak, döneme uygun bir geçiş sağlandı. |
| **At Boynu ve Kafa Profili (Ajan 02 & 05)** | Basit silindir boyun ve düz kafa. | Kavisli boyun tepesi (crested neck), kafa craniumu, incelen burun köprüsü, belirgin burun delikleri, çene kemiği kavisleri ve alert dik kulak formu. | Atın kafa silüeti soylu bir savaş atı karakterine kavuştu. |
| **At Göğüs, Karın ve Sağrı (Ajan 02)** | Düz silindir gövde ve düz küre sağrı. | Çift göğüs kası hacmi (pectoralis), derin kaburga kafesi, karın çekikliği (flank tuck) ve güçlü eğimli sağrı (sloping croup) hatları. | At gövdesi organik bir kas kütlesine ve gerçekçi hacme sahip oldu. |
| **At Yele ve Kuyruk Çizgileri (Ajan 02 & 05)** | Basit 2 parçalı çubuk kuyruk. | Boyun boyunca uzanan çok kademeli yele çizgileri ve çift katmanlı dalgalı dökümlü kuyruk formu. | Hareket esnasında atın arka silüeti dinamizm kazandı. |
| **Toynak ve Bacak Çizgileri (Ajan 05)** | Düz frustum bacaklar. | Arka bacaklarda hock ve stifle eklem hatları, ön bacaklarda fetlock ve zemine açılı basan toynak geometrisi ($bottomY \ge -0.05$). | Yürüyüş ve tırıs adımlarında toynak zemine doğal temas eder. |
| **Gövde Zırh Çizgileri (Ajan 03)** | Düz gri göğüslük kutusu. | Merkezi omurgalı göğüs zırhı (peascod cuirass central tapul ridge), göğüs bombesi ve fauld etek çizgileri. | 1650 Otuz Yıl Savaşları zırhlarının karakteristik silüeti sağlandı. |
| **Butluk ve Kıyafet Hatları (Ajan 03)** | Belirsiz kalça plakaları. | Kalçadan dizlere basamaklı inen 3 kademeli mafsallı butluklar (laminated tassets), dökümlü ceket etekleri (basques) ve altın sırma kenar şeritleri. | Askerin kalça ve bacak oranları belirginleşti. |
| **Miğfer Siperlik ve Yanaklık Çizgileri (Ajan 04)** | Basit çanak miğfer. | Morion perçinli tarak çizgisi, Zischägge 3 barlı yüz siperi (triple nasal bar), Doğu şişak burun koruma demiri ve yanaklıklar. | Baş korumalarının yüzü çevreleyen hatları tarihsel gerçekliğe kavuştu. |
| **El ve Silah Tutuş Çizgileri (Ajan 04)** | Küre el ucu. | El bileği ve modellenmiş parmak çizgileri; kılıç kabzası, mızrak gövdesi ve tüfek kundağını kavrayan hand-weld kilit geometrisi. | Silahlar havada asılı durmaz, el tarafından sıkıca kavranır. |
| **Kontur Speküler Işık Çizgileri (Ajan 05)** | Yalnızca difüz + ambient aydınlatma. | `instancedFS` içine Blinn-Phong speküler yansıma eklendi: $spec = pow(dot(n, halfDir), 16 + 48 \cdot metal) \cdot metal$. | Parlak zırh çeliği, miğferler ve kılıç namlularının kenar çizgileri güneş altında ışıldar. |
| **Saha Formasyon Çizgileri (Ajan 06)** | Standart görünüm. | Teğetsel rim lighting ve speküler vurgular sayesinde kuşbakışı RTS kamerasında saf, tabur ve süvari bölük çizgileri netleşti. | Savaş alanında Mavi ve Kırmızı ordular uzaktan tek bakışta ayırt edilir. |

---

### 3. SİSTEMSEL DİYAGRAM

```mermaid
graph TD
    A["Surat, Vücut ve At Çizgileri"] --> B["Surat & Kafa Çizgileri"]
    A --> C["Vücut & Zırh Çizgileri"]
    A --> D["At Silüet & Kas Çizgileri"]
    A --> E["Işık & Shader Çizgileri"]
    
    B --> B1["Ajan 01: Çene, Burun, Bıyık, Rabat Yaka"]
    B --> B2["Ajan 04: Zischägge 3-Bar Siperlik, Şişak Burunluk"]
    
    C --> C1["Ajan 01: Cavalier Bucket Çizmeler, Rhingrave Breeches"]
    C --> C2["Ajan 03: Peascod Tapul Omurga, 3-Kademeli Butluk"]
    C --> C3["Ajan 04: Modellenmiş El & Parmak Tutuşu"]
    
    D --> D1["Ajan 02: Crested Boyun, Pectoralis Göğüs, Sloping Croup"]
    D --> D2["Ajan 05: İnce Burun Köprüsü, Kulaklar, Hock/Toynak"]
    
    E --> E1["Ajan 05: Blinn-Phong Speküler Kontur Yansıması"]
    E --> E2["Ajan 06: Saha Formasyon Çizgileri & Rim Light"]
```
