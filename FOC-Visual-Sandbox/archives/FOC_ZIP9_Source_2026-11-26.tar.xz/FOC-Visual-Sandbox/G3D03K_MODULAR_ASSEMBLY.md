# FALL OF CAVALRY — G3D-03K MODÜLER ASKER BİRLEŞTİRME VE VİTRİN
## RTSModularUnitBuilder & MODEL KALİTESİ KIYASLAMA REHBERİ

Bu doküman, Ajan 06 tarafından geliştirilen `RTSModularUnitBuilder` motorunu, asker çeşitlilik sistemini ve Asker Vitrini'ndeki Model Kalitesi Karşılaştırma aracını açıklar.

---

## 1. MODÜLER BİRLEŞTİRME MOTORU (`RTSModularUnitBuilder`)

Askerler artık tek bir monolitik şablon yerine, modüler parçaların deterministik kombinasyonu ile oluşturulur:

```
[Temel Beden Profili: Slim / Average / Heavy]
       + [Anatomik Baş & Yüz Kılı: Bıyık / Van Dyke / Sakal / Genç]
       + [Katmanlı Giysi: Kaftan / Peascod Doublet / Buff Coat]
       + [Zırh Katmanı: Çevşen / Çar-Ayna / Tapul / Morion / Börk]
       + [Silah & Kalkan Donanımı]
       = YÜKSEK DETAYLI RTS ASKERİ (G3D-03K)
```

### Kod Yapısı:
```javascript
class RTSModularUnitBuilder {
    static assembleSoldier(archetype, side, seed = 0) {
        const isOttoman = ...;
        const profiles = ['slim', 'average', 'heavy'];
        const profile = profiles[Math.abs(seed) % profiles.length];

        if (isOttoman) {
            if (archetype.includes('janissary')) {
                const base = buildOttomanHighDefHumanBase(side, profile, ...);
                return [...base, ...buildHighDefBork(), ...buildHighDefCevsen()];
            } ...
        } else {
            if (archetype.includes('pikeniere')) {
                const base = buildEuropeanHighDefHumanBase(side, profile, ...);
                return [...base, ...buildHighDefMorion(), ...buildHighDefTapulArmor()];
            } ...
        }
    }
}
```

---

## 2. ASKER VİTRİNİ'NDE MODEL KALİTESİ KIYASLAMASI

Arayüzün üst barındaki **`🏛️ Asker Vitrini`** modalına (`#rtsShowcaseOverlay`) yeni bir kalite karşılaştırma aracı eklenmiştir:

### Kalite Geçiş Butonu:
- **`✨ Model Kalitesi: G3D-03K (Detaylı)`**: Yeni anatomik vücut profillerini, kloş kaftan eteklerini, mafsallı elleri, burun/kaş yüz detaylarını ve Tapul/Çevşen zırh kalınlıklarını görüntüler.
- **`📦 Model Kalitesi: G3D-03J (Klasik)`**: Önceki sürümün temel geometrik gövde ve başlık yapısına anında geçiş yaparak görsel kalite artışını model üzerinde canlı kıyaslamayı sağlar.

### Bilgi Kartı Güncellemesi:
Kalite modu değiştirildiğinde bilgi kartı dinamik olarak güncellenir:
- **Model Standardı:** Age of Empires III DE Seviyesi vs G3D-03J Temel.
- **Anatomi & Profil:** 3 Beden Profili (Slim/Avg/Heavy) vs Standart Silindir.
- **Kıyafet Katmanı:** Katmanlı dökümlü kumaş vs Tek katman gövde.
