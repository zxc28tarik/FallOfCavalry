# AJAN 02 — OSMANLI KIYAFET VE ZIRH KALİTESİ

## 1. GÖREV TANIMI
1648–1650 Osmanlı askerlerinin kıyafetlerini ve zırhlarını katmanlı, hacimli ve otantik detaylarla geliştirmek:
- Kaftan: Vücuda boyanmış gibi durmayan, hacimli ve dökümlü alt eteklik (`flared skirt`), yırtmaçlı ön açıklık ve altın sırma kenarlık.
- Şalvar: Çizmenin içine giren boğumlu kumaş kıvrımları.
- Kuşak: Beli 3 boyutlu olarak saran geniş ipek kumaş ve altın toka.
- Çevşen: Göğüste çelik disk plaka, pirinç merkez göbeği ve kollarda bazuband kolçakları.
- Çar-Ayna: Ağır zırhlı süvariler için 4 ayna plakası.
- Başlıklar: İçi kafaya oturan, arkaya sarkan kumaşlı keçe Börk ve pirinç kaşıklık (`zarf`), şişak tolga ve sarık detayları.

## 2. TAMAMLANAN GELİŞTİRMELER
- `buildOttomanHighDefHumanBase` geliştirildi.
- `buildHighDefBork`, `buildHighDefCevsen` ve `buildHighDefSisak` fonksiyonları yazıldı.
- Test 66 tanımlandı ve %100 başarıyla doğrulandı.
