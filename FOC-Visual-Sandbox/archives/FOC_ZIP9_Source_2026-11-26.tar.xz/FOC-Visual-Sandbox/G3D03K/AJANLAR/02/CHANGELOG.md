# AJAN 02 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `buildOttomanHighDefHumanBase` (kloş kaftan eteği, altın kenarlık, 3D kuşak).
- Eklendi: `buildHighDefBork` (zarf kaşıklık, beyaz keçe taç, enseye sarkan kumaş).
- Eklendi: `buildHighDefCevsen` (çelik disk göğüslük, bazuband kolçaklar).
- Eklendi: `buildHighDefSisak` (şişak tolga burunluğu ve zincir camail örtüsü).
- Eklendi: Test 66 (Osmanlı Çok Katmanlı Kıyafet ve Zırh Geometrisi Doğrulaması).
