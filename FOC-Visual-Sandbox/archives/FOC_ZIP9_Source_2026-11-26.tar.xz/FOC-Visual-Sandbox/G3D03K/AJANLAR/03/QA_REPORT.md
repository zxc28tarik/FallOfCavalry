# AJAN 03 KALİTE GÜVENCE RAPORU

- Test 67: Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları -> PASS
- Zırh Derinliği: Tapul ve Morion zırhları düz gri doku yerine 3D hacimli olarak algılanmaktadır.
- Test 16 Regresyonu: Mızraklı (44), Tüfekçi (43), Kılıçlı (41) temel parça sayıları korundu.
- Performans: 120 FPS.
