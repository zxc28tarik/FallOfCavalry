# AJAN 03 — AVRUPA / HRE ASKER KIYAFETLERİ VE ZIRHLARI

## 1. GÖREV TANIMI
1648–1650 30 Yıl Savaşları dönemi Avrupa birliklerinin kıyafet ve zırh kalitesini yükseltmek:
- Peascod Doublet / Buff Coat: Belde sarkan etek parçaları (peplos tabs), kolalı beyaz keten devrik yaka (falling collar).
- Süvari Baldriği: Göğüsten çapraz inen kılıç askı kayışı ve tokası.
- Çizme: Katlanabilir geniş koni ağızlı süvari çizmeleri (bucket-top boots).
- Morion Miğferi: Yüksek hilal ibikli dövme çelik başlık, kıvrık ön-arka siperlik ve pirinç perçin şeridi.
- Burgonet: Sabit kaş siperliği ve ense lamel koruması (lobster tail).
- Tapul Göğüs Zırhı: Mermi saptırıcı merkezi dikey omurga ve sallanan uyluk tasset plakaları.
- Kürassier Üç Çeyrek Zırhı: Karartılmış çelik lamine zırh.

## 2. TAMAMLANAN GELİŞTİRMELER
- `buildEuropeanHighDefHumanBase` geliştirildi.
- `buildHighDefMorion`, `buildHighDefBurgonet`, `buildHighDefTapulArmor` ve `buildHighDefCavalierHat` yazıldı.
- Test 67 tanımlandı ve %100 başarıyla doğrulandı.
