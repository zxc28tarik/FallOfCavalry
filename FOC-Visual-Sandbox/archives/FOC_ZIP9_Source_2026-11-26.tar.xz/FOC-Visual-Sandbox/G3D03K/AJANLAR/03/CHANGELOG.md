# AJAN 03 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `buildEuropeanHighDefHumanBase` (peascod ceket, düşen keten yaka, süvari baldriği).
- Eklendi: `buildHighDefMorion` (yüksek çelik ibik, perçin şeridi, kavisli siperlik).
- Eklendi: `buildHighDefBurgonet` (ense lamelleri, kaş siperliği, yanak korumaları).
- Eklendi: `buildHighDefTapulArmor` (mermi saptırıcı omurga, mafsallı tassetler).
- Eklendi: `buildHighDefCavalierHat` (geniş kenar, devekuşu tüyü).
- Eklendi: Test 67 (Avrupa / HRE Asker Kıyafetleri ve Zırh Detayları Doğrulaması).
