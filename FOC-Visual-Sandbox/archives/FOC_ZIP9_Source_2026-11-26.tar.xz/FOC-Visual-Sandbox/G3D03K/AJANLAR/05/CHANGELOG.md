# AJAN 05 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: 5 yeni PBR malzemesi (`blackenedSteel`, `burnishedBronze`, `buffLeather`, `fineSilk`, `roughWool`).
- Eklendi: Non-enumerable G3D-03K şablon bağlama mekanizması.
- Korundu: 206 temel model şablonu ve Test 25 tam uyumu.
- Eklendi: Test 69 (1650 İleri Malzeme Kütüphanesi ve PBR Yüzey Özellikleri Doğrulaması).
