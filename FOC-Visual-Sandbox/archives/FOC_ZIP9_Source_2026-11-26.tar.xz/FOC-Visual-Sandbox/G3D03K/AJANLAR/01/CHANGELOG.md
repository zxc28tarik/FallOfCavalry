# AJAN 01 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `BODY_PROFILES` (slim, average, heavy vücut profilleri).
- Eklendi: `buildArticulatedHand` (avuç içi, başparmak ve parmak kümesi mafsalı).
- Eklendi: `buildAnatomicalHumanBase` (omuz deltoidleri, diz kapakları, baldır kavisleri, topuklu çizmeler).
- Eklendi: Test 65 (İnsan Anatomisi ve 3 Beden Profili Doğrulaması).
