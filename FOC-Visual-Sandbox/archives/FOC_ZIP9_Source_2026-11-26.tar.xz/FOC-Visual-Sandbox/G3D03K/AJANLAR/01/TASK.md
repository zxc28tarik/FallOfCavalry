# AJAN 01 — İNSAN ANATOMİSİ VE GÖVDE KALİTESİ

## 1. GÖREV TANIMI
Mevcut asker modellerinin temel anatomisini Age of Empires III: Definitive Edition kalitesine yaklaştıracak şekilde geliştirmek:
- Baş ve boyun oranlarını düzeltme, servikal konik boyun geçişi.
- Omuz ve deltoid kas kavisleri ile göğüs-bel incelmesi (V-taper).
- Eklemlerdeki sert kırılmaları yumuşatma: Dirsek ve diz mafsalları (`dome` kubbe geçişleri).
- Parmak kümesi ve başparmak kavrayışına sahip mafsallı el geometrisi (`buildArticulatedHand`).
- Baldır (gastrocnemius) kavisleri ve topuklu deri çizme/ayakkabı anatomisi.
- 3 Temel Vücut Profili (`BODY_PROFILES`):
  1. `slim`: İnce yapılı, çevik birlikler (Azap, genç Levend).
  2. `average`: Standart hat askeri fiziği (Yeniçeri, Musketier, Pikeniere).
  3. `heavy`: Geniş omuzlu, derin göğüslü ağır askerler (Bostancı, Kürassier, Kapıkulu).
- Mevcut animasyon ve rig gruplarının (`torso`, `leftLegLower`, `twoHandPike` vb.) eksiksiz korunması.

## 2. TAMAMLANAN GELİŞTİRMELER
- `BODY_PROFILES` tanımlandı (omuz, göğüs, bel ve uzuv oranları ayrıştırıldı).
- `buildArticulatedHand` fonksiyonu eklendi.
- `buildAnatomicalHead` ve `buildAnatomicalHumanBase` fonksiyonları geliştirildi.
- Test 65 tanımlandı ve %100 başarıyla doğrulandı.
