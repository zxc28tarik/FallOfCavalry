# AJAN 06 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSModularUnitBuilder` sınıfı (deterministik modüler asker üretimi).
- Eklendi: `#btnShowcaseQualityToggle` vitrin butonu.
- Eklendi: Model kalitesi kıyaslama mekanizması (G3D-03J Klasik vs G3D-03K Detaylı).
- Eklendi: Test 70 (Modüler Asker Birleştirme Motoru ve Vitrin Model Kalitesi Kıyaslaması).
