# AJAN 04 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `buildAnatomicalHead` fonksiyonu (kaş kemeri, burun köprüsü, çene, kulaklar).
- Eklendi: Yüz kılı varyantları (`ottoman_pala`, `vandyke`, `full_beard`).
- Eklendi: Başlık içi kafa hacmi boşluğu optimizasyonu.
- Eklendi: Test 68 (Baş, Yüz Anatomisi ve Miğfer Oturumu Doğrulaması).
