# FALL OF CAVALRY — G3D-03H RTS ÖZELLİKLERİ VE KULLANICI REHBERİ
## 6 AJANLI RTS KOMUTA, BİRLİK YÖNETİMİ VE FORMASYON SİSTEMİ

### 1. GENEL BAKIŞ VE TASARIM VİZYONU

G3D-03H aşamasıyla birlikte *Fall of Cavalry Visual Sandbox*, salt bir 3D görsel animasyon izleyicisinden **tam işlevli, oynanabilir bir 3D Gerçek Zamanlı Strateji (RTS) savaş motoruna** dönüştürülmüştür.

- **Görsel Kalite Referansı:** Age of Empires III: Definitive Edition (1648–1650 dönemi üniformaları, miğferleri, tüfekleri ve 5 binek ırkı).
- **Savaş Alanı Okunurluğu:** Age of Empires IV (Sade ve ergonomik arayüz, temiz seçim çemberleri, formasyon silüeti netliği).
- **Ölçek:** 300 aktif asker (150 Mavi Dost / 150 Kırmızı Düşman) üzerinde 100+ FPS akıcı performans.

---

### 2. GELİŞTİRİLEN 6 TEMEL RTS SİSTEMİ

#### A. RTS Birlik Seçimi (Ajan 01)
- **Sol Tık Seçim:** Tıklanan asker veya bağlı olduğu taktik grup doğrudan seçilir.
- **Dikdörtgen Alan Seçimi (Marquee Drag-Box):** Fare sol tuşu basılı tutularak sürüklendiğinde yarı saydam mavi seçim kutusu açılır ve kapsanan alandaki tüm dost birlikler seçilir.
- **Shift ile Çoklu Seçim:** Shift tuşuna basılı tutularak tıklanan veya kutuyla taranan birlikler mevcut seçime eklenir veya seçimden çıkarılır.
- **Çift Tıklama (Aynı Sınıf):** Bir birliğe 350 ms içinde çift tıklandığında ekranda görünen aynı sınıftaki (ör. tüm mızrakçılar veya tüm tüfekçiler) tüm birlikler seçilir.
- **Kontrol Grupları (1–9):**
  - `Ctrl + 1..9`: Mevcut seçimi ilgili kontrol grubuna atar.
  - `1..9`: İlgili kontrol grubunu anında geri çağırır.
- **Görsel Seçim Halkaları:** Seçilen askerlerin altında dinamik WebGL zemin halkaları belirir (Dost birlikler için `#38bdf8` Mavi/Camgöbeği, Düşman için `#ef4444` Kırmızı).

#### B. Birlik Hareketi ve Yönlendirme (Ajan 02)
- **Sağ Tık Hareket Emri:** Seçili birlikler haritada sağ tıklanan zemin koordinatına doğru formasyon düzeninde intikale başlar.
- **Shift ile Sıralı Rota (Waypoint Queue):** Shift + Sağ tık yapıldığında yeni hedef mevcut intikalin ardına eklenir. Askerler ilk noktaya varınca durmaksızın sıradaki rotaya devam eder.
- **Görsel Hedef Halkası (Move Beacon):** Sağ tıklanan noktada zemin üzerinde genişleyerek sönen altın sarısı (`#facc15`) bir radar dalgası oluşur (0.8 saniyede sönümlenir).
- **Pürüzsüz Dönüş ve Adım:** Askerler hedef yönüne doğru yumuşak açısal sönümleme (angular lerp) ile döner ve yürüyüş animasyonu adımla kusursuz senkronize edilir.

#### C. 6 Taktik Formasyon Sistemi (Ajan 03)
Seçili birlikler alt konsoldaki butonlarla veya `F1–F6` tuşlarıyla anında taktik dizilişlerini değiştirebilir:
1. **Hat (Line - F1):** 2 kademe derinliğinde geniş ateş ve mızrak hattı. Tüfekçi yaylım ateşi için idealdir.
2. **Kol (Column - F2):** 3 sıra genişliğinde yürüyüş kolu. Hızlı intikal ve dar geçitler için uygundur.
3. **Kama (Wedge - F3):** Liderin uçta olduğu V-şekilli süvari yarma düzeni.
4. **Gevşek (Loose - F4):** Top ve yaylım ateşine karşı 2 kat geniş aralıklı seyrek düzen.
5. **Dağınık (Skirmish - F5):** Avcı ve hafif piyadeler için organik Fibonacci sarmalı dağılımı.
6. **Çember / Kirpi (Circle - F6):** Dört bir yana ($360^\circ$) dışa dönük dairesel savunma halkası. Süvari hücumlarına karşı geçilmez kirpi düzeni.

*Not: Süvari birlikleri piyadeye kıyasla otomatik olarak 1.8 kat daha geniş manevra aralığı kullanır. Askerler formasyon değişiminde ışınlanmaz; yürüyerek yeni yuvalarına geçer.*

#### D. RTS Kamera ve Savaş Alanı Kontrolü (Ajan 04)
- **Kaydırma (Pan):** `WASD` veya Yön tuşları ya da fareyi ekran kenarına götürerek haritada akıcı gezinti.
- **Yakınlaşma (Zoom):** Fare tekerleğiyle 10m (asker yüzlerini ve zırh detaylarını inceleme) ile 95m (genel taktik kuşbakışı) arasında yumuşak zoom.
- **Döndürme (Orbit):** Fare orta tuşuyla (tekerlek basılı) veya `Alt + Sol Tık` ya da `Q / E` tuşlarıyla sahneyi $360^\circ$ döndürme.
- **Seçime Odaklanma:** `Space` tuşu kamerayı doğrudan seçili birliklerin merkezine yumuşakça odaklar.

#### E. 8 Taktik RTS Emri (Ajan 05)
Alt konsoldan veya tek tuşla verilebilen gerçek eylem komutları:
- `[M] Hareket (Move):` Hedefe intikal eder, çatışmaya girmez.
- `[H] Konum Tut (Hold):` Asker olduğu yerde durur; mızrakçılar mızrak indirir (`guard` pozu), tüfekçiler tetik kurar.
- `[A] Saldır (Attack):` Hedefe hücum eder, yakın dövüş / ateş eylemine başlar.
- `[T] Saldır-İlerle (Attack Move):` İlerlerken menzile giren düşmanla çatışır.
- `[R] Geri Çekil (Retreat):` Anında 180 derece dönüp geriye 20 metre taktiksel ricat yapar (+%25 hız).
- `[F] Serbest Ateş (Fire at Will):` Menzildeki düşmana sürekli yaylım ateşi açar.
- `[X] Ateşi Kes (Hold Fire):` Atışı durdurur, kara barut tasarrufu sağlar.
- `[G] Yeniden Topla (Regroup):` Dağılmış birlikleri komutanın etrafında derhal sıkı formasyona çeker.

#### F. Sade Taktik Arayüz & İnteraktif Minimap (Ajan 06)
- **Alt Konsol:** Yarı saydam cam panel; sol tarafta seçili birliğin armasını, sınıfını, asker sayısını, aktif emrini ve formasyonunu gösterir.
- **İnteraktif Minimap (Radar):**
  - Savaş alanının kuşbakışı 2D radar haritası.
  - Dost (mavi) ve düşman (kırmızı) birlik noktaları; seçili birliklerde parlak sarı halka.
  - Kameranın baktığı alanı gösteren dinamik görüş piramidi (frustum) çerçevesi.
  - **Minimapa Sol Tık:** Kamerayı doğrudan tıklanan koordinata uçurur.
  - **Minimapa Sağ Tık:** Seçili birliklere harita üzerinden doğrudan hareket emri verir.

---

### 3. KONTROL VE KISAYOL LİSTESİ

| Eylem | Fare / Klavye Girişi | Açıklama |
|---|---|---|
| **Birlik Seç** | `Sol Tık` | Tekil asker veya grup seçer |
| **Kutuyla Çoklu Seç** | `Sol Tık + Sürükle` | Dikdörtgen alan içindeki tüm dost birlikleri seçer |
| **Seçime Ekle/Çıkar** | `Shift + Sol Tık / Sürükle` | Mevcut seçime yeni birlikler dahil eder |
| **Aynı Sınıfı Seç** | `Çift Tık` | Ekrandaki aynı sınıftan tüm birlikleri toplar |
| **Hareket Emri Ver** | `Sağ Tık` | Seçili birlikleri tıklanan zemin noktasına sevk eder |
| **Sıralı Rota Ekle** | `Shift + Sağ Tık` | Rota noktası (waypoint) kuyruğuna ekler |
| **Kamera Kaydır** | `W, A, S, D` veya `Yön Tuşları` | Savaş alanında gezinti |
| **Kamera Döndür** | `Orta Fare Tuşu` veya `Q / E` | Kamerayı ekseni etrafında çevirir |
| **Kamera Yakınlaş** | `Fare Tekerleği` | Zoom yapar (10m - 95m) |
| **Seçime Odaklan** | `Space` | Kamerayı seçili birliklerin merkezine kilitler |
| **Kontrol Grubu Ata** | `Ctrl + 1..9` | Seçimi hafızaya kaydeder |
| **Kontrol Grubu Çağır**| `1..9` | Kayıtlı grubu seçer |
| **Taktik Emirler** | `M, H, A, T, R, F, X, G` | 8 taktik RTS emrini anında tetikler |
| **Formasyonlar** | `F1, F2, F3, F4, F5, F6` | Hat, Kol, Kama, Gevşek, Dağınık, Çember |
| **Minimap Gezintisi** | Minimapta `Sol Tık / Sürükle` | Kamerayı tıklanan bölgeye ışınlar |
| **Minimap Komutu** | Minimapta `Sağ Tık` | Harita üzerinden doğrudan intikal emri verir |
