# FALL OF CAVALRY — G3D-03J BİRLİK KATALOĞU (UNIT CATALOG)
## 1648–1650 OSMANLI VE AVRUPA / KUTSAL ROMA ASKER SINIFLARI DETAYLI REHBERİ

Bu katalog, G3D-03J aşamasında modellenen 10 Osmanlı ve 5 Avrupa birliğinin tarihsel arka planını, görsel anatomisini, silah-zırh donanımlarını ve RTS savaş rollerini içerir.

---

## 1. OSMANLI ORDUSU (THE OTTOMAN ARMY)

### 1.1. YENİÇERİ (JANISSARY) — KAPIKULU OCAĞI
- **Tarihsel Tanım:** 17. yüzyıl ortası Osmanlı ordusunun daimi, maaşlı ve seçkin piyade omurgası.
- **Görsel Başlık:** Beyaz keçe **Börk (Serpuş)**. Ön tarafında pirinç kaşıklık (**zarf**) bulunur, arka kısmı enseye ve sırtın üstüne doğru sarkar.
- **Kıyafet ve Zırh:** Yakut kırmızısı kaftan (`ottomanCrimson`), koyu lacivert şalvar (`ottomanNavy`), altın sarısı ipek kuşak. Varyant 2'de göğüste çelik halka örme ve disk plakadan oluşan **Çevşen**.
- **Silahlar:**
  - *Varyant 1 (Menzilli):* Uzun namlulu Osmanlı fitilli tüfengi (`damascusSteel`), pirinç bilezikler ve barutluk.
  - *Varyant 2 (Yakın Dövüş):* Fildişi kabzalı eğri **Yatağan** kılıcı ve dairesel örme hasır **Kalkan** (`gold` / `bronze`).
- **Taktik RTS Rolü:** Yüksek disiplinli ateş hattı veya çevşen zırhlı yakın koruma piyadesi.

### 1.2. AZAP (AZAP HAFİF PİYADESİ)
- **Tarihsel Tanım:** Sefer dönemlerinde eyaletlerden toplanan, ön saflarda düşman hücumunu karşılayan ve kargı duvarı ören hafif piyade.
- **Görsel Başlık:** Kırmızı sivri külah etrafına sarılmış beyaz pamuklu **Sarık**.
- **Kıyafet ve Zırh:** Ham keten gömlek (`linen`), deri koruyucu yelek, hafif şalvar. Ağır zırh taşımazlar, hareket kabiliyetleri yüksektir.
- **Silahlar:**
  - *Varyant 1:* 3.85 metre uzunluğunda, çelik hilal ağızlı **Tırpan Kargı** (`twoHandPike`).
  - *Varyant 2:* Kavisli Osmanlı kılıcı (**Şemşir**) ve hafif deri kalkan.
- **Taktik RTS Rolü:** Hızlı intikal eden mızrak duvarı ve süvari önleme birliği.

### 1.3. HUMBARACI (BOMBARDIER / GRENADIER)
- **Tarihsel Tanım:** Humbaracı Ocağı'na bağlı, el humbaraları (ilkel el bombaları) ve havan topları konusunda uzmanlaşmış istihkâm piyadesi.
- **Görsel Başlık:** Zümrüt yeşili külahlı humbaracı sarığı (`ottomanEmerald`).
- **Kıyafet ve Zırh:** Patlamalara ve kıvılcımlara dayanıklı kalın deri önlük ve deri tozluklar. Çapraz asılmış deri humbara çantası.
- **Silahlar:**
  - *Varyant 1:* Sağ elde fitili tutuşmuş, kalın döküm demir küre **Humbara** bombası.
  - *Varyant 2:* Kuşakta kısa süvari piştovu ve savunma için yatağan.
- **Taktik RTS Rolü:** Düşman tahkimatlarına ve sıkışık piyade karelerine (tercio) karşı yüksek alan hasarlı şok birliği.

### 1.4. BOSTANCI (SARAY MUHAFIZI / ELITE GUARD)
- **Tarihsel Tanım:** Payitahtı, sarayı ve padişahı korumakla görevli, fiziksel güçleriyle seçilen en üst düzey saray muhafızı.
- **Görsel Başlık:** Karakteristik yüksek konik kırmızı **Bostancı Külahı** ve altın alınlık bandı.
- **Kıyafet ve Zırh:** Kırmızı dolaman, altın varaklı ağır çelik çevşen göğüs zırhı (`damascusSteel`).
- **Silahlar:**
  - *Varyant 1:* İki elle savrulan, hilal şeklinde geniş çelik ağızlı ağır muhafız **Teberi** (crescent poleaxe).
  - *Varyant 2:* Ağır kalibreli altın işlemeli saray tüfengi.
- **Taktik RTS Rolü:** En yüksek can ve zırh değerine sahip, geri çekilmeyen elit hat yarıcı muhafız.

### 1.5. LEVEND (DÜZENSİZ SAHİL & DENİZ PİYADESİ)
- **Tarihsel Tanım:** Ege ve Akdeniz kıyılarından toplanan, donanmada ve kara seferlerinde kullanılan cesur ve atılgan düzensiz tüfekçiler.
- **Görsel Başlık:** Sarı ve lacivert çizgili levent sarığı (`ottomanSaffron` & `ottomanNavy`).
- **Kıyafet ve Zırh:** Göğsü açık keten gömlek, kolsuz deri yelek, geniş kuşak.
- **Silahlar:**
  - *Varyant 1:* Kuşakta çapraz duran çift namlulu Osmanlı piştovları ve tırpan.
  - *Varyant 2:* Fitilli uzun menzilli Balkan tüfengi.
- **Taktik RTS Rolü:** Çevik taciz ateşi, açık formasyon çatışması ve pusu eylemleri.

---

## 2. OSMANLI SÜVARİLERİ (THE OTTOMAN CAVALRY)

### 2.1. SİPAHİ (TIMARLI SÜVARİ)
- **Tarihsel Tanım:** Dirlik ve tımar sahibi, sefer zamanı kendi atı ve cebe donanımıyla orduya katılan asil Osmanlı süvarisi.
- **Görsel Başlık:** Sivri uçlu, burun demirli (nasal bar) çelik **Şişak / Tolga** miğfer.
- **Kıyafet ve Zırh:** Çelik halka ve levha çevşen zırh, bazuband kolçaklar, işlemeli kumaş çaprak örtülü Arap/Anadolu harp atı (`courser_horse`).
- **Silahlar:**
  - *Varyant 1:* 4 metrelik kırmızı-altın flandreli **Sipahi Kargısı** ve sol kolda örme çelik kalkan.
  - *Varyant 2:* Eğri Osmanlı kılıcı (`damascusSteel`) ve sadak.
- **Taktik RTS Rolü:** Dengeli, manevra kabiliyeti yüksek ana muharebe süvarisi.

### 2.2. KAPIKULU SİPAHİSİ (HASSA AĞIR SÜVARİSİ)
- **Tarihsel Tanım:** Padişahın hassa ordusuna bağlı 6 Bölük Halkı süvarisi; dönemin en ağır zırhlı Osmanlı atlı birliği.
- **Görsel Başlık:** Zırh peçeli (camail) altın yaldızlı tolga.
- **Kıyafet ve Zırh:** Göğüs, sırt ve yanları koruyan dört büyük yuvarlak çelik levhadan oluşan **Çar-Ayna** göğüslüğü. Ağır harp atının başında çelik alınlık (**chamfron** / alınlık) bulunur.
- **Silahlar:**
  - *Varyant 1:* Ağır süvari kargısı.
  - *Varyant 2:* 6 dilimli çelik ezici **Şeşper** gürzü.
- **Taktik RTS Rolü:** Düşman hatlarını yarmak üzere tasarlanmış süper ağır şok süvarisi.

### 2.3. DELİ SÜVARİSİ (DARING VANGUARD SHOCK CAVALRY)
- **Tarihsel Tanım:** Korkusuzlukları, gözü kara hücumları ve egzotik vahşi hayvan postlarıyla düşmana dehşet salan sınır boyu akıncı süvarisi.
- **Görsel Başlık:** İki yanında gerçek kartal kanatları yükselen yüksek kırmızı kalpak.
- **Kıyafet ve Zırh:** Gövdeye ve omuza sarılmış benekli leopar/pars postu (`leopardPelt`). Metal plaka zırh taşımazlar.
- **Silahlar:**
  - *Varyant 1:* Sivri uçlu hafif şok kargısı.
  - *Varyant 2:* Yalmanlı süvari kılıcı ve hafif kalkan.
- **Taktik RTS Rolü:** Yüksek hücum bonusuna ve moral bozucu etkiye sahip öncü şok birliği.

### 2.4. CİRİTÇİ (ATLI CİRİT / TACİZ SÜVARİSİ)
- **Tarihsel Tanım:** Anadolu'nun kadim atlı cirit geleneğini harp sahasına taşıyan, hareket halindeyken cirit fırlatan çevik süvari.
- **Görsel Donanım:** Eyerin arka yan tarafına monte edilmiş deri cirit sadakı; sadakta 3 adet sert ahşap ve demir uçlu cirit mızrağı bulunur.
- **Taktik RTS Rolü:** Ağır birliklerin etrafında dönerek menzilli mızrak tacizi uygulama.

### 2.5. AKINCI (BOZKIR STEP ATLI OKÇUSU)
- **Tarihsel Tanım:** Düşman topraklarına keşif ve yıpratma akınları düzenleyen, yay ve ok ustası hafif süvari.
- **Görsel Donanım:** Sırtta asılı kompozit Türk yayı ve tirkeş (ok sadakı). Dayanıklı step atı (`steppe_horse`).
- **Taktik RTS Rolü:** Vur-kaç taktikleri ve düşman ikmal hatlarını kesme.

---

## 3. AVRUPA / KUTSAL ROMA İMPARATORLUĞU (HOLY ROMAN EMPIRE)

### 3.1. MUSKETIER (TÜFEKÇİ)
- **Görsel Başlık:** Geniş siperlikli, sola doğru bükük devekuşu tüylü süvari şapkası.
- **Donanım:** Göğüsten çapraz inen 12 ahşap barut tüpünden oluşan **12 Havariler (Twelve Apostles)** bandolyesi.
- **Silah:** Ağır fitilli musket ve namlu ağırlığını destekleyen metal çatallı değnek (rest).

### 3.2. PIKENIERE (MIZRAKÇI)
- **Görsel Başlık:** Yüksek hilal ibikli çelik **Morion** miğferi.
- **Zırh:** Mermiyi sektirmek için sivri omurgalı dövülen **Tapul** göğüs zırhı ve uylukları koruyan çelik tasset plakaları.
- **Silah:** 4.5 metre uzunluğunda kül dişbudak piyade pikesi.

### 3.3. HELLEBARDIER (HALBERDIER)
- **Görsel Başlık:** Öne eğik siperlikli ve yanak korumalı **Burgonet** miğferi.
- **Silah:** Balta ağzı, arkasında süvariyi attan çekmek için gaga kancası ve tepesinde zırh delici sivri kargı ucu bulunan çok işlevli **Hellebarda**.

### 3.4. KÜRASSİER (AĞIR SÜVARİ)
- **Görsel Başlık:** Üç koruyucu çubuklu demir burunluk taşıyan karartılmış **Zischägge** miğferi.
- **Zırh:** Boyundan dize kadar uzanan ağır üç çeyrek karartılmış çelik plaka zırh (`darkSteel`).
- **Silah:** Eyer kılıfında çift çarklı piştov (wheellock) ve geniş ağızlı süvari kılıcı.

### 3.5. REITER (KARABİNİER SÜVARİSİ)
- **Görsel Donanım:** Karartılmış çelik göğüslük, kalın manda derisi yelek (**buff coat**), çarklı mekanizmaya sahip süvari karabinası.
