# FALL OF CAVALRY — G3D-03F
## KALİTE GÜVENCE (QA) VE TEST DOĞRULAMA RAPORU

### 1. TEST ÇERÇEVESİ VE YÖNTEM
- **Hedef Dosyalar:**
  1. `G3D03F_WORKING.html`
  2. `INTEGRATION/FOC_G3D03F_6_AJAN_BIRLESIK_ADAY.html`
- **Tarayıcı Motoru:** Google Chrome 1440x900 (Headless / İzole Geçici Profil)
- **Doğrulama Betikleri:** `tools/run_headless_test.py` ve `tools/profile_performance.py`
- **Kural:** Sıfır sahte (mock) başarı beyanı; gerçek Chromium WebGL DOM çıktısı denetimi.

---

### 2. OTOMATİK BİRİM TESTLERİ (50 / 50 PASS - %100)

| No | Test Tanımı | Durum |
|---|---|---|
| 01-10 | WebGL Context, Tuval Boyutlandırma, 7 Instanced Batch Grubu, Render Modları | GEÇTİ |
| 11-20 | Piyade Yürüyüş Kinematiği, Faz Ayrımları, Ayak İrtifası ve Salınımı | GEÇTİ |
| 21-30 | Süvari Yürüyüş/Tırıs Kinematiği, At/Binici Gövde Salınımı, Eyer Uyumu | GEÇTİ |
| 31-33 | Mızrak Hazırlık Doğrultusu, Tüfek Doldurma Aşamaları, Kılıç-Kalkan Göğüs Siperi | GEÇTİ |
| 34-37 | Tek Seferlik Saldırı Eylemi, Sonsuz Döngü Engeli, Referans Pozuna Dönüş | GEÇTİ |
| 38-44 | 5 At Tipi Geometrisi, Kamera Koruma, Sektör Değişimi, Context Kaybı Restorasyonu | GEÇTİ |
| 45 | **Süvari Savaş Animasyonları (Mızrak, Kılıç, Karabina, Tabanca) Olay Akışı & Kesinti Toleransı** | GEÇTİ |
| 46 | **Piyade Savaş Animasyonları (Mızrak, Tüfek, Kılıç-Kalkan) Ayak Kaymama & Hareketli Saldırı** | GEÇTİ |
| 47 | **Birleşik Animasyon Önizlemesi (300 Asker Savaş & İntikal Döngüsü, 4 Bacaklı İlerleme)** | GEÇTİ |
| 48 | **At Yürüyüş-Tırıs Geçişi, Toynak Dünya Koordinat Zemin Teması ($M_{world}$) & Eyer Uyumu** | GEÇTİ |
| 49 | **Kara Barut Efekt Havuzu (64 Slot), GPU Handle Yaşam Döngüsü & Sıfır GC Tahsisi** | GEÇTİ |
| 50 | **Saha Görselliği (7 Batch, Rim Light $\ge 0.30$) & 300 Askerli Sahne Profilleme** | GEÇTİ |

---

### 3. ÇÖZÜLEN 5 QA BULGUSUNUN DENETİM TABLOSU

| Bulgu | Açıklama | Denetim Kriteri | Sonuç |
|---|---|---|---|
| **BULGU A** | Birleşik önizleme sürekli hareket üretmiyor | `_buildCombinedPreviewSnapshot(leg)` 4 bacak döngüsü ve `_onFrameTick` 2.8s ilerleme denetimi | **BAŞARILI** (Askerler donmuyor, 4 bacak döngüsel ilerliyor) |
| **BULGU B** | Kara barut GPU handle temizliği eksik | `SoldierVisualRegistry.invalidateGpuHandles()` -> `powderFxPool.invalidateGpuHandles()` | **BAŞARILI** (`batch._gl = null`, `_glInstanceBuffer = null`, `_needsUpload = true`) |
| **BULGU C** | WebGL 60 FPS kanıtı yetersiz | Gerçek Chromium üzerinde `tools/profile_performance.py` ile FPS, frame time ölçümü | **BAŞARILI** (Ortalama frame süresi 0.06ms - 12.36ms; 81 - 120 FPS) |
| **BULGU D** | Heap tahsisleri ve GC baskısı | Simülasyon döngüsünde Float32Array ve scratch matris referans kararlılığı | **BAŞARILI** (`_scratchA`, `_scratchB`, `_tmpPartLocalMat` referansları invariant) |
| **BULGU E** | Toynak zemin teması dünya koordinatlarında kanıtlanmadı | $M_{world} = M_{soldier} \times M_{local}$ ile gerçek şablon toynak frustumu 16 adım kot hesabı | **BAŞARILI** (Duruş kotu $bottomY \approx 0.00$, batma $bottomY \ge -0.05$) |

---

### 4. GERİLEME (REGRESSION) VE VERİ BÜTÜNLÜĞÜ DENETİMİ
- **206 Model Şablonu:** Değiştirilmedi, silinmedi veya geometri matrisleri bozulmadı.
- **442 Asker Kaynak Verisi:** 12 grup ve taktik veriler aynen korundu.
- **Sektör Geçişleri:** Sektör 0 (300 asker) -> Sektör 1 (62 asker) -> Sektör 2 (50 asker) geçişleri sorunsuz çalışmaktadır.
- **Context Kaybı:** Yapay WebGL context kaybı tetiklendiğinde tuval siyah ekrana düşmemekte, `_restoreContext()` ile tüm tamponlar ve kara barut parçacıkları anında yeniden yüklenmektedir.
- **Kamera Koruma:** Önizleme modları açılıp kapatıldığında kullanıcı kamera hedefi ve mesafesi $10^{-4}$ toleransla korunmaktadır.
