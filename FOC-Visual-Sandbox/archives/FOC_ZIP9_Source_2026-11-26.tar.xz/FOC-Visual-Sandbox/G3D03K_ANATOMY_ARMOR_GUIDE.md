# FALL OF CAVALRY — G3D-03K ANATOMİ, KIYAFET VE ZIRH DETAY REHBERİ

Bu rehber, G3D-03K aşamasında asker modellerine kazandırılan anatomik geliştirmeleri, vücut profillerini, çok katmanlı giysi yapılarını ve zırh geometrilerini açıklar.

---

## 1. İNSAN ANATOMİSİ VE VÜCUT PROFİLLERİ (BODY PROFILES)

Asker modelleri artık tek bir standart silindir veya kutu gövde üzerinden üretilmemektedir. `BODY_PROFILES` kütüphanesi ile üç farklı anatomik beden tipi tanımlanmıştır:

```javascript
const BODY_PROFILES = {
    slim: {
        shoulderWidth: 0.46,
        chestWidth: 0.44,
        chestDepth: 0.28,
        waistWidth: 0.36,
        waistDepth: 0.24,
        limbRadiusScale: 0.88,
        headScale: 0.96
    },
    average: {
        shoulderWidth: 0.52,
        chestWidth: 0.50,
        chestDepth: 0.32,
        waistWidth: 0.40,
        waistDepth: 0.27,
        limbRadiusScale: 1.0,
        headScale: 1.0
    },
    heavy: {
        shoulderWidth: 0.58,
        chestWidth: 0.56,
        chestDepth: 0.38,
        waistWidth: 0.46,
        waistDepth: 0.32,
        limbRadiusScale: 1.15,
        headScale: 1.05
    }
};
```

### Anatomik Özellikler:
- **Omuz ve Deltoidler:** Göğsün üst iki köşesinde omuz mafsalını saran deltoid kas kubbeleri (`sphere`) eklenmiştir. Bu yapı kol sallanırken gövde ile kol arasında delik veya ayrılma oluşmasını engeller.
- **V-Taper Göğüs:** Omuzlardan bele doğru doğal bir incelme uygulanmıştır.
- **Mafsallı Eller (`buildArticulatedHand`):**
  - Avuç içi düzlemi (`box` 0.08 x 0.09 x 0.05).
  - Başparmak kökü ve açılı kavrama mafsalı.
  - Silahı kavrayan parmak kümesi.
- **Bacak ve Ayak Anatomisi:**
  - Uylukta kuadriseps kas kitlesi.
  - Diz kapağında artikülasyon kubbesi (`dome`).
  - Baldırda arkaya doğru kavis yapan gastrocnemius kas kitlesi.
  - Ayakta deri ayakkabı tabanı ve yükseltilmiş topuk parçası.

---

## 2. OSMANLI ÇOK KATMANLI KIYAFET VE ZIRHLARI

### 2.1. Kaftan ve Şalvar
- **Kloş Alt Etek:** Bel kotundan (`y = 0.84`) uyluklara doğru genişleyen `frustum` geometrisi ile dökümlü kumaş silueti sağlanmıştır.
- **Altın Sırma Kenarlık:** Kaftanın etek ucunda 3 cm kalınlığında altın nakışlı bordür (`gold`).
- **Yırtmaçlı Ön Açıklık:** Kaftanın önündeki dikey yırtmaç aralığından iç dolaman ve gömlek görünmektedir.
- **3 Boyutlu İpek Kuşak:** Beli tamamen saran kalın kumaş silindiri ve üzerinde kabartmalı altın toka.

### 2.2. Zırh Donanımları
- **Çevşen (Disk Plaka & Örme):** Göğsün tam ortasında dövme çelik dairesel disk (`damascusSteel`) ve merkezinde pirinç göbek (`burnishedBronze`).
- **Bazuband (Kolçaklar):** Ön kolda dirsekten bileğe kadar uzanan çelik boru koruyucular.
- **Börk Başlığı:** Beyaz keçeden konik tepe, önde pirinç kaşıklık (`zarf`) ve arkadan omuzlara dökülen kumaş kıvrımları.

---

## 3. AVRUPA / HRE ASKER KIYAFET VE ZIRHLARI

### 3.1. Peascod Doublet & Falling Collar
- **Peascod Formu:** 17. yüzyıl ortasının öne doğru bombeli, aşağıya doğru incelen süvari ceketi kesimi.
- **Bel Dilimleri (Peplos Tabs):** Bel kemerinin altından uyluklara sarkan kumaş/deri kanatçıklar.
- **Düşen Keten Yaka (Falling Collar):** Omuzların üzerine yayılan kolalı beyaz keten devrik yaka.
- **Süvari Baldriği:** Sol omuzdan sağ kalçaya inen kalın manda derisi kılıç taşıma kayışı ve demir tokası.

### 3.2. Yüksek Detaylı Zırhlar
- **Morion Miğferi:** Yüksek hilal ibikli çelik gövde (`steel`), öne ve arkaya doğru sivrilen kavisli siperlik ve pirinç perçin şeridi.
- **Burgonet Miğferi:** Sabit kaş siperliği, enseye inen 3 kademeli lamel zırhı (ıstakoz kuyruğu) ve menteşeli yanak siperleri.
- **Tapul Göğüslüğü:** Göğsün ortasında tüfek mermisini sağa/sola sektiren dövme omurga ve uylukları örten mafsallı tasset plakaları.
- **Kürassier Üç Çeyrek Zırhı:** Karartılmış çelikten (`blackenedSteel`) omuzluk, dirseklik, göğüslük ve dizçek plakaları.
