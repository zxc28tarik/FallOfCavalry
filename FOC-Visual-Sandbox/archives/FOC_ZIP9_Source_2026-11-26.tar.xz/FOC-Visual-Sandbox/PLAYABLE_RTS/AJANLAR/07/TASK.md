# Ajan 07 — Taktik Arazi Sistemi & Hız Çarpanları
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** Yol Hız Bonusu (+%20), Engebeli Arazi/Bataklık Yavaşlatması, Yükseklik Menzil/Hasar Avantajı
- **Ayrıntılı Açıklama:** Tarihsel savaş alanındaki ana toprak yoldan yürüyen birlikler %20 daha hızlı intikal eder. Yüksek sırtı tutan tüfekçiler %12 menzil ve %10 hasar avantajı kazanır; mermilerin vurduğu zeminlerde dinamik yanık/darbe izleri oluşur.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
