# Ajan 04 — Süvari Hücumu (Charge) & Pike Karşı-Duruşu
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** Dinamik Hücum Hızı (9.0 m/s), Nallardan Toz Kalkışı, Şok Hasarı (+%60) & Braced Pike Savunması
- **Ayrıntılı Açıklama:** Süvari birliği 10m üzeri mesafeden taarruza kalktığında dörtnal hız bonusu kazanır. Hafif piyadeye çarptığında şok hasarı verip geriye iter; fakat savunma konumundaki (Hold/Braced) pikelere çarptığında hücum kırılır ve süvari ağır karşı hasar alır.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
