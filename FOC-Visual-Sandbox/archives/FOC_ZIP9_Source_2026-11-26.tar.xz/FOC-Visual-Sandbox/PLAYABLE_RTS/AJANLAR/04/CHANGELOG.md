# CHANGELOG — Ajan 04 — Süvari Hücumu (Charge) & Pike Karşı-Duruşu
## Sürüm G3D-03L Geliştirmeleri
- Doğrudan ana oynanabilir RTS motoruna (`FallOfCavalry_PLAYABLE_RTS.html` ve `G3D03L_WORKING.html`) entegre edildi.
- Test kapsamı 78'den 84 teste çıkarıldı (%100 PASS).
- Başarıyla tamamlandı ve koordinatör tarafından doğrulandı.
