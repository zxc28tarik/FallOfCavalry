# Ajan 02 — Dinamik Taktik Formasyon Motoru
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** 6 Formasyon (Hat, Kol, Kama, Gevşek, Dağınık, Çember) & Yumuşak Ayrışma (Anti-Bunching)
- **Ayrıntılı Açıklama:** Seçili birliklerin geometriye göre slot hesaplayarak düzenli intikal etmesi, Hat (geniş yaylım), Kama (süvari yarma), Kol (yol yürüyüşü), Dağınık (avcı/top atışından kaçınma) ve askerlerin iç içe girmesini önleyen soft-collision ayrışma fiziği.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
