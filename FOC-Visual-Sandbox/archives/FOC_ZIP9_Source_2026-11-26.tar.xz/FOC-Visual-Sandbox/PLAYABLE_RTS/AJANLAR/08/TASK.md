# Ajan 08 — İnteraktif Taktik Radar & Dinamik Birim Kartı
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** Radar Üzerinden Tıkla-Kaydır Kamera, Sağ Tık İntikal Emri & Canlı Sağlık/Durum Birim Kartı
- **Ayrıntılı Açıklama:** Taktik radar üzerine sol tıklandığında kamera doğrudan o koordinata kayar; sağ tıklandığında seçili birlikler harita üzerinden hedef konuma intikal eder. Alt konsoldaki birim kartı seçili askerlerin sınıfını, canlı sayısını ve ortalama can yüzdesini anlık gösterir.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
