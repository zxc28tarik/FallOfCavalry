# Ajan 03 — Balistik Motoru & Mermi İzleri (Tracers)
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** Yaylım Ateşi Balistiği, Mermi İzi (Tracer) Havuzu, Barut Dumanı (Powder FX) & Menzil Çemberi
- **Ayrıntılı Açıklama:** Tüfekler 24m menzile girdiğinde namludan hedefe doğru yüksek hızlı parlak mermi izleri (tracers) çizer, namlu önünde hacimli barut dumanları açar ve seçili birliklerin menzil çemberini dinamik gösterir.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
