# Ajan 06 — Taktik Savaş Yapay Zekası (Battle AI)
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** 3 Taktik Kol Düzeni (Merkez Tercio, Sol Kanat Süvari, Sağ Kanat Süvari) & Kuşatma Manevraları
- **Ayrıntılı Açıklama:** Kutsal Roma ordusunu 3 kola böler: Merkez pikeli ve yaylım tüfekçileri ana hattı tutarak oyuncu merkezine ilerlerken, iki kanattaki Kürassier süvarileri geniş açıyla oyuncu ordusunun arkasına sarkarak kanat taarruzu gerçekleştirir.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
