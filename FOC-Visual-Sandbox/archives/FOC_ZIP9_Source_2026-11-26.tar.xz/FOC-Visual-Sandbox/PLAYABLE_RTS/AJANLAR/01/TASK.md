# Ajan 01 — Çoklu Birim Seçimi & Kontrol Grupları
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** SoldierInstance ↔ Seçim Havuzu, 1-9 Kontrol Grubu Atama/Çağırma, Çift Tık Odaklanma
- **Ayrıntılı Açıklama:** Birliklerin sol tık veya sürükleme ile seçilmesi, Ctrl+1..9 ile kontrol gruplarına atanması, 1..9 ile geri çağrılması ve gruba çift tıklandığında kameranın birliklerin merkezine otomatik kayması.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
