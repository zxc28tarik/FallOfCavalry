# Ajan 09 — Anatomik El, Silah Tutuşu ve Tarihsel Ekipman Geometrisi
## Görev Tanımı ve Hedefler
- **Modül Sorumluluğu:** 5 Parçalı Anatomik El (Avuç, Başparmak, 4 Kıvrık Parmak), Çift El Musket Tutuşu & Destek Çatalı
- **Ayrıntılı Açıklama:** Silahların havada asılı durmasını engelleyerek tüfek kabzasını kavrayan sağ el, kundağı alttan destekleyen sol el, 1.50m fitilli musket ve yere basan pirinç çatallı ahşap destek direği (furquet) geometrilerini sıfırdan inşa eder.
- **Sürüm Uyumluluğu:** Fall of Cavalry G3D-03L (Playable RTS)
- **Bağımlılıklar:** WebGL Instanced Batching, SoldierVisualRegistry, RTSBattleEngine, Web Audio API
- **Hedef Test Sayısı:** 84 / 84 Birim Testi (%100 PASS)
