# DEĞİŞİKLİK GÜNLÜĞÜ (CHANGELOG) — G3D-03F
## 6 AJANLI GERÇEK ZAMANLI GÖRSEL SAVAŞ AKIŞI VE QA HARDENING

### [G3D-03F] — 2026-11-25

#### 1. Mimari ve Yaşam Döngüsü İyileştirmeleri
- **4-Bacaklı Döngüsel Savaş Akışı (BULGU A Çözümü):**
  - `Battle3DPreviewController.prototype._buildCombinedPreviewSnapshot(legIndex = 0)` yöntemi 4 taktik savaş fazına bölündü (İntikal → Çarpışma/Yaylım → Doldurma/Mızrak İtişmesi → Toparlanma).
  - `_onFrameTick(dt)` içine 2.8 saniyelik zamanlayıcı eklenerek birleşik önizleme bacaklarının döngüsel ilerlemesi sağlandı. Askerlerin tek seferlik saldırı sonrası donması engellendi.
  - `{ preserveCamera: true }` parametresi ile bacak geçişlerinde kamera açısı ve mesafesi sarsıntısız korundu.
- **WebGL Context Kaybı ve GPU Handle Sıfırlama (BULGU B Çözümü):**
  - `BlackPowderFxPool.prototype.invalidateGpuHandles()` içindeki hatalı referans düzeltildi; batch'in `_gl = null`, `_glInstanceBuffer = null` ve `_needsUpload = true` bayrakları ayarlandı.
  - `SoldierVisualRegistry.prototype.invalidateGpuHandles()` içine `this.powderFxPool.invalidateGpuHandles()` çağrısı bağlandı.
- **Sıfır GC ve Scratch Matris Kararlılığı (BULGU D Çözümü):**
  - `SoldierVisualRegistry.prototype.update(dt)` iç döngüsünde geçici matris oluşturma kaldırıldı; `_scratchA`, `_scratchB`, `_tmpPartLocalMat`, `_tmpWorldPartMat` tamponları yeniden tahsis edilmeden kullanıldı.
- **Süvari Ateşli Silahları Görsel Olay Entegrasyonu:**
  - Karabina (`cavalry_carbine`) ve tabanca (`cavalry_pistol`) birimlerinin ateşleme fazı ($0.34 \le phase < 0.50$) süvari yüksekliğine ($y = 1.75$, $fwd = 0.65$) kilitlenerek namlu dumanı ve parlaması tetiklendi.

#### 2. Test Sertleştirmeleri (QA Hardening)
- **Test 45:** Süvari eylem kesintisi (`walkBlend = 0.6`, `actionBlend = 0.8`) simülasyonu ile matris geçerliliği ve sayısal kararlılık kanıtlandı.
- **Test 46:** Hareket halinde mızrak hamlesi (`computeInfantryPartLocalMatrix` ile bacak matrisi) ve ayak kaymama telafisi doğrulandı.
- **Test 47:** 300 askerin 4 taktik bacak boyunca veri bütünlüğü ve `_onFrameTick(3.0)` ile bacak ilerlemesi test edildi.
- **Test 48 (BULGU E Çözümü):** İzole yerel matris yerine dünya matrisi ($M_{world} = M_{soldier} \times M_{local}$) ve gerçek şablon toynak frustumu kullanılarak 16 adım boyunca zemin teması ($bottomY \ge -0.05$) ve eyer uyumu ($-0.05 \le riderDy \le 0.15$) kanıtlandı.
- **Test 49 (BULGU B & D Çözümü):** Context kaybı esnasında BlackPowderFxPool GPU handle'larının sıfırlandığı ve 100 karelik simülasyonda scratch matris referanslarının değişmediği doğrulandı.
- **Test 50 (BULGU C):** 7 instanced batch ve rim light faktörleri birim testinde doğrulandı; harici tarayıcı profilleyicisi ile desteklendi.

#### 3. Yeni Araçlar ve Altyapı
- **`tools/profile_performance.py`:** Google Chrome Headless üzerinde gerçek WebGL Direct3D11 bağlamında 8 farklı senaryoda ortalama FPS, P95/P99 kare gecikmeleri, draw call ve bellek kullanımını ölçen bağımsız profilleyici geliştirildi.
- **`tools/build_g3d03f_master.py`:** 6 ajanın geliştirmelerini tek kaynakta birleştiren ve regresyon denetimini otomatikleştiren derleyici betik oluşturuldu.
