# AJAN 06 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSMinimapController` sınıfı ve canvas çizim motoru.
- Eklendi: `#rtsMinimapCanvas` ve koordinat göstergesi.
- Eklendi: `#rtsBottomConsole` cam tasarım alt komut konsolu.
- Eklendi: Seçili birlik kartı dinamik bilgi güncellemesi (`_updateRTSHUD`).
- Eklendi: Minimap sol tık kamera hareketi, sağ tık hareket emri.
- Doğrulandı: Test 58 (PASS).
