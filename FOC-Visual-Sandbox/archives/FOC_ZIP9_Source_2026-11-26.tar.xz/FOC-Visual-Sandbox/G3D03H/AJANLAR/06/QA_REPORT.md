# AJAN 06 KALİTE GÜVENCE RAPORU

- Test 58: İnteraktif Minimap (3D->2D Koordinat Dönüşümü, Kamera Frustum Göstergesi & Tıklama ile Yönlendirme) -> PASS
- Arayüz Düzeni: Ekranın orta alanını kapatmayan, minimalist Age of Empires IV ergonomisi.
- Minimap Performansı: Kare başına < 0.2ms canvas çizim maliyeti.
