# AJAN 06 — SADE RTS ARAYÜZÜ VE TAKTİK MİNİMAP

## 1. GÖREV TANIMI
Keep It Simple prensibiyle ekranda dikkat dağıtmayan modern RTS arayüzü ve radar oluşturmak:
- Seçili birlik bilgi kartı (birlik adı, sınıfı, sayısı, aktif emir, formasyon).
- 8 kompakt emir butonu ve 6 formasyon butonu.
- İnteraktif Taktik Minimap (180x180 px):
  - Dost (mavi) ve düşman (kırmızı) askerlerin gerçek zamanlı noktaları.
  - Seçili birliklerin sarı halkayla vurgulanması.
  - Kamera bakış açısını gösteren beyaz frustum dikdörtgeni.
  - Minimap üzerine tıklayarak/sürükleyerek kamerayı haritada taşıma.
  - Minimap üzerine sağ tıklayarak birliklere hedef emri verme.

## 2. TAMAMLANAN GELİŞTİRMELER
- `#rtsBottomConsole` ve `#rtsMinimapWrapper` DOM/CSS bileşenleri eklendi.
- `RTSMinimapController` sınıfı geliştirildi.
- Minimap üzerinde 3D dünya koordinatları (-60..60m) ile 2D piksel eşleşmesi sağlandı.
- Test 58 eklendi ve doğrulandı.
