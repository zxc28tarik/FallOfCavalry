# AJAN 04 — RTS KAMERA VE SAVAŞ ALANI KONTROLÜ

## 1. GÖREV TANIMI
Gelişmiş 3D RTS kamera yönetiminin sağlanması:
- WASD ve yön tuşlarıyla haritada yumuşak kaydırma.
- Ekran kenarı ile kaydırma (edge pan).
- Fare tekerleğiyle yumuşak yakınlaşma/uzaklaşma (zoom 10m–95m).
- Orta fare tuşu veya Alt+Sol tıkla kamera döndürme (orbit).
- Seçili birliğe anında odaklanma (Space tuşu / double tap).
- Harita sınırlarına kelepçeleme (-60m .. +60m).
- Kamera hareketi ile fare seçiminin birbirini bozmaması.

## 2. TAMAMLANAN GELİŞTİRMELER
- `RTSCamera3D` sınıfına `focusOnSelection` fonksiyonu eklendi.
- Fare girişleri ayrıştırıldı: Sol tık (seçim), Orta tık (orbit), Sağ tık (hareket).
- Space tuşu seçili birliklerin merkezine odaklanacak şekilde güncellendi.
- Test 56 eklendi ve doğrulandı.
