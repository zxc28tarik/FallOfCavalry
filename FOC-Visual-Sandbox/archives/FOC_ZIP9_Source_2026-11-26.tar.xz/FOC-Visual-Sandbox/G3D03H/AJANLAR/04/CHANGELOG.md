# AJAN 04 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSCamera3D.focusOnSelection(selectionList)` metodu.
- İyileştirildi: Sol tık sürükleme seçim kutusuna ayrıldı, kamera orbit orta tık / Alt tuşuna bağlandı.
- Eklendi: Sektör sınırları dışına taşmayı engelleyen eksen kelepçeleri.
- Doğrulandı: Test 56 (PASS).
