# AJAN 04 KALİTE GÜVENCE RAPORU

- Test 56: RTS Kamera Panning (WASD/Sınırlar), Zoom, Eğim & Seçili Birliğe Odaklanma (Space) -> PASS
- Kamera Seçim Ayrımı: Sol tık artık kamerayı sürüklemez, seçim kutusunu çalıştırır.
- Yumuşak Sönümleme: Exponansiyel lerp ile 120 FPS titreşimsiz kamera takibi.
