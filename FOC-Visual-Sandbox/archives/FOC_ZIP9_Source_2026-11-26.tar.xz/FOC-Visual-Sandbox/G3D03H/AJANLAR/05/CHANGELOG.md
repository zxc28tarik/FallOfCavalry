# AJAN 05 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSCommandManager` sınıfı ve `executeCommand` metodu.
- Eklendi: 8 taktik emir durumu ve asker durum makinesi entegrasyonu.
- Eklendi: Geri çekilme emrinde 20m taktiksel ricat intikali.
- Eklendi: Klavyeden tek tuşla emir verme (M, H, A, T, R, F, X, G).
- Doğrulandı: Test 57 (PASS).
