# AJAN 05 — RTS TAKTİK EMİR SİSTEMİ

## 1. GÖREV TANIMI
Birliklere verilecek 8 temel RTS emrinin uygulanması:
- Hareket Et (Move - M)
- Konumu Tut (Hold - H)
- Hedefe Saldır (Attack - A)
- Saldırarak İlerle (Attack Move - T)
- Geri Çekil (Retreat - R)
- Serbest Ateş (Fire at Will - F)
- Ateşi Kes (Hold Fire - X)
- Birlikleri Yeniden Topla (Regroup - G)
Emirlerin doğrudan asker animasyonlarına ve duruşlarına bağlanması.

## 2. TAMAMLANAN GELİŞTİRMELER
- `RTSCommandManager` sınıfı geliştirildi.
- Her emir türü için askerlerin `isMoving`, `isCombatActing`, `actionMode` durumları eşleştirildi.
- Hold emrinde kalkan kaldırma ve mızrak indirme (`guard` modu) bağlandı.
- Konsol üzerindeki butonlar ve M, H, A, T, R, F, X, G klavye kısayolları bağlandı.
- Test 57 eklendi ve doğrulandı.
