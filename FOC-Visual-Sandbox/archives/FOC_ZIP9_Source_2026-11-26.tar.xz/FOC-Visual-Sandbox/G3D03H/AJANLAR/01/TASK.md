# AJAN 01 — RTS BİRLİK SEÇİMİ VE KONTROL GRUPLARI

## 1. GÖREV TANIMI
Mevcut 3D görsel sahne altyapısı üzerinde tam teşekküllü RTS seçim sistemini inşa etmek:
- Sol tıkla tekil asker veya birlik seçimi.
- Fareyle dikdörtgen alan (marquee drag-box) seçimi.
- Shift ile seçime yeni birlik ekleme ve çıkarma.
- Çift tıklama ile ekrandaki aynı sınıftan tüm birlikleri seçme.
- Birliklerin altında sade ve şık seçim halkaları (Dost: Mavi/Camgöbeği, Düşman: Kırmızı).
- 1–9 kontrol grubu atama (Ctrl+1..9) ve geri çağırma (1..9).
- SoldierInstance ve UnitGroup veri kimliklerinin eksiksiz korunması.

## 2. TAMAMLANAN GELİŞTİRMELER
- `RTSSelectionManager` sınıfı geliştirildi.
- Ekran koordinatlarını 3D dünya uzayına izdüşüren `projectWorldToScreen` fonksiyonu yazıldı.
- `#selectionMarquee` 2D seçim kutusu arayüze eklendi.
- Dinamik WebGL zemin seçim halkaları `selectionRingsNode` eklendi.
- Kontrol grupları (1-9) Map veri yapısıyla hafızaya bağlandı.
- Test 51 ve Test 52 eklendi ve başarıyla geçti.
