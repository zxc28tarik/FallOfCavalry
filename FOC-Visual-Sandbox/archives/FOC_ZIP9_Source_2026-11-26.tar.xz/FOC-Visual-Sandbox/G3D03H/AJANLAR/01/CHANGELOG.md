# AJAN 01 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSSelectionManager` sınıfı (tekil, grup, dikdörtgen alan, sınıf seçimi).
- Eklendi: `selectionRingsNode` zemin seçim çemberleri (Mavi/Kırmızı).
- Eklendi: `#selectionMarquee` yarı saydam seçim kutusu DOM öğesi ve CSS stilleri.
- Eklendi: `Ctrl+1..9` ve `1..9` kontrol grubu mekanizması.
- Eklendi: Çift tıklama ile aynı sınıftan birlikleri seçme (350ms tolerans).
- Doğrulandı: Test 51 ve Test 52 (2/2 PASS).
