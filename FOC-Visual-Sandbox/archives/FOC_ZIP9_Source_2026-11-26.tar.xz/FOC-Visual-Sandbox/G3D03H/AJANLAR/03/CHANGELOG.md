# AJAN 03 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSFormationManager` sınıfı ve `computeSlots` fonksiyonu.
- Eklendi: Hat (2 kademe), Kol (3 sıra), Kama (V-şekli), Gevşek (2x aralık), Dağınık (Fibonacci sarmalı), Çember (360 derece dışa dönük halka).
- Eklendi: Süvari ve piyade için adaptif genişlik çarpanları.
- Eklendi: Formasyon butonları ve F1..F6 kısayol desteği.
- Doğrulandı: Test 54 ve Test 55 (2/2 PASS).
