# AJAN 02 — BİRLİK HAREKETİ VE YÖNLENDİRME

## 1. GÖREV TANIMI
Seçili birliklerin sağ tıkla harita üzerinde yönlendirilmesi:
- Sağ tıkla hedef konuma intikal emri.
- Shift + sağ tık ile sıralı hareket emirleri (waypoint kuyruğu).
- Tıklanan zemin üzerinde kısa süreli genişleyen görsel işaret (move ping / beacon).
- Birlik merkezinden hedef noktaya doğru pürüzsüz yön açısı (yaw) hesabı.
- Hedefe ulaşınca yumuşak duruşa geçme (ready/idle stance).
- 300 asker için düşük maliyetli grup tabanlı rota hesaplaması.

## 2. TAMAMLANAN GELİŞTİRMELER
- `RTSMovementManager` sınıfı geliştirildi.
- Zemin kesişimini tam hassasiyetle hesaplayan `screenToGroundPlane` raycast fonksiyonu entegre edildi.
- `triggerMovePing` ve `movePingNode` ile tıklanan yere sarı/altın genişleyen radar halkası eklendi.
- Sıralı hareket emirleri için `waypointQueues` Map kuyruğu kuruldu.
- Test 53 başarıyla eklendi ve doğrulandı.
