# AJAN 02 DEĞİŞİKLİK KAYDI (CHANGELOG)

- Eklendi: `RTSMovementManager` sınıfı.
- Eklendi: `screenToGroundPlane` kapalı form analitik ışın-zemin kesişim fonksiyonu.
- Eklendi: `movePingNode` dinamik zemin hedef halkası görseli.
- Eklendi: Shift ile sıralı rota noktası kuyruğu (`waypointQueues`).
- Eklendi: Birlik varış eşiği kontrolü ve otomatik duruşa geçiş.
- Doğrulandı: Test 53 (PASS).
