# FALL OF CAVALRY — G3D-03J MODÜLER DONANIM SİSTEMİ
## RTS_EQUIPMENT_POOLS & DETERMINİSTİK DONANIM ÇÖZÜCÜ REHBERİ

Bu doküman, Ajan 04 tarafından geliştirilen ve G3D-03J genelinde kullanılan modüler ekipman havuzlarının (`RTS_EQUIPMENT_POOLS`) mimarisini, kültür izolasyon kurallarını ve deterministik donanım çözüm motorunu açıklar.

---

## 1. MİMARİ VE TASARIM PRENSİPLERİ

Önceki sürümlerde asker modelleri statik ve tek parça olarak üretilmekteydi. G3D-03J ile birlikte donanım parçaları mantıksal havuzlara ayrılmış ve kültür bağımsızlığı sağlanmıştır.

### Havuz Yapısı:
```javascript
const RTS_EQUIPMENT_POOLS = {
    ottoman: {
        headwear: [...],
        armor: [...],
        weapons: [...],
        shields: [...],
        mounts: [...]
    },
    european: {
        headwear: [...],
        armor: [...],
        weapons: [...],
        shields: [...],
        mounts: [...]
    }
};
```

---

## 2. KÜLTÜR İZOLASYON KURALLARI

1648–1650 döneminin tarihsel özgünlüğünü korumak amacıyla iki kültürün donanımları arasında katı bir filtreleme uygulanır:

1. **Osmanlı Özel Donanımları:**
   - Başlık: Beyaz keçe Börk, Sarık, Bostancı Külahı, Şişak Tolga, Kanatlı Deli Kalpağı.
   - Zırh: Kaftan/Dolaman, Çevşen halka-plaka, Çar-Ayna dört ayna, Leopar/Kurt postu.
   - Silah: Osmanlı fitilli tüfengi, fildişi kabzalı yatağan, şemşir kılıç, 4m sipahi kargısı, döküm humbara, teber hilal baltası, cirit sadakı, kompozit Türk yayı.
   - Kalkan: Örme hasır ve pirinç kalkan (kalkan).
   - *Kural:* Bu öğeler Avrupa havuzunda kesinlikle yer alamaz.

2. **Avrupa / Kutsal Roma Özel Donanımları:**
   - Başlık: Yüksek ibikli Morion, Burgonet, 3 çubuklu Zischägge, devekuşu tüylü süvari şapkası.
   - Zırh: Tapul göğüslüğü ve tassetler, üç çeyrek karartılmış plaka, süvari manda derisi (buff coat), 12 Havariler bandolyesi.
   - Silah: Avrupa fitilli musketi ve rest ayağı, 4.5m dişbudak pikesi, gaga kancalı hellebarda, çift oluklu süvari kılıcı, çarklı piştovlar, karabina.
   - *Kural:* Bu öğeler Osmanlı havuzunda kesinlikle yer alamaz.

---

## 3. DETERMINİSTİK DONANIM ÇÖZÜCÜ (`resolveUnitEquipment`)

Savaş alanındaki yüzlerce askerin aynı anda rastgele donanım alıp her karede farklı görünmesini engellemek ve ağ/tekrar oynatma senkronizasyonunu güvenceye almak için fonksiyon deterministik bir seed parametresiyle çalışır:

```javascript
function resolveUnitEquipment(culture, unitClass, seed = 0) {
    const pool = RTS_EQUIPMENT_POOLS[culture] || RTS_EQUIPMENT_POOLS.ottoman;
    const s = Math.abs(seed);
    const headwear = pool.headwear[s % pool.headwear.length];
    const armor = pool.armor[(s + 1) % pool.armor.length];
    const weapon = pool.weapons[(s + 2) % pool.weapons.length];
    const shield = pool.shields[(s + 3) % pool.shields.length];
    const mount = pool.mounts[(s + 4) % pool.mounts.length];

    return {
        culture,
        unitClass,
        headwear,
        armor,
        weapon,
        shield,
        mount,
        seed
    };
}
```

### Doğrulama Güvenceleri:
- **Aynı Seed -> Özdeş Donanım:** `resolveUnitEquipment('ottoman', 'janissary', 42)` iki kez çağrıldığında aynı silah ve zırhı döndürür (Test 62 ile kanıtlanmıştır).
- **Sıfır Bellek Tahsisi:** Havuz nesneleri `Object.freeze` prensibiyle salt okunurdur, her karede yeniden dizi veya nesne klonlanmaz.
