# FX DENETİM RAPORU: KARA BARUT EFEKTİ, GPU HAVUZU VE WEBGL YAŞAM DÖNGÜSÜ
**Doküman:** `QA/FX_AUDIT.md`  
**Faz / Paket:** Fall of Cavalry G3D-03D Entegrasyonu  
**Denetçi:** Ajan 4 — FX_AUDIT  
**Tarih:** 24 Kasım 2026  
**İncelenen Dosyalar:**
- `FOC_ANTIGRAVITY_6_AJAN_PAKETI\BASE_KORUNMUS_G3D03C_R1.html` (Temel Sürüm)
- `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\05_KARA_BARUT\DELIVERABLE.html` (Teslim Edilen Sürüm)
- `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\05_KARA_BARUT\CHANGELOG.md` (Değişiklik Günlüğü)

---

## YÖNETİCİ ÖZETİ

Bu denetim, Ajan 5 (05_KARA_BARUT) tarafından teslim edilen kara barut namlu parlaması (muzzle flash), duman efekti (black powder smoke), GPU efekt havuzu mimarisi, WebGL kaynak yönetimi ve yaşam döngüsü temizliğini kapsamaktadır.

Yapılan kod analizi, statik fark incelemeleri (`diff`), yerel headless WebGL çalışma doğrulaması ve birim test sonuçları neticesinde:
- **Genel Değerlendirme:** **KUSURSUZ (ONAYLANDI)**
- **Test Başarısı:** 38 / 38 Test Başarılı (Mevcut 37 test korunmuş, Test 38 eklenmiş ve geçmiştir).
- **GPU Buffer Sızıntısı:** **SIFIR**. `gl.bufferSubData` ile yerinde güncelleme yapılmakta, kare başına yeni buffer/mesh oluşturulmamaktadır.
- **Asker Batch Bütünlüğü:** **KORUNDU**. Askerlerin 7 instanced batch çizim grubu bozulmamış, duman havuzu bağımsız bir `InstancedBatchGroup` düğümü olarak entegre edilmiştir.
- **Sıfır GC Yükü:** Güncelleme döngüsünde bellek tahsisi (heap allocation) yapılmamakta, sabit 64 slotluk Float32Array havuzu dairesel rotasyonla çalışmaktadır.

---

## 1. `BlackPowderFxPool` SINIFI VE MİMARİ DENETİMİ

### 1.1 Sabit Kapasite ve Bellek Tahsisi
- `BlackPowderFxPool` sınıfı varsayılan olarak `capacity = 64` slot ile başlatılmaktadır.
- Kurucu fonksiyonda (`constructor`) tek seferlik bellek tahsisleri gerçekleştirilmektedir:
  - `this.particles`: 64 elemanlı hazır parçacık nesnesi dizisi (`active`, `isFlash`, koordinatlar, hızlar, boyutlar, renk ve opaklık alanları).
  - `this.instanceData`: `new Float32Array(this.capacity * INSTANCE_STRIDE_FLOATS)` (`64 * 21 = 1344 floats`). Bu tampon, parçacıkların model matrisi (16 float), baz rengi (3 float), opaklığı (1 float) ve metalik değerini (1 float) tutar.
  - `this._tmpMat`: `FOC_THREE.Mat4.create()` ile önceden tahsis edilmiş 16 elemanlık geçici matris.
- Çalışma zamanında (runtime) kare başına (frame-by-frame) hiçbir `new Float32Array`, `new Object` veya `new Array` çağrısı yapılmamaktadır.

### 1.2 Slot Rotasyonu ve Yaş Temelli Geri Kazanım (Eviction Policy)
- `_spawnParticle(cfg)` fonksiyonu iki aşamalı slot tahsis algoritması kullanır:
  1. **Boş Slot Arama:** `this.particles` dizisinde `active === false` olan ilk boş slot bulunur.
  2. **Dolu Havuz Rotasyonu:** Eğer 64 slotun tamamı aktifse, `ratio = particle.life / particle.maxLife` oranı hesaplanarak ömrünün sonuna en yakın (en yaşlı/en sönük) parçacık tespit edilir ve bu slot ezilerek (`in-place overwrite`) yeniden kullanılır.
- Bu mekanizma sayesinde 20'den fazla tüfekçi aynı karede ateş etse dahi (20 * 4 = 80 parçacık talebi) havuz taşması (`IndexOutOfBounds`) veya istisna oluşması kesinlikle engellenmiştir.

### 1.3 Çöp Toplayıcı (GC) Baskısı Analizi
- **Animasyon Döngüsü (`update`):**
  - Döngü içinde matris oluşturma işlemi `FOC_THREE.Mat4.identity(this._tmpMat)` ile mevcut nesne üzerinde yapılmakta, matris doğrudan `this.instanceData.set(this._tmpMat, base)` ile TypedArray'e yazılmaktadır.
  - Hiçbir çöp toplayıcı nesnesi (garbage) üretilmez. GC baskısı **0.00 byte/frame** seviyesindedir.
- **Tetikleme Anı (`spawnMuzzleFlashAndSmoke`):**
  - Yalnızca ateş anında (tüfekçi başına ~2.6 saniyede bir kez) `_spawnParticle` için 4 adet küçük konfigürasyon nesnesi geçilmektedir. V8 ve modern JavaScript motorlarında kısa ömürlü bu çağrılar optimize edilmekte ve kalıcı nesne oluşturmamaktadır.

---

## 2. GPU BUFFER YÖNETİMİ VE `_renderInstancedBatches` DENETİMİ

### 2.1 Yerinde Güncelleme (`gl.bufferSubData`) Mekanizması
`WebGLRenderer._renderInstancedBatches` fonksiyonunda yapılan düzenleme derinlemesine incelenmiştir:

```javascript
// DELIVERABLE.html Satır 2081-2093
if (!batch._glInstanceBuffer || batch._gl !== gl) {
    batch._gl = gl;
    batch._glInstanceBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, batch._glInstanceBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, batch.instanceData, gl.DYNAMIC_DRAW);
    batch._needsUpload = false;
} else if (batch._needsUpload && typeof gl.bufferSubData === 'function') {
    gl.bindBuffer(gl.ARRAY_BUFFER, batch._glInstanceBuffer);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, batch.instanceData);
    batch._needsUpload = false;
}

if (batch.count <= 0) continue;
```

#### Denetim Bulguları:
1. **Buffer Tahsis Zamanlaması:** Temel sürümde (`BASE`), `batch.count <= 0` kontrolü buffer kontrolünün önündeydi. Bu durum, duman havuzu boşken (`count === 0`) buffer'ın ilk tahsisinin yapılamamasına ve ateşleme olduğu karede ani senkronizasyon gecikmelerine neden olabilirdi. Ajan 5 bu kontrolü buffer kontrolünden sonraya alarak mimariyi düzeltmiştir.
2. **Kare Başına Yeni Buffer Oluşumunun Engellenmesi:** Buffer bir kez `gl.createBuffer()` ve `gl.bufferData(..., gl.DYNAMIC_DRAW)` ile tahsis edildikten sonra, sonraki karelerde sadece `batch._needsUpload` bayrağı aktif olduğunda `gl.bufferSubData` çağrılmaktadır.
3. **Boş Havuz GPU Korunumu:** `if (batch.count <= 0) continue;` sayesinde havuzda aktif parçacık yokken `ext.drawElementsInstancedANGLE` veya `gl.drawElements` çağrısı yapılmamakta, 0 draw call overhead sağlanmaktadır.
4. **Saydamlık ve Derinlik Maskesi:**
   - Duman ve alev saydam olduğundan `batch.transparent = true` olarak işaretlenmiştir.
   - Çizim öncesi: `gl.enable(gl.BLEND)`, `gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)`, `gl.depthMask(false)`.
   - Çizim sonrası: `gl.depthMask(true)`, `gl.disable(gl.BLEND)`.
   - WebGL state temizliği eksiksiz ve simetriktir; sonraki sahne çizimlerine kirlilik sızmaz.

---

## 3. EFEKT ÖMRÜ VE TETİKLEME MANTIĞI

### 3.1 Namlu Alevi (Muzzle Flash) Parametreleri
- **Ömür (`maxLife`):** `0.07 saniye` (yaklaşık 4 kare / 60 FPS).
- **Boyut Evrimi:** `0.18m` başlangıçtan `0.06m` bitişe doğru küçülme (`p.size = p.startSize * (1.0 - t * 0.7)`).
- **Renk ve Yoğunluk:** Sıcak altın sarısı ve kükürt alevi tonu (`r: 1.0, g: 0.88, b: 0.48`), opaklık `0.95 -> 0.0`.
- **Konum:** Namlu ucundan namlu yönünde +0.05m ileri ofset ile anlık parlama.

### 3.2 Kara Barut Dumanı (Black Powder Smoke) Parametreleri
- **Parçacık Sayısı:** Atış başına 3 adet genişleyen duman kümesi (`smokePuffs = 3`).
- **Açısal Yayılım (Conical Spread):** `(i - 1) * 0.32 radyan` (~18 derece) konik açı ile namlu istikametinde ileri fırlama.
- **Ömür (`maxLife`):** `0.45s` ile `0.63s` arasında rastgele (ortalama ~0.54s).
- **Boyut Genişlemesi:** `0.08m` başlangıçtan `0.32m` - `0.40m` çapa kadar genleşme (`Math.sin(t * PI * 0.5)` sinüzoidal genleşme eğrisi).
- **Kinematik ve Fizik:**
  - Aerodinamik sürtünme: `drag = 1.0 - safeDt * 3.2` ile yatay hız hızla sönümlenir.
  - Termal süzülme (Buoyancy): `vy = Math.max(0.08, p.vy * drag + safeDt * 0.12)` ile sıcak duman yukarı doğru süzülür.
  - Renk: Tarihsel gerçekçilikte kükürt-gri tonları (`r: 0.76..0.84, g: 0.76..0.84, b: 0.73..0.81`).
  - Sönümlenme: `p.alpha = startAlpha * (1.0 - t) * (1.0 - t * 0.5)` ile havaya karışarak kaybolur.

### 3.3 Tetikleme Mantığı ve `muzzleFired` Bayrağı
Tüfekçi ateş animasyonu 2.6 saniyelik bir döngüye sahiptir:
- `[0.00 - 0.28)`: Nişan alma ve tüfeği omuzlama fazı.
- `[0.28 - 0.44)`: **Tetik çekme, ateşleme ve geri tepme fazı.**
- `[0.44 - 1.00]`: Namluyu indirme, barut dökme ve harbi ile doldurma fazı.

#### Tetikleme ve Sürekli Duman Önleme Doğrulaması:
1. **Koşul:** `isMusketeer && rec.actionMode === 'attack' && rec.actionBlend > 0.1`.
2. **Tekil Tetikleme:**
   ```javascript
   if (rec.actionPhase < 0.28 && nextPhase >= 0.28 && !rec.muzzleFired) {
       rec.muzzleFired = true;
       // spawnMuzzleFlashAndSmoke(...)
   } else if (rec.actionPhase >= 0.28 && rec.actionPhase < 0.44 && !rec.muzzleFired) {
       rec.muzzleFired = true;
       // spawnMuzzleFlashAndSmoke(...)
   }
   ```
   Tetiklenme anında `rec.muzzleFired = true` yapılarak ateş fazı boyunca (yaklaşık 0.41 saniye süren `0.28-0.44` aralığında) **her karede mükerrer duman oluşumu kesin olarak engellenmiştir**.
3. **Bayrak Sıfırlama:**
   - Saldırı döngüsü bittiğinde (`nextPhase >= 1.0`): `rec.muzzleFired = false`.
   - Eylem sonlandığında (`actionBlend === 0`): `rec.muzzleFired = false`.
   - Sürekli ateş döngüsünde yeni döngünün başına dönüldüğünde (`rec.actionPhase < 0.25`): `rec.muzzleFired = false`.
   - Sektör senkronizasyonunda (`sync`): Durum değiştiğinde `rec.muzzleFired = false`.

---

## 4. 7 ASKER BATCH BÜTÜNLÜĞÜ VE İZOLASYON DENETİMİ

Askerlerin çizim grupları ile efekt havuzunun ilişkisi titizlikle incelenmiştir:

| Parametre | Asker Çizim Grubu (`soldierRegistry.batchGroup`) | Efekt Havuzu (`powderFxPool.batchGroup`) |
| :--- | :--- | :--- |
| **Düğüm Tipi** | `FOC_THREE.InstancedBatchGroup` | `FOC_THREE.InstancedBatchGroup` |
| **Batch Sayısı** | **Tam 7 Batch** (kutu, silindir, frustum, koni, küre, kubbe, gölge) | **1 Batch** (küre geometrisi, saydam parçacıklar) |
| **Sahneye Eklenme** | `scene.add(this.soldierRegistry.batchGroup)` | `scene.add(this.soldierRegistry.powderFxPool.batchGroup)` |
| **İlişki** | Tamamen Bağımsız | Tamamen Bağımsız |
| **Asker Sayısına Etki** | Merkez Sektör: 300 asker (150/150 limit) | **0 Asker** (Asker sayımını ve istatistikleri kirletmez) |

- **Batch Kirliliği Yok:** Duman parçacıkları askerlerin 7 batch'i içine enjekte edilmemiştir. Ayrı bir instanced batch group olarak çalıştığından askerlerin 7 batch sabiti (`batches.length === 7`) korunmuştur.
- **Asker Sayımı İzolasyonu:** `this.records` ve `this.stats.activeCount` yalnızca simülasyon askerlerini sayar. `powderFxPool.particles` bu yapıya dahil edilmemiştir.

---

## 5. YAŞAM DÖNGÜSÜ, SEKTÖR GEÇİŞLERİ VE CONTEXT KAYBI DENETİMİ

### 5.1 Sektör Değişimleri (Merkez / Batı / Doğu / Boş)
- `SoldierVisualRegistry.sync(snapshot)` fonksiyonunda:
  ```javascript
  if (this.records.size === 0 && this.powderFxPool) {
      this.powderFxPool.clear();
  }
  ```
- Boş sektöre (`emptySnapshot`) geçildiğinde veya askerler temizlendiğinde duman havuzu `clear()` çağrısıyla anında sıfırlanır (`activeCount = 0`, `batch.count = 0`).
- Sektörler arası geçişte (`selectSector`) var olan parçacıklar en fazla ~0.5s içinde kendiliğinden sönümlenir.

### 5.2 Sahne Kapatma ve Yeniden Başlatma (`dispose` / `reinit`)
- `Battle3DRenderer.dispose()` -> `SoldierVisualRegistry.dispose()` zinciri:
  1. `this.powderFxPool.dispose()` çağrılır.
  2. `powderFxPool.dispose()` kendi içinde `this.clear()` ve `this.batchGroup.dispose()` çağırır.
  3. `this.batchGroup.dispose()` -> `clearBatches()` fonksiyonunu tetikler ve `gl.deleteBuffer(b._glInstanceBuffer)` çalıştırılarak GPU bellek bloğu serbest bırakılır.
  4. WebGL handle referansları (`_gl`, `_glInstanceBuffer`) `null` yapılır.

### 5.3 WebGL Context Kaybı ve Geri Yükleme (`webglcontextlost` / `restored`)
- Context kaybında `SoldierVisualRegistry.invalidateGpuHandles()` çağrılır:
  - `powderFxPool.invalidateGpuHandles()` -> `powderFxPool.batchGroup.invalidateGpuHandles()` çalışır.
  - `b._gl = null`, `b._glInstanceBuffer = null`, `b._needsUpload = true` bayrakları ayarlanır.
- Context yeniden kazanıldığında (`restored`), `_renderInstancedBatches` içindeki `!batch._glInstanceBuffer || batch._gl !== gl` bloğu yeni GL bağlamını tanır ve buffer'ı yeni context üzerinde baştan tahsis eder.

---

## 6. TEST 38 BİRİM TESTİ VE DOĞRULAMA KANITLARI

`AJANLAR\05_KARA_BARUT\DELIVERABLE.html` dosyasına entegre edilen Test 38 ve tüm test paketi gerçek motorla (Chromium / Microsoft Edge Headless) çalıştırılmış ve doğrulanmıştır:

### Test 38 Doğrulama Maddeleri:
1. Başlangıçta 7 asker instanced batch'i ve FX havuzu (kapasite 64, aktif 0) doğrulandı.
2. Tüfekçiler ateşleme fazına (0.27 -> 0.28+) geçirildiğinde namlu parlaması ve dumanın üretildiği (`activeCount > 0`) doğrulandı.
3. Aynı ateşleme fazı devam ederken mükerrer duman oluşmadığı (`activeCount <= initialActiveAfterFire`) teyit edildi.
4. 25 kare boyunca animasyon çalıştırıldı; `mockCtx.getBufferCount() === initialBufferCount` olduğu ve `bufferSubDataCalls >= 25` ile yerinde güncelleme yapıldığı (sıfır GPU bellek sızıntısı) kanıtlandı.
5. 30 kare sonra tüm parçacıkların kendiliğinden sönümlenip havuza döndüğü (`activeCount === 0`) doğrulandı.
6. `renderer.dispose()` sonrasında `gl.deleteBuffer` ile GPU tamponunun yok edildiği doğrulandı.

### Konsol / Motor Test Çıktısı:
```
Sonuç: 38 / 38 doğrulama testi başarıyla geçti.
✔ 38. Kara Barut Dumanı & Namlu Parlaması Havuzu GPU Buffer Sızıntısı Yok Doğrulaması (G3D-03D Ajan 5)
```

---

## 7. BULGULAR VE GELECEK ENTEGRASYON TAVSİYELERİ

1. **Katı Kurallara Tam Uyum:** Ajan 5, temel veri yapılarına (206 model şablonu, 12 ordu grubu, 442 asker kaydı, 37 mevcut birim testi, kamera kontrolleri) kesinlikle dokunmamış, kendi sınırları içinde kalarak çalışmıştır.
2. **Küçük Konfigürasyon Nesnesi Optimizasyonu (İsteğe Bağlı):** `spawnMuzzleFlashAndSmoke` içinde `_spawnParticle` metoduna konfigürasyon nesnesi (`{ isFlash, x, y, ... }`) geçilmektedir. Bu fonksiyon sadece ateş anında (~2.6 saniyede bir) çağrıldığı için GC yükü ihmal edilebilir seviyededir. Ancak 6 ajanın nihai birleşiminde mikroskobik optimizasyon istenirse parametreler doğrudan argüman olarak geçilebilir.
3. **Sektör Geçişi Temizliği (İsteğe Bağlı):** `sync()` fonksiyonunda boş sektörde dumanlar sıfırlanmaktadır (`this.records.size === 0 -> powderFxPool.clear()`). Çok hızlı sektör geçişlerinde (ör. merkezden batı sektörüne geçilirken) dumanların anında kesilmesi istenirse `sync()` metodunun girişinde veya `selectSector()` fonksiyonunda da `powderFxPool.clear()` çağrılabilir.

---

## 8. SONUÇ VE KARAR

| Kriter | Durum | Açıklama |
| :--- | :---: | :--- |
| **`BlackPowderFxPool` Sınıfı** | **GEÇTİ** | 64 sabit slot, Float32Array, LRU rotasyon, 0 GC güncelleme |
| **GPU Buffer Yönetimi** | **GEÇTİ** | `gl.bufferSubData` ile yerinde güncelleme, sızıntı yok |
| **Efekt Ömrü & Tetikleme** | **GEÇTİ** | Alev ~0.07s, duman ~0.5s, `0.28-0.44` fazında tekil tetikleme |
| **7 Asker Batch Bütünlüğü** | **GEÇTİ** | Asker gruplarından izole, 7 batch sabit |
| **Yaşam Döngüsü & Context Kaybı** | **GEÇTİ** | `clear()`, `dispose()`, `invalidateGpuHandles()` eksiksiz |
| **Birim Testleri** | **GEÇTİ** | 38 / 38 Test Başarılı |

**Nihai Karar:** Ajan 5 (05_KARA_BARUT) tarafından teslim edilen `DELIVERABLE.html` dosyası entegrasyona **TAM UYGUNDUR** ve üretim standartlarını karşılamaktadır.
