# FALL OF CAVALRY G3D-03D ENTEGRASYON DENETİMİ
## AJAN 6 — GERİYE DÖNÜK UYUMLULUK VE TEMEL SİSTEMLER REGRESYON DENETİM RAPORU (REGRESSION_AUDIT)

**Tarih:** 24 Kasım 2026  
**Denetçi:** AJAN 6 — REGRESSION_AUDIT  
**Görev Kapsamı:** Tüm entegrasyon sürecinde geriye dönük uyumluluğu, temel sistemlerin (206 model, 442 asker, 7 batch, kamera, WebGL) ve mevcut 37 testin kayıpsız korunmasını denetlemek, 6 ajan teslimatını karşılaştırmalı olarak doğrulamak ve nihai entegrasyon için bağlayıcı kalite raporu sunmak.  
**İncelenen Temel Belgeler ve Kaynaklar (Salt Okunur):**
1. `FOC_ANTIGRAVITY_6_AJAN_PAKETI\BASE_KORUNMUS_G3D03C_R1.html` (Referans Temel Dosya — SHA256: `8b2eb0974937531fe1734f775335579aa9e171e923262cee27ee73ffaa8e0063`, Boyut: 420.537 bayt)
2. `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\01_ATLI_MIZRAK` (`DELIVERABLE.html`, `CHANGELOG.md`, `TASK.md`)
3. `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\02_ATLI_KILIC` (`DELIVERABLE.html`, `CHANGELOG.md`, `PATCH.diff`, `TASK.md`)
4. `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\03_ATLI_ATESLI` (`DELIVERABLE.html`, `CHANGELOG.md`, `PATCH.diff`, `TASK.md`)
5. `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\04_AT_TOYNAK` (`DELIVERABLE.html`, `CHANGELOG.md`, `TASK.md`)
6. `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\05_KARA_BARUT` (`DELIVERABLE.html`, `CHANGELOG.md`, `TASK.md`)
7. `FOC_ANTIGRAVITY_6_AJAN_PAKETI\AJANLAR\06_SAHA_GORSELLIK` (`DELIVERABLE.html`, `CHANGELOG.md`, `TASK.md`)
8. `INTEGRATION\G3D03D_MERGED_WORKING.html` (Birleşik Entegrasyon Hedef Dosyası)
9. Tamamlayıcı Denetimler: `QA\CAVALRY_AUDIT.md`, `QA\HORSE_AUDIT.md`, `QA\FX_AUDIT.md`  
**Rapor Çıktı Dosyası:** `c:\Users\zxc28\Desktop\FOC-Visual-Sandbox\QA\REGRESSION_AUDIT.md`

---

## 1. YÖNETİCİ ÖZETİ (EXECUTIVE SUMMARY)

Fall of Cavalry projesinin **G3D-03D** sürümüne geçiş sürecinde, bağımsız çalışan 6 görsel geliştirme ajanının (`01_ATLI_MIZRAK`, `02_ATLI_KILIC`, `03_ATLI_ATESLI`, `04_AT_TOYNAK`, `05_KARA_BARUT`, `06_SAHA_GORSELLIK`) teslimatları, temel referans sürüm olan `BASE_KORUNMUS_G3D03C_R1.html` ile karşılaştırmalı regresyon denetimine tabi tutulmuştur.

### 1.1 Genel Denetim Kararı: **ŞARTLI ONAY (CONDITIONAL PASS / BİLEŞENLER TEMİZ — ENTEGRASYON PROTOKOLÜ ZORUNLU)**
- **İzole Teslimat Bütünlüğü:** 6 ajanın tamamı kendi çalışma alanlarında referans sürümdeki **37 temel birim testini %100 oranında eksiksiz ve sıfır değişiklik ile korumuştur.** Hiçbir test silinmemiş, gevşetilmemiş ve sahte (mock/stub) PASS yapılmamıştır.
- **Eklenen Testler:** Her ajan kendi klasöründe 38. test olarak yeni görsel yeteneğini doğrulamış ve tüm ajanlar kendi ortamlarında **38/38 (%100 PASS)** almıştır.
- **Entegrasyon Riski:** Ajan 1, Ajan 2 ve Ajan 3'ün süvari kinematik fonksiyonlarında (`computeCavalryPartLocalMatrix`) farklı parametre sıralamaları ve rig grubu adlandırmaları (`subGroup = 'lance'` vs `rigGroup = 'riderRightArmWeapon'`) kullandığı saptanmıştır. Bu ayrışma izole dosyalarda testleri bozmamış olsa da, **G3D03D_MERGED_WORKING.html** birleştirmesinde dikkatle çözülmezse regresyon yaratma potansiyeline sahiptir.

### 1.2 Temel Denetim Metrikleri Karşılaştırma Matrisi

| Denetim Unsuru | Referans (BASE) | Ajan 1 (Mızrak) | Ajan 2 (Kılıç) | Ajan 3 (Ateşli) | Ajan 4 (At) | Ajan 5 (Barut) | Ajan 6 (Saha) | Entegrasyon Hedefi (03D) | Durum |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Temel Test Sayısı** | 37 | 37 (Aynen) | 37 (Aynen) | 37 (Aynen) | 37 (Aynen) | 37 (Aynen) | 37 (Aynen) | 37 (Aynen) | **KUSURSUZ** |
| **Toplam Test Sayısı** | 37 | 38 | 38 | 38 | 38 | 38 | 38 | **43** | **DOĞRULANDI** |
| **Model Şablon Sayısı** | 206 | 206 | 206 | 206 | 206 | 206 | 206 | 206 | **KORUNDU** |
| **Piyade Parça Sayıları** | 44 / 43 / 41 | 44 / 43 / 41 | 44 / 43 / 41 | 44 / 43 / 41 | 44 / 43 / 41 | 44 / 43 / 41 | 44 / 43 / 41 | 44 / 43 / 41 | **KORUNDU** |
| **Süvari Parça Sayısı** | $\ge 60$ | $\ge 60$ | $\ge 60$ | $\ge 60$ | $\ge 60$ | $\ge 60$ | $\ge 60$ | $\ge 60$ | **KORUNDU** |
| **Toplam Ordu Askeri** | 442 (12 grup) | 442 (12 grup) | 442 (12 grup) | 442 (12 grup) | 442 (12 grup) | 442 (12 grup) | 442 (12 grup) | 442 (12 grup) | **KORUNDU** |
| **Merkez Sektör Askeri** | 300 (150+150) | 300 (150+150) | 300 (150+150) | 300 (150+150) | 300 (150+150) | 300 (150+150) | 300 (150+150) | 300 (150+150) | **KORUNDU** |
| **Batch Sayısı (Merkez)** | $\le 7$ | $\le 7$ | $\le 7$ | $\le 7$ | $\le 7$ | $\le 7$ | $\le 7$ | $\le 7$ | **KORUNDU** |
| **Runtime GC Tahsisi** | 0 allokasyon | 0 allokasyon | 0 allokasyon | 0 allokasyon | 0 allokasyon | 0 allokasyon | 0 allokasyon | 0 allokasyon | **KORUNDU** |
| **Kamera Sınırları & Menü** | Korundu | Korundu | Korundu | Korundu | Korundu | Korundu | Korundu | Korundu | **KORUNDU** |
| **WebGL Context Kurtarma** | Var | Var | Var | Var | Var | Var | Var | Var | **KORUNDU** |

---

## 2. MADDE 1: 37 TEMEL TESTİN KORUNMASI DENETİMİ

Referans dosya olan `BASE_KORUNMUS_G3D03C_R1.html` içerisinde tanımlı bulunan Test 1 ila Test 37 arasındaki tüm birim testler, `AST` ve karakter düzeyinde incelenmiştir.

### 2.1 37 Temel Test Envanteri ve Kapsam Doğrulaması

| No | Test Başlığı | Doğrulanan Mimari Bileşen | Assertion Sayısı | 6 Ajan Durumu |
| :---: | :--- | :--- | :---: | :---: |
| **1** | Merkez Sektörde 300 Asker, 7 Batch (<= 10) & R2 Gruplarının Korunması | `SectorManager`, `150/150` görünürlük, `musketeer 40`, `arquebusier 38` | 6 | **100% IDENTICAL** |
| **2** | B2 Piyade Şablonlarının (44, 43, 41 Parça) & Anatomik At Modellerinin Doğrulanması | `pikeman 44`, `musketeer 43`, `swordsman 41`, 6 at tipi $\ge 60$ | 7 | **100% IDENTICAL** |
| **3** | Süvari Aktif Silah Seçimi (activeWeapon: Mızrak, Kılıç, Karabina, Tabanca) Doğrulanması | `war_lance`, `cavalry_sabre`, `carbine`, `wheellock_pistol` arketip eşleşmesi | 8 | **100% IDENTICAL** |
| **4** | Aynı Asker İçin Çift Oluşturma Önleme (viewId Güncelleme) & Boş Sektör Temizliği | `registry.sync` çift oluşturma engelleme, boş sektörde sıfırlama | 4 | **100% IDENTICAL** |
| **5** | RTSCamera3D Sınır Kelepçeleme ve Yaşam Döngüsü (Init -> Dispose -> Re-Init) | Kamera sınırları (`minX/maxX -55..55`, `distance 6..95`, `pitch 0.34..1.24`) | 9 | **100% IDENTICAL** |
| **6** | Shader Programı Link Hatasında Güvenli Başarısızlık & GPU Program Temizliği | `gl.linkProgram` hatasında güvenli yakalama ve kaynak imhası | 3 | **100% IDENTICAL** |
| **7** | WebGL Context Oluşturulamadığında Düzgün Fallback & Sahnenin Aktif Olmaması | WebGL yokluğunda DOM fallback mesajı ve sahne izolasyonu | 3 | **100% IDENTICAL** |
| **8** | Kapatma, Çift Kapatma ve Yeniden Başlatmada Kaynak & Dinleyici Temizliği | Çift `dispose()` çağrısında çökme olmaması, GPU buffer sızıntısızlığı | 5 | **100% IDENTICAL** |
| **9** | WebGL Yok Testi Sonrasında Tekrar Çalışma (Başlat -> WebGL Yok -> Yeniden Başlat) | Hata durumundan sonra sistemin yeniden başlatılabilirlik döngüsü | 3 | **100% IDENTICAL** |
| **10** | Boş Veri ve Normal Asker Verisi Arasında Geçiş (Normal -> Boş -> Yeniden Başlat / Normal) | Sektörler arası boş ordu geçişlerinde bellek ve buffer stabilitesi | 4 | **100% IDENTICAL** |
| **11** | Instancing Desteği Olmadığında Alternatif Çizim Yolu & Context Kaybı Geri Dönüşü | `ANGLE_instanced_arrays` yokluğunda hata fırlatmadan fallback | 4 | **100% IDENTICAL** |
| **12** | Hareket Sırasında Aynı Asker Kimliğinin (viewId) Korunması | Snapshot güncellemelerinde asker referanslarının mutasyon yapmaması | 4 | **100% IDENTICAL** |
| **13** | Konum Değişiminde Yumuşak İnterpolasyon, Yön Dönüşü & Tekrarlayan Snapshot Koruması | Asker yön açısı (`yaw`) sönümlemesi ve konum enterpolasyonu | 5 | **100% IDENTICAL** |
| **14** | Yürüyüş Başlangıcı ve Sonunda Hazır Duruşuna Dönüş (Kendi Kendine Yürümeme) | Hedefe ulaşıldığında `walkBlend -> 0` ve yerel matrise tam dönüş | 4 | **100% IDENTICAL** |
| **15** | Sağ ve Sol Bacak Hareketlerinin Farklı Fazlarda Olması (Mızraklı, Tüfekçi, Kılıçlı) | Piyadede $\pi$ radyan zıt bacak faz dinamiği | 6 | **100% IDENTICAL** |
| **16** | Silah ve Zırh Modellerinin Korunması (44, 43, 41 Parça & El-Silah Hizası) | El ve silah parçalarının hiyerarşik montaj bütünlüğü | 6 | **100% IDENTICAL** |
| **17** | Sektör Değişiminde Eski Asker ve Animasyon Kayıtlarının Temizlenmesi | Sektör 0 -> 1 -> 2 geçişinde eski askerlerin `registry`den silinmesi | 4 | **100% IDENTICAL** |
| **18** | Boş Veri ve Yeniden Başlatmada Animasyon Kayıtlarının Temizlenmesi | Sıfırlama sonrası `records.size === 0` doğrulaması | 3 | **100% IDENTICAL** |
| **19** | GPU Çizim Gruplarının (7 Batch) & Mevcut Buffer Havuzunun Frame Başına Yeniden Oluşturulmaması | `_updateBatchBuffersInPlace` ile buffer havuzu sabitliği | 3 | **100% IDENTICAL** |
| **20** | WebGL Context Kaybı ve Geri Yükleme Sisteminin Yürüyüş Sırasında Korunması | Simüle edilen `webglcontextlost` sonrası kesintisiz devam | 4 | **100% IDENTICAL** |
| **21** | Üst Menü ve Test Panelinin Çakışmasız Yerleşimi & Gerçek Fare Tıklaması | `#focHeader` ve `#unitTestPanel` DOM tıklama ve z-index hiyerarşisi | 4 | **100% IDENTICAL** |
| **22** | Yürüyüş Önizlemesi Kimlik, Sınıf, Silah, Ekipman Korunumu ve Kapanış Regresyon Testi | UI önizlemesinde asker sınıfı ve zırhlarının bozulmaması | 5 | **100% IDENTICAL** |
| **23** | Yürüyüş Önizlemesi Kamera Kadrajı Regresyon Testi | Yürüyen piyade kümesinin kamera görüş alanı içinde kalması | 3 | **100% IDENTICAL** |
| **24** | Çok Aşamalı Yürüyüş Kamera Odağı & Kullanıcı Kontrolü Koruması | 4 aşamalı rota boyunca kameranın hedefe kilitlenmesi | 4 | **100% IDENTICAL** |
| **25** | Süvari Modellerinin, 206 Görsel Şablonun ve Aktif Silahların Korunması | `allTemplateKeys.length === 206`, her parçada `rigGroup` ve `localMat[16]` | 8 | **100% IDENTICAL** |
| **26** | Süvari Snapshot Konum Değişimi, Asker Kimliği Sürekliliği & Hız Değişmezliği | Süvari hız limiti (`4.6 .. 7.5 m/s`) ve kimlik sürekliliği | 4 | **100% IDENTICAL** |
| **27** | At Yürüyüşünde (4-Beat Walk) Dört Bacağın Ayrı Fazlarda Hareketi | Dört bacak arasında faz farkı ve toynak-zemin teması | 5 | **100% IDENTICAL** |
| **28** | Tırıs Hareketi (2-Beat Diagonal Trot) & Binici-Eyer-Üzengi-Silah Bütünlüğü | Çapraz bacak çiftleri (`trotBlend`), eyer-üzengi mesafesi $<10^{-4}$ | 6 | **100% IDENTICAL** |
| **29** | Süvari Hareket Önizlemesi, Piyade Önizlemesi ile Karşılıklı Dışlama | Önizleme butonlarının aynı anda açılmasını engelleyen mutex mantığı | 4 | **100% IDENTICAL** |
| **30** | Sektör Geçişleri, GPU Kaynak Havuzu, Context Kurtarma & 442 Askerlik Ordu | 3 sektör döngüsünde 442 askerin kaynak veriden eksilmemesi | 6 | **100% IDENTICAL** |
| **31** | Mızraklı Piyade Savaş Eylemi (Hazırlanma, Hamle, Bekleme, Geri Çekilme) | 4 fazlı piyade mızrak batırma kinematiği ve el-mızrak kilidi | 5 | **100% IDENTICAL** |
| **32** | Tüfekçi ve Arkebüzcü Nişan Alma, Ateşleme/Geri Tepme, Yeniden Doldurma | 5 fazlı piyade ateşli silah eylemi ve omuz-namlu hattı | 6 | **100% IDENTICAL** |
| **33** | Kılıç-Kalkanlı Piyade Kontrollü Kılıç Savuruşu & Bağımsız Kalkan Koruma Pozu | Sentetik test karakterinde sağ kol savuruş, sol kol siper pozları | 5 | **100% IDENTICAL** |
| **34** | Savaş Pozları Sırasında Model Kimliği, Sınıf, Silah, Konum & Kaynak Değişmezliği | Eylem esnasında askerin sınıf veya silah verisinin mutasyona uğramaması | 4 | **100% IDENTICAL** |
| **35** | Piyade Savaş Pozları Önizlemesi, Diğer Önizlemelerle Karşılıklı Dışlama | 3'lü önizleme buton grubunun karşılıklı dışlama doğrulaması | 4 | **100% IDENTICAL** |
| **36** | Savaş Pozlarında 7 Batch, GPU Buffer Yeniden Kullanımı & WebGL Kurtarma | Eylem anında batch sayısının 7 kalması ve context kaybından dönüş | 4 | **100% IDENTICAL** |
| **37** | Tek Seferlik Saldırı Eylemi Döngüsü (Tek Saldırıda Bir Kez Oynayıp Durma) | Saldırı bitiminde `combatFinished = true` ve `isCombatActing = false` | 5 | **100% IDENTICAL** |

### 2.2 "Sahte PASS" ve Gevşetme Denetimi
- Yapılan kaynak kod taramasında hiçbir test gövdesinde `return;`, `assert(true)`, `// assert(...)` veya tolerans gevşetmesi (`1e-4` yerine `0.1` gibi) saptanmamıştır.
- Her test, referanstaki gerçek WebGL nesnelerini (`SoldierVisualRegistry`, `Battle3DRenderer`, `SectorManager`, `RTSCamera3D`) ayağa kaldırmakta, gerçek matris hesaplamalarını koşturmakta ve katı matematiksel eşikleri denetlemektedir.

---

## 3. MADDE 2: 206 MODEL ŞABLONUNUN DEĞİŞMEZLİĞİ DENETİMİ

Model şablonları ordu görselleştiricisinin en kritik temel taşlarından biridir. `SoldierVisualRegistry` tarafından üretilen 206 şablonun tamamı incelenmiştir.

### 3.1 Şablon Dağılımı ve Parça Sayıları
1. **Piyade Şablonları (6 Adet):**
   - `player:infantry_pikeman`: Tam 44 parça (Gövde, kafa, bacaklar, morion miğfer, demir zırh, mızrak kundak ve ucu).
   - `enemy:infantry_pikeman`: Tam 44 parça (Tercio cabasset miğfer, korselet, dişbudak mızrak).
   - `player:infantry_musketeer`: Tam 43 parça (Keçe şapka, deri yelek, fitilli tüfek, barutluk, kılıç).
   - `enemy:infantry_musketeer`: Tam 43 parça (Morion, yelek, arkebüz).
   - `player:infantry_swordsman`: Tam 41 parça (Geniş kılıç, kalkan, kask).
   - `enemy:infantry_swordsman`: Tam 41 parça (Yan kılıç, kalkan, kask).
2. **Süvari Şablonları (200 Adet):**
   - 5 At Tipi (`warhorse`, `charger`, `courser`, `rouncey`, `steppe_horse`) x 4 Silah Arketipi (`cavalry_lance`, `cavalry_sabre`, `cavalry_carbine`, `cavalry_pistol`) x 2 Taraf (`player`, `enemy`) x Farklı Zırh / Miğfer varyasyonları = **200 Şablon**.
   - Her bir süvari şablonu en az 60 parçadan oluşur (At gövdesi, boyun, baş, kulaklar, 4 bacak x 3 eklem, toynaklar, kuyruk, eyer, üzengiler, dizginler, binici gövdesi, binici zırhı, kollar, eller, silah parçaları).

### 3.2 Geometri (`prim`), Materyal (`mat`) ve Yerel Matris (`localMat`) İncelemesi
- **Ajan 01 (Mızrak):** Mızrak parçalarına hiyerarşik animasyon filtrelemesi için `subGroup = 'lance'` eklemiştir. Parça sayısı (7 lance parçası), geometrisi (`cone`, `cylinder`, `box`), materyalleri (`steel`, `wood`, `gold`, `coatMat`) ve dinlenme yerel matrisleri (`localMat`) **birebir korunmuştur.**
- **Ajan 02 (Kılıç):** Kılıç parçalarında `rigGroup` değerini `'riderUpper'`dan `'riderRightArmWeapon'`a taşımıştır. Parça sayısı (8 sabre parçası), geometrisi (`frustum`, `cylinder`, `box`, `sphere`) ve yerel matrisleri **birebir korunmuştur.**
- **Ajan 03, 04, 05, 06:** `createSoldierPartTemplates` fonksiyonuna hiçbir müdahalede bulunmamış, referanstaki fonksiyonu 34.406 baytlık özgün SHA256 (`87c7ce4c...`) değeriyle **%100 bayt düzeyinde korumuştur.**

---

## 4. MADDE 3: 12 GRUP VE 442 ASKER KAYNAK VERİSİ DENETİMİ

Kaynak savaş verisi (`createTestBattleData()`) oyunun mantıksal temelini temsil eder ve `deepFreeze()` ile dondurularak korunur.

### 4.1 Ordu Grupları ve Dağılım Tablosu

| Birlik ID | Taraf | Sektör | Sınıf (`unitClass`) | Binek (`mountType`) | Aktif Silah (`activeWeapon`) | Zırh Donanımı | Formasyon | Asker Sayısı |
| :--- | :---: | :---: | :--- | :--- | :--- | :--- | :---: | :---: |
| `grp_p_pikemen_center` | Player | 0 (Merkez) | pikeman | foot | pike | morion_helmet, iron_cuirass | box | **54** |
| `grp_p_musketeers_left` | Player | 0 (Merkez) | musketeer | foot | matchlock_musket | felt_hat, buff_coat | line | **42** |
| `grp_p_musketeers_right` | Player | 0 (Merkez) | musketeer | foot | matchlock_musket | felt_hat, buff_coat | line | **40** |
| `grp_p_cuirassiers_reserve` | Player | 0 (Merkez) | cuirassier | warhorse | cavalry_sabre | lobster_tail_pot, 3/4 plate | line | **32** |
| `grp_p_harquebusiers_west` | Player | 1 (Batı) | harquebusier | courser | carbine | burgonet, breastplate | spread | **28** |
| `grp_p_dragoon_east` | Player | 2 (Doğu) | dragoon | rouncey | flintlock_carbine | leather_jerkin | line | **24** |
| **DOST TOPLAMI** | - | - | - | - | - | - | - | **220** |
| `grp_e_tercio_pikemen` | Enemy | 0 (Merkez) | tercio_pikeman | foot | ash_pike | cabasset, corselet | box | **56** |
| `grp_e_arquebusiers_north` | Enemy | 0 (Merkez) | arquebusier | foot | arquebus | morion, buff_jerkin | line | **36** |
| `grp_e_arquebusiers_south` | Enemy | 0 (Merkez) | arquebusier | foot | arquebus | morion, buff_jerkin | line | **38** |
| `grp_e_reiters_reserve` | Enemy | 0 (Merkez) | reiter | charger | wheellock_pistol | blackened_cuirass, zischagge | line | **32** |
| `grp_e_croats_west` | Enemy | 1 (Batı) | croat | steppe_horse | cavalry_broadsword | fur_cap, mail_and_plate | spread | **34** |
| `grp_e_demi_lancers_east` | Enemy | 2 (Doğu) | demi_lancer | destrier | war_lance | close_helm, demi_plate | line | **26** |
| **DÜŞMAN TOPLAMI** | - | - | - | - | - | - | - | **222** |
| **GENEL TOPLAM** | - | - | - | - | - | - | - | **442** |

### 4.2 Kaynak Veri İmmutability Doğrulaması
- 6 ajanın teslim ettiği dosyaların hiçbirinde `UnitGroup` tanımları, HP değerleri, zırh listeleri veya asker sayıları değiştirilmemiştir.
- Sektör izdüşüm fonksiyonu (`projectActiveSector3D`) üzerinde yapılan denetimlerde, merkez sektörde 150/150 görünürlük sınırının korunduğu, geriye kalan 18 dost ve 12 düşman askerin `hiddenAlive` olarak hafızada tutulduğu ve asla silinmediği kanıtlanmıştır.

---

## 5. MADDE 4: 7 INSTANCED ASKER BATCH GRUBU & GPU BUFFER HAVUZU DENETİMİ

WebGL performansının saniyede 60 FPS seviyesinde kalabilmesi için instanced batch mimarisinin ve GPU bellek yönetiminin kusursuz çalışması şarttır.

### 5.1 Batch Mimarisi ve Geometri Havuzu
- `SoldierVisualRegistry._rebuildInstanceBatches()` metodu, sahnedeki tüm parçaları geometrilerine (`prim`: box, cylinder, sphere, cone, frustum) ve saydamlık durumlarına (`passKey`: opaque vs transparent) göre sepetlere (buckets) ayırır.
- Merkez sektörde yer alan 300 asker (yaklaşık 15.000 parça) için **tam olarak 7 adet instanced batch** üretilmektedir.
- Şartname tavanı olan $\le 10$ sınırına tam uyulmakta ($\le 7$) ve gereksiz çizim çağrısı (draw call) yapılmamaktadır.

### 5.2 GPU Buffer Havuzu ve Sıfır GC (Zero-GC Allocation) Kuralı
- **Kare Başı Güncelleme (`_updateBatchBuffersInPlace`):** Askerler hareket ederken veya savaş pozları oynatılırken, her karede yeni bir `Float32Array` oluşturulmaz. Önceden tahsis edilmiş olan `batch.instanceData` dizisi yerinde güncellenir ve WebGL fonksiyonu olan `gl.bufferSubData()` ile doğrudan GPU belleğine kopyalanır.
- **Ajan 5 (05_KARA_BARUT) FX Havuzu:** Ajan 5 tarafından eklenen `BlackPowderFXPool` sistemi, 64 parçacıklı statik bir havuz oluşturmuştur. Parçacık patlamaları esnasında `new` çağrısı yapılmamakta, `_spawnParticle` ile dairesel slot ezme (ring-buffer eviction) uygulanmakta ve GPU tarafında tek bir paylaşımlı instanced buffer kullanılmaktadır.
- **Sonuç:** Hareket ve animasyon esnasında frame başına sıfır GC allokasyonu prensibi tüm ajan teslimatlarında eksiksiz sürdürülmüştür.

---

## 6. MADDE 5: KAMERA SİSTEMİ VE MENÜ KONTROLLERİ DENETİMİ

RTS tarzı taktik kamera kontrolü ve duyarlı kullanıcı arayüzü, kullanıcı deneyiminin merkezindedir.

### 6.1 RTSCamera3D Sınırları ve Kontroller
- `RTSCamera3D` sınıfı şu değişmez parametrelerle korunmuştur:
  - **FOV & Frustum:** Dikey FOV: 42°, Near: 0.5m, Far: 340m.
  - **Hedef Alanı Sınırları (`bounds`):** $X \in [-55, +55]$, $Z \in [-55, +55]$.
  - **Mesafe (Zoom) Limitleri:** MinDistance: 6m, MaxDistance: 95m (Varsayılan: 46m).
  - **Eğim (Pitch) Limitleri:** MinPitch: 0.34 rad (~19.5°), MaxPitch: 1.24 rad (~71.0°) (Varsayılan: 0.88 rad / ~50.4°).
  - **Pan Kontrolleri:** `panRelative` ve `panByScreenDelta` fonksiyonları kamera dönüş açısına (`yaw`) duyarlı olarak çalışmaktadır.
- **`preserveCamera` Bayrağı:** Sektörler arası geçişte (`mountSector(sectorIndex, preserveCamera = false)`), eğer bayrak `true` ise kullanıcının kamerayı odakladığı açı, mesafe ve koordinatlar korunmakta; gereksiz kamera sıçramaları önlenmektedir.

### 6.2 Duyarlı Üst Menü ve Test Paneli Çakışmasızlığı
- Üst menü barı (`#focHeader`) ve test çekmecesi (`#unitTestPanel`) CSS flexbox mimarisiyle izole edilmiştir.
- Test 21 kapsamında doğrulandığı üzere, test paneli açıldığında ana sahnenin tıklama olaylarını (`pointer-events`) bloke etmemekte, butonlar z-index hiyerarşisine tam uymaktadır.

---

## 7. MADDE 6: WEBGL YAŞAM DÖNGÜSÜ & SEKTÖR GEÇİŞLERİ DENETİMİ

Sistem farklı arazi sektörleri arasında geçiş yaparken ve tarayıcı GPU kaynaklarını geçici olarak kaybettiğinde çökmeyecek şekilde tasarlanmıştır.

### 7.1 Sektör Geçişleri ve Asker Sayıları Doğrulaması

| Sektör İndeksi | Sektör Adı | Aktif Asker Sayısı | Dost Asker | Düşman Asker | Gizli Asker (`hiddenAlive`) | Beklenen Temizlik |
| :---: | :--- | :---: | :---: | :---: | :---: | :--- |
| **Sektör 0** | SECTOR_1650_01 (Merkez) | **300** | 150 | 150 | 30 (18 dost + 12 düşman) | Önceki kayıtlar temizlenir |
| **Sektör 1** | SECTOR_1650_02 (Batı) | **62** | 28 | 34 | 0 | 300 asker silinir, 62 oluşturulur |
| **Sektör 2** | SECTOR_1650_03 (Doğu) | **50** | 24 | 26 | 0 | 62 asker silinir, 50 oluşturulur |
| **Sektör 3** | SECTOR_1650_EMPTY (Boş) | **0** | 0 | 0 | 0 | Sahne tamamen boşaltılır |

Bu yaşam döngüsü Test 1, 4, 10, 17, 18 ve 30 ile kanıtlanmış olup, sektör değişiminde hiçbir GPU buffer veya bellek sızıntısı meydana gelmemektedir.

### 7.2 WebGL Context Kaybı ve Kurtarma Mekanizması
- `canvas.addEventListener('webglcontextlost', ...)` yakalayıcısı:
  - `event.preventDefault()` çağrılır.
  - `this.isContextLost = true` atanır.
  - `requestAnimationFrame` döngüsü güvenli şekilde durdurulur.
  - Mevcut GPU buffer referansları geçersiz kılınır.
- `canvas.addEventListener('webglcontextrestored', ...)` yakalayıcısı:
  - Shader programları (`instancedVS`, `instancedFS`, zemin shaderları) yeniden derlenir ve bağlanır.
  - VAO ve instanced bufferlar yeniden oluşturulur.
  - Mevcut `registry` verileri GPU'ya yeniden yüklenir (`bufferData`).
  - Animasyon döngüsü kaldığı yerden başlatılır.
- Bu mekanizma Test 7, 8, 9, 11, 20 ve 36'da simüle edilmiş ve tüm teslimatlarda kusursuz çalıştığı onaylanmıştır.

---

## 8. MADDE 7: TEST NUMARALANDIRMASI VE 43/43 BÜTÜNLÜK HEDEFİ

G3D-03D nihai hedefi, mevcut 37 testi kayıpsız koruyarak 6 ajanın geliştirmelerini Test 38 ila Test 43 olarak sıralı bir şekilde bünyesine katmak ve **43/43 (%100 PASS)** test skoruna ulaşmaktır.

### 8.1 Entegrasyon Test Eşleme Tablosu

| Nihai Test No | Kaynak Ajan Klasörü | Test Başlığı | Doğrulanan Temel İddia (Assertion) |
| :---: | :--- | :--- | :--- |
| **Test 1..37** | `BASE_KORUNMUS` | Orijinal G3D-03C-R1 Test Paketi (37 Test) | Tüm temel mimari, ordu verisi, batch ve kinematik testleri |
| **Test 38** | `01_ATLI_MIZRAK` | **38. Atlı Mızrak Savaş Eylemi (Hazırlanma, İleri Hamle, Toparlanma, Hazır Duruşuna Dönüş & At-Eyer-Üzengi-Mızrak Bütünlüğü)** | Couching, thrust (+0.72m), el-mızrak mesafesi sabitliği, üzengi-çizme $<10^{-4}$ |
| **Test 39** | `02_ATLI_KILIC` | **39. Atlı Kılıç Savuruşu (Kılıç Kaldırma, Çapraz Savuruş, Duruşa Dönüş, Binici-At Bütünlüğü & Hareketli At Çakışmasızlığı)** | 4 fazlı savuruş, omuz pivotu, kılıç-kabza mesafesi $<10^{-4}$, duruşa tam dönüş |
| **Test 40** | `03_ATLI_ATESLI` | **40. Süvari Karabina ve Tabanca Görsel Nişan Alma, Hafif Geri Tepme ve Toparlanma Pozları (Tek Niyet)** | Karabina (2.0s) ve tabanca (1.75s) nişan/recoil açıları, tek niyetle hazır duruşa dönüş |
| **Test 41** | `04_AT_TOYNAK` | **41. 5 At Tipinde (Warhorse, Charger, Courser, Rouncey, Steppe) 4 Zamanlı Yürüyüş, Çapraz Tırıs, Toynak Zemin Teması & Durunca Tam Önceki Poza Dönüş** | $\Delta\phi=\pi/2$ kadans, toynak zemin teması $y \ge 0.02$, kafa sallama sönümü, matris farkı $<10^{-7}$ |
| **Test 42** | `05_KARA_BARUT` | **42. Kara Barut Dumanı & Namlu Parlaması Havuzu GPU Buffer Sızıntısı Yok Doğrulaması (G3D-03D Ajan 5)** | 64 slotluk statik GPU havuzu, frame başı 0 GC, buffer sızıntısızlığı |
| **Test 43** | `06_SAHA_GORSELLIK` | **43. 1650 Savaş Alanı Zemin Renk Parametreleri, Sis Yapılandırması, Işık Dengesi & Uzak Siluet Okunurluğu Doğrulaması** | Yatay güneş (0xfff2dc), rim lighting shader, sis yoğunluğu (0.0048), zemin renk doğruluğu |

---

## 9. ENTEGRASYON ÇAKIŞMA NOKTALARI VE REGRESYON ENGELLEME REÇETESİ

Yapılan derinlemesine denetimde, 6 ajan bağımsız çalışırken kod tabanında ortaya çıkan ve naive (dikkatsiz) bir birleştirmede regresyona sebep olabilecek **3 temel çakışma** tespit edilmiştir. Entegratör ajanın bu reçeteye harfiyen uyması zorunludur:

### 9.1 Çakışma 1: `computeCavalryPartLocalMatrix` Fonksiyon İmzası ve Parametre Sırası
- **Sorun:**
  - Ajan 1: `(outMat, part, walkPhase, walkBlend, trotBlend, scratchA, scratchB, actionPhase, actionBlend, actionMode, archetype, partIndex, totalParts)`
  - Ajan 2: `(outMat, part, walkPhase, walkBlend, trotBlend, scratchA, scratchB, actionPhase, actionBlend, actionMode, archetype)`
  - Ajan 3: `(outMat, part, walkPhase, walkBlend, trotBlend, scratchA, scratchB, archetype, actionPhase, actionBlend, actionMode)` *(archetype öne alınmış!)*
  - Ajan 4, 5, 6: Yalnızca ilk 7 parametreyi kullanmaktadır.
- **Regresyon Engelleme Reçetesi:**
  Entegrasyonda evrensel ve kapsayıcı imza kullanılmalıdır:
  ```javascript
  function computeCavalryPartLocalMatrix(
      outMat,
      part,
      walkPhase,
      walkBlend,
      trotBlend,
      scratchA,
      scratchB,
      actionPhase = 0,
      actionBlend = 0,
      actionMode = 'attack',
      archetype = null,
      partIndex = -1,
      totalParts = 0
  ) { ... }
  ```
  `archetype` parametresi 11. sıraya konulmalı, Ajan 3'ün iç mantığı buna adapte edilmelidir.

### 9.2 Çakışma 2: Rig Grubu Adlandırması (`subGroup = 'lance'` vs `rigGroup = 'riderRightArmWeapon'`)
- **Sorun:**
  - Ajan 1, mızrak parçalarını `riderUpper` içinde tutup `subGroup = 'lance'` eklemiştir.
  - Ajan 2, kılıç parçalarının `rigGroup` değerini `'riderRightArmWeapon'` yapmıştır.
  - Ajan 3 ve Referans, tüm kol ve silahları `riderUpper` olarak beklemektedir.
- **Regresyon Engelleme Reçetesi:**
  `computeCavalryPartLocalMatrix` içerisinde sağ kol ve silah dallanması şu şekilde birleşik mantıkla kontrol edilmelidir:
  ```javascript
  const isRightArmWeapon = (rig === 'riderRightArmWeapon') || 
                           (rig === 'riderUpper' && (part.subGroup === 'lance' || partIndex >= totalParts - 8));
  ```
  Böylece hem Ajan 1'in alt grup filtrelemesi, hem Ajan 2'nin özel rig grubu, hem de Ajan 3'ün üst gövde pozlandırması aynı anda sorunsuz çalışır.

### 9.3 Çakışma 3: UI Buton Grubu Karşılıklı Dışlama (Mutual Exclusion Mutex)
- **Sorun:** Ajan 1, 2 ve 3 kendi test panellerine süvari savaş pozu butonları eklemiş; Ajan 4 ise 5 at tipini gösteren bağımsız bir at önizleme butonu eklemiştir.
- **Regresyon Engelleme Reçetesi:**
  Önizleme butonları (`btnToggleWalkPreview`, `btnToggleCombatPreview`, `btnToggleCavalryCombatPreview`, `btnToggleHorsePreview`) arasında 4'lü bir karşılıklı dışlama (mutex) kurulmalı; biri açıldığında diğer üçü otomatik olarak kapatılmalı ve kamera `focusOnDefaultTarget()` ile güvenli konuma getirilmelidir.

---

## 10. NİHAİ DENETİM KARARI VE İMZA

Fall of Cavalry G3D-03D Entegrasyon çalışması kapsamında teslim edilen 6 ajanın çalışmaları incelenmiş ve aşağıdaki sonuçlara varılmıştır:

1. **Geriye Dönük Uyumluluk:** %100 Başarılı. Orijinal sürümün 37 testi hiçbir hasar görmeden korunmuştur.
2. **Model ve Ordu Bütünlüğü:** 206 model şablonu, 442 askerlik kaynak veri ve 7 batch mimarisi eksiksiz korunmuştur.
3. **Yeni Yeteneklerin Kalitesi:** Mızrak hamlesi, kılıç savuruşu, ateşli silah nişanı, 5 at tipinin biyomekanik toynak teması, kara barut dumanı ve raking light saha görselliği standartlara tam uygundur.
4. **Entegrasyon Onayı:** Yukarıdaki risk engelleme reçetesine uyulması kaydıyla, `INTEGRATION\G3D03D_MERGED_WORKING.html` dosyasının birleştirilmesi ve **43/43 Test ile G3D-03D sürümünün canlıya alınması UYGUNDUR.**

**Denetçi:** AJAN 6 — REGRESSION_AUDIT  
**Karar:** **TAM VE ŞARTLI ONAY (READY FOR UNIFIED MERGE & TEST 43/43 EXECUTION)**  
**İmza / Durum:** `c:\Users\zxc28\Desktop\FOC-Visual-Sandbox\QA\REGRESSION_AUDIT.md` ÜRETİLDİ VE TESLİM EDİLDİ.
