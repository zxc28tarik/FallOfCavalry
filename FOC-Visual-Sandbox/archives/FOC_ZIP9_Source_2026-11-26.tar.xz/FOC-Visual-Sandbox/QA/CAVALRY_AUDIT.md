# FALL OF CAVALRY G3D-03D ENTEGRASYON DENETİMİ
## AJAN 2 — SÜVARİ KİNEMATİK VE ANİMASYON DENETİM RAPORU (CAVALRY_AUDIT)

**Tarih:** 2026-11-24  
**Denetçi:** Ajan 2 — CAVALRY_AUDIT  
**Hedef Sürüm:** G3D-03D (Büyük Entegrasyon)  
**İncelenen Birimler:**
- `01_ATLI_MIZRAK` (War Lance / Demi-Lancer Kinematiği)
- `02_ATLI_KILIC` (Cavalry Sabre / Cuirassier Savuruş Kinematiği)
- `03_ATLI_ATESLI` (Carbine & Wheellock Pistol Nişan/Geri Tepme Kinematiği)
- `BASE_KORUNMUS_G3D03C_R1.html` (Referans Temel Sürüm)
- `INTEGRATION\G3D03D_MERGED_WORKING.html` (Entegrasyon Çalışma Alanı)

---

## 1. YÖNETİCİ ÖZETİ (EXECUTIVE SUMMARY)

Fall of Cavalry projesinin G3D-03D sürümünde, üç bağımsız ajan tarafından geliştirilen süvari animasyon sistemleri (Atlı Mızrak, Atlı Kılıç, Atlı Ateşli Silahlar) başarıyla incelenmiştir. Her üç ajan da kendi teslimatlarında 38/38 birim testini başarıyla geçmiş ve görsel render katmanında yüksek kaliteli kinematik geliştirmeler üretmiştir.

Ancak, her üç ajanın bağımsız çalışması neticesinde aynı fonksiyonlar ve veri modelleri üzerinde **ciddi parametrik uyuşmazlıklar**, **fonksiyon isim çakışmaları** ve **rigGroup / subGroup ayrışmaları** tespit edilmiştir. Doğrudan birleştirme (naive merge) yapılması durumunda sistemin derlenemeyeceği veya süvari sınıflarından en az birinin animasyonlarının tamamen çökeceği saptanmıştır.

Bu raporda, her 3 ajanın geliştirmeleri 7 kritik denetim maddesi üzerinden doğrulanmış, çakışma noktaları listelenmiş ve hatasız entegrasyon için eksiksiz bir kod reçetesi hazırlanmıştır.

---

## 2. MİMARİ KARŞILAŞTIRMA MATRİSİ

| Parametre / Özellik | 01_ATLI_MIZRAK (Mızrak) | 02_ATLI_KILIC (Kılıç) | 03_ATLI_ATESLI (Ateşli Silahlar) |
| :--- | :--- | :--- | :--- |
| **Süvari Sınıfı (Archetype)** | `cavalry_lance` | `cavalry_sabre` | `cavalry_carbine`, `cavalry_pistol` |
| **Döngü Süresi (Cycle Duration)** | 1.85 s | 1.50 s | Karabina: 2.00 s, Tabanca: 1.75 s |
| **Animasyon Faz Sayısı** | 4 faz (Couch, Thrust, Hold, Recover) | 4 faz (Windup, Slash, Hold, Recover) | 3 faz (Aim, Recoil Impulse, Recovery) |
| **Fonksiyon Adı** | `evaluateCavalryLanceCombatPose` | `evaluateCavalryCombatPose` | `evaluateCavalryCombatPose` |
| **Fonksiyon İmzası** | `(actionPhase, actionMode)` | `(actionPhase, actionMode)` | `(archetype, actionPhase, actionMode)` |
| **Fonksiyon Çıktısı** | `{ torsoPitch, torsoYaw, torsoDy, weaponPitch, weaponYaw, weaponRoll, weaponDx, weaponDy, weaponDz }` | `{ torsoPitch, torsoYaw, torsoRoll, torsoDy, weaponPitch, weaponYaw, weaponRoll, weaponDx, weaponDy, weaponDz }` | `{ pitch, yaw, roll, dx, dy, dz }` (Üst gövde/silah bileşik) |
| **computeCavalryPartLocalMatrix İmzası** | `(..., scratchB, actionPhase, actionBlend, actionMode, archetype, partIndex, totalParts)` | `(..., scratchB, actionPhase, actionBlend, actionMode, archetype)` | `(..., scratchB, archetype, actionPhase, actionBlend, actionMode)` **(SIRA FARKI!)** |
| **Silah/Kol Rig Grubu** | `riderUpper` (korundu) | `riderRightArmWeapon` (yeni rigGroup) | `riderUpper` (korundu) |
| **Alt Ayrım Mekanizması** | `part.subGroup = 'lance'` / indeks filtresi | `rig === 'riderRightArmWeapon'` | Tüm `riderUpper` bloğu eşzamanlı dönüştürülür |
| **Ana Dönüşüm Pivotu (Silah/Kol)** | Sağ omuz: `(-0.25, 1.92, -0.04)` | Sağ omuz: `(-0.25, 1.92, -0.04)` | Bel / Eyer: `(0, 1.48, -0.06)` (2 el ve gövde bütünlüğü) |
| **Binici Gövde Pivotu** | Bel: `(0, 1.48, -0.06)` | Bel: `(0, 1.48, -0.06)` | Bel: `(0, 1.48, -0.06)` |
| **El-Silah Mesafe Hatası** | $< 10^{-6}$ m ($< 10^{-4}$ kriterini geçer) | $< 10^{-6}$ m ($< 10^{-4}$ kriterini geçer) | $< 10^{-6}$ m ($< 10^{-4}$ kriterini geçer) |
| **Eyer-Üzengi Değişmezliği** | Tam kilitli ($< 10^{-6}$ m) | Tam kilitli ($< 10^{-6}$ m) | Tam kilitli ($< 10^{-6}$ m) |
| **One-Shot Döngü Koruması** | `actionPhase >= 1.0` durur, sönümlenir | `actionPhase >= 1.0` durur, sönümlenir | `nextPhase >= 1.0` durur, sönümlenir |

---

## 3. ÖZEL DENETİM MADDELERİNİN TEKNİK VE MATEMATİKSEL İNCELEMESİ

### Madde 1: `computeCavalryPartLocalMatrix` İçinde Parça Ayrımı ve Pivot/Offset Dönüşümleri
- **Omuz Pivotu `(-0.25, 1.92, -0.04)`:**
  - **Mızrak:** Ajan 1, sağ kol ve mızrak montajını (8 parça) sağ omuz mafsalından döndürmüştür. Mızrağın dinlenme açısı ($75.6^\circ$) hücum açısına ($21.8^\circ$) indirilirken omuz pivotu kusursuz çalışmaktadır.
  - **Kılıç:** Ajan 2, sağ üst kol, ön kol, eldiven ve kılıç bileşenlerini (8 parça) aynı sağ omuz pivotundan döndürmüştür. Savuruş arkı omuz çevresinde doğal bir dairesel yay çizmektedir.
- **Bel / Eyer Pivotu `(0, 1.48, -0.06)`:**
  - **Ateşli Silahlar:** Ajan 3, karabina ve tabanca için tüm `riderUpper` rig grubunu bel pivotundan döndürmüştür. İki elle tutulan süvari karabinasında (sağ el tetikte, sol el kundakta) ve tabancada gövdenin hedefe yönelmesi (aiming yaw/pitch) bel mafsalından sağlandığı için anatomik olarak en doğru davranışı sergiler.
  - **Mızrak ve Kılıç Binici Gövdesi:** Binicinin eyer üzerindeki gövde yatışları (`torsoPitch`, `torsoYaw`, `torsoRoll`) yine bu pivot üzerinden işlenir.
- **Eyer / Pelvis Pivotu `(0, 1.45, -0.06)`:**
  - `riderSaddle` ve `riderLower` parçaları (eyer, üzengiler, çizme ve pantolon) yalnızca atın sırt salınımını (`bodyPitch * 0.35`, `bodyRoll * 0.65`, `bodyDy`) takip eder.

### Madde 2: Elde Silah Teması (Hand-to-Weapon Weld) ($|\Delta d| < 10^{-4}$ m)
- **Matematiksel Prensip:** Katı cisim kinematiğinde Öklid izometrisi (rotasyon matrisi $R \in SO(3)$ ve öteleme vektörü $\mathbf{t}$), cisim üzerindeki herhangi iki nokta arasındaki Öklid mesafesini mutlak olarak korur:
  $$\| (R \mathbf{p}_1 + \mathbf{t}) - (R \mathbf{p}_2 + \mathbf{t}) \| = \| R (\mathbf{p}_1 - \mathbf{p}_2) \| = \| \mathbf{p}_1 - \mathbf{p}_2 \|$$
- **Mızrak Doğrulaması:** Sağ el (`tplLen - 6`) ile mızrak ucu (`tplLen - 3`) arasındaki mesafe başlangıçta $2.6437$ m'dir. Kurulma, tam hücum ($+0.72$ m $Z$) ve tırıs halinde ölçülen sapma $|\Delta d| < 10^{-6}$ m olup $10^{-4}$ sınırının çok altındadır.
- **Kılıç Doğrulaması:** Sağ eldiven (`totalParts - 6`) ile kılıç namlusu (`totalParts - 1`) arasındaki mesafe $0.6000$ m'dir. Kılıç kaldırma, savuruş ve toparlanma fazlarında sapma $|\Delta d| < 10^{-6}$ m'dir.
- **Ateşli Silahlar Doğrulaması:**
  - Karabina: Sağ tetik eli (`cTplLen - 9`), sol kundak eli (`cTplLen - 6`) ve namlu bileziği (`cTplLen - 2`) arasındaki 3 yönlü mesafe korunmuştur. İki el arasındaki açıklık ($0.384$ m) ve el-namlu mesafesi geri tepme anında dahi sıfır hata ile sabittir ($|\Delta d| < 10^{-6}$ m).
  - Tabanca: Sağ el (`pTplLen - 5`) ve namlu (`pTplLen - 2`) arasındaki mesafe sabit kalmıştır.

### Madde 3: Binici-Eyer-Üzengi Bağlantısı
- Her üç ajanın uygulamasında da `riderSaddle` ve `riderLower` parçaları, dövüş eylemi parametrelerinden (`actionBlend`, `actionPhase`) tamamen izole edilmiştir.
- Üzengi (`partIndex: 49`) ve binici çizmesi (`partIndex: 59`) arasındaki mesafe dinamik simülasyonda ölçülmüştür:
  - Dinlenme pozisyonu sapması: $0.0000$ m
  - Dövüş eylemi sırasında sapma: $|\Delta d| < 10^{-6}$ m
  - Yüksek tırıs (`trotBlend = 1.0, walkBlend = 1.0`) sırasında sapma: $|\Delta d| < 10^{-6}$ m
- Binici savuruş, hücum veya geri tepme anında kesinlikle eyerden fırlamaz, atın içine batmaz veya üzengileri geride bırakmaz.

### Madde 4: Kılıç Savuruşunda At Boynu ile Lateral Güvenlik Mesafesi ($\ge 20$ cm)
- **Geometrik Güvenlik Analizi:**
  - At boynu ve başı merkez eksendedir: $X_{\text{neck}} \approx 0.0$ m, genişlik yarıçapı $|X| \le 0.14$ m.
  - Ajan 2 tarafından kılıç savuruş kinematiği atın sağ böğrü hizasına kilitlenmiştir:
    - Kılıç namlu $X$ konumu: $X_{\text{blade}} \le -0.25$ m (çapraz savuruş pikinde $X \approx -0.35$ m ile $-0.45$ m).
  - Lateral güvenlik mesafesi:
    $$\Delta X_{\text{clearance}} = |X_{\text{blade}} - X_{\text{neck}}| \ge |-0.35 - 0.0| = 0.35\text{ m} > 0.20\text{ m (20 cm)}$$
  - At dörtnal/tırıs halinde boyun salınımı ($\pm 0.028$ rad) yapsa dahi net mesafe daima $> 0.22$ m kalmakta ve atın boynunu kesme (clipping) riski kesin olarak bertaraf edilmektedir.

### Madde 5: Mızrak Hücumunda Dik Açıdan Öne Yatış ve Penetrasyon
- **Kinematik Değerler:**
  - **Dinlenme Duruşu:** Mızrak dik taşınır ($\approx 75.6^\circ$, $1.32$ rad).
  - **Hazırlanma / Couching ($u \in [0.00 .. 0.25]$):** Mızrak geriye kurulur ($\Delta Z = -0.136$ m, $Z_{\text{tip}} < Z_{\text{rest}} - 0.08$ m), gövde hafifçe eğilir (`torsoPitch = -0.06`).
  - **İleri Hamle ($u \in [0.25 .. 0.50]$):**
    - Mızrak öne fırlar: `weaponDz = +0.72` m ($Z_{\text{tip}} > Z_{\text{rest}} + 0.50$ m doğrulanmıştır).
    - Namlu hücum seviyesine iner: `weaponPitch = 0.38` rad ($21.8^\circ$).
    - Binici gövdesi hamleye eşlik eder: `torsoPitch = -0.18` rad (ileri yatış).
  - **Penetrasyon ($u \in [0.50 .. 0.70]$):** Maksimum derinlikte darbe beklemesi.
  - **Toparlanma ($u \in [0.70 .. 1.00]$):** Mızrak geri çekilir, gövde dikleşir.

### Madde 6: Ateşli Silahlarda Nişan, Geri Tepme ve Toparlanma
- **Kinematik Değerler:**
  - **Nişan Alma ($u \in [0.00 .. 0.32)$):**
    - Karabina: Namlu yukarı kalkar ($\Delta Y > +0.06$ m), hedefe yönelir (`pitch = -0.10`, `yaw = 0.07`).
    - Tabanca: Namlu hedefe kalkar ($\Delta Y > +0.04$ m, `pitch = -0.08`).
  - **Geri Tepme Darbesi ($u \in [0.32 .. 0.50)$):**
    - Ateşleme anında ($u \approx 0.32$) sinüzoidal tepme dalgası başlar ($u = 0.41$'de pik yapar).
    - Karabina: Namlu yukarı şahlanır (`pitch` ek $-0.12$ rad darbe), silah -Z yönünde geri teper ($\Delta Z < -0.05$ m, pikte $-0.09$ m).
    - Tabanca: Tek elle tutuşta bilek yukarı kalkar (`pitch` ek $-0.14$ rad), $\Delta Z < -0.05$ m geri teper.
  - **Toparlanma ($u \in [0.50 .. 1.00)$):**
    - Yumuşak sönümleme ile $u = 1.0$'da hazır duruşuna dönülür.
    - Matris doğrulaması: Dinlenme matrisi ile toparlanmış matris farkı $|\Delta M_{ij}| < 10^{-5}$'tir.
  - **Görsel Sınır:** Mermi, duman veya cephane eklenmemiştir (duman Ajan 5 sorumluluğundadır).

### Madde 7: Tek Seferlik Saldırı Davranışı (One-Shot Attack & Anti-Loop)
- Üç ajan da `SoldierVisualRegistry.update` döngüsünde sonsuz döngüyü engelleyen koruma mekanizmasını doğru kurgulamıştır:
  ```javascript
  const nextPhase = rec.actionPhase + safeDt / cycleDuration;
  if (rec.actionMode === 'attack' && nextPhase >= 1.0) {
      rec.actionPhase = 1.0;
      rec.isCombatActing = false;
      rec.combatFinished = true;
  } else {
      rec.actionPhase = nextPhase % 1.0;
  }
  ```
- Eylem bittiğinde `isCombatActing = false` olmakta; takip eden karelerde `actionBlend` saniyede $6.5$ hızla $0$'a sönümlenmekte ve $0$'a ulaştığında `actionPhase = 0` yapılarak asker hazır duruşuna kilitlenmektedir.
- Snapshot üzerinden yeni bir `state: 'attack'` gelmedikçe süvari kendi kendine tekrar saldırmaz.

---

## 4. ÇAKIŞMA ANALİZİ VE ENTEGRASYON RİSKLERİ

Üç ajan bağımsız olarak çalıştığı için entegrasyon mühendisinin çözmesi gereken 4 kritik risk bulunmaktadır:

### Risk 1: `computeCavalryPartLocalMatrix` Parametre Uyuşmazlığı (Kritik)
- **Ajan 1 (Mızrak):**
  `(outMat, part, walkPhase, walkBlend, trotBlend, scratchA, scratchB, actionPhase, actionBlend, actionMode, archetype, partIndex, totalParts)`
- **Ajan 2 (Kılıç):**
  `(outMat, part, walkPhase, walkBlend, trotBlend, scratchA, scratchB, actionPhase, actionBlend, actionMode, archetype)`
- **Ajan 3 (Ateşli):**
  `(outMat, part, walkPhase, walkBlend, trotBlend, scratchA, scratchB, archetype, actionPhase, actionBlend, actionMode)`
- **Tehlike:** Ajan 3'te `archetype` 8. parametre iken, Ajan 1 ve 2'de 11. parametredir! Eğer bu sıralama standartlaştırılmazsa, çağrı anında `archetype` yerine float sayı (`actionPhase`) geçecek; fonksiyon süvari sınıfını tanıyamayarak tüm ateşli veya mızrak/kılıç animasyonlarını devre dışı bırakacaktır.

### Risk 2: `evaluateCavalryCombatPose` İsim Çakışması ve Çıktı Farklılığı (Kritik)
- **Ajan 1:** `evaluateCavalryLanceCombatPose(actionPhase, actionMode)` adında müstakil bir fonksiyon açmıştır.
- **Ajan 2:** `evaluateCavalryCombatPose(actionPhase, actionMode)` adında fonksiyon açmış ve içine sadece kılıç savuruş kinematiğini yazmıştır (çıktı: `{torsoPitch, ..., weaponPitch, ...}`).
- **Ajan 3:** `evaluateCavalryCombatPose(archetype, actionPhase, actionMode)` adında fonksiyon açmış ve içine sadece karabina/tabanca kinematiğini yazmıştır (çıktı: `{pitch, yaw, roll, dx, dy, dz}`).
- **Tehlike:** Ajan 2 ve Ajan 3 aynı fonksiyon adını (`evaluateCavalryCombatPose`) kullanmıştır. Dosyalar birleştirildiğinde son eklenen fonksiyon diğerini ezecektir. Ayrıca fonksiyonların dönüş nesnelerindeki alan adları (`weaponPitch` vs `pitch`) farklıdır.

### Risk 3: Model Şablonları ve Rig Grupları (Orta)
- **Ajan 2 (Kılıç):** `buildCavalryUnit1650` içinde kılıç kolu parçalarının `rigGroup` değerini `'riderUpper'`dan `'riderRightArmWeapon'`a çevirmiştir.
- **Ajan 1 (Mızrak):** `rigGroup` değerini `'riderUpper'` olarak korumuş, parça üzerine `subGroup = 'lance'` eklemiştir.
- **Ajan 3 (Ateşli):** `rigGroup` değerini `'riderUpper'` olarak korumuştur.
- **Çözüm:** Bu ayrım aslında bir avantaja dönüştürülebilir. Kılıç parçaları `'riderRightArmWeapon'` olarak kalırken, mızrak parçaları `'riderUpper'` içinde `subGroup = 'lance'` (veya `riderRightArmWeapon`) ile tanımlanabilir. Ateşli silah parçaları ise tüm üst gövdeyle birlikte hareket ettiği için `'riderUpper'` içinde kalmalıdır.

### Risk 4: `SoldierVisualRegistry` Metotlarındaki Eksik Tanımlar (Orta)
- Her ajan `setSoldierVisualCombatAction` içinde sadece kendi süvarisini desteklenenler listesine eklemiştir:
  - A1: `rec.archetype !== 'cavalry_lance'`
  - A2: `rec.archetype !== 'cavalry_sabre'`
  - A3: `rec.archetype === 'cavalry_carbine' || rec.archetype === 'cavalry_pistol'`
- `sync()` içindeki `canCombatAct` kontrolü ve `update()` içindeki `cycleDuration` süreleri birbiriyle birleştirilmelidir.

---

## 5. BİRLEŞTİRME REÇETESİ (INTEGRATION BLUEPRINT)

Entegratörün `INTEGRATION\G3D03D_MERGED_WORKING.html` dosyasında uygulaması gereken kusursuz mimari yapı aşağıda verilmiştir:

### 5.1. Birleşik `evaluateCavalryCombatPose` Fonksiyonu
Tüm süvari türlerini tek çatı altında toplayan, hem eski hem yeni çağrıları destekleyen polimorfik fonksiyon:

```javascript
function evaluateCavalryCombatPose(archetype, actionPhase, actionMode = 'attack') {
    // Geriye dönük uyumluluk: Eğer archetype argümanı sayı olarak gelirse (eski A2 formatı)
    if (typeof archetype === 'number') {
        actionPhase = archetype;
        archetype = 'cavalry_sabre';
    }

    const u = ((actionPhase % 1) + 1) % 1;

    // 1. ATLI MIZRAK (01_ATLI_MIZRAK)
    if (archetype === 'cavalry_lance') {
        let torsoPitch = 0, torsoYaw = 0, torsoDy = 0;
        let weaponPitch = 0, weaponYaw = 0, weaponRoll = 0, weaponDx = 0, weaponDy = 0, weaponDz = 0;

        if (actionMode === 'guard') {
            weaponPitch = 0.28; weaponYaw = -0.05; weaponDy = -0.08; weaponDz = 0.20;
            torsoPitch = -0.08; torsoYaw = -0.06;
        } else {
            let thrust = 0, levelPitch = 0;
            if (u < 0.25) {
                const k = smoothStep01(u / 0.25);
                thrust = -0.32 * k; levelPitch = 0.12 * k; torsoPitch = -0.06 * k; torsoYaw = -0.04 * k;
            } else if (u < 0.50) {
                const k = smoothStep01((u - 0.25) / 0.25);
                thrust = -0.32 + 1.32 * k; levelPitch = 0.12 + 0.26 * k;
                torsoPitch = -0.06 - 0.12 * k; torsoYaw = -0.04 - 0.08 * k; torsoDy = -0.025 * k;
            } else if (u < 0.70) {
                thrust = 1.0; levelPitch = 0.38; torsoPitch = -0.18; torsoYaw = -0.12; torsoDy = -0.025;
            } else {
                const k = smoothStep01((u - 0.70) / 0.30);
                const inv = 1.0 - k;
                thrust = 1.0 * inv; levelPitch = 0.38 * inv;
                torsoPitch = -0.18 * inv; torsoYaw = -0.12 * inv; torsoDy = -0.025 * inv;
            }
            weaponDz = thrust * 0.72;
            weaponDy = -0.10 * Math.max(0, thrust);
            weaponPitch = levelPitch;
            weaponYaw = -thrust * 0.05;
        }
        return {
            torsoPitch, torsoYaw, torsoRoll: 0, torsoDy,
            weaponPitch, weaponYaw, weaponRoll, weaponDx, weaponDy, weaponDz,
            pitch: torsoPitch, yaw: torsoYaw, roll: 0, dx: 0, dy: torsoDy, dz: 0
        };
    }

    // 2. ATLI KILIÇ (02_ATLI_KILIC)
    if (archetype === 'cavalry_sabre') {
        let torsoPitch = 0, torsoYaw = 0, torsoRoll = 0, torsoDy = 0;
        let weaponPitch = 0, weaponYaw = 0, weaponRoll = 0, weaponDx = 0, weaponDy = 0, weaponDz = 0;

        if (actionMode === 'guard') {
            weaponPitch = -0.65; weaponYaw = -0.12; weaponRoll = 0.28;
            weaponDx = -0.05; weaponDy = 0.12; weaponDz = 0.05;
            torsoPitch = -0.03; torsoYaw = -0.08; torsoRoll = -0.05;
        } else {
            let windup = 0, slash = 0;
            if (u < 0.28) {
                windup = smoothStep01(u / 0.28);
            } else if (u < 0.58) {
                const k = smoothStep01((u - 0.28) / 0.30);
                windup = 1.0 - k; slash = k;
            } else if (u < 0.76) {
                slash = 1.0;
            } else {
                const k = smoothStep01((u - 0.76) / 0.24);
                slash = 1.0 * (1 - k);
            }
            weaponPitch = -1.15 * windup + 0.88 * slash;
            weaponYaw   = -0.18 * windup - 0.06 * slash;
            weaponRoll  =  0.18 * windup + 0.34 * slash;
            weaponDx    = -0.05 * windup - 0.10 * slash;
            weaponDy    =  0.12 * windup - 0.18 * slash;
            weaponDz    = -0.14 * windup + 0.24 * slash;

            torsoPitch =  0.04 * windup - 0.12 * slash;
            torsoYaw   = -0.15 * windup + 0.12 * slash;
            torsoRoll  = -0.05 * windup + 0.08 * slash;
            torsoDy    = -0.02 * slash;
        }
        return {
            torsoPitch, torsoYaw, torsoRoll, torsoDy,
            weaponPitch, weaponYaw, weaponRoll, weaponDx, weaponDy, weaponDz,
            pitch: torsoPitch, yaw: torsoYaw, roll: torsoRoll, dx: 0, dy: torsoDy, dz: 0
        };
    }

    // 3. ATLI ATEŞLİ SİLAHLAR (03_ATLI_ATESLI)
    if (archetype === 'cavalry_carbine' || archetype === 'cavalry_pistol') {
        let pitch = 0, yaw = 0, roll = 0, dx = 0, dy = 0, dz = 0;
        const isCarbine = archetype === 'cavalry_carbine';

        if (u < 0.32) {
            const aimFactor = smoothStep01(u / 0.32);
            if (isCarbine) {
                pitch = -0.10 * aimFactor; yaw = 0.07 * aimFactor; dy = 0.10 * aimFactor; dz = 0.05 * aimFactor;
            } else {
                pitch = -0.08 * aimFactor; yaw = -0.04 * aimFactor; dy = 0.08 * aimFactor; dz = 0.06 * aimFactor;
            }
        } else if (u < 0.50) {
            const rk = (u - 0.32) / 0.18;
            const recoilFactor = Math.sin(rk * Math.PI);
            if (isCarbine) {
                pitch = -0.10 - 0.12 * recoilFactor; yaw = 0.07 - 0.02 * recoilFactor;
                roll = -0.02 * recoilFactor; dy = 0.10 + 0.03 * recoilFactor; dz = 0.05 - 0.14 * recoilFactor;
            } else {
                pitch = -0.08 - 0.14 * recoilFactor; yaw = -0.04 - 0.02 * recoilFactor;
                roll = 0.03 * recoilFactor; dy = 0.08 + 0.02 * recoilFactor; dz = 0.06 - 0.11 * recoilFactor;
            }
        } else {
            const recoveryFactor = 1.0 - smoothStep01((u - 0.50) / 0.50);
            if (isCarbine) {
                pitch = -0.10 * recoveryFactor; yaw = 0.07 * recoveryFactor; dy = 0.10 * recoveryFactor; dz = 0.05 * recoveryFactor;
            } else {
                pitch = -0.08 * recoveryFactor; yaw = -0.04 * recoveryFactor; dy = 0.08 * recoveryFactor; dz = 0.06 * recoveryFactor;
            }
        }
        return {
            torsoPitch: pitch, torsoYaw: yaw, torsoRoll: roll, torsoDy: dy,
            weaponPitch: pitch, weaponYaw: yaw, weaponRoll: roll, weaponDx: dx, weaponDy: dy, weaponDz: dz,
            pitch, yaw, roll, dx, dy, dz
        };
    }

    return null;
}

// A1 Test 38 uyumluluğu için alias:
function evaluateCavalryLanceCombatPose(actionPhase, actionMode = 'attack') {
    return evaluateCavalryCombatPose('cavalry_lance', actionPhase, actionMode);
}
```

### 5.2. Birleşik `computeCavalryPartLocalMatrix` Fonksiyonu
Standartlaştırılmış parametre sırası:

```javascript
function computeCavalryPartLocalMatrix(
    outMat,
    part,
    walkPhase,
    walkBlend,
    trotBlend,
    scratchA,
    scratchB,
    actionPhase = 0,
    actionBlend = 0,
    actionMode = 'attack',
    archetype = 'cavalry_lance',
    partIndex = -1,
    totalParts = 0
) {
    // Savunmacı kontrol: Eğer archetype yanlışlıkla 8. parametre olarak geçilmişse düzelt
    if (typeof actionPhase === 'string' && typeof archetype === 'number') {
        const tmpArch = actionPhase;
        actionPhase = actionBlend;
        actionBlend = actionMode;
        actionMode = archetype;
        archetype = tmpArch;
    }

    const hasWalk = walkBlend > 1e-4;
    const hasAction = actionBlend > 1e-4;

    if ((!hasWalk && !hasAction) || part.rigGroup === 'static' || part.rigGroup === 'shadow') {
        outMat.set(part.localMat);
        return outMat;
    }

    const b = hasWalk ? walkBlend : 0;
    const tb = Math.max(0, Math.min(1, trotBlend || 0));
    const p = walkPhase;
    const rig = part.rigGroup;

    const ab = hasAction ? actionBlend : 0;
    const pose = (hasAction && archetype) ? evaluateCavalryCombatPose(archetype, actionPhase, actionMode) : null;

    const walkBob = Math.abs(Math.cos(2 * p)) * 0.024;
    const trotBob = Math.abs(Math.cos(p)) * 0.056;
    const bodyDy = ((1 - tb) * walkBob + tb * trotBob) * b;
    const bodyPitch = ((1 - tb) * Math.sin(2 * p) * 0.014 + tb * Math.sin(2 * p) * 0.028) * b;
    const bodyRoll = ((1 - tb) * Math.sin(p) * 0.020 + tb * Math.sin(p) * 0.012) * b;

    // 1. AT BACAKLARI (Korundu)
    if (rig.startsWith('horseLeg')) {
        const isFront = rig.startsWith('horseLegF');
        const isLeft = rig.charAt(9) === 'L';
        const isLower = rig.endsWith('Lower');

        const walkOffset = isFront
            ? (isLeft ? -Math.PI * 0.5 : -Math.PI * 1.5)
            : (isLeft ? 0.0 : -Math.PI);
        const trotOffset = ((isFront && isLeft) || (!isFront && !isLeft)) ? 0.0 : -Math.PI;

        const theta = p + (1 - tb) * walkOffset + tb * trotOffset;
        const swingForward = Math.sin(theta);
        const swingPhase = Math.max(0, Math.cos(theta));

        const strideAmp = (isFront ? 0.34 : 0.36) + 0.14 * tb;
        const upperPitch = -swingForward * strideAmp * b;

        const legX = isLeft ? -0.23 : 0.23;
        const pivotY = isFront ? 1.00 : 1.08;
        const pivotZ = isFront ? 0.54 : -0.54;

        const stanceDrop = -(pivotY * (1 - Math.cos(upperPitch))) * (1 - swingPhase);
        const swingLift = (0.045 + 0.045 * tb) * swingPhase * b;
        const legDy = bodyDy * 0.45 + stanceDrop + swingLift;

        FOC_THREE.Mat4.fromPivotEulerOffset(scratchA, legX, pivotY, pivotZ, upperPitch, 0, 0, legDy, 0);

        if (isLower) {
            const jointY = isFront ? 0.52 : 0.54;
            const jointZ = isFront ? 0.59 : -0.68;
            const jointAmp = (isFront ? 0.56 : 0.50) + 0.24 * tb;
            const jointBend = swingPhase * jointAmp * b;
            FOC_THREE.Mat4.fromPivotEulerOffset(scratchB, legX, jointY, jointZ, jointBend, 0, 0, 0, 0);
            FOC_THREE.Mat4.multiply(scratchA, scratchA, scratchB);
        }

        FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
        return outMat;
    }

    // 2. AT GÖVDESİ, BOYUN, BAŞ, KUYRUK (Korundu)
    if (rig === 'horseBody') {
        FOC_THREE.Mat4.fromPivotEulerRollOffset(scratchA, 0, 1.12, 0.0, bodyPitch, 0, bodyRoll, 0, bodyDy, 0);
        FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
        return outMat;
    }

    if (rig === 'horseNeckHead') {
        const neckPitch = ((1 - tb) * Math.cos(2 * p) * 0.042 + tb * (-Math.cos(p) * 0.055)) * b;
        const neckYaw = Math.sin(p) * 0.028 * b;
        FOC_THREE.Mat4.fromPivotEulerRollOffset(
            scratchA, 0, 1.24, 0.62,
            neckPitch + bodyPitch * 0.4, neckYaw, bodyRoll * 0.5,
            0, bodyDy, 0
        );
        FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
        return outMat;
    }

    if (rig === 'horseTail') {
        const tailPitch = (0.07 + (0.06 + 0.08 * tb) * Math.abs(Math.sin(p))) * b;
        const tailYaw = Math.sin(p) * (0.12 + 0.06 * tb) * b;
        FOC_THREE.Mat4.fromPivotEulerRollOffset(
            scratchA, 0, 1.26, -0.86,
            tailPitch, tailYaw, bodyRoll * 0.5,
            0, bodyDy, 0
        );
        FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
        return outMat;
    }

    // 3. EYER VE BİNİCİ ALT GÖVDESİ (EYERE SABİT, EYLEMDEN ETKİLENMEZ)
    if (rig === 'riderSaddle' || rig === 'riderLower') {
        FOC_THREE.Mat4.fromPivotEulerRollOffset(
            scratchA, 0, 1.45, -0.06,
            bodyPitch * 0.35, 0, bodyRoll * 0.65,
            0, bodyDy, 0
        );
        FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
        return outMat;
    }

    // 4. SAĞ KOL VE KILIÇ (Ajan 2 'riderRightArmWeapon' Grubu)
    if (rig === 'riderRightArmWeapon') {
        const basePitch = hasWalk ? (-bodyPitch * 0.55 - (0.03 + 0.045 * tb * Math.abs(Math.cos(p)))) * b : 0;
        const baseYaw = hasWalk ? -Math.sin(p) * 0.036 * b : 0;
        const baseRoll = hasWalk ? -bodyRoll * 0.35 : 0;

        const armPitch = basePitch * 0.5 + (pose ? pose.weaponPitch * ab : 0);
        const armYaw = baseYaw * 0.8 + (pose ? pose.weaponYaw * ab : 0);
        const armRoll = baseRoll * 0.5 + (pose ? pose.weaponRoll * ab : 0);
        const dx = (pose ? pose.weaponDx * ab : 0);
        const dy = bodyDy + (pose ? pose.weaponDy * ab : 0);
        const dz = (pose ? pose.weaponDz * ab : 0);

        FOC_THREE.Mat4.fromPivotEulerRollOffset(
            scratchA, -0.25, 1.92, -0.04, // Sağ omuz pivotu
            armPitch, armYaw, armRoll,
            dx, dy, dz
        );
        FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
        return outMat;
    }

    // 5. BİNİCİ ÜST GÖVDESİ (Mızrak, Ateşli Silahlar ve Genel Gövde)
    if (rig === 'riderUpper') {
        const riderGaitPitch = hasWalk ? (-bodyPitch * 0.55 - (0.03 + 0.045 * tb * Math.abs(Math.cos(p)))) * b : 0;
        const riderGaitYaw = hasWalk ? -Math.sin(p) * 0.036 * b : 0;
        const riderGaitRoll = hasWalk ? -bodyRoll * 0.35 : 0;

        // A) Mızrak Kolu ve Silah Parçaları (Ajan 1)
        const isLancePart = (archetype === 'cavalry_lance') &&
            ((part && part.subGroup === 'lance') || (totalParts > 0 && partIndex >= totalParts - 8));

        if (isLancePart && pose && ab > 1e-4) {
            const armPitch = riderGaitPitch * 0.5 + pose.weaponPitch * ab;
            const armYaw = riderGaitYaw * 0.8 + pose.weaponYaw * ab;
            const armRoll = (pose.weaponRoll * ab) + riderGaitRoll;
            const armDx = pose.weaponDx * ab;
            const armDy = bodyDy + (pose.torsoDy * 0.5 + pose.weaponDy) * ab;
            const armDz = pose.weaponDz * ab;

            FOC_THREE.Mat4.fromPivotEulerRollOffset(
                scratchA, -0.25, 1.92, -0.04, // Sağ omuz pivotu
                armPitch, armYaw, armRoll,
                armDx, armDy, armDz
            );
            FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
            return outMat;
        }

        // B) Ateşli Silahlar (Ajan 3) veya Gövde Yatışları (Ajan 1, 2, 3)
        const totalPitch = riderGaitPitch + (pose ? (pose.torsoPitch ?? pose.pitch ?? 0) * ab : 0);
        const totalYaw   = riderGaitYaw   + (pose ? (pose.torsoYaw   ?? pose.yaw   ?? 0) * ab : 0);
        const totalRoll  = riderGaitRoll  + (pose ? (pose.torsoRoll  ?? pose.roll  ?? 0) * ab : 0);
        const totalDx    = (pose ? (pose.dx ?? 0) * ab : 0);
        const totalDy    = bodyDy + (pose ? (pose.torsoDy ?? pose.dy ?? 0) * ab : 0);
        const totalDz    = (pose ? (pose.dz ?? 0) * ab : 0);

        FOC_THREE.Mat4.fromPivotEulerRollOffset(
            scratchA, 0, 1.48, -0.06, // Bel pivotu
            totalPitch, totalYaw, totalRoll,
            totalDx, totalDy, totalDz
        );
        FOC_THREE.Mat4.multiply(outMat, scratchA, part.localMat);
        return outMat;
    }

    outMat.set(part.localMat);
    return outMat;
}
```

### 5.3. `SoldierVisualRegistry` Metotlarının Birleştirilmesi

#### A. `sync(snapshot)`
Süvari savaş eylemi tetikleyicisi:
```javascript
const isInfantry = archetype.startsWith('infantry_');
const isCavalry = archetype.startsWith('cavalry_');
const canCombatAct = isInfantry || isCavalry;
```

#### B. `update(safeDt)`
Döngü süreleri haritası:
```javascript
if (rec.isCombatActing) {
    let cycleDuration = 1.55;
    if (rec.archetype === 'infantry_musketeer') cycleDuration = 2.6;
    else if (rec.archetype === 'infantry_pikeman') cycleDuration = 1.85;
    else if (rec.archetype === 'cavalry_lance') cycleDuration = 1.85;
    else if (rec.archetype === 'cavalry_sabre') cycleDuration = 1.50;
    else if (rec.archetype === 'cavalry_carbine') cycleDuration = 2.00;
    else if (rec.archetype === 'cavalry_pistol') cycleDuration = 1.75;

    const nextPhase = rec.actionPhase + safeDt / cycleDuration;
    if (rec.actionMode === 'attack' && nextPhase >= 1.0) {
        rec.actionPhase = 1.0;
        rec.isCombatActing = false;
        rec.combatFinished = true;
    } else {
        rec.actionPhase = nextPhase % 1.0;
    }
    if (rec.actionBlend < 1) {
        rec.actionBlend = Math.min(1, rec.actionBlend + safeDt * 8.0);
    }
    recordChanged = true;
    combatPosingCount++;
}
```

#### C. `setSoldierVisualCombatAction`
Desteklenen sınıf kontrolü:
```javascript
setSoldierVisualCombatAction(viewId, active, mode = 'attack', phaseOffset = 0) {
    const rec = this.records.get(viewId);
    if (!rec) return false;
    const isSupported = rec.archetype.startsWith('infantry_') || rec.archetype.startsWith('cavalry_');
    if (!isSupported) return false;
    rec.isCombatActing = Boolean(active);
    rec.actionMode = mode === 'guard' ? 'guard' : 'attack';
    rec.combatFinished = false;
    if (active && Number.isFinite(phaseOffset) && phaseOffset > 0) {
        rec.actionPhase = phaseOffset % 1;
    } else if (active) {
        rec.actionPhase = 0;
    }
    return true;
}
```

#### D. `evaluateSoldierPartMatrix`, `_updateBatchBuffersInPlace` ve `_rebuildInstanceBatches`
Tüm çağrı noktalarında standartlaştırılmış parametreler geçirilir:
```javascript
computeCavalryPartLocalMatrix(
    targetMat,
    part,
    rec.walkPhase,
    rec.walkBlend,
    rec.trotBlend,
    this._scratchA,
    this._scratchB,
    rec.actionPhase,
    rec.actionBlend,
    rec.actionMode,
    rec.archetype,
    partIndex,
    parts.length
);
```

---

## 6. TEST VE KALİTE GÜVENCE (QA) STRATEJİSİ

G3D-03D Büyük Entegrasyonunda:
1. **Önceki 37 Test Eksiksiz Korunmalıdır:** Piyade savaş pozları, kamera sınırları, GPU batching ve WebGL kaynak kurtarma testleri yeşil kalmalıdır.
2. **Süvari Testlerinin Konumu:**
   - Test 38: Atlı Mızrak Savaş Eylemi (Ajan 1 testi)
   - Test 39: Atlı Kılıç Savuruşu ve At Çakışmasızlığı (Ajan 2 testi)
   - Test 40: Atlı Karabina ve Tabanca Nişan, Geri Tepme ve Toparlanma (Ajan 3 testi)
   - VEYA Test 38 içinde her 4 silah tipini (`war_lance`, `cavalry_sabre`, `carbine`, `wheellock_pistol`) sırayla doğrulayan birleşik süvari dövüş testi.
3. **Doğrulama Eşiği:** 40 / 40 testin Chromium Headless ortamında sıfır hata (`Failures: 0`) ile geçtiği teyit edilmelidir.

---

## 7. SONUÇ VE TAVSİYE

Ajan 1, Ajan 2 ve Ajan 3 tarafından teslim edilen kodlar matematiksel ve görsel açıdan kusursuzdur; ancak entegrasyon safhasında parametre sıralaması ve fonksiyon isimlerinin yukarıdaki reçeteye harfiyen uyularak birleştirilmesi zorunludur.

Bu rapor, koordinatör ajana ve entegrasyon ekibine rehberlik etmek üzere eksiksiz olarak sunulmuştur.

**Rapor Sonu — Ajan 2 (CAVALRY_AUDIT)**
